package com.radiomaster.egogcs.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.ScrollView
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 商业航空级 60FPS 物理弹簧与连贯微交互动画引擎：
 * 支持三档全局动效风格 (0=灵动物理弹簧, 1=迅捷阻尼过渡, 2=极速低耗)，零阻塞触控响应。
 */
object AnimHelper {

    val EASE_OUT_EXPO = PathInterpolator(0.22f, 1f, 0.36f, 1f)
    val EASE_IN_OUT_CUBIC = PathInterpolator(0.65f, 0f, 0.35f, 1f)

    private var toastHideRunnable: Runnable? = null
    private var dockVisibleLogical: Boolean = false

    @Volatile var hapticsEnabled: Boolean = true
    @Volatile var animStyle: Int = 0

    private fun dur(baseMs: Long): Long = when (animStyle) {
        1 -> (baseMs * 0.68f).toLong().coerceAtLeast(80L)
        2 -> (baseMs * 0.35f).toLong().coerceAtLeast(45L)
        else -> baseMs
    }

    private fun springStiffness(base: Float): Float = when (animStyle) {
        1 -> base * 1.45f
        2 -> base * 2.4f
        else -> base
    }

    private fun springDamping(base: Float): Float = when (animStyle) {
        1 -> (base + 0.08f).coerceAtMost(0.96f)
        2 -> 0.98f
        else -> base
    }

    fun triggerHaptic(view: View, feedbackConstant: Int = HapticFeedbackConstants.KEYBOARD_TAP) {
        if (hapticsEnabled) {
            view.performHapticFeedback(feedbackConstant)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun attachSpringTouch(view: View) {
        val scaleXAnim = SpringAnimation(view, DynamicAnimation.SCALE_X, 1f).apply {
            spring = SpringForce(1f).apply {
                stiffness = SpringForce.STIFFNESS_MEDIUM
                dampingRatio = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY
            }
        }
        val scaleYAnim = SpringAnimation(view, DynamicAnimation.SCALE_Y, 1f).apply {
            spring = SpringForce(1f).apply {
                stiffness = SpringForce.STIFFNESS_MEDIUM
                dampingRatio = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY
            }
        }

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (hapticsEnabled) {
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    }
                    val pressScale = if (animStyle == 2) 0.96f else 0.92f
                    scaleXAnim.spring.stiffness = springStiffness(SpringForce.STIFFNESS_MEDIUM)
                    scaleYAnim.spring.stiffness = springStiffness(SpringForce.STIFFNESS_MEDIUM)
                    scaleXAnim.animateToFinalPosition(pressScale)
                    scaleYAnim.animateToFinalPosition(pressScale)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    scaleXAnim.animateToFinalPosition(1.0f)
                    scaleYAnim.animateToFinalPosition(1.0f)
                }
            }
            false
        }
    }

    /**
     * 物理弹簧抽屉开合 + 内部卡片错落级联入场动画
     */
    fun animateDrawer(
        drawer: View,
        rightEdgeViews: List<View>,
        centerShiftViews: List<View>,
        open: Boolean,
        drawerWidthPx: Float,
        activePanelForCascade: View? = null,
        density: Float = 2f
    ) {
        if (open) drawer.visibility = View.VISIBLE
        drawer.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        val finalTx = if (open) 0f else drawerWidthPx + 32f
        SpringAnimation(drawer, DynamicAnimation.TRANSLATION_X, finalTx).apply {
            spring = SpringForce(finalTx).apply {
                stiffness = springStiffness(410f)
                dampingRatio = springDamping(0.84f)
            }
            addEndListener { _, _, _, _ ->
                drawer.setLayerType(View.LAYER_TYPE_NONE, null)
                if (!open) drawer.visibility = View.INVISIBLE
            }
            start()
        }

        drawer.animate()
            .alpha(if (open) 1f else 0f)
            .setDuration(dur(195L))
            .setInterpolator(EASE_OUT_EXPO)
            .start()

        if (open && activePanelForCascade != null && animStyle != 2) {
            animateStaggeredChildren(activePanelForCascade, density)
        }

        for (rv in rightEdgeViews) {
            if (rv.tag == "HIDDEN_BY_PREF") {
                rv.visibility = View.GONE
                continue
            }
            rv.animate().cancel()
            if (open) {
                rv.animate()
                    .alpha(0f)
                    .translationX(18f)
                    .setDuration(dur(160L))
                    .withEndAction { rv.visibility = View.INVISIBLE }
                    .start()
            } else {
                rv.visibility = View.VISIBLE
                rv.animate()
                    .alpha(1f)
                    .translationX(0f)
                    .setDuration(dur(210L))
                    .setInterpolator(EASE_OUT_EXPO)
                    .start()
            }
        }

        val centerOffset = if (open) -(drawerWidthPx * 0.36f) else 0f
        for (cv in centerShiftViews) {
            SpringAnimation(cv, DynamicAnimation.TRANSLATION_X, centerOffset).apply {
                spring = SpringForce(centerOffset).apply {
                    stiffness = springStiffness(385f)
                    dampingRatio = springDamping(0.85f)
                }
                start()
            }
        }
    }

    /**
     * 右侧快捷浮窗锚点缩放弹簧展开与收起
     */
    fun animatePopover(popover: View, show: Boolean, density: Float) {
        popover.animate().cancel()
        popover.pivotX = popover.width.takeIf { it > 0 }?.toFloat() ?: (210f * density)
        popover.pivotY = 12f * density
        if (show) {
            popover.visibility = View.VISIBLE
            popover.alpha = 0f
            popover.scaleX = 0.88f
            popover.scaleY = 0.88f
            popover.translationX = 8f * density
            popover.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationX(0f)
                .setDuration(dur(195L))
                .setInterpolator(EASE_OUT_EXPO)
                .start()
        } else {
            popover.animate()
                .alpha(0f)
                .scaleX(0.92f)
                .scaleY(0.92f)
                .translationX(6f * density)
                .setDuration(dur(150L))
                .withEndAction { popover.visibility = View.GONE }
                .start()
        }
    }

    /**
     * 商业级全屏背景遮罩 + 居中系统设置中心弹簧浮现过渡动画
     */
    fun animateSettingsModal(scrimHost: View, dialogCard: View, show: Boolean, density: Float) {
        scrimHost.animate().cancel()
        dialogCard.animate().cancel()
        if (show) {
            scrimHost.visibility = View.VISIBLE
            scrimHost.alpha = 0f
            dialogCard.alpha = 0f
            dialogCard.scaleX = 0.92f
            dialogCard.scaleY = 0.92f
            dialogCard.translationY = 14f * density

            scrimHost.animate()
                .alpha(1f)
                .setDuration(dur(200L))
                .setInterpolator(EASE_OUT_EXPO)
                .start()

            dialogCard.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(dur(210L))
                .setInterpolator(EASE_OUT_EXPO)
                .start()

            SpringAnimation(dialogCard, DynamicAnimation.SCALE_X, 1f).apply {
                spring = SpringForce(1f).apply {
                    stiffness = springStiffness(440f)
                    dampingRatio = springDamping(0.80f)
                }
                start()
            }
            SpringAnimation(dialogCard, DynamicAnimation.SCALE_Y, 1f).apply {
                spring = SpringForce(1f).apply {
                    stiffness = springStiffness(440f)
                    dampingRatio = springDamping(0.80f)
                }
                start()
            }
        } else {
            scrimHost.animate()
                .alpha(0f)
                .setDuration(dur(165L))
                .withEndAction { scrimHost.visibility = View.GONE }
                .start()

            dialogCard.animate()
                .alpha(0f)
                .scaleX(0.94f)
                .scaleY(0.94f)
                .translationY(10f * density)
                .setDuration(dur(155L))
                .start()
        }
    }

    /**
     * 顶栏设置齿轮开合物理旋转反馈
     */
    fun animateGearRotation(gearView: View, open: Boolean) {
        val targetDeg = if (open) 75f else 0f
        SpringAnimation(gearView, DynamicAnimation.ROTATION, targetDeg).apply {
            spring = SpringForce(targetDeg).apply {
                stiffness = springStiffness(360f)
                dampingRatio = springDamping(0.74f)
            }
            start()
        }
    }

    /**
     * 底部中央智能指令坞弹簧升降与内容更新微脉冲
     */
    fun animateCommandDock(dock: View, show: Boolean, density: Float, pulseOnUpdate: Boolean = false) {
        if (show) {
            if (!dockVisibleLogical || dock.visibility != View.VISIBLE) {
                dockVisibleLogical = true
                dock.animate().cancel()
                dock.visibility = View.VISIBLE
                dock.alpha = 0f
                dock.translationY = 18f * density
                dock.scaleX = 0.95f
                dock.scaleY = 0.95f
                dock.animate()
                    .alpha(1f)
                    .setDuration(dur(175L))
                    .setInterpolator(EASE_OUT_EXPO)
                    .start()
                SpringAnimation(dock, DynamicAnimation.TRANSLATION_Y, 0f).apply {
                    spring = SpringForce(0f).apply {
                        stiffness = springStiffness(450f)
                        dampingRatio = springDamping(0.80f)
                    }
                    start()
                }
                SpringAnimation(dock, DynamicAnimation.SCALE_X, 1f).apply {
                    spring = SpringForce(1f).apply {
                        stiffness = springStiffness(460f)
                        dampingRatio = springDamping(0.78f)
                    }
                    start()
                }
                SpringAnimation(dock, DynamicAnimation.SCALE_Y, 1f).apply {
                    spring = SpringForce(1f).apply {
                        stiffness = springStiffness(460f)
                        dampingRatio = springDamping(0.78f)
                    }
                    start()
                }
            } else if (pulseOnUpdate && animStyle != 2) {
                pulseViewSubtle(dock)
            }
        } else if (dockVisibleLogical || dock.visibility == View.VISIBLE) {
            dockVisibleLogical = false
            dock.animate().cancel()
            dock.animate()
                .alpha(0f)
                .translationY(14f * density)
                .scaleX(0.96f)
                .scaleY(0.96f)
                .setDuration(dur(150L))
                .withEndAction {
                    if (!dockVisibleLogical) {
                        dock.visibility = View.GONE
                        dock.translationY = 0f
                        dock.scaleX = 1f
                        dock.scaleY = 1f
                    }
                }
                .start()
        }
    }

    fun pulseViewSubtle(view: View) {
        if (animStyle == 2) return
        view.scaleX = 0.975f
        view.scaleY = 0.975f
        SpringAnimation(view, DynamicAnimation.SCALE_X, 1f).apply {
            spring = SpringForce(1f).apply {
                stiffness = 580f
                dampingRatio = 0.72f
            }
            start()
        }
        SpringAnimation(view, DynamicAnimation.SCALE_Y, 1f).apply {
            spring = SpringForce(1f).apply {
                stiffness = 580f
                dampingRatio = 0.72f
            }
            start()
        }
    }

    /**
     * 标签页滑块物理弹簧滑动 + 页面卡片错落级联浮现
     */
    fun animateTabSwitch(glider: View, tabIndex: Int, tabWidthPx: Float, panels: List<View>, density: Float) {
        val targetX = tabIndex * tabWidthPx
        SpringAnimation(glider, DynamicAnimation.TRANSLATION_X, targetX).apply {
            spring = SpringForce(targetX).apply {
                stiffness = springStiffness(480f)
                dampingRatio = springDamping(0.80f)
            }
            start()
        }

        for (i in panels.indices) {
            val p = panels[i]
            if (i == tabIndex) {
                p.visibility = View.VISIBLE
                p.alpha = 0f
                p.translationY = 7f * density
                p.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(dur(195L))
                    .setInterpolator(EASE_OUT_EXPO)
                    .start()
                if (animStyle != 2) {
                    animateStaggeredChildren(p, density)
                }
            } else {
                p.visibility = View.GONE
            }
        }
    }

    /**
     * 对 ScrollView 或 LinearLayout 内的前 6 张可见卡片执行错峰微距浮现，快速连点自动无损取消
     */
    fun animateStaggeredChildren(pageRoot: View, density: Float) {
        if (animStyle == 2) return
        val container: ViewGroup = when (pageRoot) {
            is ScrollView -> (pageRoot.getChildAt(0) as? ViewGroup) ?: return
            is ViewGroup -> pageRoot
            else -> return
        }
        val count = min(container.childCount, 6)
        var visibleIdx = 0
        for (i in 0 until count) {
            val child = container.getChildAt(i)
            if (child.visibility != View.VISIBLE) continue
            child.animate().cancel()
            child.alpha = 0.0f
            child.translationY = 9f * density
            child.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(visibleIdx * 20L)
                .setDuration(dur(205L))
                .setInterpolator(EASE_OUT_EXPO)
                .start()
            visibleIdx++
        }
    }

    /**
     * 主题实时切换时的柔和亮度过渡动画
     */
    fun animateThemeCrossfade(views: List<View>) {
        if (animStyle == 2) return
        for (v in views) {
            if (v.visibility != View.VISIBLE) continue
            v.animate().cancel()
            v.alpha = 0.82f
            v.animate()
                .alpha(1f)
                .setDuration(dur(240L))
                .setInterpolator(EASE_OUT_EXPO)
                .start()
        }
    }

    /**
     * 顶部电量进度条宽度平滑插值过渡
     */
    fun animateBarWidthSmooth(barView: View, targetWidthPx: Int) {
        val curW = barView.layoutParams.width
        if (kotlin.math.abs(curW - targetWidthPx) <= 2) return
        if (animStyle == 2 || curW <= 0) {
            barView.layoutParams.width = targetWidthPx
            barView.requestLayout()
            return
        }
        ValueAnimator.ofInt(curW, targetWidthPx).apply {
            duration = dur(220L)
            interpolator = EASE_OUT_EXPO
            addUpdateListener { a ->
                barView.layoutParams.width = a.animatedValue as Int
                barView.requestLayout()
            }
            start()
        }
    }

    fun showDjiToast(banner: TextView, msg: String, density: Float) {
        banner.text = msg
        banner.visibility = View.VISIBLE
        toastHideRunnable?.let { banner.removeCallbacks(it) }

        banner.animate().cancel()
        banner.translationY = -12f * density
        banner.scaleX = 0.94f
        banner.scaleY = 0.94f
        banner.alpha = 0f
        banner.animate()
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(dur(205L))
            .setInterpolator(EASE_OUT_EXPO)
            .start()

        val hideTask = Runnable {
            banner.animate()
                .translationY(-9f * density)
                .scaleX(0.96f)
                .scaleY(0.96f)
                .alpha(0f)
                .setDuration(dur(185L))
                .withEndAction { banner.visibility = View.INVISIBLE }
                .start()
        }
        toastHideRunnable = hideTask
        banner.postDelayed(hideTask, 2350L)
    }
}
