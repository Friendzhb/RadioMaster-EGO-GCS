package com.radiomaster.egogcs.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.TopicConfig
import com.radiomaster.egogcs.ui.GcsIcons.Type
import com.radiomaster.egogcs.ui.GcsTheme.Role
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 商业航空级系统设置与主题/功能编排中心 (6大分类导航 + 实时无损换肤 + 物理级联入场动画 · 零表情符号)：
 * 0. 主题动效：深空航电黑 / 户外强光白 / 战术夜视绿 / 工业琥珀金四套主题卡片、三档界面物理动效风格与三维相机运镜阻尼；
 * 1. 功能编排：座舱工作台一键预设、顶栏快捷胶囊前后排序与显隐、全屏 HUD 模块独立开关；
 * 2. 飞控安全：长按快捷直飞、返航双击确认、触觉震动、高度步幅、近障与低电量变色告警阈值、重设返航点 H；
 * 3. 三维显示：视线遮挡透视、地面坐标网格、轨迹高程垂幕、历史航迹、点云配色与 FAST-LIO 建图精度；
 * 4. 通信链路：自动寻机连接、ELRS Backpack MAVLink 监听、首选协议与机载算法栈话题模板；
 * 5. 系统维护：AX12 实时运行指标、导出 PCD 点云、复制全局配置 JSON、清空建图与恢复出厂默认设置。
 */
class GcsSettingsModal(
    private val context: Context,
    private val hub: GcsSharedHub,
    private val getCurrentTopicConfig: () -> TopicConfig,
    private val onThemeChanged: (animate: Boolean) -> Unit,
    private val onHudOrchestrationChanged: () -> Unit,
    private val onVisualSettingsChanged: () -> Unit,
    private val onApplyTopicPreset: (String) -> Unit,
    private val onProtocolChanged: (String) -> Unit,
    private val onJumpToConnDrawer: () -> Unit,
    private val onSetHomeHere: () -> Unit,
    private val onExportPcd: () -> Unit,
    private val onClearMapAndTrail: () -> Unit,
    private val onFactoryResetApplied: () -> Unit,
    private val onShowToast: (String) -> Unit
) {

    interface ToggleSyncHandle {
        fun syncFromState(newVal: Boolean)
        fun refreshThemeColors()
    }

    private data class WorkspacePresetSpec(
        val icon: Type,
        val title: String,
        val applyAction: () -> Unit
    )

    data class SliderHandle(
        val seekBar: SeekBar,
        val valueTv: TextView,
        val minI: Int,
        val scale: Float,
        val fmt: String
    ) {
        fun syncValue(realVal: Float) {
            val p = ((realVal / scale).roundToInt() - minI).coerceIn(0, seekBar.max)
            if (seekBar.progress != p) seekBar.progress = p
            valueTv.text = String.format(Locale.US, fmt, (minI + p) * scale)
        }
    }

    private val d = context.resources.displayMetrics.density
    private val uiHandler = Handler(Looper.getMainLooper())

    lateinit var scrimRoot: FrameLayout
        private set
    private lateinit var dialogCard: LinearLayout
    private lateinit var btnCloseHeader: ImageView

    var isOpen: Boolean = false
        private set
    private var activeCategory: Int = 0

    private val catNavItems = mutableListOf<LinearLayout>()
    private val catNavLabels = mutableListOf<TextView>()
    private val catNavBars = mutableListOf<View>()
    private val catPages = mutableListOf<View>()
    private val allToggleHandles = mutableListOf<ToggleSyncHandle>()
    private val allActionBtns = mutableListOf<TextView>()

    // Category 0: 主题动效组件
    private val themeCards = mutableListOf<LinearLayout>()
    private val themeCardTitles = mutableListOf<TextView>()
    private val themeCardSubs = mutableListOf<TextView>()
    private val themeCardChecks = mutableListOf<TextView>()
    private val animStyleSegBtns = mutableListOf<TextView>()
    private lateinit var slCamDamping: SliderHandle

    // Category 1: 功能编排组件
    private lateinit var quickOrderListBox: LinearLayout
    private val presetModeBtns = mutableListOf<TextView>()
    private var activeWorkspacePreset = -1

    private lateinit var swHudCompass: ToggleSyncHandle
    private lateinit var swHudHsi: ToggleSyncHandle
    private lateinit var swHudTelemetry: ToggleSyncHandle
    private lateinit var swHudAttitude: ToggleSyncHandle
    private lateinit var swHudCamStack: ToggleSyncHandle
    private lateinit var swHudDemoTools: ToggleSyncHandle

    // Category 2: 飞控安全组件
    private lateinit var swLongPressFly: ToggleSyncHandle
    private lateinit var swRthConfirm: ToggleSyncHandle
    private lateinit var swHaptics: ToggleSyncHandle
    private lateinit var swAutoCloseDrawer: ToggleSyncHandle
    private val altStepBtns = mutableListOf<TextView>()
    private lateinit var slWarnClearance: SliderHandle
    private lateinit var slLowBatWarn: SliderHandle

    // Category 3: 三维显示组件
    private lateinit var swXray: ToggleSyncHandle
    private lateinit var swInflateLayer: ToggleSyncHandle
    private lateinit var swCloudLayer: ToggleSyncHandle
    private lateinit var swGridLayer: ToggleSyncHandle
    private lateinit var swCurtainLayer: ToggleSyncHandle
    private lateinit var swTrailLayer: ToggleSyncHandle
    private val colorSchemeBtns = mutableListOf<TextView>()
    private lateinit var slVoxelSize: SliderHandle
    private lateinit var slZSlice: SliderHandle
    private lateinit var slPointScale: SliderHandle

    // Category 4: 通信链路组件
    private lateinit var swAutoConn: ToggleSyncHandle
    private lateinit var swMavlinkUdp: ToggleSyncHandle
    private val protoPrefBtns = mutableListOf<TextView>()
    private lateinit var tvTopicSummaryBox: TextView

    // Category 5: 系统维护与渲染性能组件
    private val perfModeSegBtns = mutableListOf<TextView>()
    private lateinit var tvSysDiagSummary: TextView
    private lateinit var btnResetFactory: TextView
    private var factoryResetConfirmPending = false
    private val cancelFactoryConfirmRunnable = Runnable {
        factoryResetConfirmPending = false
        if (::btnResetFactory.isInitialized) {
            GcsIcons.bind(btnResetFactory, Type.UNDO, "恢复全部出厂默认设置", d, iconDp = 12f)
            btnResetFactory.background = pillBg(Color.argb(46, 255, 59, 48), Color.parseColor("#FF3B30"), radiusDp = 7f)
        }
    }

    companion object {
        const val PREFS_NAME = "ego_native_prefs"
        const val CAT_THEME_ANIM = 0
        const val CAT_ORCHESTRATE = 1
        const val CAT_SAFETY = 2
        const val CAT_VISUAL_3D = 3
        const val CAT_COMMS = 4
        const val CAT_SYSTEM = 5

        private val ALL_QUICK_SLOTS = listOf("mission", "topics", "pcd", "recenter")

        fun loadPersistedSettings(context: Context, hub: GcsSharedHub) {
            val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            hub.themeId = sp.getInt("themeId", GcsTheme.THEME_AERO_CARBON).coerceIn(0, 3)
            hub.perfMode = sp.getInt("perfMode", 0).coerceIn(0, 2)
            hub.animStyle = sp.getInt("animStyle", 0).coerceIn(0, 2)
            AnimHelper.animStyle = hub.animStyle
            hub.cameraDampingScale = sp.getFloat("cameraDampingScale", 1.0f).coerceIn(0.5f, 2.0f)

            hub.autoConnectDiscovered = sp.getBoolean("autoConnectDiscovered", true)
            hub.mavlinkBackpackEnabled = sp.getBoolean("mavlinkBackpackEnabled", true)
            hub.xrayOcclusionEnabled = sp.getBoolean("xrayOcclusionEnabled", true)

            hub.showFastLioMap = sp.getBoolean("showFastLioMap", true)
            hub.showInflate = sp.getBoolean("showInflate", true)
            hub.showLocalBox = sp.getBoolean("showLocalBox", true)
            hub.showCtrlPts = sp.getBoolean("showCtrlPts", true)
            hub.showGroundGrid = sp.getBoolean("showGroundGrid", true)
            hub.showTrajCurtain = sp.getBoolean("showTrajCurtain", true)
            hub.showFlightTrail = sp.getBoolean("showFlightTrail", true)
            hub.pointColorMode = sp.getInt("pointColorMode", 0).coerceIn(0, 2)
            hub.mapVoxelSize = sp.getFloat("mapVoxelSize", 0.12f).coerceIn(0.06f, 0.30f)
            hub.zSliceMax = sp.getFloat("zSliceMax", 3.0f).coerceIn(0.6f, 6.0f)
            hub.pointSizeScale = sp.getFloat("pointSizeScale", 1.0f).coerceIn(0.6f, 2.0f)

            hub.longPressQuickFlyEnabled = sp.getBoolean("longPressQuickFlyEnabled", true)
            hub.rthDoubleConfirm = sp.getBoolean("rthDoubleConfirm", true)
            hub.hapticFeedbackEnabled = sp.getBoolean("hapticFeedbackEnabled", true)
            AnimHelper.hapticsEnabled = hub.hapticFeedbackEnabled
            hub.autoCloseDrawerOnConnect = sp.getBoolean("autoCloseDrawerOnConnect", true)
            hub.altStepMeters = sp.getFloat("altStepMeters", 0.2f).coerceIn(0.1f, 0.5f)
            hub.warnClearanceMeters = sp.getFloat("warnClearanceMeters", 0.65f).coerceIn(0.35f, 1.80f)
            hub.lowBatWarnPct = sp.getInt("lowBatWarnPct", 25).coerceIn(15, 45)

            hub.hudShowCompass = sp.getBoolean("hudShowCompass", true)
            hub.hudShowHsiRadar = sp.getBoolean("hudShowHsiRadar", true)
            hub.hudShowTelemetryBox = sp.getBoolean("hudShowTelemetryBox", true)
            hub.hudShowAttitudeWidget = sp.getBoolean("hudShowAttitudeWidget", true)
            hub.hudShowRightCamStack = sp.getBoolean("hudShowRightCamStack", true)
            hub.hudShowDemoTools = sp.getBoolean("hudShowDemoTools", true)

            hub.quickSlotOrderCsv = normalizeSlotOrder(sp.getString("quickSlotOrderCsv", "mission,topics,pcd,recenter") ?: "mission,topics,pcd,recenter")
            hub.quickShowMission = sp.getBoolean("quickShowMission", true)
            hub.quickShowTopics = sp.getBoolean("quickShowTopics", true)
            hub.quickShowPcd = sp.getBoolean("quickShowPcd", false)
            hub.quickShowRecenter = sp.getBoolean("quickShowRecenter", false)

            hub.routeLoopMode = sp.getInt("routeLoopMode", 0).coerceIn(0, 2)
            hub.routeFinishAction = sp.getInt("routeFinishAction", 0).coerceIn(0, 1)
        }

        fun persistAllSettings(context: Context, hub: GcsSharedHub) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putInt("themeId", hub.themeId)
                .putInt("perfMode", hub.perfMode)
                .putInt("animStyle", hub.animStyle)
                .putFloat("cameraDampingScale", hub.cameraDampingScale)
                .putBoolean("autoConnectDiscovered", hub.autoConnectDiscovered)
                .putBoolean("mavlinkBackpackEnabled", hub.mavlinkBackpackEnabled)
                .putBoolean("xrayOcclusionEnabled", hub.xrayOcclusionEnabled)
                .putBoolean("showFastLioMap", hub.showFastLioMap)
                .putBoolean("showInflate", hub.showInflate)
                .putBoolean("showLocalBox", hub.showLocalBox)
                .putBoolean("showCtrlPts", hub.showCtrlPts)
                .putBoolean("showGroundGrid", hub.showGroundGrid)
                .putBoolean("showTrajCurtain", hub.showTrajCurtain)
                .putBoolean("showFlightTrail", hub.showFlightTrail)
                .putInt("pointColorMode", hub.pointColorMode)
                .putFloat("mapVoxelSize", hub.mapVoxelSize)
                .putFloat("zSliceMax", hub.zSliceMax)
                .putFloat("pointSizeScale", hub.pointSizeScale)
                .putBoolean("longPressQuickFlyEnabled", hub.longPressQuickFlyEnabled)
                .putBoolean("rthDoubleConfirm", hub.rthDoubleConfirm)
                .putBoolean("hapticFeedbackEnabled", hub.hapticFeedbackEnabled)
                .putBoolean("autoCloseDrawerOnConnect", hub.autoCloseDrawerOnConnect)
                .putFloat("altStepMeters", hub.altStepMeters)
                .putFloat("warnClearanceMeters", hub.warnClearanceMeters)
                .putInt("lowBatWarnPct", hub.lowBatWarnPct)
                .putBoolean("hudShowCompass", hub.hudShowCompass)
                .putBoolean("hudShowHsiRadar", hub.hudShowHsiRadar)
                .putBoolean("hudShowTelemetryBox", hub.hudShowTelemetryBox)
                .putBoolean("hudShowAttitudeWidget", hub.hudShowAttitudeWidget)
                .putBoolean("hudShowRightCamStack", hub.hudShowRightCamStack)
                .putBoolean("hudShowDemoTools", hub.hudShowDemoTools)
                .putString("quickSlotOrderCsv", hub.quickSlotOrderCsv)
                .putBoolean("quickShowMission", hub.quickShowMission)
                .putBoolean("quickShowTopics", hub.quickShowTopics)
                .putBoolean("quickShowPcd", hub.quickShowPcd)
                .putBoolean("quickShowRecenter", hub.quickShowRecenter)
                .putInt("routeLoopMode", hub.routeLoopMode)
                .putInt("routeFinishAction", hub.routeFinishAction)
                .apply()
        }

        fun normalizeSlotOrder(csv: String): String {
            val parsed = csv.split(",")
                .map { it.trim() }
                .filter { it in ALL_QUICK_SLOTS }
                .distinct()
                .toMutableList()
            for (s in ALL_QUICK_SLOTS) {
                if (s !in parsed) parsed.add(s)
            }
            return parsed.joinToString(",")
        }
    }

    fun buildModalView(): View {
        val dm = context.resources.displayMetrics
        val modalW = min((dm.widthPixels * 0.86f).roundToInt(), dp(772f))
        val modalH = min((dm.heightPixels * 0.86f).roundToInt(), dp(492f))

        allToggleHandles.clear()
        allActionBtns.clear()

        scrimRoot = FrameLayout(context).apply {
            setBackgroundColor(GcsTheme.of(hub.themeId).modalScrim)
            visibility = View.GONE
            isClickable = true
            isFocusable = true
            setOnClickListener { setVisible(false) }
        }

        dialogCard = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            GcsTheme.markRole(this, Role.MODAL_CARD, cornerDp = 12f)
            isClickable = true
            setOnClickListener { }
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14f), dp(8f), dp(10f), dp(8f))
            GcsTheme.markRole(this, Role.MODAL_HEADER)
        }
        val titleTv = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
            GcsIcons.bind(this, Type.SETTINGS_GEAR, "系统设置 · 主题与功能编排中心", d, iconDp = 14f, gapDp = 5.5f)
        }
        val subHintTv = TextView(context).apply {
            text = "修改实时生效并自动持久化"
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
            setPadding(dp(10f), 0, dp(10f), 0)
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        }
        btnCloseHeader = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                setVisible(false)
            }
        }
        AnimHelper.attachSpringTouch(btnCloseHeader)

        header.addView(titleTv)
        header.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(subHintTv)
        header.addView(btnCloseHeader, LinearLayout.LayoutParams(dp(30f), dp(28f)))
        dialogCard.addView(header, LinearLayout.LayoutParams(MATCH_PARENT, dp(41f)))

        dialogCard.addView(View(context).apply {
            GcsTheme.markRole(this, Role.DIVIDER)
        }, LinearLayout.LayoutParams(MATCH_PARENT, 1))

        val bodyRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val leftNav = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8f), dp(9f), dp(8f), dp(9f))
            GcsTheme.markRole(this, Role.MODAL_LEFT_NAV)
        }

        val categories = listOf(
            Type.PALETTE_THEME to "主题动效",
            Type.LAYOUT_GRID to "功能编排",
            Type.SHIELD_SAFE to "飞控安全",
            Type.CUBE_3D to "三维显示",
            Type.LINK to "通信链路",
            Type.SYSTEM_CHIP to "系统维护"
        )

        catNavItems.clear()
        catNavLabels.clear()
        catNavBars.clear()

        for (i in categories.indices) {
            val (ic, name) = categories[i]
            val itemRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8f), dp(7.8f), dp(10f), dp(7.8f))
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    switchCategory(i)
                }
            }
            val bar = View(context)
            val lbl = TextView(context).apply {
                isSingleLine = true
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
                typeface = Typeface.DEFAULT_BOLD
                GcsIcons.bind(this, ic, name, d, iconDp = 13f, gapDp = 6f)
            }
            itemRow.addView(bar, LinearLayout.LayoutParams(dp(3f), dp(15f)).apply { rightMargin = dp(7f) })
            itemRow.addView(lbl)

            catNavItems.add(itemRow)
            catNavBars.add(bar)
            catNavLabels.add(lbl)
            leftNav.addView(itemRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                if (i > 0) topMargin = dp(3.5f)
            })
        }

        bodyRow.addView(leftNav, LinearLayout.LayoutParams(dp(146f), MATCH_PARENT))
        bodyRow.addView(View(context).apply {
            GcsTheme.markRole(this, Role.DIVIDER)
        }, LinearLayout.LayoutParams(1, MATCH_PARENT))

        val rightHost = FrameLayout(context)
        catPages.clear()
        val pThemeAnim = buildCategoryThemeAndAnim()
        val pOrchestrate = buildCategoryOrchestration()
        val pSafety = buildCategoryFlightSafety()
        val pVisual = buildCategoryVisual3D()
        val pComms = buildCategoryCommsLink()
        val pSystem = buildCategorySystemMaint()

        catPages.addAll(listOf(pThemeAnim, pOrchestrate, pSafety, pVisual, pComms, pSystem))
        for (idx in catPages.indices) {
            catPages[idx].visibility = if (idx == 0) View.VISIBLE else View.GONE
            rightHost.addView(catPages[idx], FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }

        bodyRow.addView(rightHost, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        dialogCard.addView(bodyRow, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        scrimRoot.addView(dialogCard, FrameLayout.LayoutParams(modalW, modalH, Gravity.CENTER))
        applyModalThemeColors()
        switchCategory(0, animate = false)
        return scrimRoot
    }

    fun applyModalThemeColors() {
        if (!::scrimRoot.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        scrimRoot.setBackgroundColor(pal.modalScrim)
        GcsTheme.applyTree(dialogCard, pal, d)

        btnCloseHeader.setImageDrawable(GcsIcons.drawable(Type.CLOSE_X, dp(14.5f), pal.textPrimary))
        btnCloseHeader.background = roundedColor(pal.cardFill, dp(6f))

        for (ab in allActionBtns) {
            ab.setTextColor(pal.textPrimary)
            ab.background = pillBg(pal.cardFill, pal.cardStroke, radiusDp = 7f)
            ab.invalidate()
        }
        for (th in allToggleHandles) {
            th.refreshThemeColors()
        }

        syncCategoryNavVisuals()
        syncThemeCardsVisual()
        syncAnimStyleButtons()
        renderQuickSlotOrchestratorRows()
        syncWorkspacePresetButtons()
        syncAltStepSegButtons()
        syncColorSchemeButtons()
        syncProtoPrefButtons()
        syncPerfModeButtons()
    }

    fun setVisible(show: Boolean, jumpCategory: Int? = null) {
        if (jumpCategory != null && jumpCategory in catPages.indices) {
            switchCategory(jumpCategory, animate = false)
        }
        if (show) {
            syncAllControlsFromHub()
        } else {
            uiHandler.removeCallbacks(cancelFactoryConfirmRunnable)
            cancelFactoryConfirmRunnable.run()
        }
        if (isOpen == show) return
        isOpen = show
        AnimHelper.animateSettingsModal(scrimRoot, dialogCard, show, d)
        if (show && activeCategory in catPages.indices) {
            AnimHelper.animateStaggeredChildren(catPages[activeCategory], d)
        }
    }

    fun syncAllControlsFromHub() {
        if (!::scrimRoot.isInitialized) return
        syncThemeCardsVisual()
        syncAnimStyleButtons()
        slCamDamping.syncValue(hub.cameraDampingScale)

        renderQuickSlotOrchestratorRows()
        syncWorkspacePresetButtons()

        swHudCompass.syncFromState(hub.hudShowCompass)
        swHudHsi.syncFromState(hub.hudShowHsiRadar)
        swHudTelemetry.syncFromState(hub.hudShowTelemetryBox)
        swHudAttitude.syncFromState(hub.hudShowAttitudeWidget)
        swHudCamStack.syncFromState(hub.hudShowRightCamStack)
        swHudDemoTools.syncFromState(hub.hudShowDemoTools)

        swLongPressFly.syncFromState(hub.longPressQuickFlyEnabled)
        swRthConfirm.syncFromState(hub.rthDoubleConfirm)
        swHaptics.syncFromState(hub.hapticFeedbackEnabled)
        swAutoCloseDrawer.syncFromState(hub.autoCloseDrawerOnConnect)
        syncAltStepSegButtons()
        slWarnClearance.syncValue(hub.warnClearanceMeters)
        slLowBatWarn.syncValue(hub.lowBatWarnPct.toFloat())

        swXray.syncFromState(hub.xrayOcclusionEnabled)
        swInflateLayer.syncFromState(hub.showInflate)
        swCloudLayer.syncFromState(hub.showFastLioMap)
        swGridLayer.syncFromState(hub.showGroundGrid)
        swCurtainLayer.syncFromState(hub.showTrajCurtain)
        swTrailLayer.syncFromState(hub.showFlightTrail)
        syncColorSchemeButtons()
        slVoxelSize.syncValue(hub.mapVoxelSize)
        slZSlice.syncValue(hub.zSliceMax)
        slPointScale.syncValue(hub.pointSizeScale)

        swAutoConn.syncFromState(hub.autoConnectDiscovered)
        swMavlinkUdp.syncFromState(hub.mavlinkBackpackEnabled)
        syncProtoPrefButtons()
        syncPerfModeButtons()
        refreshTopicSummaryBox()
        refreshSystemDiagnostics()
    }

    private fun syncCategoryNavVisuals() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in catNavItems.indices) {
            val sel = (i == activeCategory)
            catNavBars[i].visibility = if (sel) View.VISIBLE else View.INVISIBLE
            catNavBars[i].background = roundedColor(pal.accent, dp(2f))
            catNavLabels[i].setTextColor(if (sel) pal.textPrimary else pal.textMuted)
            catNavLabels[i].invalidate()
            catNavItems[i].background = if (sel) {
                pillBg(pal.accentSoftFill, pal.accentStroke, radiusDp = 8f)
            } else {
                roundedColor(Color.TRANSPARENT, dp(8f))
            }
        }
    }

    private fun switchCategory(idx: Int, animate: Boolean = true) {
        activeCategory = idx
        syncCategoryNavVisuals()
        for (i in catPages.indices) {
            val page = catPages[i]
            if (i == idx) {
                page.visibility = View.VISIBLE
                if (animate) {
                    page.alpha = 0f
                    page.translationY = dp(6f).toFloat()
                    page.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(180L)
                        .setInterpolator(AnimHelper.EASE_OUT_EXPO)
                        .start()
                    AnimHelper.animateStaggeredChildren(page, d)
                } else {
                    page.alpha = 1f
                    page.translationY = 0f
                }
            } else {
                page.visibility = View.GONE
            }
        }
        if (idx == CAT_COMMS) refreshTopicSummaryBox()
        if (idx == CAT_SYSTEM) refreshSystemDiagnostics()
    }

    // ==================== Category 0: 商业座舱主题与物理动效引擎 ====================

    private fun buildCategoryThemeAndAnim(): View {
        val sv = ScrollView(context)
        val col = pageColumn()

        val themeGroup = groupCard(
            "商业航空全栈视觉主题 (2D 玻璃面板 + HSI 仪表 + 3D 天际大气实时联动)",
            "专为不同光照环境打造：户外烈日下推荐开启「户外强光白」，夜间暗场巡检推荐「战术夜视绿」"
        )

        themeCards.clear()
        themeCardTitles.clear()
        themeCardSubs.clear()
        themeCardChecks.clear()

        val iconsForThemes = arrayOf(Type.MOON_NIGHT, Type.SUN_DAYLIGHT, Type.RADAR_SIGNAL, Type.SHIELD_SAFE)

        for (rowIdx in 0..1) {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            for (colIdx in 0..1) {
                val tid = rowIdx * 2 + colIdx
                val palSpec = GcsTheme.PALETTES[tid]
                val card = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10f), dp(8.5f), dp(10f), dp(8.5f))
                    setOnClickListener {
                        if (hub.themeId != tid) {
                            AnimHelper.triggerHaptic(it)
                            hub.themeId = tid
                            persistAllSettings(context, hub)
                            onThemeChanged(true)
                        }
                    }
                }
                AnimHelper.attachSpringTouch(card)

                val topLine = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val swatchDot = View(context).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(palSpec.swatchColor)
                        setStroke(maxOf(1, dp(1f)), Color.argb(130, 255, 255, 255))
                    }
                }
                val titleTv = TextView(context).apply {
                    isSingleLine = true
                    setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
                    typeface = Typeface.DEFAULT_BOLD
                    GcsIcons.bind(this, iconsForThemes[tid], palSpec.name, d, iconDp = 12.5f, gapDp = 4.5f)
                }
                val checkTv = TextView(context).apply {
                    isSingleLine = true
                    setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
                    typeface = Typeface.DEFAULT_BOLD
                    GcsIcons.bind(this, Type.CHECK, "当前", d, iconDp = 10.5f, gapDp = 2.5f)
                }

                topLine.addView(swatchDot, LinearLayout.LayoutParams(dp(10f), dp(10f)).apply { rightMargin = dp(6f) })
                topLine.addView(titleTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
                topLine.addView(checkTv)

                val subTv = TextView(context).apply {
                    text = palSpec.subtitle
                    setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.2f)
                    setPadding(0, dp(3f), 0, 0)
                }

                card.addView(topLine)
                card.addView(subTv)

                themeCards.add(card)
                themeCardTitles.add(titleTv)
                themeCardSubs.add(subTv)
                themeCardChecks.add(checkTv)

                row.addView(card, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                    if (colIdx > 0) leftMargin = dp(7f)
                })
            }
            themeGroup.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                if (rowIdx > 0) topMargin = dp(7f)
            })
        }
        col.addView(themeGroup)

        val animCard = groupCard(
            "物理弹簧动画与三维相机运镜阻尼",
            "调节抽屉滑块、弹窗卡片级联入场、选点指令坞升降弹簧及三维相机跟随柔顺度"
        )
        val styleLbl = TextView(context).apply {
            text = "界面交互动效风格"
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(5f))
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
        }
        animCard.addView(styleLbl)

        val animSeg = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2.5f), dp(2.5f), dp(2.5f), dp(2.5f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val animOptions = listOf(
            Type.SPARK_MOTION to "灵动物理弹簧",
            Type.SEND_FLY to "迅捷跟手阻尼",
            Type.GAUGE_HIGH to "极速零延迟"
        )
        animStyleSegBtns.clear()
        for (i in animOptions.indices) {
            val (ic, name) = animOptions[i]
            val b = TextView(context).apply {
                gravity = Gravity.CENTER
                isSingleLine = true
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
                typeface = Typeface.DEFAULT_BOLD
                GcsIcons.bind(this, ic, name, d, iconDp = 11.5f, gapDp = 3.5f)
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hub.animStyle = i
                    AnimHelper.animStyle = i
                    persistAllSettings(context, hub)
                    syncAnimStyleButtons()
                    AnimHelper.pulseViewSubtle(dialogCard)
                    onShowToast("已切换动效引擎为：$name")
                }
            }
            animStyleSegBtns.add(b)
            animSeg.addView(b, LinearLayout.LayoutParams(0, dp(29f), 1f))
        }
        animCard.addView(animSeg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8f) })

        slCamDamping = addSliderRow(
            animCard,
            "三维相机旋转与聚焦响应倍率 (数值越小运镜越柔和)",
            5,
            20,
            (hub.cameraDampingScale * 10f).roundToInt(),
            0.1f,
            "%.1f x"
        ) { v ->
            hub.cameraDampingScale = v
            persistAllSettings(context, hub)
        }

        col.addView(animCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun syncThemeCardsVisual() {
        val curPal = GcsTheme.of(hub.themeId)
        for (i in themeCards.indices) {
            val sel = (hub.themeId == i)
            val cardPal = GcsTheme.PALETTES[i]
            themeCards[i].background = pillBg(
                if (sel) curPal.accentSoftFill else curPal.cardFill,
                if (sel) cardPal.swatchColor else curPal.cardStroke,
                radiusDp = 8f
            )
            themeCardTitles[i].setTextColor(curPal.textPrimary)
            themeCardTitles[i].invalidate()
            themeCardSubs[i].setTextColor(curPal.textMuted)
            themeCardChecks[i].visibility = if (sel) View.VISIBLE else View.GONE
            themeCardChecks[i].setTextColor(cardPal.swatchColor)
            themeCardChecks[i].invalidate()
        }
    }

    private fun syncAnimStyleButtons() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in animStyleSegBtns.indices) {
            val sel = (hub.animStyle == i)
            animStyleSegBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
            animStyleSegBtns[i].background = roundedColor(
                if (sel) pal.accent else Color.TRANSPARENT,
                dp(5f)
            )
            animStyleSegBtns[i].invalidate()
        }
    }

    // ==================== Category 1: 功能与座舱编排 ====================

    private fun buildCategoryOrchestration(): View {
        val sv = ScrollView(context)
        val col = pageColumn()

        val wsCard = groupCard("座舱工作台一键编排预设", "按飞行作业场景快速重组顶栏快捷入口与全屏悬浮仪表模块")
        val wsRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val wsSpecs = listOf(
            WorkspacePresetSpec(Type.LAYOUT_GRID, "标准巡检座舱") {
                activeWorkspacePreset = 0
                hub.hudShowCompass = true
                hub.hudShowHsiRadar = true
                hub.hudShowTelemetryBox = true
                hub.hudShowAttitudeWidget = true
                hub.hudShowRightCamStack = true
                hub.hudShowDemoTools = true
                hub.quickSlotOrderCsv = "mission,topics,pcd,recenter"
                hub.quickShowMission = true
                hub.quickShowTopics = true
                hub.quickShowPcd = false
                hub.quickShowRecenter = false
                saveAndNotifyHud("已应用「标准巡检座舱」功能编排")
            },
            WorkspacePresetSpec(Type.COMPASS_AIM, "极简沉浸飞控") {
                activeWorkspacePreset = 1
                hub.hudShowCompass = true
                hub.hudShowHsiRadar = true
                hub.hudShowTelemetryBox = true
                hub.hudShowAttitudeWidget = true
                hub.hudShowRightCamStack = true
                hub.hudShowDemoTools = false
                hub.quickShowMission = true
                hub.quickShowTopics = false
                hub.quickShowPcd = false
                hub.quickShowRecenter = false
                saveAndNotifyHud("已应用「极简沉浸飞控」精简座舱编排")
            },
            WorkspacePresetSpec(Type.RADAR_SIGNAL, "ROS研发调试台") {
                activeWorkspacePreset = 2
                hub.hudShowCompass = true
                hub.hudShowHsiRadar = true
                hub.hudShowTelemetryBox = true
                hub.hudShowAttitudeWidget = true
                hub.hudShowRightCamStack = true
                hub.hudShowDemoTools = true
                hub.quickSlotOrderCsv = "topics,mission,pcd,recenter"
                hub.quickShowMission = true
                hub.quickShowTopics = true
                hub.quickShowPcd = true
                hub.quickShowRecenter = true
                saveAndNotifyHud("已应用「ROS研发调试台」全快捷入口编排")
            }
        )
        presetModeBtns.clear()
        for (i in wsSpecs.indices) {
            val spec = wsSpecs[i]
            val btn = actionBtn(spec.icon, spec.title, registerGeneric = false) { spec.applyAction() }
            presetModeBtns.add(btn)
            wsRow.addView(btn, LinearLayout.LayoutParams(0, dp(32f), 1f).apply {
                if (i > 0) leftMargin = dp(6f)
            })
        }
        wsCard.addView(wsRow)
        col.addView(wsCard)

        val slotCard = groupCard("顶栏快捷入口顺序与显隐编排", "自定义主界面顶部状态栏常驻快捷胶囊的排列先后与开启状态")
        quickOrderListBox = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        slotCard.addView(quickOrderListBox)
        col.addView(slotCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        val hudCard = groupCard("全屏 HUD 悬浮组件开关", "独立控制座舱四周各遥测仪表与操控栏的显示状态")
        swHudCompass = addSwitchRow(hudCard, Type.COMPASS_AIM, "顶部航向罗盘刻度带", "显示 360 度实时航向角与正北刻度基准", hub.hudShowCompass) {
            activeWorkspacePreset = -1
            hub.hudShowCompass = it
            saveAndNotifyHud(null)
        }
        swHudHsi = addSwitchRow(hudCard, Type.RADAR_SIGNAL, "左下 HSI 避障姿态雷达球", "显示全向障碍距离包络与横滚俯仰姿态球", hub.hudShowHsiRadar) {
            activeWorkspacePreset = -1
            hub.hudShowHsiRadar = it
            saveAndNotifyHud(null)
        }
        swHudTelemetry = addSwitchRow(hudCard, Type.TELEMETRY_PULSE, "左下飞行速度与三维坐标框", "显示实时高度 H、水平速度 HS、目标距离 D 与世界系坐标", hub.hudShowTelemetryBox) {
            activeWorkspacePreset = -1
            hub.hudShowTelemetryBox = it
            saveAndNotifyHud(null)
        }
        swHudAttitude = addSwitchRow(hudCard, Type.DRONE_QUAD, "右下无人机三维实时姿态视窗", "实时驱动矢量机体展示俯仰/横滚/偏航三维姿态，点击可切换追尾/等轴/正视", hub.hudShowAttitudeWidget) {
            activeWorkspacePreset = -1
            hub.hudShowAttitudeWidget = it
            saveAndNotifyHud(null)
        }
        swHudCamStack = addSwitchRow(hudCard, Type.CUBE_3D, "右侧三维相机与图层快捷栏", "显示 3D/2D 切换、跟随模式、透视开关、图层浮窗与缩放键", hub.hudShowRightCamStack) {
            activeWorkspacePreset = -1
            hub.hudShowRightCamStack = it
            saveAndNotifyHud(null)
        }
        swHudDemoTools = addSwitchRow(hudCard, Type.PLAY, "仿真巡航与场景快切胶囊", "内置仿真模式下在左侧安全栏下方显示巡航开关与场景切换", hub.hudShowDemoTools, showDivider = false) {
            activeWorkspacePreset = -1
            hub.hudShowDemoTools = it
            saveAndNotifyHud(null)
        }
        col.addView(hudCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun renderQuickSlotOrchestratorRows() {
        if (!::quickOrderListBox.isInitialized) return
        quickOrderListBox.removeAllViews()
        val pal = GcsTheme.of(hub.themeId)
        val slots = normalizeSlotOrder(hub.quickSlotOrderCsv).split(",")

        for (idx in slots.indices) {
            val key = slots[idx]
            val (icon, title, desc) = when (key) {
                "mission" -> Triple(Type.ROUTE_NODES, "航线编排直达胶囊", "一键展开多航点任务编排与规划调参页")
                "topics" -> Triple(Type.RADAR_SIGNAL, "ROS1 话题监控胶囊", "一键展开活跃话题截取与实时流监控页")
                "pcd" -> Triple(Type.DOWNLOAD, "导出 PCD 点云胶囊", "顶栏一键将当前三维建图保存为标准 .pcd 文件")
                else -> Triple(Type.COMPASS_AIM, "视角回中锁定胶囊", "漫游偏离时一键将三维相机平滑锁定回无人机")
            }
            val enabled = isQuickSlotEnabled(key)

            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(9f), dp(6.5f), dp(9f), dp(6.5f))
                background = roundedColor(pal.wellFill, dp(7f))
            }

            val textCol = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            val tvTitle = TextView(context).apply {
                setTextColor(if (enabled) pal.textPrimary else pal.textMuted)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
                typeface = Typeface.DEFAULT_BOLD
                GcsIcons.bind(this, icon, "#${idx + 1}  $title", d, iconDp = 12f, gapDp = 5f)
            }
            val tvSub = TextView(context).apply {
                text = desc
                setTextColor(pal.textMuted)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.2f)
                setPadding(0, dp(1.5f), 0, 0)
            }
            textCol.addView(tvTitle)
            textCol.addView(tvSub)

            val btnUp = miniIconSquareBtn(Type.ARROW_UP, active = idx > 0) {
                if (idx > 0) {
                    val m = slots.toMutableList()
                    val t = m[idx - 1]; m[idx - 1] = m[idx]; m[idx] = t
                    hub.quickSlotOrderCsv = m.joinToString(",")
                    activeWorkspacePreset = -1
                    saveAndNotifyHud(null)
                }
            }
            val btnDown = miniIconSquareBtn(Type.ARROW_DOWN, active = idx < slots.lastIndex) {
                if (idx < slots.lastIndex) {
                    val m = slots.toMutableList()
                    val t = m[idx + 1]; m[idx + 1] = m[idx]; m[idx] = t
                    hub.quickSlotOrderCsv = m.joinToString(",")
                    activeWorkspacePreset = -1
                    saveAndNotifyHud(null)
                }
            }
            val btnToggle = TextView(context).apply {
                gravity = Gravity.CENTER
                isSingleLine = true
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(9f), dp(4f), dp(9f), dp(4f))
                setTextColor(if (enabled) Color.WHITE else pal.textMuted)
                GcsIcons.bind(this, if (enabled) Type.CHECK else null, if (enabled) "显示" else "隐藏", d, iconDp = 10.5f, gapDp = 3f)
                background = pillBg(
                    if (enabled) pal.accent else pal.cardFill,
                    if (enabled) pal.accentStroke else pal.cardStroke,
                    radiusDp = 14f
                )
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    setQuickSlotEnabled(key, !enabled)
                    activeWorkspacePreset = -1
                    saveAndNotifyHud(null)
                }
            }

            row.addView(textCol, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(btnUp, LinearLayout.LayoutParams(dp(27f), dp(26f)).apply { leftMargin = dp(5f) })
            row.addView(btnDown, LinearLayout.LayoutParams(dp(27f), dp(26f)).apply { leftMargin = dp(4f) })
            row.addView(btnToggle, LinearLayout.LayoutParams(dp(60f), dp(26f)).apply { leftMargin = dp(6f) })

            quickOrderListBox.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                if (idx > 0) topMargin = dp(5f)
            })
        }
    }

    private fun isQuickSlotEnabled(key: String): Boolean = when (key) {
        "mission" -> hub.quickShowMission
        "topics" -> hub.quickShowTopics
        "pcd" -> hub.quickShowPcd
        "recenter" -> hub.quickShowRecenter
        else -> false
    }

    private fun setQuickSlotEnabled(key: String, en: Boolean) {
        when (key) {
            "mission" -> hub.quickShowMission = en
            "topics" -> hub.quickShowTopics = en
            "pcd" -> hub.quickShowPcd = en
            "recenter" -> hub.quickShowRecenter = en
        }
    }

    private fun syncWorkspacePresetButtons() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in presetModeBtns.indices) {
            val sel = (i == activeWorkspacePreset)
            presetModeBtns[i].setTextColor(if (sel) Color.WHITE else pal.textPrimary)
            presetModeBtns[i].background = pillBg(
                if (sel) pal.accent else pal.cardFill,
                if (sel) pal.accentStroke else pal.cardStroke,
                radiusDp = 7f
            )
            presetModeBtns[i].invalidate()
        }
    }

    private fun saveAndNotifyHud(toast: String?) {
        persistAllSettings(context, hub)
        renderQuickSlotOrchestratorRows()
        syncWorkspacePresetButtons()
        onHudOrchestrationChanged()
        if (toast != null) onShowToast(toast)
    }

    // ==================== Category 2: 飞控安全与触控习惯 ====================

    private fun buildCategoryFlightSafety(): View {
        val sv = ScrollView(context)
        val col = pageColumn()

        val touchCard = groupCard("触控交互与防误触保护", "定制地图指点操控行为与关键安全指令确认机制")
        swLongPressFly = addSwitchRow(touchCard, Type.SEND_FLY, "长按地图 0.4s 快捷直飞", "关闭后长按地图仅放置选点预览光柱，须点击底部「立即飞往」才下发指令", hub.longPressQuickFlyEnabled) {
            hub.longPressQuickFlyEnabled = it
            persistAllSettings(context, hub)
        }
        swRthConfirm = addSwitchRow(touchCard, Type.HOME_RTH, "一键返航二次确认防误触", "开启后点击左侧「返航起点」需在 2.5 秒内再次点击方可执行返航", hub.rthDoubleConfirm) {
            hub.rthDoubleConfirm = it
            persistAllSettings(context, hub)
        }
        swHaptics = addSwitchRow(touchCard, Type.TELEMETRY_PULSE, "全局触控震动反馈", "按钮按压、航点放置与紧急悬停时触发遥控器线性震动反馈", hub.hapticFeedbackEnabled) {
            hub.hapticFeedbackEnabled = it
            AnimHelper.hapticsEnabled = it
            persistAllSettings(context, hub)
        }
        swAutoCloseDrawer = addSwitchRow(touchCard, Type.CLOSE_X, "配对连接真机后自动收起菜单", "在局域网扫描列表点击连接无人机后自动收起右侧抽屉展示全屏地图", hub.autoCloseDrawerOnConnect) {
            hub.autoCloseDrawerOnConnect = it
            persistAllSettings(context, hub)
        }

        val stepWrap = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7f), 0, dp(2f))
        }
        val stepLbl = TextView(context).apply {
            text = "目标高度微调步进量 (+/-)"
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
        }
        val stepSeg = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val stepChoices = listOf(0.1f to "0.1 m", 0.2f to "0.2 m", 0.5f to "0.5 m")
        altStepBtns.clear()
        for ((v, txt) in stepChoices) {
            val b = TextView(context).apply {
                text = txt
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(11f), dp(4f), dp(11f), dp(4f))
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hub.altStepMeters = v
                    persistAllSettings(context, hub)
                    syncAltStepSegButtons()
                }
            }
            altStepBtns.add(b)
            stepSeg.addView(b)
        }
        stepWrap.addView(stepLbl, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        stepWrap.addView(stepSeg)
        touchCard.addView(stepWrap)
        col.addView(touchCard)

        val safeCard = groupCard("安全告警阈值与返航点校准", "当最近障碍物净空或飞机动力电量低于设定阈值时顶栏自动变色预警")
        slWarnClearance = addSliderRow(safeCard, "近障净空预警阈值", 35, 160, (hub.warnClearanceMeters * 100f).roundToInt(), 0.01f, "%.2f m") { v ->
            hub.warnClearanceMeters = v
            persistAllSettings(context, hub)
        }
        slLowBatWarn = addSliderRow(safeCard, "无人机低电量告警阈值", 15, 45, hub.lowBatWarnPct, 1f, "%.0f %%") { v ->
            hub.lowBatWarnPct = v.roundToInt()
            persistAllSettings(context, hub)
        }

        val btnHomeHere = actionBtn(Type.HOME_RTH, "将无人机当前所在坐标设为返航点 H") {
            onSetHomeHere()
        }
        safeCard.addView(btnHomeHere, LinearLayout.LayoutParams(MATCH_PARENT, dp(32f)).apply { topMargin = dp(7f) })
        col.addView(safeCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun syncAltStepSegButtons() {
        val pal = GcsTheme.of(hub.themeId)
        val vals = floatArrayOf(0.1f, 0.2f, 0.5f)
        for (i in altStepBtns.indices) {
            val sel = abs(hub.altStepMeters - vals[i]) < 0.04f
            altStepBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
            altStepBtns[i].background = roundedColor(
                if (sel) pal.accent else Color.TRANSPARENT,
                dp(5f)
            )
        }
    }

    // ==================== Category 3: 三维显示与建图渲染 ====================

    private fun buildCategoryVisual3D(): View {
        val sv = ScrollView(context)
        val col = pageColumn()

        val layerCard = groupCard("三维空间透视与图层细项", "控制 EGO 膨胀体素、遮挡透视动画与辅助空间参考要素")
        swXray = addSwitchRow(layerCard, Type.XRAY_EYE, "膨胀体素视线透视与遮挡流动虚线", "挡视野膨胀体素自动羽化为半透明全息线框，被挡轨迹切换为流动虚线", hub.xrayOcclusionEnabled) {
            hub.xrayOcclusionEnabled = it
            persistAllSettings(context, hub)
            onVisualSettingsChanged()
        }
        swInflateLayer = addSwitchRow(layerCard, Type.CUBE_3D, "显示 EGO 三维膨胀占据体素地图", "渲染 /grid_map/occupancy_inflate 离散三维体素块", hub.showInflate) {
            hub.showInflate = it
            persistAllSettings(context, hub)
            onVisualSettingsChanged()
        }
        swCloudLayer = addSwitchRow(layerCard, Type.LAYERS, "显示 FAST-LIO 全局三维激光点云", "硬件 VBO 渲染累积配准点云与球面深度浮雕", hub.showFastLioMap) {
            hub.showFastLioMap = it
            persistAllSettings(context, hub)
            onVisualSettingsChanged()
        }
        swGridLayer = addSwitchRow(layerCard, Type.GRID_2X2, "显示地面战术坐标网格与原点轴", "渲染地面 1m/4m 透视比例网格与世界坐标系 RGB 参考轴", hub.showGroundGrid) {
            hub.showGroundGrid = it
            persistAllSettings(context, hub)
            onVisualSettingsChanged()
        }
        swCurtainLayer = addSwitchRow(layerCard, Type.ROUTE_NODES, "显示三维规划轨迹高程投影垂幕", "在 B 样条三维轨迹下方绘制半透明高度垂幕增强离地高度感", hub.showTrajCurtain) {
            hub.showTrajCurtain = it
            persistAllSettings(context, hub)
            onVisualSettingsChanged()
        }
        swTrailLayer = addSwitchRow(layerCard, Type.TELEMETRY_PULSE, "显示历史飞行轨迹与全局里程计路径", "渲染已飞过的历史尾迹线与 FAST-LIO /path 路径", hub.showFlightTrail, showDivider = false) {
            hub.showFlightTrail = it
            persistAllSettings(context, hub)
            onVisualSettingsChanged()
        }
        col.addView(layerCard)

        val cloudCard = groupCard("点云配色方案与建图精度", "调节 FAST-LIO 体素哈希分辨率、高度切片上限与渲染粒径")
        val schemeRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val schemes = listOf("高程彩虹色谱", "激光反射强度", "暗夜战术翠绿")
        colorSchemeBtns.clear()
        for (i in schemes.indices) {
            val b = TextView(context).apply {
                text = schemes[i]
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
                typeface = Typeface.DEFAULT_BOLD
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hub.pointColorMode = i
                    persistAllSettings(context, hub)
                    syncColorSchemeButtons()
                    onVisualSettingsChanged()
                }
            }
            colorSchemeBtns.add(b)
            schemeRow.addView(b, LinearLayout.LayoutParams(0, dp(28f), 1f))
        }
        cloudCard.addView(schemeRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(6f) })

        slVoxelSize = addSliderRow(cloudCard, "体素哈希分辨率 (voxel_size)", 6, 30, (hub.mapVoxelSize * 100f).roundToInt(), 0.01f, "%.2f m") { v ->
            hub.mapVoxelSize = v
            persistAllSettings(context, hub)
        }
        slZSlice = addSliderRow(cloudCard, "天花板高度切片上限 (z_slice)", 6, 60, (hub.zSliceMax * 10f).roundToInt(), 0.1f, "%.1f m") { v ->
            hub.zSliceMax = v
            persistAllSettings(context, hub)
        }
        slPointScale = addSliderRow(cloudCard, "点云屏幕粒径缩放倍率", 6, 20, (hub.pointSizeScale * 10f).roundToInt(), 0.1f, "%.1f x") { v ->
            hub.pointSizeScale = v
            persistAllSettings(context, hub)
        }
        col.addView(cloudCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun syncColorSchemeButtons() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in colorSchemeBtns.indices) {
            val sel = (hub.pointColorMode == i)
            colorSchemeBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
            colorSchemeBtns[i].background = roundedColor(
                if (sel) pal.accent else Color.TRANSPARENT,
                dp(5f)
            )
        }
    }

    // ==================== Category 4: 通信链路与算法模板 ====================

    private fun buildCategoryCommsLink(): View {
        val sv = ScrollView(context)
        val col = pageColumn()

        val linkCard = groupCard("局域网寻机与双路电源遥测链路", "配置开机自动寻机策略、MAVLink 监听与默认 ROS1 传输协议")
        swAutoConn = addSwitchRow(linkCard, Type.SEARCH, "启动时自动扫描局域网并配对无人机", "检测到同一网段开放 11311 / 9090 的机载电脑时自动建立连接", hub.autoConnectDiscovered) {
            hub.autoConnectDiscovered = it
            persistAllSettings(context, hub)
        }
        swMavlinkUdp = addSwitchRow(linkCard, Type.TELEMETRY_PULSE, "ELRS Backpack MAVLink UDP:14550 监听", "无损旁路监听本机 UDP 14550 动力电池电压与实时电流帧 (零串口冲突)", hub.mavlinkBackpackEnabled, showDivider = false) {
            hub.mavlinkBackpackEnabled = it
            persistAllSettings(context, hub)
        }

        val protoRowWrap = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8f), 0, dp(2f))
        }
        val protoLbl = TextView(context).apply {
            text = "首选 ROS1 传输协议"
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
        }
        val protoSeg = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val pList = listOf("tcpros" to "原生 TCPROS (:11311)", "rosbridge" to "rosbridge (:9090)")
        protoPrefBtns.clear()
        for ((pKey, pName) in pList) {
            val b = TextView(context).apply {
                text = pName
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(10f), dp(4.5f), dp(10f), dp(4.5f))
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    onProtocolChanged(pKey)
                    syncProtoPrefButtons()
                    refreshTopicSummaryBox()
                }
            }
            protoPrefBtns.add(b)
            protoSeg.addView(b)
        }
        protoRowWrap.addView(protoLbl, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        protoRowWrap.addView(protoSeg)
        linkCard.addView(protoRowWrap)
        col.addView(linkCard)

        val tplCard = groupCard("机载算法栈话题映射一键模板", "快速切换主流 SLAM + 规划器标准话题组合，或前往连接面板自定义编辑")
        val tplRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        tplRow.addView(actionBtn(Type.CUBE_3D, "FAST-LIO + EGO") {
            onApplyTopicPreset("fastlio")
            refreshTopicSummaryBox()
        }, LinearLayout.LayoutParams(0, dp(31f), 1f))
        tplRow.addView(actionBtn(Type.COMPASS_AIM, "VINS + EGO") {
            onApplyTopicPreset("vins")
            refreshTopicSummaryBox()
        }, LinearLayout.LayoutParams(0, dp(31f), 1f).apply { leftMargin = dp(6f) })
        tplRow.addView(actionBtn(Type.DRONE_QUAD, "Swarm_0 集群") {
            onApplyTopicPreset("swarm0")
            refreshTopicSummaryBox()
        }, LinearLayout.LayoutParams(0, dp(31f), 1f).apply { leftMargin = dp(6f) })
        tplCard.addView(tplRow)

        tvTopicSummaryBox = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
            typeface = Typeface.MONOSPACE
            setLineSpacing(dp(1.5f).toFloat(), 1.0f)
            setPadding(dp(9f), dp(7f), dp(9f), dp(7f))
            GcsTheme.markRole(this, Role.CONSOLE_BOX, cornerDp = 6f)
        }
        tplCard.addView(tvTopicSummaryBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(7f) })

        val jumpBtn = actionBtn(Type.LINK, "打开「连接」抽屉编辑机载 IP 与自定义话题路径", trailing = Type.CHEVRON_RIGHT) {
            setVisible(false)
            onJumpToConnDrawer()
        }
        tplCard.addView(jumpBtn, LinearLayout.LayoutParams(MATCH_PARENT, dp(31f)).apply { topMargin = dp(7f) })
        col.addView(tplCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun syncProtoPrefButtons() {
        val pal = GcsTheme.of(hub.themeId)
        val cur = getCurrentTopicConfig().protocol
        val keys = arrayOf("tcpros", "rosbridge")
        for (i in protoPrefBtns.indices) {
            val sel = (cur == keys[i])
            protoPrefBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
            protoPrefBtns[i].background = roundedColor(
                if (sel) pal.accent else Color.TRANSPARENT,
                dp(5f)
            )
        }
    }

    private fun refreshTopicSummaryBox() {
        if (!::tvTopicSummaryBox.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        tvTopicSummaryBox.setTextColor(pal.textConsole)
        val c = getCurrentTopicConfig()
        val endpoint = if (c.protocol == "tcpros") "TCPROS  ${c.masterUri}" else "WS      ${c.wsUrl}"
        val txt = buildString {
            append("Endpoint : $endpoint\n")
            append("Odom     : ${c.odomTopic}\n")
            append("Inflate  : ${c.inflateTopic}\n")
            append("Cloud    : ${c.fastLioCloudTopic.ifEmpty { "(disabled)" }}\n")
            append("Traj/Goal: ${c.optimalTopic}  ->  ${c.goalTopic}")
        }
        if (!TextUtils.equals(tvTopicSummaryBox.text, txt)) {
            tvTopicSummaryBox.text = txt
        }
    }

    // ==================== Category 5: 系统维护与数据备份 ====================

    private fun buildCategorySystemMaint(): View {
        val sv = ScrollView(context)
        val col = pageColumn()

        val diagCard = groupCard(
            "RadioMaster AX12 硬件性能策略与渲染遥测",
            "针对 MT8788 八核处理器 + Mali-G72 GPU 调优：9 路专用 VBO、齐次视锥剔除与稳态零 GC 仪表管线"
        )
        val perfLbl = TextView(context).apply {
            text = "硬件渲染性能档位"
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.4f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(4.5f))
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
        }
        diagCard.addView(perfLbl)

        val perfSeg = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2.5f), dp(2.5f), dp(2.5f), dp(2.5f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val perfSpecs = listOf(
            Triple(Type.GAUGE_MID, "均衡60帧", "推荐：2800 体素视锥裁剪 · 满帧 60FPS"),
            Triple(Type.GAUGE_HIGH, "极致画质", "全量 4096 膨胀体素 + 高密雷达采样"),
            Triple(Type.GAUGE_LOW, "省电30帧", "户外长续航：智能限帧 30FPS 降温省电")
        )
        perfModeSegBtns.clear()
        for (i in perfSpecs.indices) {
            val (ic, title, toastDesc) = perfSpecs[i]
            val b = TextView(context).apply {
                gravity = Gravity.CENTER
                isSingleLine = true
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
                typeface = Typeface.DEFAULT_BOLD
                GcsIcons.bind(this, ic, title, d, iconDp = 11.5f, gapDp = 3.5f)
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hub.perfMode = i
                    persistAllSettings(context, hub)
                    syncPerfModeButtons()
                    refreshSystemDiagnostics()
                    onShowToast("已切换性能策略：$toastDesc")
                }
            }
            perfModeSegBtns.add(b)
            perfSeg.addView(b, LinearLayout.LayoutParams(0, dp(29f), 1f))
        }
        diagCard.addView(perfSeg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8f) })

        tvSysDiagSummary = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
            typeface = Typeface.MONOSPACE
            setLineSpacing(dp(2f).toFloat(), 1.0f)
            setPadding(dp(9f), dp(7.5f), dp(9f), dp(7.5f))
            GcsTheme.markRole(this, Role.CONSOLE_BOX, cornerDp = 6f)
        }
        diagCard.addView(tvSysDiagSummary)
        col.addView(diagCard)

        val dataCard = groupCard("三维地图数据与全局配置维护", "导出点云建图、备份设置快照或一键恢复出厂初始配置")
        val row1 = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(actionBtn(Type.DOWNLOAD, "导出三维点云 (.pcd)") {
            onExportPcd()
        }, LinearLayout.LayoutParams(0, dp(32f), 1f))
        row1.addView(actionBtn(Type.COPY, "复制全局配置 JSON") {
            copyConfigSnapshotJson()
        }, LinearLayout.LayoutParams(0, dp(32f), 1f).apply { leftMargin = dp(6f) })
        dataCard.addView(row1)

        val row2 = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(actionBtn(Type.ERASER, "清空点云建图与航迹") {
            onClearMapAndTrail()
            refreshSystemDiagnostics()
        }, LinearLayout.LayoutParams(0, dp(32f), 1f))

        btnResetFactory = TextView(context).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            setTextColor(Color.parseColor("#FF5252"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10f), dp(5f), dp(10f), dp(5f))
            background = pillBg(Color.argb(46, 255, 59, 48), Color.parseColor("#FF3B30"), radiusDp = 7f)
            GcsIcons.bind(this, Type.UNDO, "恢复全部出厂默认设置", d, iconDp = 12f)
            setOnClickListener { handleFactoryResetTap() }
        }
        AnimHelper.attachSpringTouch(btnResetFactory)
        row2.addView(btnResetFactory, LinearLayout.LayoutParams(0, dp(32f), 1.15f).apply { leftMargin = dp(6f) })
        dataCard.addView(row2, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(7f) })

        col.addView(dataCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun syncPerfModeButtons() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in perfModeSegBtns.indices) {
            val sel = (hub.perfMode == i)
            perfModeSegBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
            perfModeSegBtns[i].background = roundedColor(
                if (sel) pal.accent else Color.TRANSPARENT,
                dp(5f)
            )
            perfModeSegBtns[i].invalidate()
        }
    }

    private fun refreshSystemDiagnostics() {
        if (!::tvSysDiagSummary.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        tvSysDiagSummary.setTextColor(pal.textConsole)
        val dm = context.resources.displayMetrics
        val s = hub.latestSnapshot
        val rt = Runtime.getRuntime()
        val usedMb = ((rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L)).toInt()
        val maxMb = (rt.maxMemory() / (1024L * 1024L)).toInt()
        val perfName = when (hub.perfMode) {
            1 -> "极致画质"
            2 -> "省电30帧"
            else -> "均衡60帧"
        }
        val modeTxt = if (hub.isRosMode) "ROS1 实机联飞 (${hub.connectionLabel})" else "本地三维体素物理仿真"
        val txt = String.format(
            Locale.US,
            "性能档位 : %s  |  帧率 : %d FPS (单帧 %.2f ms · %dx%d)\n" +
                "内存与栈 : JVM %d / %d MB  |  %s\n" +
                "地图统计 : 膨胀体素 %d blks  |  累积点云 %d pts\n" +
                "双路电源 : 飞机 %.2fV (%.1fA, %d%%)  |  AX12本机 %.2fV (%d%%)",
            perfName, hub.renderFps, hub.frameRenderMs, dm.widthPixels, dm.heightPixels,
            usedMb, maxMb, modeTxt,
            s.voxelCount, s.mapPointCount,
            s.batVolt, s.batCurrentAmps, s.batPct, s.txBatVolt, s.txBatPct
        )
        if (!TextUtils.equals(tvSysDiagSummary.text, txt)) {
            tvSysDiagSummary.text = txt
        }
    }

    private fun copyConfigSnapshotJson() {
        val c = getCurrentTopicConfig()
        val json = """
            {
              "themeId": ${hub.themeId},
              "themeName": "${GcsTheme.of(hub.themeId).name}",
              "perfMode": ${hub.perfMode},
              "animStyle": ${hub.animStyle},
              "protocol": "${c.protocol}",
              "masterUri": "${c.masterUri}",
              "wsUrl": "${c.wsUrl}",
              "topics": {
                "odom": "${c.odomTopic}",
                "inflate": "${c.inflateTopic}",
                "cloud": "${c.fastLioCloudTopic}",
                "optimal": "${c.optimalTopic}",
                "goal": "${c.goalTopic}"
              },
              "kinematics": {
                "inflation": ${hub.obstaclesInflation},
                "maxVel": ${hub.maxVel},
                "maxAcc": ${hub.maxAcc},
                "goalZ": ${hub.goalZ}
              },
              "hudOrchestration": {
                "quickOrder": "${hub.quickSlotOrderCsv}",
                "showMission": ${hub.quickShowMission},
                "showTopics": ${hub.quickShowTopics},
                "showPcd": ${hub.quickShowPcd},
                "showRecenter": ${hub.quickShowRecenter}
              }
            }
        """.trimIndent()
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ego_gcs_config", json))
        onShowToast("已复制地面站全局 JSON 配置快照至剪贴板")
    }

    private fun handleFactoryResetTap() {
        if (!factoryResetConfirmPending) {
            factoryResetConfirmPending = true
            AnimHelper.triggerHaptic(btnResetFactory)
            GcsIcons.bind(btnResetFactory, Type.WARNING, "2.5s内再点确认重置", d, iconDp = 12f)
            btnResetFactory.background = pillBg(Color.argb(145, 255, 59, 48), Color.parseColor("#FFD54F"), radiusDp = 7f)
            uiHandler.removeCallbacks(cancelFactoryConfirmRunnable)
            uiHandler.postDelayed(cancelFactoryConfirmRunnable, 2500L)
            return
        }
        uiHandler.removeCallbacks(cancelFactoryConfirmRunnable)
        cancelFactoryConfirmRunnable.run()
        AnimHelper.triggerHaptic(btnResetFactory, HapticFeedbackConstants.LONG_PRESS)

        hub.themeId = GcsTheme.THEME_AERO_CARBON
        hub.perfMode = 0
        hub.animStyle = 0
        AnimHelper.animStyle = 0
        hub.cameraDampingScale = 1.0f

        hub.autoConnectDiscovered = true
        hub.mavlinkBackpackEnabled = true
        hub.xrayOcclusionEnabled = true
        hub.showFastLioMap = true
        hub.showInflate = true
        hub.showLocalBox = true
        hub.showCtrlPts = true
        hub.showGroundGrid = true
        hub.showTrajCurtain = true
        hub.showFlightTrail = true
        hub.pointColorMode = 0
        hub.mapVoxelSize = 0.12f
        hub.zSliceMax = 3.0f
        hub.pointSizeScale = 1.0f

        hub.longPressQuickFlyEnabled = true
        hub.rthDoubleConfirm = true
        hub.hapticFeedbackEnabled = true
        AnimHelper.hapticsEnabled = true
        hub.autoCloseDrawerOnConnect = true
        hub.altStepMeters = 0.2f
        hub.warnClearanceMeters = 0.65f
        hub.lowBatWarnPct = 25

        hub.hudShowCompass = true
        hub.hudShowHsiRadar = true
        hub.hudShowTelemetryBox = true
                hub.hudShowAttitudeWidget = true
        hub.hudShowRightCamStack = true
        hub.hudShowDemoTools = true
        hub.quickSlotOrderCsv = "mission,topics,pcd,recenter"
        hub.quickShowMission = true
        hub.quickShowTopics = true
        hub.quickShowPcd = false
        hub.quickShowRecenter = false
        hub.routeLoopMode = 0
        hub.routeFinishAction = 0
        activeWorkspacePreset = 0

        persistAllSettings(context, hub)
        onThemeChanged(true)
        syncAllControlsFromHub()
        onFactoryResetApplied()
        onShowToast("已恢复全部系统设置、主题动效与功能编排默认配置")
    }

    // ==================== 主题感知原子构建工具 ====================

    private fun dp(v: Float): Int = (v * d).roundToInt()

    private fun pageColumn(): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12f), dp(10f), dp(12f), dp(12f))
    }

    private fun groupCard(title: String, subtitle: String? = null): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(11f), dp(9f), dp(11f), dp(9.5f))
        GcsTheme.markRole(this, Role.SECTION_CARD, cornerDp = 8f)
        addView(TextView(context).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_ACCENT)
        })
        if (subtitle != null) {
            addView(TextView(context).apply {
                text = subtitle
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.2f)
                setPadding(0, dp(2f), 0, dp(6f))
                GcsTheme.markRole(this, Role.TEXT_MUTED)
            })
        } else {
            addView(View(context), LinearLayout.LayoutParams(MATCH_PARENT, dp(5f)))
        }
    }

    private fun addSwitchRow(
        parent: LinearLayout,
        icon: Type,
        title: String,
        desc: String,
        initial: Boolean,
        showDivider: Boolean = true,
        onToggle: (Boolean) -> Unit
    ): ToggleSyncHandle {
        var cur = initial
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5.5f), 0, dp(5.5f))
        }
        val textCol = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val tvTitle = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
            GcsIcons.bind(this, icon, title, d, iconDp = 12f, gapDp = 5f)
        }
        val tvDesc = TextView(context).apply {
            text = desc
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.2f)
            setPadding(0, dp(1.5f), dp(8f), 0)
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        }
        textCol.addView(tvTitle)
        textCol.addView(tvDesc)

        val pillSwitch = FrameLayout(context)
        val thumb = View(context).apply {
            background = roundedColor(Color.WHITE, dp(9f))
        }
        pillSwitch.addView(thumb, FrameLayout.LayoutParams(dp(16f), dp(16f), Gravity.CENTER_VERTICAL).apply {
            leftMargin = dp(2.5f)
        })

        fun renderState(animate: Boolean) {
            val pal = GcsTheme.of(hub.themeId)
            pillSwitch.background = pillBg(
                if (cur) pal.accent else pal.wellFill,
                if (cur) pal.accentStroke else pal.cardStroke,
                radiusDp = 12f
            )
            val targetTx = if (cur) dp(17f).toFloat() else 0f
            if (animate) {
                SpringAnimationSwitchThumb(thumb, targetTx)
            } else {
                thumb.translationX = targetTx
            }
        }
        renderState(false)

        val toggleAction = {
            cur = !cur
            AnimHelper.triggerHaptic(row)
            renderState(true)
            onToggle(cur)
        }
        row.setOnClickListener { toggleAction() }
        pillSwitch.setOnClickListener { toggleAction() }

        row.addView(textCol, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(pillSwitch, LinearLayout.LayoutParams(dp(38f), dp(21f)))
        parent.addView(row)

        if (showDivider) {
            parent.addView(View(context).apply {
                GcsTheme.markRole(this, Role.DIVIDER)
            }, LinearLayout.LayoutParams(MATCH_PARENT, 1))
        }

        val handle = object : ToggleSyncHandle {
            override fun syncFromState(newVal: Boolean) {
                if (cur != newVal) {
                    cur = newVal
                    renderState(false)
                }
            }

            override fun refreshThemeColors() {
                renderState(false)
            }
        }
        allToggleHandles.add(handle)
        return handle
    }

    private fun SpringAnimationSwitchThumb(thumb: View, targetTx: Float) {
        androidx.dynamicanimation.animation.SpringAnimation(
            thumb,
            androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X,
            targetTx
        ).apply {
            spring = androidx.dynamicanimation.animation.SpringForce(targetTx).apply {
                stiffness = 520f
                dampingRatio = 0.76f
            }
            start()
        }
    }

    private fun addSliderRow(
        parent: LinearLayout,
        label: String,
        minI: Int,
        maxI: Int,
        initI: Int,
        scale: Float,
        fmt: String,
        onChanged: (Float) -> Unit
    ): SliderHandle {
        val wrap = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4f), 0, dp(4f))
        }
        val top = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val tvLbl = TextView(context).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
        }
        val safeInit = initI.coerceIn(minI, maxI)
        val tvVal = TextView(context).apply {
            text = String.format(Locale.US, fmt, safeInit * scale)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
            typeface = Typeface.MONOSPACE
            GcsTheme.markRole(this, Role.TEXT_ACCENT)
        }
        top.addView(tvLbl, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        top.addView(tvVal)
        wrap.addView(top)

        val sb = SeekBar(context).apply {
            max = maxI - minI
            progress = safeInit - minI
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = (minI + progress) * scale
                    tvVal.text = String.format(Locale.US, fmt, v)
                    onChanged(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        wrap.addView(sb)
        parent.addView(wrap)
        return SliderHandle(sb, tvVal, minI, scale, fmt)
    }

    private fun actionBtn(
        icon: Type,
        label: String,
        trailing: Type? = null,
        registerGeneric: Boolean = true,
        onClick: () -> Unit
    ): TextView = TextView(context).apply {
        val pal = GcsTheme.of(hub.themeId)
        gravity = Gravity.CENTER
        isSingleLine = true
        setTextColor(pal.textPrimary)
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.3f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(9f), dp(5f), dp(9f), dp(5f))
        background = pillBg(pal.cardFill, pal.cardStroke, radiusDp = 7f)
        GcsIcons.bind(this, icon, label, d, iconDp = 12f, gapDp = 4f, trailing = trailing, trailDp = 10f)
        setOnClickListener {
            AnimHelper.triggerHaptic(it)
            onClick()
        }
        AnimHelper.attachSpringTouch(this)
        if (registerGeneric) allActionBtns.add(this)
    }

    private fun miniIconSquareBtn(icon: Type, active: Boolean, onClick: () -> Unit): ImageView = ImageView(context).apply {
        val pal = GcsTheme.of(hub.themeId)
        scaleType = ImageView.ScaleType.CENTER
        val col = if (active) pal.textPrimary else pal.textHint
        setImageDrawable(GcsIcons.drawable(icon, dp(12.5f), col))
        background = roundedColor(if (active) pal.cardFill else Color.TRANSPARENT, dp(5f))
        isEnabled = active
        setOnClickListener {
            if (active) {
                AnimHelper.triggerHaptic(it)
                onClick()
            }
        }
    }

    private fun roundedColor(col: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(col)
        cornerRadius = radiusPx.toFloat()
    }

    private fun pillBg(fillCol: Int, strokeCol: Int, radiusDp: Float = 16f): GradientDrawable = GradientDrawable().apply {
        setColor(fillCol)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(maxOf(1, dp(0.9f)), strokeCol)
    }
}
