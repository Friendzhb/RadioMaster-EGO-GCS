# EGO Pilot · 纯原生 Kotlin + OpenGL ES 实时三维姿态与商业多主题高性能地面站

本工程为 **100% 纯原生 Kotlin + [OpenGL ES](https://developer.android.com/develop/ui/views/graphics/opengl/about-opengl) 硬件加速安卓应用（无任何 WebView、无 HTML 套壳文件、全界面零 Emoji 表情符号）**，专为 [RadioMaster AX12](https://radiomasterrc.com/products/ax12-android-radio-controller)（MediaTek MT8788 八核处理器、ARM Mali-G72 GPU、4GB RAM、`1280×720` 1000nits 5 英寸高亮触控屏，见 [AX12 规格手册](https://manuals.plus/radiomaster/ax12-android-radio-controller-manual)）深度调优，视觉与空间交互对标 [DJI FlightHub 2 三维航线投影](https://enterprise.dji.com/flighthub-2) 与 [DJI Fly 交互规范](https://support.dji.com/help/content?customId=en-us03400006562&spaceId=34&re=US&lang=en&documentType=artical&paperDocType=paper)。

## 1. 针对 RadioMaster AX12 (MT8788 + Mali-G72) 的全链路性能优化架构

- **OpenGL ES 9 路独立持久化 VBO 与硬件视锥剔除 (`GlPointCloudMapView.kt`)**：针对 Mali-G72 分块延迟渲染器（TBDR）拆分 9 个独立显存 VBO（彻底消除同帧重复覆写 VBO 引发的驱动 Buffer Ghosting 管线阻塞），结合齐次裁剪空间视锥剔除、视线隧道平方距离提前剪枝（消除 97% 冗余开方）与 256 段单位圆三角函数查表，在 `系统设置 -> 系统维护` 内置 **「均衡60帧 · 极致画质 · 省电30帧」** 三档渲染性能策略与实时帧耗时/内存遥测。
- **主线程与 Canvas 稳态零 GC 堆分配 (`FastHudFormatter.kt` + `UavAttitudeHudView.kt` + `DjiHudWidgets.kt`)**：采用原始整型量化脏检查槽位替代高频 `String.format` 与 `Integer` 装箱，消除 `onDraw` 内局部函数闭包与临时数组分配，并通过后台线程 60 扇区三角查表与内联快速欧氏距离 (`EgoSimEngine.kt`) 大幅降低 CPU 温升与功耗。

## 2. 无人机三维实时姿态视窗、四套商业航空主题与多航点编排

- **右下角对称航空三维姿态视窗 (`UavAttitudeHudView.kt` + `DroneVectorModel.kt`)**：实时解算实机 `/Odometry` 单位四元数 `(qw, qx, qy, qz)` 与仿真气动姿态，支持追尾地平仪、三维等轴陀螺与迎面正视三视角平滑切换；机体定义独立封装于 `DroneVectorModel.kt`，后续可直接替换为自定义矢量无人机模型。
- **四套全栈实战主题与系统设置/功能编排 (`GcsTheme.kt` + `GcsSettingsModal.kt`)**：内置 `深空航电黑 / 户外强光白 / 战术夜视绿 / 工业琥珀金` 四套主题与三档物理弹簧动效，配备 55 枚 `24×24` 抗锯齿单色几何矢量图标 (`GcsIcons.kt`)、六大分类设置中心及多航点任务序列编排。

## 3. 真实 EGO-Planner 三维膨胀体素透视与原生 ROS1 话题监控

- **真实 `/grid_map/occupancy_inflate` 三维膨胀体素块与 [OpenGL Depth Testing](https://learnopengl.com/Advanced-OpenGL/Depth-testing) 双遍遮挡透视**：还原真实 [EGO-Planner](https://github.com/ZJU-FAST-Lab/ego-planner/issues/106) 离散三维膨胀占据体素块，视线走廊内自动羽化为全息半透明线框，被遮挡轨迹自动切换为向前流动的霓虹虚线，融合 [Eye-Dome Lighting](https://www.researchgate.net/publication/320616607_Eye-Dome_Lighting_a_non-photorealistic_shading_technique) 点云浮雕。
- **原生 ROS1 话题监控与双路电源遥测**：通过 [ROS Master XML-RPC API](https://wiki.ros.org/ROS/Master_API) 与 [TCPROS Connection Header](https://wiki.ros.org/ROS/Connection%20Header) 支持话题列表浏览、单次截取、持续读取与一键绑定通道；零串口冲突（不触碰 `/dev/ttyS0`，见 [ax12-research](https://github.com/rmeadomavic/ax12-research) 与 [Flyshark 分析](https://github.com/rmeadomavic/ax12-research/blob/main/docs/software/flyshark-app.md)），兼容 [BatteryManager](https://developer.android.com/reference/android/os/BatteryManager)、[`/mavros/battery`](https://docs.ros.org/en/noetic/api/sensor_msgs/html/msg/BatteryState.html)、[ELRS Backpack](https://github.com/rmeadomavic/ax12-research/blob/main/docs/hardware/elrs-backpack.md) [MAVLink](https://mavlink.io/en/messages/common.html) `UDP :14550`、原生 [TCPROS](https://wiki.ros.org/ROS/TCPROS) 与 [FAST-LIO2](https://github.com/hku-mars/fast_lio)（见 [laserMapping.cpp](https://github.com/hku-mars/FAST_LIO/blob/main/src/laserMapping.cpp)），上传压缩包至仓库即可通过 [GitHub Actions](https://docs.github.com/actions) 自动构建发布 APK。
