package com.radiomaster.egogcs

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.radiomaster.egogcs.engine.EgoSimEngine
import com.radiomaster.egogcs.hw.Ax12HardwareBridge
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.RenderSnapshot
import com.radiomaster.egogcs.model.TopicConfig
import com.radiomaster.egogcs.ros.DiscoveredDrone
import com.radiomaster.egogcs.ros.LanDroneScanner
import com.radiomaster.egogcs.ros.RosBridgeClient
import com.radiomaster.egogcs.ros.RosConnectionManager
import com.radiomaster.egogcs.ros.TcpRosNativeClient
import com.radiomaster.egogcs.ui.AnimHelper
import com.radiomaster.egogcs.ui.DjiCompassTapeView
import com.radiomaster.egogcs.ui.DjiHsiRadarView
import com.radiomaster.egogcs.ui.GlPointCloudMapView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * DJI Pilot 2 风格航空级零模式切换主控座舱 + 硬件 Z-Buffer 三维遮挡透视交互：
 * 1. 零模式切换「单击插针预检 -> 底部悬浮指令坞 (立即飞往 / 加入航线 / 调高度 / 取消)」，兼顾长按 0.4s 快捷直飞；
 * 2. 硬件深度立体光影与视线遮挡反馈：障碍物阻挡视线时平滑融化为磨砂玻璃，被挡轨迹自动切换流动虚线，顶部浮现透视状态提示；
 * 3. 仿真演练与实机 ROS1 场景自适应 UI：进入实机模式自动隐藏「自动巡航」与「仿真场景切换」，杜绝误触清图；
 * 4. 紧急悬停零延迟一键瞬发，返航与清空点云地图均配备 2.5s 二次点击防误操作保护。
 */
class MainActivity : Activity() {

    private val hub = GcsSharedHub()
    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var simEngine: EgoSimEngine
    private lateinit var hwBridge: Ax12HardwareBridge
    private lateinit var rosManager: RosConnectionManager
    private val lanScanner = LanDroneScanner()
    private val fileIoExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "PcdExportIO").apply { isDaemon = true }
    }

    private lateinit var mapView: GlPointCloudMapView
    private lateinit var hsiView: DjiHsiRadarView
    private lateinit var compassView: DjiCompassTapeView
    private lateinit var topBannerStack: LinearLayout
    private lateinit var recenterBanner: TextView
    private lateinit var occlusionBadge: TextView
    private lateinit var toastBanner: TextView

    private lateinit var topBatFill: View
    private lateinit var statusAccent: View
    private lateinit var accentGreen: GradientDrawable
    private lateinit var accentAmber: GradientDrawable
    private lateinit var accentRed: GradientDrawable
    private var lastAppliedConnLevel = -1
    private var lastIsRosModeUi = false
    private var lastOccludedHudState = false

    private lateinit var tvModeBadge: TextView
    private lateinit var tvConnStatus: TextView
    private lateinit var btnQuickScan: TextView
    private lateinit var tvClearanceTop: TextView
    private lateinit var tvHzTop: TextView
    private lateinit var tvBatTop: TextView

    // 左侧常驻安全操控区 + 仿真专属组
    private lateinit var btnRth: TextView
    private lateinit var demoControlGroup: LinearLayout
    private lateinit var btnPatrol: TextView
    private lateinit var btnDemoScene: TextView
    private lateinit var btnClearMapRef: TextView

    // 底部中央上下文悬浮「选点确认 & 连续航线指令坞」
    private lateinit var commandDock: LinearLayout
    private lateinit var tvDockHeader: TextView
    private lateinit var dockPinRow: LinearLayout
    private lateinit var tvDockAltVal: TextView
    private lateinit var btnDockFlyNow: TextView
    private lateinit var dockRouteRow: LinearLayout
    private lateinit var btnDockStartRoute: TextView
    private lateinit var btnDockUndo: TextView
    private lateinit var btnDockClearRoute: TextView

    private lateinit var sbGoalZRef: SeekBar
    private lateinit var tvGoalZSliderVal: TextView

    // 右侧直观中文相机胶囊栈 (含 3D/2D、跟随视角、遮挡透视、点云配色、缩放、复位)
    private lateinit var btn3DRef: TextView
    private lateinit var btnFollowRef: TextView
    private lateinit var btnXrayRef: TextView
    private lateinit var btnColorRef: TextView
    private lateinit var btnXrayDrawerRef: TextView

    private var rthConfirmPending = false
    private val resetRthConfirmRunnable = Runnable {
        rthConfirmPending = false
        if (::btnRth.isInitialized) {
            setTextIfChanged(btnRth, "⌂ 返航起点")
            btnRth.background = pillBg(Color.argb(46, 255, 171, 0), Color.parseColor("#FFAB00"))
        }
    }

    private var clearMapConfirmPending = false
    private val resetClearMapConfirmRunnable = Runnable {
        clearMapConfirmPending = false
        if (::btnClearMapRef.isInitialized) {
            setTextIfChanged(btnClearMapRef, "清空建图")
            btnClearMapRef.background = glassBg(dp(6f))
        }
    }

    private lateinit var tvOsdH: TextView
    private lateinit var tvOsdHs: TextView
    private lateinit var tvOsdD: TextView
    private lateinit var tvOsdMapPts: TextView
    private lateinit var tvOsdSubXyz: TextView

    private lateinit var drawerRoot: LinearLayout
    private lateinit var tabGlider: View
    private val tabBtns = mutableListOf<TextView>()
    private val tabPanels = mutableListOf<View>()

    private lateinit var tvUavPowerCard: TextView
    private lateinit var tvTxPowerCard: TextView
    private lateinit var tvMapPtsCard: TextView
    private lateinit var tvCloudRateCard: TextView
    private lateinit var tvPosX: TextView
    private lateinit var tvPosY: TextView
    private lateinit var tvPosZ: TextView
    private lateinit var tvVelNorm: TextView
    private lateinit var tvYaw: TextView
    private lateinit var tvGoalDist: TextView
    private lateinit var tvClearanceCard: TextView
    private lateinit var tvSolveCard: TextView
    private lateinit var tvVoxelCount: TextView
    private lateinit var tvTrajLen: TextView

    private lateinit var tvScanStatus: TextView
    private lateinit var btnDrawerScan: TextView
    private lateinit var discoveredListContainer: LinearLayout

    private lateinit var inpMasterUri: EditText
    private lateinit var inpWsUrl: EditText
    private lateinit var inpOdom: EditText
    private lateinit var inpFastLioCloud: EditText
    private lateinit var inpFastLioPath: EditText
    private lateinit var inpInflate: EditText
    private lateinit var inpOptimal: EditText
    private lateinit var inpGoal: EditText
    private lateinit var btnProtoToggleRef: TextView

    private val discoveredDrones = mutableListOf<DiscoveredDrone>()
    private val sceneCycle = arrayOf("pillars" to "柱林", "corridor" to "走廊", "utrap" to "U型弯", "random" to "随机")
    private var sceneIdx = 0

    private var drawerOpen = false
    private var activeTabIndex = 0
    private var lastBackMs = 0L
    private var d = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersiveFullscreen()

        accentGreen = roundedColor(Color.parseColor("#00E676"), dp(2f))
        accentAmber = roundedColor(Color.parseColor("#FFAB00"), dp(2f))
        accentRed = roundedColor(Color.parseColor("#FF3B30"), dp(2f))

        simEngine = EgoSimEngine(hub).apply {
            onRosWaypointAdvanced = { gx, gy, gz, curX, curY ->
                rosManager.publishGoal(gx, gy, gz, curX, curY)
                runOnUiThread {
                    refreshCommandDockUi()
                    AnimHelper.showDjiToast(
                        toastBanner,
                        String.format(Locale.US, "航线推进 -> 下一站 (%.1f, %.1f)", gx, gy),
                        d
                    )
                }
            }
        }

        hwBridge = Ax12HardwareBridge(this, hub, simEngine)

        val wsClient = RosBridgeClient(hub, simEngine) { msg ->
            runOnUiThread { AnimHelper.showDjiToast(toastBanner, msg, d) }
        }
        val tcpClient = TcpRosNativeClient(hub, simEngine) { msg ->
            runOnUiThread { AnimHelper.showDjiToast(toastBanner, msg, d) }
        }
        rosManager = RosConnectionManager(hub, tcpClient, wsClient)
        loadSavedTopics()

        setContentView(buildNativeDjiCockpit())
        syncCameraControlLabels()
        syncModeSpecificControls(force = true)
        simEngine.start()
        hwBridge.start()

        if (hub.autoConnectDiscovered) {
            triggerLanScan(silentIfEmpty = true)
        }
    }

    override fun onResume() {
        super.onResume()
        applyImmersiveFullscreen()
        mapView.startLoop()
    }

    override fun onPause() {
        mapView.stopLoop()
        super.onPause()
    }

    override fun onDestroy() {
        uiHandler.removeCallbacksAndMessages(null)
        lanScanner.cancelScan()
        hwBridge.stop()
        mapView.stopLoop()
        rosManager.shutdown()
        simEngine.stop()
        fileIoExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveFullscreen()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveFullscreen() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) {
            toggleDrawer()
            return
        }
        if (simEngine.hasActivePreviewPin()) {
            simEngine.clearPreviewPin()
            refreshCommandDockUi()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBackMs < 1800L) {
            super.onBackPressed()
        } else {
            lastBackMs = now
            AnimHelper.showDjiToast(toastBanner, "再按一次返回键退出地面站", d)
        }
    }

    private fun openDrawerAtTab(targetTab: Int) {
        val singleTabW = dp(348f) / 3f
        if (!drawerOpen) {
            toggleDrawer()
        }
        if (activeTabIndex != targetTab) {
            switchTab(targetTab, singleTabW)
        }
    }

    private fun setXrayOcclusionState(enabled: Boolean, showToast: Boolean = true) {
        hub.xrayOcclusionEnabled = enabled
        getSharedPreferences("ego_native_prefs", Context.MODE_PRIVATE).edit()
            .putBoolean("xrayOcclusionEnabled", enabled)
            .apply()
        syncCameraControlLabels()
        syncDrawerXrayToggleButton()
        if (!enabled && lastOccludedHudState) {
            updateOcclusionHudVisibility(false)
        }
        if (showToast) {
            AnimHelper.showDjiToast(
                toastBanner,
                if (enabled) "遮挡透视已开启：挡视野墙体自动半透明，被挡航迹化为流动虚线" else "已切换为纯实景遮挡模式",
                d
            )
        }
    }

    private fun syncDrawerXrayToggleButton() {
        if (!::btnXrayDrawerRef.isInitialized) return
        val on = hub.xrayOcclusionEnabled
        setTextIfChanged(btnXrayDrawerRef, "遮挡透视虚线与墙体半透明: ${if (on) "ON" else "OFF"}")
        btnXrayDrawerRef.setTextColor(if (on) Color.WHITE else Color.argb(130, 255, 255, 255))
        btnXrayDrawerRef.background = pillBg(
            if (on) Color.argb(52, 24, 144, 255) else Color.argb(90, 0, 0, 0),
            if (on) Color.parseColor("#1890FF") else Color.argb(30, 255, 255, 255)
        )
    }

    private fun syncCameraControlLabels() {
        val is3D = mapView.is3DMode
        setTextIfChanged(btn3DRef, if (is3D) "3D透视" else "2D俯视")
        btn3DRef.background = camPillBg(is3D)

        val fMode = mapView.followMode
        val followTxt = when (fMode) {
            2 -> "视角:追尾"
            0 -> "视角:漫游"
            else -> "视角:环视"
        }
        setTextIfChanged(btnFollowRef, followTxt)
        btnFollowRef.background = camPillBg(fMode != 0)
        recenterBanner.visibility = if (fMode == 0) View.VISIBLE else View.GONE

        val xrayOn = hub.xrayOcclusionEnabled
        setTextIfChanged(btnXrayRef, if (xrayOn) "遮挡:透视" else "遮挡:实景")
        btnXrayRef.background = camPillBg(xrayOn)

        val colTxt = when (hub.pointColorMode) {
            1 -> "点云:强度"
            2 -> "点云:翠绿"
            else -> "点云:高程"
        }
        setTextIfChanged(btnColorRef, colTxt)
    }

    private fun updateOcclusionHudVisibility(occluded: Boolean) {
        if (occluded == lastOccludedHudState) return
        lastOccludedHudState = occluded
        occlusionBadge.animate().cancel()
        if (occluded) {
            occlusionBadge.visibility = View.VISIBLE
            occlusionBadge.alpha = 0f
            occlusionBadge.translationY = -dp(5f).toFloat()
            occlusionBadge.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(190L)
                .setInterpolator(AnimHelper.EASE_OUT_EXPO)
                .start()
        } else {
            occlusionBadge.animate()
                .alpha(0f)
                .translationY(-dp(4f).toFloat())
                .setDuration(180L)
                .withEndAction {
                    if (!lastOccludedHudState) {
                        occlusionBadge.visibility = View.GONE
                    }
                }
                .start()
        }
    }

    private fun syncPatrolPillUi() {
        setTextIfChanged(btnPatrol, if (hub.autoPatrol) "▶ 自动巡航: 开" else "▶ 自动巡航: 关")
        btnPatrol.background = pillBg(
            if (hub.autoPatrol) Color.argb(46, 0, 230, 118) else Color.argb(190, 18, 20, 24),
            if (hub.autoPatrol) Color.parseColor("#00E676") else Color.argb(35, 255, 255, 255)
        )
    }

    /**
     * 场景感知自适应显示：连接实机 ROS1 时自动隐藏「自动巡航」与「仿真场景切换」，防止实飞误触
     */
    private fun syncModeSpecificControls(force: Boolean = false) {
        val rosNow = hub.isRosMode
        if (!force && rosNow == lastIsRosModeUi) return
        lastIsRosModeUi = rosNow
        demoControlGroup.visibility = if (rosNow) View.GONE else View.VISIBLE
    }

    /**
     * 刷新底部中央「智能选点确认 & 连续航线指令坞」：无选点且无航线时自动隐藏，保持画面极致通透
     */
    private fun refreshCommandDockUi(latestPin: EgoSimEngine.PinInspectResult? = null) {
        val snap = hub.latestSnapshot
        val hasPin = latestPin != null || simEngine.hasActivePreviewPin()
        val (routeCnt, isStaged, arcLen) = simEngine.routeStatusSummary()

        if (hasPin) {
            val px = latestPin?.x ?: snap.previewX
            val py = latestPin?.y ?: snap.previewY
            val pz = latestPin?.z ?: hub.goalZ
            val dist = latestPin?.distFromUav ?: hypot(hypot(px - snap.uavX, py - snap.uavY), pz - snap.uavZ)
            val clr = latestPin?.clearance ?: snap.previewClearance
            val safe = latestPin?.isSafe ?: snap.previewSafe

            commandDock.visibility = View.VISIBLE
            dockPinRow.visibility = View.VISIBLE
            dockRouteRow.visibility = View.GONE

            setTextIfChanged(tvDockAltVal, String.format(Locale.US, "高 %.1fm", pz))
            if (safe) {
                tvDockHeader.setTextColor(Color.parseColor("#80D8FF"))
                val routeHint = if (isStaged && routeCnt > 0) " · 已编 $routeCnt 站" else ""
                setTextIfChanged(
                    tvDockHeader,
                    String.format(Locale.US, "📍 选点 (%.1f, %.1f) · 距机 %.1fm · 净空 %.1fm 安全%s", px, py, dist, clr, routeHint)
                )
                btnDockFlyNow.alpha = 1.0f
            } else {
                tvDockHeader.setTextColor(Color.parseColor("#FF6961"))
                setTextIfChanged(
                    tvDockHeader,
                    String.format(Locale.US, "⚠ 贴近障碍物 (净空 %.2fm) · 请重选位置或调高飞行高度", clr)
                )
                btnDockFlyNow.alpha = if (hub.isRosMode) 0.9f else 0.45f
            }
            return
        }

        if (routeCnt > 0) {
            commandDock.visibility = View.VISIBLE
            dockPinRow.visibility = View.GONE
            dockRouteRow.visibility = View.VISIBLE

            if (isStaged) {
                tvDockHeader.setTextColor(Color.parseColor("#FFD54F"))
                setTextIfChanged(
                    tvDockHeader,
                    String.format(Locale.US, "🗺 待执行航线：共 %d 个航点 · 预计总长 %.1fm (点地面可继续加点)", routeCnt, arcLen)
                )
                btnDockStartRoute.visibility = View.VISIBLE
                setTextIfChanged(btnDockStartRoute, "▶ 启动航线($routeCnt)")
                setTextIfChanged(btnDockClearRoute, "🗑 清空")
            } else {
                tvDockHeader.setTextColor(Color.parseColor("#00E676"))
                setTextIfChanged(tvDockHeader, "✈ 连续航线自主飞行中 · 队列剩余 $routeCnt 个待飞航点")
                btnDockStartRoute.visibility = View.GONE
                setTextIfChanged(btnDockClearRoute, "❚❚ 终止航线")
            }
            return
        }

        commandDock.visibility = View.GONE
    }

    private fun adjustTargetAltitudeByStep(delta: Float) {
        val (nextZ, pinInfo) = simEngine.nudgeGoalZ(delta)
        if (::sbGoalZRef.isInitialized) {
            val prog = ((nextZ * 10f).roundToInt() - 4).coerceIn(0, 36)
            if (sbGoalZRef.progress != prog) sbGoalZRef.progress = prog
            setTextIfChanged(tvGoalZSliderVal, String.format(Locale.US, "%.2f m", nextZ))
        }
        mapView.triggerPinSpringAnim()
        refreshCommandDockUi(pinInfo)
    }

    private fun handleRthButtonTap() {
        if (!rthConfirmPending) {
            rthConfirmPending = true
            btnRth.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            setTextIfChanged(btnRth, "⌂ 再点确认")
            btnRth.background = pillBg(Color.argb(145, 255, 171, 0), Color.parseColor("#FFD54F"))
            AnimHelper.showDjiToast(toastBanner, "防误触保护：2.5 秒内再次点击确认避障返航 H", d)
            uiHandler.removeCallbacks(resetRthConfirmRunnable)
            uiHandler.postDelayed(resetRthConfirmRunnable, 2500L)
            return
        }

        uiHandler.removeCallbacks(resetRthConfirmRunnable)
        resetRthConfirmRunnable.run()
        btnRth.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)

        val rth = simEngine.triggerReturnToHome()
        syncPatrolPillUi()
        refreshCommandDockUi()
        mapView.spawnRipple(rth[0], rth[1])
        rosManager.publishGoal(rth[0], rth[1], rth[2], rth[3], rth[4])
        AnimHelper.showDjiToast(toastBanner, String.format(Locale.US, "一键返航：正在避障飞回起飞点 H (%.1f, %.1f)", rth[0], rth[1]), d)
    }

    private fun handleClearMapTap() {
        if (!clearMapConfirmPending) {
            clearMapConfirmPending = true
            btnClearMapRef.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            setTextIfChanged(btnClearMapRef, "再点清图")
            btnClearMapRef.background = pillBg(Color.argb(120, 255, 59, 48), Color.parseColor("#FF6961"))
            AnimHelper.showDjiToast(toastBanner, "防误删保护：2.5 秒内再次点击确认清空三维点云地图", d)
            uiHandler.removeCallbacks(resetClearMapConfirmRunnable)
            uiHandler.postDelayed(resetClearMapConfirmRunnable, 2500L)
            return
        }
        uiHandler.removeCallbacks(resetClearMapConfirmRunnable)
        resetClearMapConfirmRunnable.run()
        btnClearMapRef.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        simEngine.clearVoxelMap()
        AnimHelper.showDjiToast(toastBanner, "已清空全局 FAST-LIO 三维体素点云地图", d)
    }

    private fun executeEmergencyHover(viewForHaptic: View) {
        uiHandler.removeCallbacks(resetRthConfirmRunnable)
        resetRthConfirmRunnable.run()
        viewForHaptic.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)

        simEngine.triggerEmergencyHover()
        syncPatrolPillUi()
        refreshCommandDockUi()
        val s = hub.latestSnapshot
        mapView.spawnRipple(s.uavX, s.uavY)
        rosManager.publishGoal(s.uavX, s.uavY, s.uavZ, s.uavX, s.uavY)
        AnimHelper.showDjiToast(toastBanner, "紧急制动：已清空全部待飞路线并下发原地悬停锁定", d)
    }

    private fun buildNativeDjiCockpit(): View {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }

        mapView = GlPointCloudMapView(
            context = this,
            hub = hub,
            voxelMap = simEngine.voxelMap,
            onHudTick = { snap -> updateHudReadouts(snap) },
            onInterceptDrawerClose = {
                if (drawerOpen) {
                    toggleDrawer()
                    true
                } else {
                    false
                }
            },
            onSingleTapPreviewPin = { wx, wy ->
                val info = simEngine.placePreviewPin(wx, wy)
                refreshCommandDockUi(info)
            },
            onLongPressQuickFly = { wx, wy ->
                val dispatched = simEngine.confirmFlyImmediate(wx, wy)
                if (dispatched == null) {
                    AnimHelper.showDjiToast(toastBanner, "长按目标位于障碍物内部，已安全拦截", d)
                } else {
                    syncPatrolPillUi()
                    refreshCommandDockUi()
                    rosManager.publishGoal(dispatched[0], dispatched[1], dispatched[2], dispatched[3], dispatched[4])
                    AnimHelper.showDjiToast(
                        toastBanner,
                        String.format(Locale.US, "长按快捷直飞 -> (%.1f, %.1f, %.1fm)", dispatched[0], dispatched[1], dispatched[2]),
                        d
                    )
                }
            },
            onFollowStateChanged = { _, toastMsg ->
                runOnUiThread {
                    syncCameraControlLabels()
                    if (toastMsg != null) {
                        AnimHelper.showDjiToast(toastBanner, toastMsg, d)
                    }
                }
            }
        )
        root.addView(mapView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        val batTrack = FrameLayout(this).apply { setBackgroundColor(Color.argb(28, 255, 255, 255)) }
        topBatFill = View(this).apply { setBackgroundColor(Color.parseColor("#00E676")) }
        batTrack.addView(topBatFill, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.86f).roundToInt(), MATCH_PARENT))
        root.addView(batTrack, FrameLayout.LayoutParams(MATCH_PARENT, dp(2.5f), Gravity.TOP))

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), dp(3f), dp(10f), 0)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(218, 0, 0, 0), Color.argb(0, 0, 0, 0))
            )
        }

        tvModeBadge = TextView(this).apply {
            text = "OFFBOARD · ARMED"
            isSingleLine = true
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(7.5f), dp(4.5f), dp(7.5f), dp(4.5f))
            background = glassBg(dp(6f))
        }
        topBar.addView(tvModeBadge)

        val statusCapsule = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7.5f), dp(4.5f), dp(8f), dp(4.5f))
            background = glassBg(dp(6f))
            setOnClickListener {
                if (hub.isRosMode && !hub.rosConnected) {
                    rosManager.connect(rosManager.topics)
                    AnimHelper.showDjiToast(toastBanner, "正在尝试重新连接机载 ROS1...", d)
                } else {
                    openDrawerAtTab(2)
                }
            }
        }
        AnimHelper.attachSpringTouch(statusCapsule)
        statusAccent = View(this).apply { background = accentGreen }
        lastAppliedConnLevel = 0
        statusCapsule.addView(statusAccent, LinearLayout.LayoutParams(dp(3.5f), dp(12f)).apply { rightMargin = dp(5f) })
        tvConnStatus = TextView(this).apply {
            text = "仿真演练 | EXEC_TRAJ"
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(148f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
        }
        statusCapsule.addView(tvConnStatus)
        topBar.addView(statusCapsule, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(5f) })

        btnQuickScan = TextView(this).apply {
            text = "🔍 搜飞机"
            isSingleLine = true
            setTextColor(Color.parseColor("#69B7FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8f), dp(4.5f), dp(8f), dp(4.5f))
            background = pillBg(Color.argb(48, 24, 144, 255), Color.argb(130, 24, 144, 255))
            setOnClickListener { triggerLanScan(silentIfEmpty = false) }
        }
        AnimHelper.attachSpringTouch(btnQuickScan)
        topBar.addView(btnQuickScan, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(5f) })

        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val rightCluster = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8f), dp(4.5f), dp(8f), dp(4.5f))
            background = glassBg(dp(6f))
            setOnClickListener { openDrawerAtTab(0) }
        }
        AnimHelper.attachSpringTouch(rightCluster)
        tvClearanceTop = monoLabel("避障1.4m", "#00E676", 10.5f)
        tvHzTop = monoLabel(" | 60fps | ", "#FFFFFF", 10.5f)
        tvBatTop = monoLabel("16.2V·12.6A | 控92%", "#00E676", 10.5f)
        rightCluster.addView(tvClearanceTop)
        rightCluster.addView(tvHzTop)
        rightCluster.addView(tvBatTop)
        topBar.addView(rightCluster)

        val btnMenu = TextView(this).apply {
            text = "••• 设置"
            isSingleLine = true
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9f), dp(4.5f), dp(9f), dp(4.5f))
            background = glassBg(dp(6f))
            setOnClickListener { toggleDrawer() }
        }
        AnimHelper.attachSpringTouch(btnMenu)
        topBar.addView(btnMenu, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(5f) })
        root.addView(topBar, FrameLayout.LayoutParams(MATCH_PARENT, dp(42f), Gravity.TOP))

        compassView = DjiCompassTapeView(this, hub).apply {
            background = glassBg(dp(7f), alpha = 178)
        }
        root.addView(compassView, FrameLayout.LayoutParams(dp(216f), dp(27f), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(45f)
        })

        // 顶部中央动态状态胶囊列 (漫游回中引导 + 视线遮挡透视虚线激活提示，自动防重叠排布)
        topBannerStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        recenterBanner = TextView(this).apply {
            text = "🎯 视角已漫游 · 点击回中锁定飞机"
            visibility = View.GONE
            isSingleLine = true
            setTextColor(Color.parseColor("#80D8FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(11f), dp(4.5f), dp(11f), dp(4.5f))
            background = pillBg(Color.argb(185, 10, 24, 42), Color.parseColor("#1890FF"))
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                mapView.recenterLockDrone()
                syncCameraControlLabels()
            }
        }
        AnimHelper.attachSpringTouch(recenterBanner)
        topBannerStack.addView(recenterBanner, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))

        occlusionBadge = TextView(this).apply {
            text = "👁 视线受阻 · 墙体半透明与透视虚线已激活"
            visibility = View.GONE
            isSingleLine = true
            setTextColor(Color.parseColor("#64FFDA"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10f), dp(3.5f), dp(10f), dp(3.5f))
            background = pillBg(Color.argb(176, 8, 28, 34), Color.parseColor("#00E5FF"))
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                setXrayOcclusionState(!hub.xrayOcclusionEnabled)
            }
        }
        AnimHelper.attachSpringTouch(occlusionBadge)
        topBannerStack.addView(occlusionBadge, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            topMargin = dp(4f)
        })

        root.addView(topBannerStack, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(75f)
        })

        // 左侧精简安全操控区 (紧急悬停最醒目置顶 + 二次确认返航 + 仅仿真模式显示的巡航与场景切换)
        val leftRail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val btnBrake = createActionPill("❚❚ 紧急悬停", "#FF3B30", true).apply {
            background = pillBg(Color.argb(78, 255, 59, 48), Color.parseColor("#FF3B30"))
            setTextColor(Color.parseColor("#FF6961"))
            setOnClickListener { executeEmergencyHover(it) }
        }
        leftRail.addView(btnBrake)

        btnRth = createActionPill("⌂ 返航起点", "#FFAB00", true).apply {
            setOnClickListener { handleRthButtonTap() }
        }
        leftRail.addView(btnRth, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(6f) })

        demoControlGroup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        btnPatrol = createActionPill("▶ 自动巡航: 开", "#00E676", true).apply {
            setOnClickListener {
                hub.autoPatrol = !hub.autoPatrol
                if (hub.autoPatrol) simEngine.clearPreviewPin()
                syncPatrolPillUi()
                refreshCommandDockUi()
                if (hub.autoPatrol) AnimHelper.showDjiToast(toastBanner, "已恢复仿真连续自动避障巡航", d)
            }
        }
        btnDemoScene = createActionPill("❖ 仿真: 柱林", "#69B7FF", false).apply {
            setOnClickListener {
                sceneIdx = (sceneIdx + 1) % sceneCycle.size
                val pair = sceneCycle[sceneIdx]
                simEngine.setScenePreset(pair.first)
                setTextIfChanged(btnDemoScene, "❖ 仿真: ${pair.second}")
                refreshCommandDockUi()
                AnimHelper.showDjiToast(toastBanner, "已切换仿真测试环境: ${pair.second}", d)
            }
        }
        demoControlGroup.addView(btnPatrol, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(6f) })
        demoControlGroup.addView(btnDemoScene, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(6f) })
        leftRail.addView(demoControlGroup)

        root.addView(leftRail, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            leftMargin = dp(12f)
            topMargin = dp(48f)
        })

        // 左下角 HSI 避障球与飞行仪表框
        val bottomLeft = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        hsiView = DjiHsiRadarView(this, hub).apply {
            setOnClickListener {
                val msg = cycleMode()
                AnimHelper.showDjiToast(toastBanner, msg, d)
            }
        }
        AnimHelper.attachSpringTouch(hsiView)
        bottomLeft.addView(hsiView, LinearLayout.LayoutParams(dp(108f), dp(108f)))

        val hdBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), dp(6.5f), dp(10f), dp(6.5f))
            background = glassBg(dp(8f))
            setOnClickListener {
                mapView.recenterLockDrone()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, "已回中锁定无人机视角", d)
            }
        }
        AnimHelper.attachSpringTouch(hdBox)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvOsdH = monoLabel("H  1.2 m", "#FFFFFF", 15f)
        tvOsdHs = monoLabel("   HS  0.0 m/s", "#FFFFFF", 15f)
        row1.addView(tvOsdH); row1.addView(tvOsdHs)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvOsdD = monoLabel("D  3.8 m", "#FFFFFF", 15f)
        tvOsdMapPts = monoLabel("   MAP 0 pts", "#69B7FF", 12.5f)
        row2.addView(tvOsdD); row2.addView(tvOsdMapPts)

        tvOsdSubXyz = monoLabel("X -5.50  Y -4.20  YAW 37°", "#B8C0CC", 9.5f).apply {
            setPadding(0, dp(2.5f), 0, 0)
        }
        hdBox.addView(row1)
        hdBox.addView(row2, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(2f) })
        hdBox.addView(tvOsdSubXyz)
        bottomLeft.addView(hdBox, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(8f) })

        root.addView(bottomLeft, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = dp(12f)
            bottomMargin = dp(10f)
        })

        // 底部中央上下文悬浮「选点确认 & 航线指令坞」 (位于 bottomMargin=80dp，避开左下仪表与右下工具栏零遮挡)
        commandDock = buildContextualCommandDock()
        commandDock.visibility = View.GONE
        root.addView(commandDock, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(80f)
        })

        // 右侧直观中文短标签相机与遮挡透视控制列
        val rightCamStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        btn3DRef = createCamPillBtn("3D透视", true).apply {
            setOnClickListener {
                val now3D = mapView.toggle3D2DWithAnimation()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, if (now3D) "平滑切换至 3D 立体透视视图" else "平滑切换至 2D 正射俯视地图", d)
            }
        }
        btnFollowRef = createCamPillBtn("视角:环视", true).apply {
            setOnClickListener {
                val (_, tip) = mapView.cycleFollowMode()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, tip, d)
            }
        }
        btnXrayRef = createCamPillBtn("遮挡:透视", hub.xrayOcclusionEnabled).apply {
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                setXrayOcclusionState(!hub.xrayOcclusionEnabled)
            }
        }
        btnColorRef = createCamPillBtn("点云:高程", false).apply {
            setOnClickListener {
                val (_, tip) = mapView.cycleColorMode()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, tip, d)
            }
        }

        val zoomPair = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = glassBg(dp(15f))
        }
        val btnZOut = TextView(this).apply {
            text = "−"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { mapView.zoomBy(0.80f) }
        }
        val btnZIn = TextView(this).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { mapView.zoomBy(1.25f) }
        }
        zoomPair.addView(btnZOut, LinearLayout.LayoutParams(dp(32f), dp(27f)))
        zoomPair.addView(View(this).apply { setBackgroundColor(Color.argb(40, 255, 255, 255)) }, LinearLayout.LayoutParams(1, MATCH_PARENT))
        zoomPair.addView(btnZIn, LinearLayout.LayoutParams(dp(32f), dp(27f)))

        val btnResetCam = createCamPillBtn("↺ 视角复位", false).apply {
            setOnClickListener {
                mapView.resetCameraSmooth()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, "已平滑复位默认三维跟随相机", d)
            }
        }

        rightCamStack.addView(btn3DRef, LinearLayout.LayoutParams(dp(65f), dp(27.5f)))
        rightCamStack.addView(btnFollowRef, LinearLayout.LayoutParams(dp(65f), dp(27.5f)).apply { topMargin = dp(4.5f) })
        rightCamStack.addView(btnXrayRef, LinearLayout.LayoutParams(dp(65f), dp(27.5f)).apply { topMargin = dp(4.5f) })
        rightCamStack.addView(btnColorRef, LinearLayout.LayoutParams(dp(65f), dp(27.5f)).apply { topMargin = dp(4.5f) })
        rightCamStack.addView(zoomPair, LinearLayout.LayoutParams(dp(65f), dp(27.5f)).apply { topMargin = dp(4.5f) })
        rightCamStack.addView(btnResetCam, LinearLayout.LayoutParams(dp(65f), dp(27.5f)).apply { topMargin = dp(4.5f) })

        root.addView(rightCamStack, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(12f)
            topMargin = dp(48f)
        })

        // 右下角纯建图/航迹工具栏 (清空建图带二次点击防误删保护)
        val bottomRightBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnSavePcd = createSmallUtilBtn("保存 PCD") { exportCurrentPointCloudPcd() }
        btnClearMapRef = createSmallUtilBtn("清空建图") { handleClearMapTap() }
        val btnClearTrail = createSmallUtilBtn("清空航迹") {
            simEngine.clearTrail()
            AnimHelper.showDjiToast(toastBanner, "已清空历史飞行轨迹显示", d)
        }
        bottomRightBar.addView(btnSavePcd)
        bottomRightBar.addView(btnClearMapRef, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })
        bottomRightBar.addView(btnClearTrail, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })
        root.addView(bottomRightBar, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            rightMargin = dp(12f)
            bottomMargin = dp(10f)
        })

        val drawerW = dp(348f)
        drawerRoot = buildSlideOverDrawer(drawerW)
        drawerRoot.visibility = View.INVISIBLE
        drawerRoot.translationX = (drawerW + dp(24f)).toFloat()
        root.addView(drawerRoot, FrameLayout.LayoutParams(drawerW, MATCH_PARENT, Gravity.END).apply {
            topMargin = dp(46f)
            rightMargin = dp(10f)
            bottomMargin = dp(10f)
        })

        toastBanner = TextView(this).apply {
            visibility = View.INVISIBLE
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
            setPadding(dp(12f), dp(5.5f), dp(12f), dp(5.5f))
            background = GradientDrawable().apply {
                setColor(Color.argb(235, 16, 18, 22))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor("#00E676"))
            }
        }
        root.addView(toastBanner, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(116f)
        })

        drawerRoot.tag = Pair(listOf(rightCamStack, bottomRightBar), listOf(compassView, topBannerStack, commandDock, toastBanner))
        return root
    }

    /**
     * 构建底部中央「智能选点确认 & 连续航线控制指令坞」
     */
    private fun buildContextualCommandDock(): LinearLayout {
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(10f), dp(7f), dp(10f), dp(7f))
            background = GradientDrawable().apply {
                setColor(Color.argb(232, 14, 18, 24))
                cornerRadius = dp(10f).toFloat()
                setStroke(dp(1f), Color.argb(110, 24, 144, 255))
            }
            isClickable = true
        }

        tvDockHeader = TextView(this).apply {
            text = "📍 选点预览"
            isSingleLine = true
            setTextColor(Color.parseColor("#80D8FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(5f))
        }
        dock.addView(tvDockHeader)

        // 模式 A：已单击地图放置预览光柱 -> [🚀 立即飞往] [+ 加航点] [− 高1.2m +] [✕]
        dockPinRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        btnDockFlyNow = TextView(this).apply {
            text = "🚀 立即飞往"
            isSingleLine = true
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10f), dp(5f), dp(10f), dp(5f))
            background = roundedColor(Color.parseColor("#00B865"), dp(6f))
            setOnClickListener {
                val dispatched = simEngine.confirmFlyImmediate()
                if (dispatched == null) {
                    it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    AnimHelper.showDjiToast(toastBanner, "选点位于障碍物内部，请换个位置或点 + 调高飞行高度", d)
                } else {
                    it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    syncPatrolPillUi()
                    refreshCommandDockUi()
                    rosManager.publishGoal(dispatched[0], dispatched[1], dispatched[2], dispatched[3], dispatched[4])
                    AnimHelper.showDjiToast(
                        toastBanner,
                        String.format(Locale.US, "已下发指点飞行 -> (%.1f, %.1f, %.1fm)", dispatched[0], dispatched[1], dispatched[2]),
                        d
                    )
                }
            }
        }
        AnimHelper.attachSpringTouch(btnDockFlyNow)

        val btnAddRoute = TextView(this).apply {
            text = "＋ 加航点"
            isSingleLine = true
            setTextColor(Color.parseColor("#FFD54F"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9f), dp(5f), dp(9f), dp(5f))
            background = pillBg(Color.argb(48, 255, 171, 0), Color.parseColor("#FFAB00"))
            setOnClickListener {
                val (ok, total, _) = simEngine.appendPreviewPinToRoute()
                if (!ok) {
                    AnimHelper.showDjiToast(toastBanner, "选点位于障碍内部，无法编入航线", d)
                } else {
                    it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    refreshCommandDockUi()
                    AnimHelper.showDjiToast(toastBanner, "已加入航点 #$total · 可继续点地图加点，或点「▶ 启动航线」", d)
                }
            }
        }
        AnimHelper.attachSpringTouch(btnAddRoute)

        val altInline = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedColor(Color.argb(120, 255, 255, 255), dp(6f)).apply {
                setColor(Color.argb(32, 255, 255, 255))
            }
        }
        val btnMinus = TextView(this).apply {
            text = "−"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                adjustTargetAltitudeByStep(-0.2f)
            }
        }
        tvDockAltVal = monoLabel(String.format(Locale.US, "高 %.1fm", hub.goalZ), "#69B7FF", 10.5f)
        val btnPlus = TextView(this).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                adjustTargetAltitudeByStep(+0.2f)
            }
        }
        altInline.addView(btnMinus)
        altInline.addView(tvDockAltVal)
        altInline.addView(btnPlus)

        val btnCancelPin = TextView(this).apply {
            text = "✕"
            gravity = Gravity.CENTER
            setTextColor(Color.argb(190, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8f), dp(4.5f), dp(8f), dp(4.5f))
            background = roundedColor(Color.argb(36, 255, 255, 255), dp(6f))
            setOnClickListener {
                simEngine.clearPreviewPin()
                refreshCommandDockUi()
            }
        }

        dockPinRow.addView(btnDockFlyNow)
        dockPinRow.addView(btnAddRoute, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })
        dockPinRow.addView(altInline, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })
        dockPinRow.addView(btnCancelPin, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })
        dock.addView(dockPinRow)

        // 模式 B：航线待发或执行中 -> [▶ 启动航线(N)] [↶ 撤销末点] [🗑 清空 / ❚❚ 终止]
        dockRouteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }

        btnDockStartRoute = TextView(this).apply {
            text = "▶ 启动航线"
            isSingleLine = true
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(11f), dp(5f), dp(11f), dp(5f))
            background = roundedColor(Color.parseColor("#00B865"), dp(6f))
            setOnClickListener {
                val committed = simEngine.commitStagedRoute()
                if (committed != null) {
                    val (firstGoal, totalPts) = committed
                    it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    syncPatrolPillUi()
                    refreshCommandDockUi()
                    mapView.spawnRipple(firstGoal[0], firstGoal[1])
                    rosManager.publishGoal(firstGoal[0], firstGoal[1], firstGoal[2], firstGoal[3], firstGoal[4])
                    AnimHelper.showDjiToast(toastBanner, "连续航线已启动：共 $totalPts 站依次自主避障飞行", d)
                }
            }
        }
        AnimHelper.attachSpringTouch(btnDockStartRoute)

        btnDockUndo = createSmallUtilBtn("↶ 撤销末点") {
            val (rem, _, _) = simEngine.undoLastWaypoint()
            refreshCommandDockUi()
            AnimHelper.showDjiToast(toastBanner, "已撤销末尾航点，当前剩余 $rem 站", d)
        }

        btnDockClearRoute = createSmallUtilBtn("🗑 清空") {
            val (_, isStaged, _) = simEngine.routeStatusSummary()
            if (isStaged) {
                simEngine.clearWaypointQueue()
                refreshCommandDockUi()
                AnimHelper.showDjiToast(toastBanner, "已清空待执行预览航线", d)
            } else {
                executeEmergencyHover(btnDockClearRoute)
            }
        }

        dockRouteRow.addView(btnDockStartRoute, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(6f) })
        dockRouteRow.addView(btnDockUndo)
        dockRouteRow.addView(btnDockClearRoute, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })
        dock.addView(dockRouteRow)

        return dock
    }

    private fun buildSlideOverDrawer(drawerWidthPx: Int): LinearLayout {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glassBg(dp(12f), alpha = 238)
            isClickable = true
            isFocusable = true
        }

        val tabBarWrap = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(85, 0, 0, 0))
        }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val titles = listOf("建图与电源", "建图/规划参数", "搜寻与连接")
        val singleTabW = drawerWidthPx / 3f

        tabBtns.clear()
        for (i in titles.indices) {
            val tb = TextView(this).apply {
                text = titles[i]
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11.5f)
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (i == 0) Color.WHITE else Color.argb(120, 255, 255, 255))
                setOnClickListener { switchTab(i, singleTabW) }
            }
            tabBtns.add(tb)
            tabRow.addView(tb, LinearLayout.LayoutParams(0, dp(36f), 1f))
        }
        tabRow.addView(TextView(this).apply {
            text = "✕"
            gravity = Gravity.CENTER
            setTextColor(Color.argb(175, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10f), 0, dp(12f), 0)
            setOnClickListener { if (drawerOpen) toggleDrawer() }
        }, LinearLayout.LayoutParams(WRAP_CONTENT, dp(36f)))

        tabBarWrap.addView(tabRow, FrameLayout.LayoutParams(MATCH_PARENT, dp(36f)))

        val usableTabsW = (drawerWidthPx - dp(34f)) / 3f
        tabGlider = FrameLayout(this).apply {
            val bar = View(this@MainActivity).apply {
                background = roundedColor(Color.parseColor("#1890FF"), dp(2f))
            }
            addView(bar, FrameLayout.LayoutParams((usableTabsW * 0.54f).roundToInt(), dp(2.5f), Gravity.CENTER))
        }
        tabBarWrap.addView(tabGlider, FrameLayout.LayoutParams(usableTabsW.roundToInt(), dp(3f), Gravity.BOTTOM or Gravity.START))
        container.addView(tabBarWrap, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val bodyHost = FrameLayout(this)
        val p0 = buildTelemetryPanel()
        val p1 = buildParamsPanel()
        val p2 = buildRosPanel()
        p1.visibility = View.GONE
        p2.visibility = View.GONE
        tabPanels.clear()
        tabPanels.addAll(listOf(p0, p1, p2))
        bodyHost.addView(p0); bodyHost.addView(p1); bodyHost.addView(p2)
        container.addView(bodyHost, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        return container
    }

    private fun switchTab(idx: Int, singleTabW: Float) {
        activeTabIndex = idx
        val usableW = (dp(348f) - dp(34f)) / 3f
        for (i in tabBtns.indices) {
            tabBtns[i].setTextColor(if (i == idx) Color.WHITE else Color.argb(120, 255, 255, 255))
        }
        AnimHelper.animateTabSwitch(tabGlider, idx, usableW, tabPanels, d)
    }

    @Suppress("UNCHECKED_CAST")
    private fun toggleDrawer() {
        drawerOpen = !drawerOpen
        val pair = drawerRoot.tag as Pair<List<View>, List<View>>
        AnimHelper.animateDrawer(drawerRoot, pair.first, pair.second, drawerOpen, dp(348f).toFloat())
    }

    private fun buildTelemetryPanel(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11f), dp(11f), dp(11f), dp(11f))
        }

        tvUavPowerCard = monoLabel("16.24V · 12.6A (86%)", "#00E676", 12.5f)
        tvTxPowerCard = monoLabel("8.08V · 1.05A (92%)", "#69B7FF", 12.5f)
        val pwrCard = sectionCard("双路电源电压与实时电流遥测 (飞机 + AX12 本机)")
        pwrCard.addView(twoColRow("无人机动力电 (MAVROS/UDP)", tvUavPowerCard, "AX12 本机双21700", tvTxPowerCard))
        col.addView(pwrCard)

        tvMapPtsCard = monoLabel("0 / 300k", "#00E676", 13.5f)
        tvCloudRateCard = monoLabel("15 Hz · 0 pts", "#69B7FF", 13.5f)
        val lioCard = sectionCard("FAST-LIO 三维体素建图 (无锁 SPSC VBO 管线)")
        lioCard.addView(twoColRow("全局累积体素点", tvMapPtsCard, "点云流帧率/单帧", tvCloudRateCard))
        val btnExportInDrawer = createSmallUtilBtn("导出标准 PCL Binary .pcd 三维点云地图") {
            exportCurrentPointCloudPcd()
        }
        lioCard.addView(btnExportInDrawer, LinearLayout.LayoutParams(MATCH_PARENT, dp(31f)).apply { topMargin = dp(6f) })
        col.addView(lioCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        tvPosX = monoLabel("0.00 m", "#FFFFFF", 13.5f)
        tvPosY = monoLabel("0.00 m", "#FFFFFF", 13.5f)
        tvPosZ = monoLabel("1.20 m", "#FFFFFF", 13.5f)
        tvVelNorm = monoLabel("0.00 m/s", "#FFFFFF", 13.5f)
        tvYaw = monoLabel("0.0°", "#FFFFFF", 13.5f)
        tvGoalDist = monoLabel("0.00 m", "#FFFFFF", 13.5f)

        val poseCard = sectionCard("无人机实时里程计 (/Odometry · world)")
        poseCard.addView(twoColRow("位置 X", tvPosX, "位置 Y", tvPosY))
        poseCard.addView(twoColRow("高度 Z", tvPosZ, "合速度 |V|", tvVelNorm))
        poseCard.addView(twoColRow("偏航 Yaw", tvYaw, "目标距离", tvGoalDist))
        col.addView(poseCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        tvClearanceCard = monoLabel("1.45 m", "#00E676", 13.5f)
        tvSolveCard = monoLabel("0.4 ms", "#69B7FF", 13.5f)
        tvVoxelCount = monoLabel("420 pts", "#FFFFFF", 13.5f)
        tvTrajLen = monoLabel("6.2 m", "#FFFFFF", 13.5f)

        val egoCard = sectionCard("EGO 局部规划与膨胀栅格 (二叉堆 A*)")
        egoCard.addView(twoColRow("最近障碍净空", tvClearanceCard, "B样条耗时", tvSolveCard))
        egoCard.addView(twoColRow("局部膨胀栅格数", tvVoxelCount, "局部轨迹弧长", tvTrajLen))
        col.addView(egoCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun buildParamsPanel(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11f), dp(11f), dp(11f), dp(11f))
        }

        val mapParamCard = sectionCard("FAST-LIO 三维点云建图与 GPU 渲染参数")
        mapParamCard.addView(sliderRow("体素哈希分辨率 (voxel_size)", 6, 30, 12, "m", 0.01f) { v ->
            hub.mapVoxelSize = v
        })
        mapParamCard.addView(sliderRow("点云高度切片上限 (z_slice)", 6, 60, 30, "m", 0.1f) { v ->
            hub.zSliceMax = v
        })
        mapParamCard.addView(sliderRow("OpenGL 点云粒径倍率", 6, 20, 10, "x", 0.1f) { v ->
            hub.pointSizeScale = v
        })
        col.addView(mapParamCard)

        val paramCard = sectionCard("EGO 避障膨胀与运动学参数 (无锁异步 + 180ms 防抖)")
        paramCard.addView(sliderRow("障碍膨胀半径 (obstacles_inflation)", 10, 65, 30, "m", 0.01f) { v ->
            hub.obstaclesInflation = v
            simEngine.requestReplanAsync()
            rosManager.setParamDebounced("/ego_planner_node/grid_map/obstacles_inflation", v)
        })
        paramCard.addView(sliderRow("最大规划速度 (manager/max_vel)", 5, 45, 20, "m/s", 0.1f) { v ->
            hub.maxVel = v
            rosManager.setParamDebounced("/ego_planner_node/manager/max_vel", v)
        })
        paramCard.addView(sliderRow("最大规划加速度 (manager/max_acc)", 5, 60, 30, "m/s²", 0.1f) { v ->
            hub.maxAcc = v
            rosManager.setParamDebounced("/ego_planner_node/manager/max_acc", v)
        })

        val zWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4f), 0, dp(5f))
        }
        val zTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        zTop.addView(TextView(this).apply {
            text = "默认目标高度 (goal_z)"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        tvGoalZSliderVal = monoLabel(String.format(Locale.US, "%.2f m", hub.goalZ), "#69B7FF", 11.5f)
        zTop.addView(tvGoalZSliderVal)
        zWrap.addView(zTop)

        sbGoalZRef = SeekBar(this).apply {
            max = 36
            progress = ((hub.goalZ * 10f).roundToInt() - 4).coerceIn(0, 36)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val target = (4 + progress) * 0.1f
                    val delta = target - hub.goalZ
                    val (realV, pinInfo) = simEngine.nudgeGoalZ(delta)
                    setTextIfChanged(tvGoalZSliderVal, String.format(Locale.US, "%.2f m", realV))
                    refreshCommandDockUi(pinInfo)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        zWrap.addView(sbGoalZRef)
        paramCard.addView(zWrap)
        col.addView(paramCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        val layerCard = sectionCard("三维感知图层与遮挡透视渲染")
        val layerRow0 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        layerRow0.addView(layerToggleBtn("FAST-LIO 点云图", true) { hub.showFastLioMap = it }, LinearLayout.LayoutParams(0, dp(32f), 1f))
        layerRow0.addView(layerToggleBtn("膨胀安全边界", true) { hub.showInflate = it }, LinearLayout.LayoutParams(0, dp(32f), 1f).apply { leftMargin = dp(6f) })
        layerCard.addView(layerRow0)

        val layerRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        layerRow2.addView(layerToggleBtn("B样条控制点", true) { hub.showCtrlPts = it }, LinearLayout.LayoutParams(0, dp(32f), 1f))
        layerRow2.addView(layerToggleBtn("8×8m感知框", true) { hub.showLocalBox = it }, LinearLayout.LayoutParams(0, dp(32f), 1f).apply { leftMargin = dp(6f) })
        layerCard.addView(layerRow2, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6f) })

        btnXrayDrawerRef = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                setXrayOcclusionState(!hub.xrayOcclusionEnabled)
            }
            AnimHelper.attachSpringTouch(this)
        }
        syncDrawerXrayToggleButton()
        layerCard.addView(btnXrayDrawerRef, LinearLayout.LayoutParams(MATCH_PARENT, dp(32f)).apply { topMargin = dp(6f) })

        val elrsBtn = layerToggleBtn("ELRS Backpack MAVLink UDP:14550 电压电流透传", hub.mavlinkBackpackEnabled) { en ->
            hub.mavlinkBackpackEnabled = en
            getSharedPreferences("ego_native_prefs", Context.MODE_PRIVATE).edit()
                .putBoolean("mavlinkBackpackEnabled", en)
                .apply()
        }
        layerCard.addView(elrsBtn, LinearLayout.LayoutParams(MATCH_PARENT, dp(32f)).apply { topMargin = dp(6f) })
        col.addView(layerCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        sv.addView(col)
        return sv
    }

    private fun buildRosPanel(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11f), dp(11f), dp(11f), dp(11f))
        }

        val scanCard = sectionCard("局域网无人机自动发现 (自动探测 11311 / 9090 并识别算法栈)")
        val scanOptRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnDrawerScan = TextView(this).apply {
            text = "🔍 扫描局域网无人机"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedColor(Color.parseColor("#00B865"), dp(6f))
            setOnClickListener { triggerLanScan(silentIfEmpty = false) }
        }
        AnimHelper.attachSpringTouch(btnDrawerScan)

        val btnAutoConnToggle = layerToggleBtn("搜到自动连", hub.autoConnectDiscovered) { enabled ->
            hub.autoConnectDiscovered = enabled
            getSharedPreferences("ego_native_prefs", Context.MODE_PRIVATE).edit()
                .putBoolean("autoConnectDiscovered", enabled)
                .apply()
        }
        scanOptRow.addView(btnDrawerScan, LinearLayout.LayoutParams(0, dp(33f), 1.25f))
        scanOptRow.addView(btnAutoConnToggle, LinearLayout.LayoutParams(0, dp(33f), 1f).apply { leftMargin = dp(6f) })
        scanCard.addView(scanOptRow)

        tvScanStatus = TextView(this).apply {
            text = "支持 Wi-Fi 局域网 / Ubuntu 热点 (10.42.0.1) / USB 共享网络自动搜索"
            setTextColor(Color.argb(165, 200, 215, 235))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            setPadding(0, dp(6f), 0, dp(4f))
        }
        scanCard.addView(tvScanStatus)

        discoveredListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scanCard.addView(discoveredListContainer)
        col.addView(scanCard)

        val connCard = sectionCard("统一连接管理 (RosTransport 接口 · 原生 TCPROS 免 rosbridge)")
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnDemo = createSmallUtilBtn("切回内置仿真") {
            rosManager.switchToDemoMode()
            simEngine.clearVoxelMap()
            simEngine.clearWaypointQueue()
            simEngine.requestReplanAsync()
            syncModeSpecificControls(force = true)
            refreshCommandDockUi()
            AnimHelper.showDjiToast(toastBanner, "已切回仿真演练模式", d)
        }
        val cfg = rosManager.topics
        btnProtoToggleRef = createSmallUtilBtn(
            if (cfg.protocol == "tcpros") "协议: 原生TCPROS" else "协议: rosbridge"
        ) {}
        btnProtoToggleRef.setOnClickListener {
            val nextProto = if (rosManager.topics.protocol == "tcpros") "rosbridge" else "tcpros"
            rosManager.topics.protocol = nextProto
            btnProtoToggleRef.text = if (nextProto == "tcpros") "协议: 原生TCPROS" else "协议: rosbridge"
            AnimHelper.showDjiToast(
                toastBanner,
                if (nextProto == "tcpros") "已选原生 TCPROS 直连 (直连 roscore 11311)" else "已选 rosbridge WebSocket (9090 端口)",
                d
            )
        }
        modeRow.addView(btnDemo, LinearLayout.LayoutParams(0, dp(32f), 1f))
        modeRow.addView(btnProtoToggleRef, LinearLayout.LayoutParams(0, dp(32f), 1f).apply { leftMargin = dp(6f) })
        connCard.addView(modeRow)

        inpMasterUri = labeledInput(connCard, "ROS_MASTER_URI (原生 TCPROS 直连默认 11311)", cfg.masterUri)
        inpWsUrl = labeledInput(connCard, "备用 rosbridge 地址 (仅 WebSocket 模式使用)", cfg.wsUrl)

        val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnConn = TextView(this).apply {
            text = "直连上方地址"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedColor(Color.parseColor("#1890FF"), dp(6f))
            setOnClickListener {
                saveCurrentTopics(quiet = true)
                connectWithConfig(rosManager.topics)
            }
        }
        AnimHelper.attachSpringTouch(btnConn)
        val btnDisc = createSmallUtilBtn("断开") {
            rosManager.disconnectAll(silent = false)
            AnimHelper.showDjiToast(toastBanner, "已断开机载 ROS1 连接", d)
        }
        actRow.addView(btnConn, LinearLayout.LayoutParams(0, dp(34f), 1f))
        actRow.addView(btnDisc, LinearLayout.LayoutParams(dp(68f), dp(34f)).apply { leftMargin = dp(6f) })
        connCard.addView(actRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })
        col.addView(connCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })

        val topicCard = sectionCard("FAST-LIO 与 EGO-Planner 话题映射 (扫描命中自动填充)")
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow.addView(createSmallUtilBtn("FAST-LIO+EGO") {
            inpOdom.setText("/Odometry")
            inpFastLioCloud.setText("/cloud_registered")
            inpFastLioPath.setText("/path")
            inpInflate.setText("/grid_map/occupancy_inflate")
            inpOptimal.setText("/ego_planner_node/optimal_list")
            inpGoal.setText("/move_base_simple/goal")
            saveCurrentTopics(quiet = false)
        }, LinearLayout.LayoutParams(0, dp(30f), 1f))
        presetRow.addView(createSmallUtilBtn("VINS+EGO") {
            inpOdom.setText("/vins_estimator/imu_propagate")
            inpFastLioCloud.setText("")
            inpFastLioPath.setText("")
            inpInflate.setText("/grid_map/occupancy_inflate")
            inpOptimal.setText("/ego_planner_node/optimal_list")
            inpGoal.setText("/move_base_simple/goal")
            saveCurrentTopics(quiet = false)
        }, LinearLayout.LayoutParams(0, dp(30f), 1f).apply { leftMargin = dp(5f) })
        presetRow.addView(createSmallUtilBtn("Swarm_0") {
            inpOdom.setText("/Odometry")
            inpFastLioCloud.setText("/cloud_registered")
            inpFastLioPath.setText("/path")
            inpInflate.setText("/drone_0_ego_planner_node/grid_map/occupancy_inflate")
            inpOptimal.setText("/drone_0_ego_planner_node/optimal_list")
            inpGoal.setText("/move_base_simple/goal")
            saveCurrentTopics(quiet = false)
        }, LinearLayout.LayoutParams(0, dp(30f), 1f).apply { leftMargin = dp(5f) })
        topicCard.addView(presetRow)

        inpOdom = labeledInput(topicCard, "里程计位姿 (FAST-LIO 默认 /Odometry)", cfg.odomTopic)
        inpFastLioCloud = labeledInput(topicCard, "FAST-LIO 世界系配准点云 (PointCloud2)", cfg.fastLioCloudTopic)
        inpFastLioPath = labeledInput(topicCard, "FAST-LIO 全局轨迹 (nav_msgs/Path)", cfg.fastLioPathTopic)
        inpInflate = labeledInput(topicCard, "EGO 局部膨胀栅格 (PointCloud2，可留空)", cfg.inflateTopic)
        inpOptimal = labeledInput(topicCard, "EGO 局部 B 样条轨迹 (Marker/Path)", cfg.optimalTopic)
        inpGoal = labeledInput(topicCard, "指点目标发布 (PoseStamped)", cfg.goalTopic)

        val btnSave = createSmallUtilBtn("保存话题配置") { saveCurrentTopics(quiet = false) }
        topicCard.addView(btnSave, LinearLayout.LayoutParams(MATCH_PARENT, dp(33f)).apply { topMargin = dp(8f) })

        val cmdCopyBtn = createSmallUtilBtn("复制机载 FAST-LIO 低带宽配置建议 (dense_publish_en)") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("fastlio_yaml", "publish:\n  path_en: true\n  scan_publish_en: true\n  dense_publish_en: false"))
            AnimHelper.showDjiToast(toastBanner, "已复制 FAST-LIO YAML 稀疏点云配置", d)
        }
        topicCard.addView(cmdCopyBtn, LinearLayout.LayoutParams(MATCH_PARENT, dp(32f)).apply { topMargin = dp(6f) })

        col.addView(topicCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(9f) })
        sv.addView(col)
        return sv
    }

    private fun triggerLanScan(silentIfEmpty: Boolean) {
        if (lanScanner.isScanning) {
            lanScanner.cancelScan()
            setTextIfChanged(btnQuickScan, "🔍 搜飞机")
            setTextIfChanged(btnDrawerScan, "🔍 扫描局域网无人机")
            setTextIfChanged(tvScanStatus, "扫描已手动停止")
            return
        }

        discoveredDrones.clear()
        discoveredListContainer.removeAllViews()
        setTextIfChanged(btnQuickScan, "⏳ 扫描中")
        setTextIfChanged(btnDrawerScan, "⏳ 正在扫描 (点击停止)")
        setTextIfChanged(tvScanStatus, "正在并发探测局域网 ROS1 机载电脑...")
        if (!silentIfEmpty) {
            AnimHelper.showDjiToast(toastBanner, "正在搜索局域网中的 ROS1 无人机 (11311 / 9090)...", d)
        }

        var autoConnectedThisRun = false

        lanScanner.startScan(
            baseConfig = rosManager.topics.copy(),
            onProgress = { pct, hint ->
                runOnUiThread {
                    setTextIfChanged(btnQuickScan, "⏳ $pct%")
                    setTextIfChanged(tvScanStatus, hint)
                }
            },
            onDroneFound = { drone ->
                runOnUiThread {
                    discoveredDrones.add(drone)
                    addDiscoveredDroneRow(drone)

                    if (hub.autoConnectDiscovered && !hub.rosConnected && !autoConnectedThisRun) {
                        autoConnectedThisRun = true
                        applyDiscoveredDroneAndConnect(drone, fromAuto = true)
                    }
                }
            },
            onComplete = { allFound, subnet ->
                runOnUiThread {
                    setTextIfChanged(btnQuickScan, if (allFound.isNotEmpty()) "🔍 在线(${allFound.size})" else "🔍 搜飞机")
                    setTextIfChanged(btnDrawerScan, "🔍 重新扫描局域网无人机")
                    if (allFound.isEmpty()) {
                        setTextIfChanged(tvScanStatus, "在 $subnet 未发现开放 11311(roscore) 或 9090 的无人机")
                        if (!silentIfEmpty) {
                            AnimHelper.showDjiToast(toastBanner, "未搜到无人机，请确认同处一个 Wi-Fi 或在连接页输入 IP", d)
                            openDrawerAtTab(2)
                        }
                    } else {
                        setTextIfChanged(tvScanStatus, "扫描完成 ($subnet)：共发现 ${allFound.size} 台机载 ROS1 设备")
                        if (!autoConnectedThisRun && !silentIfEmpty) {
                            AnimHelper.showDjiToast(toastBanner, "发现 ${allFound.size} 台无人机，请在列表点选连接", d)
                            openDrawerAtTab(2)
                        }
                    }
                }
            }
        )
    }

    private fun addDiscoveredDroneRow(drone: DiscoveredDrone) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9f), dp(7f), dp(9f), dp(7f))
            background = GradientDrawable().apply {
                setColor(Color.argb(145, 8, 16, 26))
                cornerRadius = dp(6f).toFloat()
                setStroke(1, Color.argb(95, 0, 230, 118))
            }
        }

        val infoCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val protoTag = if (drone.protocol == "tcpros") "TCPROS:${drone.port}" else "WS:${drone.port}"
        val titleTv = TextView(this).apply {
            text = "${drone.ip}  ·  ${drone.rttMs} ms"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11.5f)
            typeface = Typeface.MONOSPACE
        }
        val subTv = TextView(this).apply {
            text = "$protoTag  |  ${drone.stackSummary}"
            setTextColor(Color.parseColor("#00E676"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
        }
        infoCol.addView(titleTv)
        infoCol.addView(subTv)

        val btnBind = TextView(this).apply {
            text = "配对连接"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10f), dp(5f), dp(10f), dp(5f))
            background = roundedColor(Color.parseColor("#1890FF"), dp(5f))
            setOnClickListener {
                applyDiscoveredDroneAndConnect(drone, fromAuto = false)
            }
        }
        AnimHelper.attachSpringTouch(btnBind)

        row.addView(infoCol, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(btnBind, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(8f) })
        discoveredListContainer.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6f) })
    }

    private fun applyDiscoveredDroneAndConnect(drone: DiscoveredDrone, fromAuto: Boolean) {
        val sc = drone.suggestedConfig
        rosManager.topics.protocol = sc.protocol
        setTextIfChanged(btnProtoToggleRef, if (sc.protocol == "tcpros") "协议: 原生TCPROS" else "协议: rosbridge")

        inpMasterUri.setText(sc.masterUri)
        inpWsUrl.setText(sc.wsUrl)
        inpOdom.setText(sc.odomTopic)
        inpFastLioCloud.setText(sc.fastLioCloudTopic)
        inpFastLioPath.setText(sc.fastLioPathTopic)
        inpInflate.setText(sc.inflateTopic)
        inpOptimal.setText(sc.optimalTopic)
        inpGoal.setText(sc.goalTopic)

        saveCurrentTopics(quiet = true)
        connectWithConfig(rosManager.topics)
        if (!fromAuto && drawerOpen) toggleDrawer()

        val prefix = if (fromAuto) "已自动发现并连接" else "已配对连接"
        AnimHelper.showDjiToast(toastBanner, "$prefix ${drone.ip} (${drone.stackSummary} · ${drone.rttMs}ms)", d)
    }

    private fun connectWithConfig(cfg: TopicConfig) {
        simEngine.resetRosSessionState()
        simEngine.clearVoxelMap()
        rosManager.connect(cfg)
        syncModeSpecificControls(force = true)
        refreshCommandDockUi()
    }

    private fun exportCurrentPointCloudPcd() {
        fileIoExecutor.execute {
            try {
                val baseDir = getExternalFilesDir("maps") ?: File(filesDir, "maps")
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val outFile = File(baseDir, "fastlio_map_$stamp.pcd")
                val exported = simEngine.voxelMap.exportBinaryPcd(outFile)
                runOnUiThread {
                    if (exported <= 0) {
                        AnimHelper.showDjiToast(toastBanner, "当前点云地图为空，暂无可导出的三维点", d)
                    } else {
                        AnimHelper.showDjiToast(toastBanner, "已保存 $exported 点至 maps/${outFile.name}", d)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    AnimHelper.showDjiToast(toastBanner, "导出 PCD 失败: ${e.localizedMessage ?: "存储不可写"}", d)
                }
            }
        }
    }

    private fun formatCompactPoints(pts: Int): String {
        return if (pts >= 1000) String.format(Locale.US, "%.1fk", pts / 1000f) else pts.toString()
    }

    private fun setTextIfChanged(tv: TextView, newText: String) {
        if (!TextUtils.equals(tv.text, newText)) {
            tv.text = newText
        }
    }

    private fun updateHudReadouts(s: RenderSnapshot) {
        hsiView.invalidateIfChanged()
        compassView.invalidateIfChanged()
        syncModeSpecificControls()
        updateOcclusionHudVisibility(hub.droneCurrentlyOccluded && hub.xrayOcclusionEnabled && mapView.is3DMode)

        val spd = hypot(hypot(s.vx, s.vy), s.vz)
        val distGoal = hypot(hypot(s.goalX - s.uavX, s.goalY - s.uavY), s.goalZ - s.uavZ)
        val yawDeg = Math.toDegrees(s.yaw.toDouble()).toFloat()

        setTextIfChanged(tvModeBadge, "${s.px4Mode} · ${if (s.armed) "ARMED" else "DISARM"}")
        setTextIfChanged(tvConnStatus, "${hub.connectionLabel} | ${s.fsmState}")

        val lv = hub.connectionLevel
        if (lv != lastAppliedConnLevel) {
            lastAppliedConnLevel = lv
            statusAccent.background = when (lv) {
                1 -> accentAmber
                2 -> accentRed
                else -> accentGreen
            }
        }

        // 若没有正在选点且有正在执行的航线，实时更新剩余站数；飞完最后一站后自动收起指令坞
        if (!s.hasPreviewPin) {
            if (s.waypointQueueCount > 0 || commandDock.visibility == View.VISIBLE) {
                refreshCommandDockUi()
            }
        }

        setTextIfChanged(tvClearanceTop, String.format(Locale.US, "避障%.1fm", s.minClearance))
        setTextIfChanged(tvHzTop, if (hub.isRosMode) " | ${s.odomHz}Hz·${hub.renderFps}fps | " else " | ${hub.renderFps}fps | ")
        setTextIfChanged(tvBatTop, String.format(Locale.US, "%.1fV·%.1fA | 控%d%%", s.batVolt, s.batCurrentAmps, s.txBatPct))

        val batW = (resources.displayMetrics.widthPixels * (s.batPct.coerceIn(5, 100) / 100f)).roundToInt()
        if (abs(topBatFill.layoutParams.width - batW) > 2) {
            topBatFill.layoutParams.width = batW
            topBatFill.requestLayout()
        }

        setTextIfChanged(tvOsdH, String.format(Locale.US, "H  %.1f m", s.uavZ))
        setTextIfChanged(tvOsdHs, String.format(Locale.US, "   HS  %.1f m/s", spd))
        setTextIfChanged(tvOsdD, String.format(Locale.US, "D  %.1f m", distGoal))
        setTextIfChanged(tvOsdMapPts, "   MAP ${formatCompactPoints(s.mapPointCount)} pts")
        setTextIfChanged(tvOsdSubXyz, String.format(Locale.US, "X %.2f  Y %.2f  YAW %.0f°", s.uavX, s.uavY, yawDeg))

        if (drawerOpen && activeTabIndex == 0) {
            setTextIfChanged(tvUavPowerCard, String.format(Locale.US, "%.2fV · %.1fA (%d%%)", s.batVolt, s.batCurrentAmps, s.batPct))
            setTextIfChanged(tvTxPowerCard, String.format(Locale.US, "%.2fV · %.2fA (%d%%)", s.txBatVolt, s.txCurrentAmps, s.txBatPct))
            setTextIfChanged(tvMapPtsCard, "${formatCompactPoints(s.mapPointCount)} / 300k")
            setTextIfChanged(tvCloudRateCard, "${s.cloudHz} Hz · ${s.cloudScanPts} pts")
            setTextIfChanged(tvPosX, String.format(Locale.US, "%.2f m", s.uavX))
            setTextIfChanged(tvPosY, String.format(Locale.US, "%.2f m", s.uavY))
            setTextIfChanged(tvPosZ, String.format(Locale.US, "%.2f m", s.uavZ))
            setTextIfChanged(tvVelNorm, String.format(Locale.US, "%.2f m/s", spd))
            setTextIfChanged(tvYaw, String.format(Locale.US, "%.1f°", yawDeg))
            setTextIfChanged(tvGoalDist, String.format(Locale.US, "%.2f m", distGoal))
            setTextIfChanged(tvClearanceCard, String.format(Locale.US, "%.2f m", s.minClearance))
            setTextIfChanged(tvSolveCard, String.format(Locale.US, "%.2f ms", s.solveMs))
            setTextIfChanged(tvVoxelCount, "${s.voxelCount} pts")
            setTextIfChanged(tvTrajLen, String.format(Locale.US, "%.1f m", s.trajLength))
        }
    }

    private fun loadSavedTopics() {
        val sp = getSharedPreferences("ego_native_prefs", Context.MODE_PRIVATE)
        hub.autoConnectDiscovered = sp.getBoolean("autoConnectDiscovered", true)
        hub.mavlinkBackpackEnabled = sp.getBoolean("mavlinkBackpackEnabled", true)
        hub.xrayOcclusionEnabled = sp.getBoolean("xrayOcclusionEnabled", true)

        val cfg = TopicConfig(
            protocol = sp.getString("protocol", "tcpros") ?: "tcpros",
            masterUri = sp.getString("masterUri", "http://192.168.1.100:11311") ?: "http://192.168.1.100:11311",
            wsUrl = sp.getString("wsUrl", "ws://192.168.1.100:9090") ?: "ws://192.168.1.100:9090",
            odomTopic = sp.getString("odom", "/Odometry") ?: "/Odometry",
            fastLioCloudTopic = sp.getString("fastLioCloud", "/cloud_registered") ?: "/cloud_registered",
            fastLioPathTopic = sp.getString("fastLioPath", "/path") ?: "/path",
            inflateTopic = sp.getString("inflate", "/grid_map/occupancy_inflate") ?: "/grid_map/occupancy_inflate",
            optimalTopic = sp.getString("optimal", "/ego_planner_node/optimal_list") ?: "/ego_planner_node/optimal_list",
            goalTopic = sp.getString("goal", "/move_base_simple/goal") ?: "/move_base_simple/goal"
        )
        rosManager.topics = cfg
    }

    private fun saveCurrentTopics(quiet: Boolean) {
        val cfg = TopicConfig(
            protocol = rosManager.topics.protocol,
            masterUri = inpMasterUri.text.toString().trim(),
            wsUrl = inpWsUrl.text.toString().trim(),
            odomTopic = inpOdom.text.toString().trim(),
            fastLioCloudTopic = inpFastLioCloud.text.toString().trim(),
            fastLioPathTopic = inpFastLioPath.text.toString().trim(),
            inflateTopic = inpInflate.text.toString().trim(),
            optimalTopic = inpOptimal.text.toString().trim(),
            goalTopic = inpGoal.text.toString().trim()
        )
        getSharedPreferences("ego_native_prefs", Context.MODE_PRIVATE).edit()
            .putString("protocol", cfg.protocol)
            .putString("masterUri", cfg.masterUri)
            .putString("wsUrl", cfg.wsUrl)
            .putString("odom", cfg.odomTopic)
            .putString("fastLioCloud", cfg.fastLioCloudTopic)
            .putString("fastLioPath", cfg.fastLioPathTopic)
            .putString("inflate", cfg.inflateTopic)
            .putString("optimal", cfg.optimalTopic)
            .putString("goal", cfg.goalTopic)
            .apply()
        rosManager.updateTopicsAndResubscribe(cfg)
        if (!quiet) AnimHelper.showDjiToast(toastBanner, "FAST-LIO 与 EGO 话题配置已保存", d)
    }

    private fun dp(v: Float): Int = (v * d).roundToInt()

    private fun glassBg(radiusPx: Int, alpha: Int = 196): GradientDrawable = GradientDrawable().apply {
        setColor(Color.argb(alpha, 18, 20, 24))
        cornerRadius = radiusPx.toFloat()
        setStroke(maxOf(1, dp(0.8f)), Color.argb(32, 255, 255, 255))
    }

    private fun pillBg(fillCol: Int, strokeCol: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fillCol)
        cornerRadius = dp(20f).toFloat()
        setStroke(dp(1f), strokeCol)
    }

    private fun roundedColor(col: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(col)
        cornerRadius = radiusPx.toFloat()
    }

    private fun camPillBg(active: Boolean): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(15f).toFloat()
        setColor(if (active) Color.argb(62, 24, 144, 255) else Color.argb(198, 18, 20, 24))
        setStroke(dp(1f), if (active) Color.parseColor("#1890FF") else Color.argb(38, 255, 255, 255))
    }

    private fun monoLabel(txt: String, hexCol: String, sizeDp: Float): TextView = TextView(this).apply {
        text = txt
        isSingleLine = true
        setTextColor(Color.parseColor(hexCol))
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, sizeDp)
        typeface = Typeface.MONOSPACE
    }

    private fun createActionPill(label: String, accentHex: String, active: Boolean): TextView = TextView(this).apply {
        text = label
        isSingleLine = true
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(11f), dp(5.5f), dp(11.5f), dp(5.5f))
        val ac = Color.parseColor(accentHex)
        background = pillBg(if (active) Color.argb(52, Color.red(ac), Color.green(ac), Color.blue(ac)) else Color.argb(196, 18, 20, 24), ac)
        AnimHelper.attachSpringTouch(this)
    }

    private fun createCamPillBtn(txt: String, active: Boolean): TextView = TextView(this).apply {
        text = txt
        isSingleLine = true
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
        typeface = Typeface.DEFAULT_BOLD
        background = camPillBg(active)
        AnimHelper.attachSpringTouch(this)
    }

    private fun createSmallUtilBtn(txt: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = txt
        isSingleLine = true
        gravity = Gravity.CENTER
        setTextColor(Color.argb(225, 255, 255, 255))
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10f), dp(5.5f), dp(10f), dp(5.5f))
        background = glassBg(dp(6f))
        setOnClickListener { onClick() }
        AnimHelper.attachSpringTouch(this)
    }

    private fun sectionCard(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10f), dp(9f), dp(10f), dp(9f))
        background = GradientDrawable().apply {
            setColor(Color.argb(16, 255, 255, 255))
            cornerRadius = dp(8f).toFloat()
            setStroke(1, Color.argb(22, 255, 255, 255))
        }
        addView(TextView(this@MainActivity).apply {
            text = title
            setTextColor(Color.argb(145, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(6f))
        })
    }

    private fun twoColRow(lbl1: String, val1: TextView, lbl2: String, val2: TextView): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(3f), 0, dp(3f))
        }
        fun cell(l: String, v: TextView): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7f), dp(5f), dp(7f), dp(5f))
            background = roundedColor(Color.argb(95, 0, 0, 0), dp(5f))
            addView(TextView(this@MainActivity).apply {
                text = l
                setTextColor(Color.argb(120, 255, 255, 255))
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
            })
            addView(v)
        }
        row.addView(cell(lbl1, val1), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(cell(lbl2, val2), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(6f) })
        return row
    }

    private fun sliderRow(label: String, minI: Int, maxI: Int, defI: Int, unit: String, scale: Float, onVal: (Float) -> Unit): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4f), 0, dp(5f))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tvName = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
        }
        val tvVal = monoLabel(String.format(Locale.US, "%.2f %s", defI * scale, unit), "#69B7FF", 11.5f)
        top.addView(tvName, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        top.addView(tvVal)
        wrap.addView(top)

        val sb = SeekBar(this).apply {
            max = maxI - minI
            progress = defI - minI
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val realV = (minI + progress) * scale
                    setTextIfChanged(tvVal, String.format(Locale.US, "%.2f %s", realV, unit))
                    onVal(realV)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        wrap.addView(sb)
        return wrap
    }

    private fun layerToggleBtn(title: String, initial: Boolean, onToggle: (Boolean) -> Unit): TextView {
        var state = initial
        return TextView(this).apply {
            fun sync() {
                text = "$title: ${if (state) "ON" else "OFF"}"
                setTextColor(if (state) Color.WHITE else Color.argb(130, 255, 255, 255))
                background = pillBg(
                    if (state) Color.argb(52, 24, 144, 255) else Color.argb(90, 0, 0, 0),
                    if (state) Color.parseColor("#1890FF") else Color.argb(30, 255, 255, 255)
                )
            }
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            sync()
            setOnClickListener {
                state = !state
                sync()
                onToggle(state)
            }
            AnimHelper.attachSpringTouch(this)
        }
    }

    private fun labeledInput(parent: LinearLayout, title: String, initVal: String): EditText {
        parent.addView(TextView(this).apply {
            text = title
            setTextColor(Color.argb(130, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            setPadding(0, dp(6f), 0, dp(2f))
        })
        return EditText(this).apply {
            setText(initVal)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11.5f)
            typeface = Typeface.MONOSPACE
            setPadding(dp(8f), dp(5f), dp(8f), dp(5f))
            background = roundedColor(Color.argb(140, 0, 0, 0), dp(5f))
            parent.addView(this, LinearLayout.LayoutParams(MATCH_PARENT, dp(31f)))
        }
    }
}
