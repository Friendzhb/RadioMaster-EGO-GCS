package com.radiomaster.egogcs.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.animation.OvershootInterpolator
import com.radiomaster.egogcs.engine.FastLioVoxelMap
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.RenderSnapshot
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/**
 * 航空级真三维深度感知 + 硬件 Z-Buffer 双遍遮挡透视虚线渲染引擎 (OpenGL ES 2.0 · 60FPS 零 GC)：
 *
 * 1. 强烈 3D 体积感构建：
 *    - 天际线大气渐变的透视穹顶 + 远景指数深度雾 (Atmospheric Depth Fog)；
 *    - 定向太阳/天光三维明暗着色 (Lambertian 法线光照 + 底部环境光遮蔽 AO 暗影 + 1m/2m 等高刻度环)；
 *    - 点云球面法线微浮雕与单遍 Eye-Dome 轮廓加深，告别扁平碎点；
 *    - DJI FlightHub 风格三维轨迹高程垂幕 (Altitude Drop-Curtain) 与地面投影暗影。
 * 2. 智能视线遮挡与双态透视动画：
 *    - 相机→无人机视线圆柱 (LOS Tunnel) 动态避让：挡住飞机视线的墙柱在 180ms 内平滑融化为 24% 磨砂半透明线框玻璃，点云墙面采用 2x2 屏幕空间抖动镂空；
 *    - 硬件深度缓冲双遍测试 (GL_GREATER X-Ray Pass + GL_LEQUAL Solid Pass)：任何被墙体、柱林或点云遮挡的轨迹段自动逐像素化作向前流动的霓虹透视虚线，被遮挡的无人机自动呈现全息扫描轮廓与脉冲定位环。
 */
class GlPointCloudMapView(
    context: Context,
    private val hub: GcsSharedHub,
    private val voxelMap: FastLioVoxelMap,
    private val onHudTick: (RenderSnapshot) -> Unit,
    private val onInterceptDrawerClose: () -> Boolean,
    private val onSingleTapPreviewPin: (wx: Float, wy: Float) -> Unit,
    private val onLongPressQuickFly: (wx: Float, wy: Float) -> Unit,
    private val onFollowStateChanged: (followMode: Int, toastMsg: String?) -> Unit
) : GLSurfaceView(context), GLSurfaceView.Renderer {

    companion object {
        private const val MAX_ENV_LINE_VERTS = 24_000
        private const val MAX_ENV_TRI_VERTS = 44_000
        private const val MAX_ACTOR_LINE_VERTS = 8_000
        private const val MAX_ACTOR_TRI_VERTS = 16_000

        // 8 floats per vertex (32 bytes, cache-aligned): x, y, z, r, g, b, a, arcDist
        private const val FLOATS_PER_VERT = 8
        private const val STRIDE_VERT = FLOATS_PER_VERT * 4

        // 1. 天际大气穹顶着色器 (NDC 全屏渐变，随相机俯仰与 3D/2D 过渡动态响应)
        private const val SKY_VS = """
            attribute vec2 aNdcPos;
            varying vec2 vUv;
            void main() {
                vUv = aNdcPos * 0.5 + 0.5;
                gl_Position = vec4(aNdcPos, 0.999, 1.0);
            }
        """

        private const val SKY_FS = """
            precision mediump float;
            uniform float uHorizonY;
            uniform float uBlend3D;
            varying vec2 vUv;
            void main() {
                vec3 flatBg = vec3(0.043, 0.051, 0.066);
                vec3 zenith = vec3(0.024, 0.038, 0.068);
                vec3 horizonGlow = vec3(0.075, 0.132, 0.215);
                vec3 groundDark = vec3(0.036, 0.046, 0.062);

                float above = smoothstep(uHorizonY - 0.08, 1.0, vUv.y);
                float band = exp(-abs(vUv.y - uHorizonY) * 10.5);
                vec3 sky3d = mix(groundDark, zenith, above) + horizonGlow * band * 0.52;
                gl_FragColor = vec4(mix(flatBg, sky3d, uBlend3D), 1.0);
            }
        """

        // 2. 点云球体浮雕 + Eye-Dome 深度描边 + 视线隧道自动镂空着色器
        private const val POINT_CLOUD_VS = """
            uniform mat4 uMVP;
            uniform float uZMax;
            uniform float uPointScale;
            uniform float uZFlatten;
            uniform int uColorMode;
            uniform vec3 uEyePos;
            uniform vec3 uDronePos;
            uniform float uFogSpan;
            uniform int uXrayOn;
            attribute vec3 aPos;
            attribute float aMeta;
            varying vec4 vColor;
            varying float vLosFade;
            varying float vFog;

            vec3 heightRamp(float t) {
                float c = clamp(t, 0.0, 1.0);
                if (c < 0.33) {
                    float u = c / 0.33;
                    return mix(vec3(0.08, 0.56, 1.00), vec3(0.00, 0.90, 0.52), u);
                } else if (c < 0.68) {
                    float u = (c - 0.33) / 0.35;
                    return mix(vec3(0.00, 0.90, 0.52), vec3(1.00, 0.78, 0.08), u);
                } else {
                    float u = (c - 0.68) / 0.32;
                    return mix(vec3(1.00, 0.78, 0.08), vec3(1.00, 0.24, 0.20), u);
                }
            }

            void main() {
                if (aPos.z > uZMax) {
                    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
                    gl_PointSize = 0.0;
                    vColor = vec4(0.0);
                    vLosFade = 1.0;
                    vFog = 0.0;
                    return;
                }
                vec3 worldPos = vec3(aPos.x, aPos.y, aPos.z * uZFlatten);
                vec4 clip = uMVP * vec4(worldPos, 1.0);
                gl_Position = clip;
                float dist = max(1.8, clip.w);
                gl_PointSize = clamp(uPointScale / dist, 2.4, 9.2);

                vec3 rgb;
                if (uColorMode == 1) {
                    float it = clamp(aMeta, 0.0, 1.0);
                    rgb = mix(vec3(0.12, 0.68, 1.00), vec3(1.00, 0.48, 0.10), it);
                } else if (uColorMode == 2) {
                    float hz = clamp((aPos.z + 0.2) / 3.0, 0.15, 1.0);
                    rgb = vec3(0.05, 0.88, 0.48) * (0.45 + 0.55 * hz);
                } else {
                    float hz = clamp((aPos.z + 0.15) / max(0.8, uZMax), 0.0, 1.0);
                    rgb = heightRamp(hz);
                }

                // 计算点云是否挡在「相机 -> 无人机」视线圆锥内
                vLosFade = 1.0;
                if (uXrayOn == 1 && worldPos.z > 0.15) {
                    vec3 seg = uDronePos - uEyePos;
                    float segLen2 = dot(seg, seg);
                    if (segLen2 > 0.25) {
                        float t = dot(worldPos - uEyePos, seg) / segLen2;
                        if (t > 0.08 && t < 0.94) {
                            vec3 closest = uEyePos + seg * t;
                            float dRay = length(worldPos - closest);
                            vLosFade = smoothstep(0.35, 1.35, dRay);
                        }
                    }
                }

                vFog = clamp(( length(worldPos.xy - uDronePos.xy) - uFogSpan * 0.85 ) / max(6.0, uFogSpan * 1.4), 0.0, 0.68);
                float alpha = (aPos.z < 0.06) ? 0.50 : 0.95;
                vColor = vec4(rgb, alpha);
            }
        """

        private const val POINT_CLOUD_FS = """
            precision mediump float;
            varying vec4 vColor;
            varying float vLosFade;
            varying float vFog;
            void main() {
                vec2 uv = gl_PointCoord - vec2(0.5);
                float r2 = dot(uv, uv);
                if (r2 > 0.25) discard;

                // 视线遮挡区域采用屏幕空间网格抖动镂空，既保留墙面存在感与硬件深度，又让后方飞机和虚线清晰透出
                if (vLosFade < 0.72) {
                    vec2 cell = mod(floor(gl_FragCoord.xy), 2.0);
                    float bayer = (cell.x * 0.5 + cell.y * 0.25);
                    if (vLosFade < bayer + 0.22) discard;
                }

                // 球面法线微光照 + Eye-Dome 边缘轮廓加深，赋予点云强烈立体颗粒感
                float nz = sqrt(max(0.0, 1.0 - r2 * 4.0));
                vec3 norm = vec3(uv.x * 2.0, -uv.y * 2.0, nz);
                float diff = max(0.0, dot(norm, vec3(0.38, 0.48, 0.79)));
                float edlRim = 1.0 - smoothstep(0.15, 0.25, r2) * 0.42;
                vec3 litRgb = vColor.rgb * (0.58 + 0.56 * diff) * edlRim;
                vec3 fogRgb = mix(litRgb, vec3(0.042, 0.058, 0.085), vFog);
                gl_FragColor = vec4(fogRgb, vColor.a);
            }
        """

        // 3. 标准三维图元着色器 (带指数远景深度雾)
        private const val PRIM_VS = """
            uniform mat4 uMVP;
            uniform vec2 uFocusXY;
            uniform float uFogSpan;
            attribute vec3 aPos;
            attribute vec4 aColor;
            attribute float aArc;
            varying vec4 vColor;
            varying float vFog;
            void main() {
                gl_Position = uMVP * vec4(aPos, 1.0);
                vColor = aColor;
                float d = length(aPos.xy - uFocusXY);
                vFog = clamp((d - uFogSpan * 0.95) / max(8.0, uFogSpan * 1.5), 0.0, 0.65);
            }
        """

        private const val PRIM_FS = """
            precision mediump float;
            varying vec4 vColor;
            varying float vFog;
            void main() {
                vec3 rgb = mix(vColor.rgb, vec3(0.042, 0.055, 0.078), vFog);
                gl_FragColor = vec4(rgb, vColor.a);
            }
        """

        // 4. 硬件深度遮挡 X-Ray 着色器 (仅在 GL_GREATER 即被障碍物/点云挡住的像素上触发！)
        //    - aArc >= 0: 世界空间等距流动透视虚线 (轨迹、航线、选点光柱)
        //    - aArc < 0 : 无人机机身全息扫描线脉冲轮廓
        private const val OCCLUDED_VS = """
            uniform mat4 uMVP;
            attribute vec3 aPos;
            attribute vec4 aColor;
            attribute float aArc;
            varying vec4 vColor;
            varying float vArc;
            void main() {
                gl_Position = uMVP * vec4(aPos, 1.0);
                vColor = aColor;
                vArc = aArc;
            }
        """

        private const val OCCLUDED_FS = """
            precision mediump float;
            uniform float uTime;
            varying vec4 vColor;
            varying float vArc;
            void main() {
                if (vArc >= 0.0) {
                    float dash = fract(vArc * 2.5 - uTime * 2.2);
                    if (dash > 0.52) discard;
                    float edge = smoothstep(0.0, 0.08, dash) * (1.0 - smoothstep(0.44, 0.52, dash));
                    vec3 xrayRgb = mix(vColor.rgb, vec3(0.22, 0.95, 1.00), 0.45);
                    gl_FragColor = vec4(xrayRgb, clamp(vColor.a * 0.72 * (0.7 + 0.3 * edge), 0.18, 0.82));
                } else {
                    float scan = 0.62 + 0.38 * sin(uTime * 7.0 + gl_FragCoord.y * 0.45);
                    vec3 holoRgb = mix(vColor.rgb, vec3(0.10, 0.92, 1.00), 0.62);
                    gl_FragColor = vec4(holoRgb * scan, 0.78);
                }
            }
        """
    }

    private val density = resources.displayMetrics.density

    var is3DMode: Boolean = true
        private set
    @Volatile private var projBlend: Float = 1.0f
    private var blendAnimator: ValueAnimator? = null

    @Volatile private var pinAnimScale: Float = 1.0f
    private var pinAnimator: ValueAnimator? = null

    @Volatile var followMode: Int = 1
        private set

    @Volatile private var camYawDesired = 0.62f
    @Volatile private var camPitchDesired = 0.62f
    @Volatile private var worldHalfSpanDesired = 6.6f

    private var camYaw = 0.62f
    private var camPitch = 0.62f
    private var worldHalfSpan = 6.6f
    @Volatile private var camPanX = 0f
    @Volatile private var camPanY = 0f
    private var camFocusX = -5.5f
    private var camFocusY = -4.2f
    private var camFocusZ = 0.45f

    private var curEyeX = -8f
    private var curEyeY = -8f
    private var curEyeZ = 5f

    // 每个实体障碍物的平滑视线避让透明度动画状态 + 无人机被遮挡平滑系数
    private val obsSmoothAlpha = FloatArray(24) { 0.94f }
    private var droneOccludedBlend = 0f
    private var shaderClockSec = 0f

    private var viewportW = 1
    private var viewportH = 1
    private var lastFrameNs = System.nanoTime()
    private var hudSyncAcc = 0f
    private var fpsFrameCount = 0
    private var fpsTimeAcc = 0f

    private var multiTouchActive = false

    private val viewMatrix = FloatArray(16)
    private val projMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val glTmpInv16 = FloatArray(16)
    private val invVpLock = Any()
    private val sharedInvVp = FloatArray(16)
    private var invVpValid = false

    private val uiInvCopy16 = FloatArray(16)
    private val uiNearIn4 = FloatArray(4)
    private val uiFarIn4 = FloatArray(4)
    private val uiNearOut4 = FloatArray(4)
    private val uiFarOut4 = FloatArray(4)
    private val uiGroundOut2 = FloatArray(2)

    private val rippleLock = Any()
    private val rippleX = FloatArray(6)
    private val rippleY = FloatArray(6)
    private val rippleAge = FloatArray(6) { -1f }

    // 天际穹顶全屏三角带顶点
    private val skyQuadBuf: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }

    // 环境批次数组 (地板网格/接触阴影、三维实体障碍、视线半透明玻璃障碍、半透明特效垂幕)
    private val groundLineArray = FloatArray(MAX_ENV_LINE_VERTS * FLOATS_PER_VERT)
    private var groundLineVerts = 0

    private val solidObsTriArray = FloatArray(MAX_ENV_TRI_VERTS * FLOATS_PER_VERT)
    private var solidObsTriVerts = 0
    private val solidObsEdgeArray = FloatArray(MAX_ENV_LINE_VERTS * FLOATS_PER_VERT)
    private var solidObsEdgeVerts = 0

    private val glassObsTriArray = FloatArray((MAX_ENV_TRI_VERTS / 2) * FLOATS_PER_VERT)
    private var glassObsTriVerts = 0
    private val glassObsEdgeArray = FloatArray((MAX_ENV_LINE_VERTS / 2) * FLOATS_PER_VERT)
    private var glassObsEdgeVerts = 0

    private val fxAlphaTriArray = FloatArray(MAX_ENV_TRI_VERTS * FLOATS_PER_VERT)
    private var fxAlphaTriVerts = 0

    // 可被遮挡并自动切换实线/流动虚线的主角批次 (B样条轨迹、多航点航线、选点光柱、无人机)
    private val actorLineArray = FloatArray(MAX_ACTOR_LINE_VERTS * FLOATS_PER_VERT)
    private var actorLineVerts = 0
    private val actorTriArray = FloatArray(MAX_ACTOR_TRI_VERTS * FLOATS_PER_VERT)
    private var actorTriVerts = 0

    private val envLineBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ENV_LINE_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val envTriBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ENV_TRI_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val actorLineBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ACTOR_LINE_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val actorTriBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ACTOR_TRI_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()

    // Shader Programs & Handles
    private var progSky = 0
    private var aSkyPos = 0
    private var uSkyHorizonY = 0
    private var uSkyBlend3D = 0

    private var progCloud = 0
    private var uCloudMvp = 0
    private var uCloudZMax = 0
    private var uCloudPointScale = 0
    private var uCloudZFlatten = 0
    private var uCloudColorMode = 0
    private var uCloudEyePos = 0
    private var uCloudDronePos = 0
    private var uCloudFogSpan = 0
    private var uCloudXrayOn = 0
    private var aCloudPos = 0
    private var aCloudMeta = 0

    private var progPrim = 0
    private var uPrimMvp = 0
    private var uPrimFocusXY = 0
    private var uPrimFogSpan = 0
    private var aPrimPos = 0
    private var aPrimColor = 0
    private var aPrimArc = 0

    private var progOccluded = 0
    private var uOccMvp = 0
    private var uOccTime = 0
    private var aOccPos = 0
    private var aOccColor = 0
    private var aOccArc = 0

    // 5 个独立硬件 VBO
    private var vboCloudId = 0
    private var vboEnvLineId = 0
    private var vboEnvTriId = 0
    private var vboActorLineId = 0
    private var vboActorTriId = 0

    private val uiTickRunnable = Runnable {
        onHudTick(hub.latestSnapshot)
    }

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val factor = 1.0f / detector.scaleFactor.coerceIn(0.8f, 1.25f)
            worldHalfSpanDesired = (worldHalfSpanDesired * factor).coerceIn(2.2f, 65.0f)
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (e2.pointerCount >= 2) {
                if (followMode != 0) {
                    val s = hub.latestSnapshot
                    camPanX = s.uavX
                    camPanY = s.uavY
                    followMode = 0
                    onFollowStateChanged(0, null)
                }
                panCameraByScreenDelta(distanceX, distanceY)
                return true
            }

            if (scaleDetector.isInProgress) return true

            if (is3DMode && followMode != 0) {
                if (followMode == 2 && abs(distanceX) > abs(distanceY) * 1.4f && abs(distanceX) > 4f * density) {
                    followMode = 1
                    onFollowStateChanged(1, null)
                }
                if (followMode == 1) {
                    camYawDesired += distanceX * 0.0072f / density * 1.6f
                }
                camPitchDesired = (camPitchDesired + distanceY * 0.0062f / density * 1.6f).coerceIn(0.20f, 1.44f)
            } else {
                if (!is3DMode && followMode != 0 && hypot(distanceX, distanceY) > 6f * density) {
                    val s = hub.latestSnapshot
                    camPanX = s.uavX
                    camPanY = s.uavY
                    followMode = 0
                    onFollowStateChanged(0, null)
                }
                panCameraByScreenDelta(distanceX, distanceY)
            }
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (onInterceptDrawerClose()) return true
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            recenterLockDrone()
            onFollowStateChanged(1, "已平滑回中并锁定跟随无人机")
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (onInterceptDrawerClose()) return true
            val world = unprojectToGroundUiThread(e.x, e.y) ?: return true
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            spawnRipple(world[0], world[1])
            triggerPinSpringAnim()
            onSingleTapPreviewPin(world[0], world[1])
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (multiTouchActive || scaleDetector.isInProgress) return
            if (onInterceptDrawerClose()) return
            val world = unprojectToGroundUiThread(e.x, e.y) ?: return
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            spawnRipple(world[0], world[1])
            onLongPressQuickFly(world[0], world[1])
        }
    })

    private fun panCameraByScreenDelta(distanceX: Float, distanceY: Float) {
        val metersPerPx = (worldHalfSpan * 2.0f) / max(1f, viewportH.toFloat())
        val effY = camYaw * projBlend
        val cosY = cos(effY)
        val sinY = sin(effY)
        val dxScreen = distanceX * metersPerPx
        val dyScreen = -distanceY * metersPerPx
        camPanX += dxScreen * cosY - dyScreen * sinY
        camPanY += dxScreen * sinY + dyScreen * cosY
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        preserveEGLContextOnPause = true
        setRenderer(this)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> multiTouchActive = true
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> multiTouchActive = false
        }
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    fun startLoop() {
        onResume()
    }

    fun stopLoop() {
        onPause()
    }

    fun triggerPinSpringAnim() {
        pinAnimator?.cancel()
        pinAnimScale = 0.15f
        pinAnimator = ValueAnimator.ofFloat(0.15f, 1.0f).apply {
            duration = 260L
            interpolator = OvershootInterpolator(1.6f)
            addUpdateListener { anim -> pinAnimScale = anim.animatedValue as Float }
            start()
        }
    }

    private fun animateProjectionTo(target3D: Boolean) {
        if (is3DMode == target3D) return
        is3DMode = target3D
        blendAnimator?.cancel()
        blendAnimator = ValueAnimator.ofFloat(projBlend, if (target3D) 1f else 0f).apply {
            duration = 420L
            interpolator = AnimHelper.EASE_OUT_EXPO
            addUpdateListener { anim -> projBlend = anim.animatedValue as Float }
            start()
        }
    }

    fun toggle3D2DWithAnimation(): Boolean {
        animateProjectionTo(!is3DMode)
        return is3DMode
    }

    fun recenterLockDrone() {
        camPanX = 0f
        camPanY = 0f
        followMode = 1
    }

    fun cycleFollowMode(): Pair<Int, String> {
        followMode = when (followMode) {
            1 -> {
                camPanX = 0f; camPanY = 0f
                camPitchDesired = 0.44f
                2
            }
            2 -> {
                val s = hub.latestSnapshot
                camPanX = s.uavX
                camPanY = s.uavY
                0
            }
            else -> {
                camPanX = 0f; camPanY = 0f
                camPitchDesired = 0.62f
                1
            }
        }
        val tip = when (followMode) {
            2 -> "相机视角：机头低仰角追尾 (沉浸式穿障遮挡透视体验)"
            0 -> "相机视角：自由平移漫游 (双击屏幕可回中飞机)"
            else -> "相机视角：阻尼锁定飞机 · 360° 自由环视"
        }
        return followMode to tip
    }

    fun zoomBy(factor: Float) {
        worldHalfSpanDesired = (worldHalfSpanDesired / factor).coerceIn(2.2f, 65.0f)
    }

    fun resetCameraSmooth() {
        followMode = 1
        camYawDesired = 0.62f
        camPitchDesired = 0.62f
        worldHalfSpanDesired = 6.6f
        camPanX = 0f
        camPanY = 0f
        animateProjectionTo(true)
    }

    fun cycleColorMode(): Pair<Int, String> {
        val next = (hub.pointColorMode + 1) % 3
        hub.pointColorMode = next
        val tip = when (next) {
            1 -> "点云着色：LiDAR 反射率强度伪彩"
            2 -> "点云着色：战术翠绿高对比单色"
            else -> "点云着色：Z 轴高度彩虹伪彩"
        }
        return next to tip
    }

    fun spawnRipple(wx: Float, wy: Float) {
        synchronized(rippleLock) {
            for (i in rippleAge.indices) {
                if (rippleAge[i] < 0f || rippleAge[i] > 1.15f) {
                    rippleX[i] = wx
                    rippleY[i] = wy
                    rippleAge[i] = 0f
                    return
                }
            }
            rippleX[0] = wx; rippleY[0] = wy; rippleAge[0] = 0f
        }
    }

    private fun unprojectToGroundUiThread(sx: Float, sy: Float): FloatArray? {
        val vw = max(1, width).toFloat()
        val vh = max(1, height).toFloat()
        val ndcX = (sx / vw) * 2f - 1f
        val ndcY = 1f - (sy / vh) * 2f

        synchronized(invVpLock) {
            if (!invVpValid) return null
            System.arraycopy(sharedInvVp, 0, uiInvCopy16, 0, 16)
        }

        uiNearIn4[0] = ndcX; uiNearIn4[1] = ndcY; uiNearIn4[2] = -1f; uiNearIn4[3] = 1f
        uiFarIn4[0] = ndcX; uiFarIn4[1] = ndcY; uiFarIn4[2] = 1f; uiFarIn4[3] = 1f
        Matrix.multiplyMV(uiNearOut4, 0, uiInvCopy16, 0, uiNearIn4, 0)
        Matrix.multiplyMV(uiFarOut4, 0, uiInvCopy16, 0, uiFarIn4, 0)
        if (abs(uiNearOut4[3]) < 1e-6f || abs(uiFarOut4[3]) < 1e-6f) return null

        val nx = uiNearOut4[0] / uiNearOut4[3]
        val ny = uiNearOut4[1] / uiNearOut4[3]
        val nz = uiNearOut4[2] / uiNearOut4[3]
        val fx = uiFarOut4[0] / uiFarOut4[3]
        val fy = uiFarOut4[1] / uiFarOut4[3]
        val fz = uiFarOut4[2] / uiFarOut4[3]

        val dz = fz - nz
        if (abs(dz) < 1e-5f) return null
        val t = -nz / dz
        if (t < 0f || t > 1.5f) return null

        val wx = nx + t * (fx - nx)
        val wy = ny + t * (fy - ny)
        if (!hub.isRosMode) {
            uiGroundOut2[0] = wx.coerceIn(-7.6f, 7.6f)
            uiGroundOut2[1] = wy.coerceIn(-7.6f, 7.6f)
        } else {
            uiGroundOut2[0] = wx.coerceIn(-500f, 500f)
            uiGroundOut2[1] = wy.coerceIn(-500f, 500f)
        }
        return uiGroundOut2
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.038f, 0.048f, 0.065f, 1.0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        progSky = buildProgram(SKY_VS, SKY_FS)
        aSkyPos = GLES20.glGetAttribLocation(progSky, "aNdcPos")
        uSkyHorizonY = GLES20.glGetUniformLocation(progSky, "uHorizonY")
        uSkyBlend3D = GLES20.glGetUniformLocation(progSky, "uBlend3D")

        progCloud = buildProgram(POINT_CLOUD_VS, POINT_CLOUD_FS)
        uCloudMvp = GLES20.glGetUniformLocation(progCloud, "uMVP")
        uCloudZMax = GLES20.glGetUniformLocation(progCloud, "uZMax")
        uCloudPointScale = GLES20.glGetUniformLocation(progCloud, "uPointScale")
        uCloudZFlatten = GLES20.glGetUniformLocation(progCloud, "uZFlatten")
        uCloudColorMode = GLES20.glGetUniformLocation(progCloud, "uColorMode")
        uCloudEyePos = GLES20.glGetUniformLocation(progCloud, "uEyePos")
        uCloudDronePos = GLES20.glGetUniformLocation(progCloud, "uDronePos")
        uCloudFogSpan = GLES20.glGetUniformLocation(progCloud, "uFogSpan")
        uCloudXrayOn = GLES20.glGetUniformLocation(progCloud, "uXrayOn")
        aCloudPos = GLES20.glGetAttribLocation(progCloud, "aPos")
        aCloudMeta = GLES20.glGetAttribLocation(progCloud, "aMeta")

        progPrim = buildProgram(PRIM_VS, PRIM_FS)
        uPrimMvp = GLES20.glGetUniformLocation(progPrim, "uMVP")
        uPrimFocusXY = GLES20.glGetUniformLocation(progPrim, "uFocusXY")
        uPrimFogSpan = GLES20.glGetUniformLocation(progPrim, "uFogSpan")
        aPrimPos = GLES20.glGetAttribLocation(progPrim, "aPos")
        aPrimColor = GLES20.glGetAttribLocation(progPrim, "aColor")
        aPrimArc = GLES20.glGetAttribLocation(progPrim, "aArc")

        progOccluded = buildProgram(OCCLUDED_VS, OCCLUDED_FS)
        uOccMvp = GLES20.glGetUniformLocation(progOccluded, "uMVP")
        uOccTime = GLES20.glGetUniformLocation(progOccluded, "uTime")
        aOccPos = GLES20.glGetAttribLocation(progOccluded, "aPos")
        aOccColor = GLES20.glGetAttribLocation(progOccluded, "aColor")
        aOccArc = GLES20.glGetAttribLocation(progOccluded, "aArc")

        val bufs = IntArray(5)
        GLES20.glGenBuffers(5, bufs, 0)
        vboCloudId = bufs[0]
        vboEnvLineId = bufs[1]
        vboEnvTriId = bufs[2]
        vboActorLineId = bufs[3]
        vboActorTriId = bufs[4]

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboCloudId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, FastLioVoxelMap.MAX_POINTS * FastLioVoxelMap.BYTES_PER_VERTEX, null, GLES20.GL_DYNAMIC_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboEnvLineId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ENV_LINE_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboEnvTriId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ENV_TRI_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ACTOR_LINE_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ACTOR_TRI_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        voxelMap.notifyGlContextRecreated()
        lastFrameNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportW = max(1, width)
        viewportH = max(1, height)
        GLES20.glViewport(0, 0, viewportW, viewportH)
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        val rawDt = (nowNs - lastFrameNs) * 1e-9f
        val dt = rawDt.coerceIn(0.001f, 0.05f)
        lastFrameNs = nowNs
        shaderClockSec = (shaderClockSec + dt) % 3600f

        fpsFrameCount++
        fpsTimeAcc += rawDt
        if (fpsTimeAcc >= 0.5f) {
            hub.renderFps = (fpsFrameCount / fpsTimeAcc).roundToInt().coerceIn(1, 120)
            fpsFrameCount = 0
            fpsTimeAcc = 0f
        }

        val snap = hub.latestSnapshot
        updateCameraMatrices(dt, snap)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        // Pass 0: 3D 天际大气渐变背景穹顶 (不写深度)
        drawSkyDomePass()

        groundLineVerts = 0
        solidObsTriVerts = 0
        solidObsEdgeVerts = 0
        glassObsTriVerts = 0
        glassObsEdgeVerts = 0
        fxAlphaTriVerts = 0
        actorLineVerts = 0
        actorTriVerts = 0

        buildSceneBatches(dt, snap)

        val zFlat = 0.08f + 0.92f * projBlend

        // Pass 1: 地面透视网格、坐标轴与地面接触 AO 暗影 (不写深度以防地面闪烁)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDepthMask(false)
        flushEnvLines(groundLineArray, groundLineVerts, max(1f, 1.15f * density))

        // Pass 2: 写入硬件 Z-Buffer 的三维立体遮挡物 (三维光影柱墙 + 点云微球体 + 视线半透明玻璃体)
        GLES20.glDepthMask(true)
        flushEnvTriangles(solidObsTriArray, solidObsTriVerts)
        flushEnvLines(solidObsEdgeArray, solidObsEdgeVerts, max(1f, 1.1f * density))

        val cloudVerts = voxelMap.syncToGpuVbo(vboCloudId)
        if (hub.showFastLioMap && cloudVerts > 0) {
            GLES20.glUseProgram(progCloud)
            GLES20.glUniformMatrix4fv(uCloudMvp, 1, false, vpMatrix, 0)
            GLES20.glUniform1f(uCloudZMax, hub.zSliceMax)
            val fovScale = (viewportH / 720f).coerceAtLeast(0.75f) * 36.0f * hub.pointSizeScale * density
            GLES20.glUniform1f(uCloudPointScale, fovScale * (0.35f + 0.65f * projBlend))
            GLES20.glUniform1f(uCloudZFlatten, zFlat)
            GLES20.glUniform1i(uCloudColorMode, hub.pointColorMode)
            GLES20.glUniform3f(uCloudEyePos, curEyeX, curEyeY, curEyeZ)
            GLES20.glUniform3f(uCloudDronePos, snap.uavX, snap.uavY, snap.uavZ * zFlat)
            GLES20.glUniform1f(uCloudFogSpan, worldHalfSpan * 2.2f)
            GLES20.glUniform1i(uCloudXrayOn, if (hub.xrayOcclusionEnabled) 1 else 0)

            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboCloudId)
            GLES20.glEnableVertexAttribArray(aCloudPos)
            GLES20.glVertexAttribPointer(aCloudPos, 3, GLES20.GL_FLOAT, false, FastLioVoxelMap.BYTES_PER_VERTEX, 0)
            GLES20.glEnableVertexAttribArray(aCloudMeta)
            GLES20.glVertexAttribPointer(aCloudMeta, 1, GLES20.GL_FLOAT, false, FastLioVoxelMap.BYTES_PER_VERTEX, 12)

            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, cloudVerts)

            GLES20.glDisableVertexAttribArray(aCloudPos)
            GLES20.glDisableVertexAttribArray(aCloudMeta)
        }

        // 挡在相机→飞机视线上的障碍物：以磨砂半透明玻璃 + 青色高光描边绘制，同时写入深度使后方轨迹变成流动虚线！
        if (glassObsTriVerts > 0) {
            flushEnvTriangles(glassObsTriArray, glassObsTriVerts)
            flushEnvLines(glassObsEdgeArray, glassObsEdgeVerts, max(1.2f, 1.35f * density))
        }

        // 将主角批次 (轨迹、航线、选点光柱、无人机) 一次性上传至专用 VBO
        uploadActorVbos()

        // Pass 3: 硬件深度逆测试 GL_GREATER 遮挡 X-Ray 遍 (被墙柱或点云遮挡的部分自动渲染为流动虚线与全息机身！)
        if (hub.xrayOcclusionEnabled) {
            GLES20.glDepthFunc(GLES20.GL_GREATER)
            GLES20.glDepthMask(false)
            drawActorBatchesOccluded(max(1.2f, 1.5f * density))
        }

        // Pass 4: 标准 GL_LEQUAL 可见前景遍 (未被遮挡的轨迹段与机身呈现 100% 锐利高亮实心质感)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDepthMask(true)
        drawActorBatchesVisible(max(1.2f, 1.5f * density))

        // Pass 5: 半透明高程垂幕、膨胀安全边界光晕与声呐波纹 (GL_LEQUAL, 不写深度)
        GLES20.glDepthMask(false)
        flushEnvTriangles(fxAlphaTriArray, fxAlphaTriVerts)
        GLES20.glDepthMask(true)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

        hudSyncAcc += dt
        if (hudSyncAcc >= 0.095f) {
            hudSyncAcc = 0f
            post(uiTickRunnable)
        }
    }

    private fun drawSkyDomePass() {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(progSky)
        // 相机俯角越小 (越平视)，地平线在屏幕上的位置越靠下，增强真实俯仰空间参考
        val horizonUvY = (0.92f - camPitch * 0.34f).coerceIn(0.42f, 0.92f)
        GLES20.glUniform1f(uSkyHorizonY, horizonUvY)
        GLES20.glUniform1f(uSkyBlend3D, projBlend)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        skyQuadBuf.position(0)
        GLES20.glEnableVertexAttribArray(aSkyPos)
        GLES20.glVertexAttribPointer(aSkyPos, 2, GLES20.GL_FLOAT, false, 0, skyQuadBuf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aSkyPos)
    }

    private fun updateCameraMatrices(dt: Float, snap: RenderSnapshot) {
        val kRot = 1f - exp(-dt * 10.5f)
        val kZoom = 1f - exp(-dt * 13.0f)

        if (followMode == 2) {
            val chaseYaw = snap.yaw - PI.toFloat() * 0.5f
            var diff = chaseYaw - camYaw
            while (diff > PI.toFloat()) diff -= (PI * 2.0).toFloat()
            while (diff < -PI.toFloat()) diff += (PI * 2.0).toFloat()
            camYaw += diff * (1f - exp(-dt * 6.5f))
            camYawDesired = camYaw
        } else {
            camYaw += (camYawDesired - camYaw) * kRot
        }
        camPitch += (camPitchDesired - camPitch) * kRot
        worldHalfSpan += (worldHalfSpanDesired - worldHalfSpan) * kZoom

        val b = projBlend
        val desFX = if (followMode != 0) snap.uavX + camPanX else camPanX
        val desFY = if (followMode != 0) snap.uavY + camPanY else camPanY
        val desFZ = if (followMode != 0) (snap.uavZ * 0.45f) * b else 0f
        val kPos = 1f - exp(-dt * 11.5f)
        camFocusX += (desFX - camFocusX) * kPos
        camFocusY += (desFY - camFocusY) * kPos
        camFocusZ += (desFZ - camFocusZ) * kPos

        val effYaw = camYaw * b
        val effPitch = 1.568f * (1f - b) + camPitch * b
        val fovYDeg = 4.2f + 41.8f * b
        val halfFovRad = Math.toRadians((fovYDeg * 0.5f).toDouble()).toFloat()
        val camDist = worldHalfSpan / max(0.02f, tan(halfFovRad))

        val horizBack = camDist * cos(effPitch)
        curEyeX = camFocusX + sin(effYaw) * horizBack
        curEyeY = camFocusY - cos(effYaw) * horizBack
        curEyeZ = camFocusZ + camDist * sin(effPitch)

        Matrix.setLookAtM(
            viewMatrix, 0,
            curEyeX, curEyeY, curEyeZ,
            camFocusX, camFocusY, camFocusZ,
            0f, 0f, 1f
        )

        val aspect = viewportW.toFloat() / max(1f, viewportH.toFloat())
        val nearClip = max(0.25f, camDist * 0.04f)
        val farClip = camDist * 8.5f + 260f
        Matrix.perspectiveM(projMatrix, 0, fovYDeg, aspect, nearClip, farClip)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        if (Matrix.invertM(glTmpInv16, 0, vpMatrix, 0)) {
            synchronized(invVpLock) {
                System.arraycopy(glTmpInv16, 0, sharedInvVp, 0, 16)
                invVpValid = true
            }
        }

        synchronized(rippleLock) {
            for (i in rippleAge.indices) {
                if (rippleAge[i] >= 0f) {
                    rippleAge[i] += dt
                    if (rippleAge[i] > 1.15f) rippleAge[i] = -1f
                }
            }
        }
    }

    /**
     * 计算三维障碍柱/墙到「相机 curEye -> 无人机 uav」视线线段的最短空间距离，
     * 用于平滑触发遮挡墙体半透明玻璃化动画与无人机遮挡提示
     */
    private fun distanceFromSightRayToColumn(
        cx: Float, cy: Float, rx: Float, ry: Float, zBottom: Float, zTop: Float, isCircle: Boolean,
        uavX: Float, uavY: Float, uavZ: Float
    ): Float {
        val vxRay = uavX - curEyeX
        val vyRay = uavY - curEyeY
        val horizLen2 = vxRay * vxRay + vyRay * vyRay
        if (horizLen2 < 0.05f) return 99f

        val s = (((cx - curEyeX) * vxRay + (cy - curEyeY) * vyRay) / horizLen2).coerceIn(0.06f, 0.96f)
        val px = curEyeX + s * vxRay
        val py = curEyeY + s * vyRay
        val pz = curEyeZ + s * (uavZ - curEyeZ)

        val d2d = if (isCircle) {
            hypot(px - cx, py - cy) - rx
        } else {
            val dx = abs(px - cx) - rx
            val dy = abs(py - cy) - ry
            hypot(max(dx, 0f), max(dy, 0f)) + min(max(dx, dy), 0f)
        }
        val dz = when {
            pz > zTop -> pz - zTop
            pz < zBottom -> zBottom - pz
            else -> 0f
        }
        return hypot(max(0f, d2d), dz)
    }

    private fun buildSceneBatches(dt: Float, snap: RenderSnapshot) {
        val b = projBlend
        val zScale = 0.08f + 0.92f * b
        val uavScaledZ = snap.uavZ * zScale

        // 1. 透视地面网格与世界原点三维 XYZ 参考轴
        val anchorX = floor(camFocusX / 4f) * 4f
        val anchorY = floor(camFocusY / 4f) * 4f
        val halfGrid = 14
        for (g in -halfGrid..halfGrid) {
            val gx = anchorX + g
            val gy = anchorY + g
            val majorX = (abs(gx.toInt()) % 4 == 0)
            val majorY = (abs(gy.toInt()) % 4 == 0)
            val fade = (1f - (abs(g) / 15.0f) * (abs(g) / 15.0f)).coerceAtLeast(0.12f)
            val aX = (if (majorX) 0.18f else 0.06f) * fade
            val aY = (if (majorY) 0.18f else 0.06f) * fade
            pushGroundLine(gx, anchorY - halfGrid, 0f, gx, anchorY + halfGrid, 0f, 0.78f, 0.86f, 0.96f, aX)
            pushGroundLine(anchorX - halfGrid, gy, 0f, anchorX + halfGrid, gy, 0f, 0.78f, 0.86f, 0.96f, aY)
        }
        // 原点三维参考坐标轴 (X红 / Y绿 / Z蓝)
        pushGroundLine(0f, 0f, 0.008f, 1.1f, 0f, 0.008f, 1.0f, 0.30f, 0.28f, 0.65f)
        pushGroundLine(0f, 0f, 0.008f, 0f, 1.1f, 0.008f, 0.15f, 0.92f, 0.50f, 0.65f)
        if (b > 0.05f) {
            pushGroundLine(0f, 0f, 0.008f, 0f, 0f, 1.1f * zScale, 0.25f, 0.68f, 1.0f, 0.65f * b)
        }

        drawHomePad3D(snap.homeX, snap.homeY)

        // 无人机感知距离环与视场锥
        pushGroundCircle(snap.uavX, snap.uavY, 0.012f, 2.0f, 36, 0f, 0.90f, 0.46f, 0.22f)
        pushGroundCircle(snap.uavX, snap.uavY, 0.012f, 4.0f, 44, 1f, 1f, 1f, 0.10f)
        val fovL = snap.yaw + 0.56f
        val fovR = snap.yaw - 0.56f
        pushFxTri(
            snap.uavX, snap.uavY, 0.014f,
            snap.uavX + cos(fovL) * 3.8f, snap.uavY + sin(fovL) * 3.8f, 0.014f,
            snap.uavX + cos(fovR) * 3.8f, snap.uavY + sin(fovR) * 3.8f, 0.014f,
            0f, 0.90f, 0.46f, 0.075f
        )

        if (hub.showLocalBox) {
            pushGroundDashedRect(snap.uavX - 4f, snap.uavY - 4f, snap.uavX + 4f, snap.uavY + 4f, 0.018f, 0.09f, 0.56f, 1.0f, 0.45f)
        }

        synchronized(rippleLock) {
            for (i in rippleAge.indices) {
                val age = rippleAge[i]
                if (age >= 0f) {
                    val prog = (age / 1.15f).coerceIn(0f, 1f)
                    val rad = 0.22f + prog * 1.48f
                    val alpha = (1f - prog) * 0.82f
                    pushFxRingXY(rippleX[i], rippleY[i], 0.025f, rad, 0.045f, 28, 0f, 0.88f, 1.0f, alpha)
                }
            }
        }

        // 2. 构建高精度三维明暗实体圆柱/墙体 + 视线遮挡平滑玻璃化避让动画
        var droneBlockedThisFrame = false
        val kAlpha = 1f - exp(-dt * 10.5f)
        val obCnt = snap.obsPrimitiveCount
        val obArr = snap.obsPrimitives
        for (i in 0 until obCnt) {
            val base = i * 6
            val cx = obArr[base]
            val cy = obArr[base + 1]
            val rx = obArr[base + 2]
            val ry = obArr[base + 3]
            val h = obArr[base + 4] * zScale
            val isCyl = obArr[base + 5] > 0.5f

            val dSight = if (b > 0.15f && hub.xrayOcclusionEnabled) {
                distanceFromSightRayToColumn(cx, cy, rx, ry, 0f, h, isCyl, snap.uavX, snap.uavY, uavScaledZ)
            } else 99f

            if (dSight < 0.22f) droneBlockedThisFrame = true

            // 阻挡相机视线的障碍物在 ~180ms 内平滑融化为 24% 磨砂透视玻璃，移开视线自动恢复实心
            val targetAlpha = if (dSight < 0.52f) {
                0.22f + (dSight / 0.52f).coerceIn(0f, 1f) * 0.72f
            } else {
                0.95f
            }
            obsSmoothAlpha[i] += (targetAlpha - obsSmoothAlpha[i]) * kAlpha
            val curA = obsSmoothAlpha[i]
            val intoGlassPass = curA < 0.86f

            if (isCyl) {
                pushLit3DCylinder(cx, cy, rx, h, 20, curA, intoGlassPass, b)
            } else {
                pushLit3DBox(cx, cy, rx, ry, 0f, h, curA, intoGlassPass, b, drawHeightTicks = true)
            }
        }

        // 3. 膨胀安全边界带 (DEMO) 或 实机三维占据体素 (/grid_map/occupancy_inflate)
        val cullSpan = worldHalfSpan * 2.8f + 4.0f
        val vCnt = min(snap.voxelCount, 2200)
        val vArr = snap.voxels
        for (i in 0 until vCnt) {
            val idx = i * 4
            val vx = vArr[idx]
            val vy = vArr[idx + 1]
            if (abs(vx - camFocusX) > cullSpan || abs(vy - camFocusY) > cullSpan) continue
            val kind = vArr[idx + 3].toInt()
            if (kind == 3) {
                // 实机 ROS1 三维膨胀占据体素：作为真实三维立体方块渲染并参与视线遮挡测试与半透明避让！
                val vzCenter = vArr[idx + 2] * zScale
                val halfH = 0.11f * zScale + 0.02f
                val z0 = max(0.01f, vzCenter - halfH)
                val z1 = vzCenter + halfH
                val dSight = if (b > 0.15f && hub.xrayOcclusionEnabled) {
                    distanceFromSightRayToColumn(vx, vy, 0.12f, 0.12f, z0, z1, false, snap.uavX, snap.uavY, uavScaledZ)
                } else 99f
                if (dSight < 0.18f) droneBlockedThisFrame = true
                val vAlpha = if (dSight < 0.55f) 0.22f else 0.88f
                pushLitRosVoxelCube(vx, vy, z0, z1, 0.11f, vAlpha, intoGlass = dSight < 0.55f)
            } else {
                // 仿真膨胀安全边界裙边 (半透明琥珀色警示带，归入 Pass 5 不遮挡实线)
                val vh = vArr[idx + 2] * zScale
                val aTop = if (kind == 0) 0.22f else 0.08f
                pushFxBox(vx, vy, 0f, max(0.04f, vh), 0.115f, 1.0f, 0.67f, 0.0f, aTop)
            }
        }

        hub.droneCurrentlyOccluded = droneBlockedThisFrame
        val targetOccBlend = if (droneBlockedThisFrame) 1f else 0f
        droneOccludedBlend += (targetOccBlend - droneOccludedBlend) * (1f - exp(-dt * 9.0f))

        // 4. 历史航迹与 FAST-LIO 里程计全局路径 (归入 Actor 批次：被墙遮挡段自动变流动虚线！)
        if (snap.lioPathCount > 1) {
            pushActorRibbon3D(snap.lioPathPts, snap.lioPathCount, zScale, 0.036f, 0.16f, 0.76f, 1.0f, 0.88f)
        }
        if (snap.trailCount > 1) {
            pushActorPolyline3D(snap.trailPts, snap.trailCount, zScale, 0.80f, 0.88f, 0.98f, 0.48f)
        }
        if (snap.astarCount > 1) {
            pushActorPolyline3D(snap.astarPts, snap.astarCount, 0.02f, 0.18f, 0.65f, 1.0f, 0.62f, fixedZ = 0.03f)
        }

        // 5. EGO-Planner 三维 B 样条轨迹 + DJI FlightHub 风格三维高程垂幕 + 地面投影暗轨
        if (snap.bsplineCount > 1) {
            val pts = snap.bsplinePts
            if (b > 0.08f) {
                pushAltitudeCurtain(pts, snap.bsplineCount, zScale, 0.0f, 0.90f, 0.48f, 0.17f * b)
            }
            // 轨迹主体写入 Actor 批次：无遮挡为实心翠绿光带，穿到柱体/墙壁背后自动切换为等距流动透视虚线！
            pushActorRibbon3D(pts, snap.bsplineCount, zScale, 0.052f, 0f, 0.94f, 0.50f, 0.98f)

            val shift = ((SystemClock.uptimeMillis() / 60L) % 8L).toInt()
            var chv = 4 + shift
            while (chv < snap.bsplineCount - 2) {
                val bp = (chv - 1) * 3; val bn = (chv + 1) * 3
                val x0 = pts[bp]; val y0 = pts[bp + 1]
                val x1 = pts[bn]; val y1 = pts[bn + 1]; val z1 = pts[bn + 2] * zScale + 0.018f
                val dx = x1 - x0; val dy = y1 - y0
                val len = hypot(dx, dy)
                if (len > 1e-4f) {
                    val ux = dx / len; val uy = dy / len
                    val px = -uy; val py = ux
                    val back = 0.16f; val wing = 0.12f
                    pushActorQuadSeg3D(x1 - ux * back + px * wing, y1 - uy * back + py * wing, z1, x1, y1, z1, 0.020f, 1f, 1f, 1f, 0.95f, -1f, -1f)
                    pushActorQuadSeg3D(x1 - ux * back - px * wing, y1 - uy * back - py * wing, z1, x1, y1, z1, 0.020f, 1f, 1f, 1f, 0.95f, -1f, -1f)
                }
                chv += 10
            }
        }

        if (snap.ctrlCount > 0) {
            for (c in 0 until snap.ctrlCount) {
                val bi = c * 3
                pushActorDiscXY(snap.ctrlPts[bi], snap.ctrlPts[bi + 1], snap.ctrlPts[bi + 2] * zScale + 0.02f, 0.052f, 8, 1f, 1f, 1f, 0.92f, -1f)
            }
        }

        // 6. 当前目标点立柱
        val gz = snap.goalZ * zScale
        if (b > 0.05f) {
            pushActorQuadSeg3D(snap.goalX, snap.goalY, 0.01f, snap.goalX, snap.goalY, gz, 0.022f, 0f, 0.92f, 0.48f, 0.85f, 0f, gz)
        }
        val pulseR = 0.24f + (sin(SystemClock.uptimeMillis() * 0.006).toFloat() + 1f) * 0.09f
        pushFxRingXY(snap.goalX, snap.goalY, 0.02f, pulseR, 0.035f, 20, 0f, 0.90f, 0.46f, 0.88f)
        pushActorBeaconBox(snap.goalX, snap.goalY, gz, 0.105f, 0f, 0.94f, 0.50f, 0.95f)

        // 7. 连续多航点航线链 (连同三维高程垂肋，被遮挡段同样自动呈现透视流动虚线)
        var lastRouteTipX = snap.uavX
        var lastRouteTipY = snap.uavY
        var lastRouteTipZ = uavScaledZ
        if (snap.waypointQueueCount > 0) {
            val isStaged = snap.isRouteStagedOnly
            var prevX = if (isStaged) snap.uavX else snap.goalX
            var prevY = if (isStaged) snap.uavY else snap.goalY
            var prevZ = if (isStaged) uavScaledZ else gz

            val lr = if (isStaged) 1.0f else 0.41f
            val lg = if (isStaged) 0.78f else 0.75f
            val lb = if (isStaged) 0.14f else 1.0f

            var cumRouteArc = 0f
            val wps = snap.waypointQueuePts
            for (w in 0 until snap.waypointQueueCount) {
                val wx = wps[w * 3]
                val wy = wps[w * 3 + 1]
                val wz = wps[w * 3 + 2] * zScale
                val segLen = hypot(hypot(wx - prevX, wy - prevY), wz - prevZ)
                pushActorQuadSeg3D(prevX, prevY, prevZ, wx, wy, wz, 0.030f, lr, lg, lb, 0.88f, cumRouteArc, cumRouteArc + segLen)
                cumRouteArc += segLen

                if (b > 0.05f) {
                    pushActorLine(wx, wy, 0.01f, wx, wy, wz, lr, lg, lb, 0.75f, 0f, wz)
                }
                pushFxRingXY(wx, wy, 0.02f, 0.21f, 0.032f, 18, lr, lg, lb, 0.85f)
                pushActorBeaconBox(wx, wy, wz, 0.092f, lr, lg, lb, 0.94f)
                prevX = wx; prevY = wy; prevZ = wz
            }
            if (isStaged) {
                lastRouteTipX = prevX; lastRouteTipY = prevY; lastRouteTipZ = prevZ
            }
        }

        // 8. 三维选点预览光柱 (带弹性落针动画 pinAnimScale + 高程垂肋 + 障碍遮挡流动虚线)
        if (snap.hasPreviewPin) {
            val animS = pinAnimScale
            val px = snap.previewX
            val py = snap.previewY
            val pz = snap.previewZ * zScale * animS.coerceAtLeast(0.1f)
            val pr = if (snap.previewSafe) 0.0f else 1.0f
            val pg = if (snap.previewSafe) 0.88f else 0.30f
            val pb = if (snap.previewSafe) 1.0f else 0.26f

            val linkLen = hypot(hypot(px - lastRouteTipX, py - lastRouteTipY), pz - lastRouteTipZ)
            pushActorQuadSeg3D(lastRouteTipX, lastRouteTipY, lastRouteTipZ, px, py, pz, 0.026f, pr, pg, pb, 0.86f, 0f, linkLen)

            if (b > 0.04f) {
                pushActorQuadSeg3D(px, py, 0.01f, px, py, pz, 0.028f, pr, pg, pb, 0.92f, 0f, pz)
                // 预览连线高程参考垂线
                for (step in 1..3) {
                    val f = step / 4f
                    val rx = lastRouteTipX + (px - lastRouteTipX) * f
                    val ry = lastRouteTipY + (py - lastRouteTipY) * f
                    val rz = lastRouteTipZ + (pz - lastRouteTipZ) * f
                    pushGroundLine(rx, ry, 0.01f, rx, ry, rz, pr, pg, pb, 0.24f * b)
                }
            }
            val pinPulse = (0.26f + (sin(SystemClock.uptimeMillis() * 0.009).toFloat() + 1f) * 0.11f) * animS.coerceIn(0.4f, 1.2f)
            pushFxRingXY(px, py, 0.022f, pinPulse, 0.040f, 24, pr, pg, pb, 0.92f)
            pushGroundLine(px - 0.42f, py, 0.022f, px + 0.42f, py, 0.022f, pr, pg, pb, 0.78f)
            pushGroundLine(px, py - 0.42f, 0.022f, px, py + 0.42f, 0.022f, pr, pg, pb, 0.78f)
            pushActorBeaconBox(px, py, pz, 0.115f * animS.coerceIn(0.5f, 1.15f), pr, pg, pb, 0.96f)
        }

        // 9. 三维四旋翼无人机模型 + 遮挡状态下的全息脉冲定位环
        drawQuadrotor3D(snap, zScale, b)
    }

    /**
     * 绘制带太阳/天光法线明暗、底部接触 AO 暗影与 1m/2m 高度等高环的三维圆柱体
     */
    private fun pushLit3DCylinder(
        cx: Float, cy: Float, rad: Float, height: Float, segs: Int,
        alpha: Float, intoGlass: Boolean, blend3D: Float
    ) {
        // 底部地面接触 AO 暗影环
        if (blend3D > 0.08f && !intoGlass) {
            pushFxRingXY(cx, cy, 0.006f, rad + 0.11f, 0.22f, 18, 0f, 0f, 0f, 0.42f * blend3D)
        }

        val baseR = if (intoGlass) 0.12f else 0.19f
        val baseG = if (intoGlass) 0.62f else 0.44f
        val baseB = if (intoGlass) 0.88f else 0.68f

        val roofR = (baseR * 1.32f).coerceAtMost(1f)
        val roofG = (baseG * 1.32f).coerceAtMost(1f)
        val roofB = (baseB * 1.28f).coerceAtMost(1f)

        var c0 = 1f
        var s0 = 0f
        for (s in 1..segs) {
            val ang = (s.toFloat() / segs) * (PI.toFloat() * 2f)
            val c1 = cos(ang)
            val s1 = sin(ang)

            // 顶盖扇形面
            pushObsTri(
                intoGlass,
                cx, cy, height,
                cx + c0 * rad, cy + s0 * rad, height,
                cx + c1 * rad, cy + s1 * rad, height,
                roofR, roofG, roofB, alpha
            )
            // 顶盖高光棱边
            pushObsEdge(
                intoGlass,
                cx + c0 * rad, cy + s0 * rad, height + 0.003f,
                cx + c1 * rad, cy + s1 * rad, height + 0.003f,
                0.45f, 0.88f, 1.0f, if (intoGlass) 0.72f else 0.65f
            )

            // 三维柱面定向光照 (光源方向 L = [0.48, -0.62, 0.62])
            if (blend3D > 0.04f && height > 0.03f) {
                val nx = (c0 + c1) * 0.5f
                val ny = (s0 + s1) * 0.5f
                val ndotl = (nx * 0.48f - ny * 0.62f)
                val shade = (0.64f + 0.36f * ndotl).coerceIn(0.32f, 1.05f)
                val wr = baseR * shade
                val wg = baseG * shade
                val wb = baseB * shade

                pushObsWallQuadAO(
                    intoGlass,
                    cx + c0 * rad, cy + s0 * rad, 0f,
                    cx + c1 * rad, cy + s1 * rad, 0f,
                    cx + c1 * rad, cy + s1 * rad, height,
                    cx + c0 * rad, cy + s0 * rad, height,
                    wr, wg, wb, alpha
                )

                // 每 1.0m 绘制一圈等高刻度线，帮助飞手直观判断柱高与飞机高度关系
                var hTick = 1.0f * (0.08f + 0.92f * blend3D)
                while (hTick < height - 0.12f && hTick > 0.25f) {
                    pushObsEdge(
                        intoGlass,
                        cx + c0 * rad * 1.005f, cy + s0 * rad * 1.005f, hTick,
                        cx + c1 * rad * 1.005f, cy + s1 * rad * 1.005f, hTick,
                        0.42f, 0.82f, 1.0f, 0.26f
                    )
                    hTick += 1.0f * (0.08f + 0.92f * blend3D)
                }
            }

            c0 = c1
            s0 = s1
        }
    }

    /**
     * 绘制带法线四面明暗对比、底部 AO 渐变与高程刻度线的三维立体墙体/长方体
     */
    private fun pushLit3DBox(
        cx: Float, cy: Float, rx: Float, ry: Float, z0: Float, z1: Float,
        alpha: Float, intoGlass: Boolean, blend3D: Float, drawHeightTicks: Boolean
    ) {
        val x0 = cx - rx; val x1 = cx + rx
        val y0 = cy - ry; val y1 = cy + ry

        if (blend3D > 0.08f && !intoGlass && z0 <= 0.02f) {
            val pad = 0.14f
            pushFxQuad(
                x0 - pad, y0 - pad, 0.005f,
                x1 + pad, y0 - pad, 0.005f,
                x1 + pad, y1 + pad, 0.005f,
                x0 - pad, y1 + pad, 0.005f,
                0f, 0f, 0f, 0.36f * blend3D
            )
        }

        val baseR = if (intoGlass) 0.12f else 0.18f
        val baseG = if (intoGlass) 0.62f else 0.42f
        val baseB = if (intoGlass) 0.88f else 0.66f

        // 顶面 (最亮天光面)
        pushObsQuadFlat(
            intoGlass,
            x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1,
            (baseR * 1.35f).coerceAtMost(1f), (baseG * 1.35f).coerceAtMost(1f), (baseB * 1.30f).coerceAtMost(1f), alpha
        )

        if (blend3D > 0.04f && z1 - z0 > 0.03f) {
            // 南面 (y0, 法线 [0, -1] 向阳亮面 0.98x)
            pushObsWallQuadAO(intoGlass, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, baseR * 0.98f, baseG * 0.98f, baseB * 0.98f, alpha)
            // 东面 (x1, 法线 [+1, 0] 次亮面 0.84x)
            pushObsWallQuadAO(intoGlass, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, baseR * 0.84f, baseG * 0.84f, baseB * 0.84f, alpha)
            // 西面 (x0, 法线 [-1, 0] 背光面 0.56x)
            pushObsWallQuadAO(intoGlass, x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, baseR * 0.56f, baseG * 0.56f, baseB * 0.58f, alpha)
            // 北面 (y1, 法线 [0, +1] 深背光面 0.44x)
            pushObsWallQuadAO(intoGlass, x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1, baseR * 0.44f, baseG * 0.44f, baseB * 0.48f, alpha)

            // 四条竖直建筑结构高光棱线 (在磨砂透视玻璃态下尤为清晰！)
            val edgeA = if (intoGlass) 0.76f else 0.48f
            pushObsEdge(intoGlass, x0, y0, z0, x0, y0, z1, 0.45f, 0.88f, 1.0f, edgeA)
            pushObsEdge(intoGlass, x1, y0, z0, x1, y0, z1, 0.45f, 0.88f, 1.0f, edgeA)
            pushObsEdge(intoGlass, x1, y1, z0, x1, y1, z1, 0.45f, 0.88f, 1.0f, edgeA)
            pushObsEdge(intoGlass, x0, y1, z0, x0, y1, z1, 0.45f, 0.88f, 1.0f, edgeA)

            if (drawHeightTicks) {
                var hTick = 1.0f * (0.08f + 0.92f * blend3D)
                while (hTick < z1 - 0.12f && hTick > 0.25f) {
                    pushObsEdge(intoGlass, x0, y0, hTick, x1, y0, hTick, 0.42f, 0.82f, 1.0f, 0.26f)
                    pushObsEdge(intoGlass, x1, y0, hTick, x1, y1, hTick, 0.42f, 0.82f, 1.0f, 0.26f)
                    pushObsEdge(intoGlass, x1, y1, hTick, x0, y1, hTick, 0.42f, 0.82f, 1.0f, 0.26f)
                    pushObsEdge(intoGlass, x0, y1, hTick, x0, y0, hTick, 0.42f, 0.82f, 1.0f, 0.26f)
                    hTick += 1.0f * (0.08f + 0.92f * blend3D)
                }
            }
        }

        val topRimA = if (intoGlass) 0.82f else 0.70f
        pushObsEdge(intoGlass, x0, y0, z1 + 0.002f, x1, y0, z1 + 0.002f, 0.48f, 0.90f, 1.0f, topRimA)
        pushObsEdge(intoGlass, x1, y0, z1 + 0.002f, x1, y1, z1 + 0.002f, 0.48f, 0.90f, 1.0f, topRimA)
        pushObsEdge(intoGlass, x1, y1, z1 + 0.002f, x0, y1, z1 + 0.002f, 0.48f, 0.90f, 1.0f, topRimA)
        pushObsEdge(intoGlass, x0, y1, z1 + 0.002f, x0, y0, z1 + 0.002f, 0.48f, 0.90f, 1.0f, topRimA)
    }

    /**
     * 实机 ROS1 膨胀体素三维带光照方块 (暖琥珀工业警示材质)
     */
    private fun pushLitRosVoxelCube(cx: Float, cy: Float, z0: Float, z1: Float, hw: Float, alpha: Float, intoGlass: Boolean) {
        val x0 = cx - hw; val x1 = cx + hw
        val y0 = cy - hw; val y1 = cy + hw
        pushObsQuadFlat(intoGlass, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 1.0f, 0.68f, 0.14f, alpha)
        pushObsWallQuadAO(intoGlass, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0.92f, 0.55f, 0.10f, alpha)
        pushObsWallQuadAO(intoGlass, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 0.78f, 0.46f, 0.08f, alpha)
        pushObsWallQuadAO(intoGlass, x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, 0.56f, 0.32f, 0.06f, alpha)
        pushObsWallQuadAO(intoGlass, x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1, 0.46f, 0.26f, 0.05f, alpha)
    }

    /**
     * DJI FlightHub 风格三维轨迹高程垂幕 (上沿亮、落地渐隐 + 等距垂直标尺肋 + 地面暗轨投影)
     */
    private fun pushAltitudeCurtain(pts: FloatArray, count: Int, zScale: Float, r: Float, g: Float, b: Float, topAlpha: Float) {
        for (i in 0 until count - 1) {
            val aIdx = i * 3
            val bIdx = (i + 1) * 3
            val x0 = pts[aIdx]; val y0 = pts[aIdx + 1]; val z0 = pts[aIdx + 2] * zScale
            val x1 = pts[bIdx]; val y1 = pts[bIdx + 1]; val z1 = pts[bIdx + 2] * zScale

            // 地面投影暗线，提供精准 XY 平面落点参照
            pushGroundLine(x0, y0, 0.010f, x1, y1, 0.010f, r, g, b, 0.25f)

            // 渐变透明高程垂幕四边形
            pushFxGradientQuad(
                x0, y0, 0.012f, r, g, b, 0.015f,
                x1, y1, 0.012f, r, g, b, 0.015f,
                x1, y1, z1, r, g, b, topAlpha,
                x0, y0, z0, r, g, b, topAlpha
            )

            if (i % 6 == 0) {
                pushGroundLine(x0, y0, 0.012f, x0, y0, z0, r, g, b, topAlpha * 1.45f)
            }
        }
    }

    private fun drawHomePad3D(hx: Float, hy: Float) {
        val z = 0.016f
        pushFxDiscXY(hx, hy, z, 0.34f, 20, 1.0f, 0.72f, 0.0f, 0.18f)
        pushFxRingXY(hx, hy, z + 0.002f, 0.34f, 0.036f, 20, 1.0f, 0.76f, 0.05f, 0.85f)
        pushActorQuadSeg3D(hx - 0.11f, hy - 0.13f, z + 0.004f, hx - 0.11f, hy + 0.13f, z + 0.004f, 0.022f, 1.0f, 0.82f, 0.12f, 0.92f, -1f, -1f)
        pushActorQuadSeg3D(hx + 0.11f, hy - 0.13f, z + 0.004f, hx + 0.11f, hy + 0.13f, z + 0.004f, 0.022f, 1.0f, 0.82f, 0.12f, 0.92f, -1f, -1f)
        pushActorQuadSeg3D(hx - 0.11f, hy, z + 0.004f, hx + 0.11f, hy, z + 0.004f, 0.022f, 1.0f, 0.82f, 0.12f, 0.92f, -1f, -1f)
    }

    private fun drawQuadrotor3D(snap: RenderSnapshot, zScale: Float, blend: Float) {
        val ux = snap.uavX
        val uy = snap.uavY
        val uz = snap.uavZ * zScale
        val yaw = snap.yaw

        // 地面投影软暗影 + 高度激光垂线
        if (blend > 0.05f) {
            pushFxDiscXY(ux, uy, 0.008f, 0.28f, 16, 0f, 0f, 0f, 0.52f * blend)
            pushActorLine(ux, uy, 0.015f, ux, uy, uz, 0.65f, 0.88f, 1.0f, 0.45f, 0f, uz)
        }

        // 当无人机被柱体/墙体遮挡时，在无人机周围展开全息声呐呼吸定位环 (写入 Actor 批次，透墙可见！)
        if (droneOccludedBlend > 0.03f) {
            val sonarPhase = (SystemClock.uptimeMillis() % 1100L) / 1100f
            val sonarR = 0.42f + sonarPhase * 0.55f
            val sonarA = (1f - sonarPhase) * 0.85f * droneOccludedBlend
            pushActorRingXY(ux, uy, uz, sonarR, 0.035f, 24, 0.12f, 0.94f, 1.0f, sonarA, -1f)
        }

        val armAngles = floatArrayOf(0.7854f, -0.7854f, 2.3562f, -2.3562f)
        for (i in 0 until 4) {
            val ang = yaw + armAngles[i]
            val rx = ux + cos(ang) * 0.32f
            val ry = uy + sin(ang) * 0.32f
            pushActorQuadSeg3D(ux, uy, uz, rx, ry, uz, 0.034f, 0.86f, 0.90f, 0.96f, 0.98f, -1f, -1f)
            pushFxDiscXY(rx, ry, uz + 0.005f, 0.17f, 14, 1f, 1f, 1f, 0.16f)
            if (i < 2) {
                pushActorRingXY(rx, ry, uz + 0.01f, 0.17f, 0.035f, 16, 1.0f, 0.24f, 0.20f, 0.98f, -1f)
            } else {
                pushActorRingXY(rx, ry, uz + 0.01f, 0.17f, 0.035f, 16, 0.0f, 0.92f, 0.48f, 0.98f, -1f)
            }
        }

        val hx = ux + cos(yaw) * 0.62f
        val hy = uy + sin(yaw) * 0.62f
        pushActorQuadSeg3D(ux, uy, uz + 0.015f, hx, hy, uz + 0.015f, 0.038f, 0.10f, 0.62f, 1.0f, 0.98f, -1f, -1f)
        pushActorDiscXY(ux, uy, uz + 0.02f, 0.125f, 12, 0.16f, 0.20f, 0.26f, 1.0f, -1f)
        pushActorRingXY(ux, uy, uz + 0.024f, 0.125f, 0.028f, 12, 1f, 1f, 1f, 0.96f, -1f)
    }

    // ==================== 底层零分配顶点压入工具函数 ====================

    private fun pushVert(arr: FloatArray, vertIdx: Int, x: Float, y: Float, z: Float, r: Float, g: Float, b: Float, a: Float, arc: Float) {
        var o = vertIdx * FLOATS_PER_VERT
        arr[o++] = x; arr[o++] = y; arr[o++] = z
        arr[o++] = r; arr[o++] = g; arr[o++] = b; arr[o++] = a
        arr[o] = arc
    }

    private fun pushGroundLine(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, r: Float, g: Float, b: Float, a: Float) {
        if (groundLineVerts + 2 > MAX_ENV_LINE_VERTS) return
        pushVert(groundLineArray, groundLineVerts++, x0, y0, z0, r, g, b, a, 0f)
        pushVert(groundLineArray, groundLineVerts++, x1, y1, z1, r, g, b, a, 0f)
    }

    private fun pushGroundCircle(cx: Float, cy: Float, z: Float, rad: Float, segs: Int, r: Float, g: Float, b: Float, a: Float) {
        var px = cx + rad; var py = cy
        for (s in 1..segs) {
            val ang = (s.toFloat() / segs) * (PI.toFloat() * 2f)
            val nx = cx + cos(ang) * rad; val ny = cy + sin(ang) * rad
            pushGroundLine(px, py, z, nx, ny, z, r, g, b, a)
            px = nx; py = ny
        }
    }

    private fun pushGroundDashedRect(x0: Float, y0: Float, x1: Float, y1: Float, z: Float, r: Float, g: Float, b: Float, a: Float) {
        pushGroundDashedSeg(x0, y0, z, x1, y0, z, r, g, b, a)
        pushGroundDashedSeg(x1, y0, z, x1, y1, z, r, g, b, a)
        pushGroundDashedSeg(x1, y1, z, x0, y1, z, r, g, b, a)
        pushGroundDashedSeg(x0, y1, z, x0, y0, z, r, g, b, a)
    }

    private fun pushGroundDashedSeg(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, r: Float, g: Float, b: Float, a: Float) {
        val steps = 16
        for (i in 0 until steps step 2) {
            val t0 = i.toFloat() / steps; val t1 = (i + 1).toFloat() / steps
            pushGroundLine(
                x0 + (x1 - x0) * t0, y0 + (y1 - y0) * t0, z0 + (z1 - z0) * t0,
                x0 + (x1 - x0) * t1, y0 + (y1 - y0) * t1, z0 + (z1 - z0) * t1,
                r, g, b, a
            )
        }
    }

    private fun pushObsEdge(intoGlass: Boolean, x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, r: Float, g: Float, b: Float, a: Float) {
        if (intoGlass) {
            if (glassObsEdgeVerts + 2 > glassObsEdgeArray.size / FLOATS_PER_VERT) return
            pushVert(glassObsEdgeArray, glassObsEdgeVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(glassObsEdgeArray, glassObsEdgeVerts++, x1, y1, z1, r, g, b, a, 0f)
        } else {
            if (solidObsEdgeVerts + 2 > MAX_ENV_LINE_VERTS) return
            pushVert(solidObsEdgeArray, solidObsEdgeVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(solidObsEdgeArray, solidObsEdgeVerts++, x1, y1, z1, r, g, b, a, 0f)
        }
    }

    private fun pushObsTri(
        intoGlass: Boolean,
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        if (intoGlass) {
            if (glassObsTriVerts + 3 > glassObsTriArray.size / FLOATS_PER_VERT) return
            pushVert(glassObsTriArray, glassObsTriVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, x1, y1, z1, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, x2, y2, z2, r, g, b, a, 0f)
        } else {
            if (solidObsTriVerts + 3 > MAX_ENV_TRI_VERTS) return
            pushVert(solidObsTriArray, solidObsTriVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, x1, y1, z1, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, x2, y2, z2, r, g, b, a, 0f)
        }
    }

    private fun pushObsQuadFlat(
        intoGlass: Boolean,
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        pushObsTri(intoGlass, x0, y0, z0, x1, y1, z1, x2, y2, z2, r, g, b, a)
        pushObsTri(intoGlass, x0, y0, z0, x2, y2, z2, x3, y3, z3, r, g, b, a)
    }

    /**
     * 墙体竖直环境光遮蔽 (Vertical AO Gradient)：根部与地面交界处压暗 40%，向上自然提亮，营造扎实落地立体感
     */
    private fun pushObsWallQuadAO(
        intoGlass: Boolean,
        bx0: Float, by0: Float, bz0: Float,
        bx1: Float, by1: Float, bz1: Float,
        tx1: Float, ty1: Float, tz1: Float,
        tx0: Float, ty0: Float, tz0: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        val ao = 0.56f
        val br = r * ao; val bg = g * ao; val bb = b * ao
        if (intoGlass) {
            if (glassObsTriVerts + 6 > glassObsTriArray.size / FLOATS_PER_VERT) return
            pushVert(glassObsTriArray, glassObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, bx1, by1, bz1, br, bg, bb, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, tx0, ty0, tz0, r, g, b, a, 0f)
        } else {
            if (solidObsTriVerts + 6 > MAX_ENV_TRI_VERTS) return
            pushVert(solidObsTriArray, solidObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, bx1, by1, bz1, br, bg, bb, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, tx0, ty0, tz0, r, g, b, a, 0f)
        }
    }

    // ==================== 主角可遮挡批次 (自动支持 GL_GREATER 流动虚线与全息轮廓) ====================

    private fun pushActorLine(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        r: Float, g: Float, b: Float, a: Float,
        arc0: Float, arc1: Float
    ) {
        if (actorLineVerts + 2 > MAX_ACTOR_LINE_VERTS) return
        pushVert(actorLineArray, actorLineVerts++, x0, y0, z0, r, g, b, a, arc0)
        pushVert(actorLineArray, actorLineVerts++, x1, y1, z1, r, g, b, a, arc1)
    }

    private fun pushActorPolyline3D(
        pts: FloatArray, count: Int, zScale: Float,
        r: Float, g: Float, b: Float, a: Float,
        fixedZ: Float = -1f
    ) {
        var cumArc = 0f
        for (i in 0 until count - 1) {
            val i0 = i * 3; val i1 = (i + 1) * 3
            val x0 = pts[i0]; val y0 = pts[i0 + 1]; val z0 = if (fixedZ >= 0f) fixedZ else pts[i0 + 2] * zScale + 0.012f
            val x1 = pts[i1]; val y1 = pts[i1 + 1]; val z1 = if (fixedZ >= 0f) fixedZ else pts[i1 + 2] * zScale + 0.012f
            val seg = hypot(hypot(x1 - x0, y1 - y0), z1 - z0)
            pushActorLine(x0, y0, z0, x1, y1, z1, r, g, b, a, cumArc, cumArc + seg)
            cumArc += seg
        }
    }

    private fun pushActorTri(
        x0: Float, y0: Float, z0: Float, arc0: Float,
        x1: Float, y1: Float, z1: Float, arc1: Float,
        x2: Float, y2: Float, z2: Float, arc2: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        if (actorTriVerts + 3 > MAX_ACTOR_TRI_VERTS) return
        pushVert(actorTriArray, actorTriVerts++, x0, y0, z0, r, g, b, a, arc0)
        pushVert(actorTriArray, actorTriVerts++, x1, y1, z1, r, g, b, a, arc1)
        pushVert(actorTriArray, actorTriVerts++, x2, y2, z2, r, g, b, a, arc2)
    }

    private fun pushActorQuadSeg3D(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        halfW: Float,
        r: Float, g: Float, b: Float, a: Float,
        arc0: Float, arc1: Float
    ) {
        val dx = x1 - x0; val dy = y1 - y0
        val len = hypot(dx, dy)
        val nx: Float; val ny: Float
        if (len > 1e-4f) {
            nx = (-dy / len) * halfW; ny = (dx / len) * halfW
        } else {
            nx = halfW; ny = 0f
        }
        pushActorTri(
            x0 - nx, y0 - ny, z0, arc0,
            x0 + nx, y0 + ny, z0, arc0,
            x1 + nx, y1 + ny, z1, arc1,
            r, g, b, a
        )
        pushActorTri(
            x0 - nx, y0 - ny, z0, arc0,
            x1 + nx, y1 + ny, z1, arc1,
            x1 - nx, y1 - ny, z1, arc1,
            r, g, b, a
        )
    }

    private fun pushActorRibbon3D(
        pts: FloatArray, count: Int, zScale: Float, halfW: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        var cumArc = 0f
        for (i in 0 until count - 1) {
            val aIdx = i * 3; val bIdx = (i + 1) * 3
            val x0 = pts[aIdx]; val y0 = pts[aIdx + 1]; val z0 = pts[aIdx + 2] * zScale + 0.012f
            val x1 = pts[bIdx]; val y1 = pts[bIdx + 1]; val z1 = pts[bIdx + 2] * zScale + 0.012f
            val seg = hypot(hypot(x1 - x0, y1 - y0), z1 - z0)
            pushActorQuadSeg3D(x0, y0, z0, x1, y1, z1, halfW, r, g, b, a, cumArc, cumArc + seg)
            cumArc += seg
        }
    }

    private fun pushActorDiscXY(cx: Float, cy: Float, z: Float, rad: Float, segs: Int, r: Float, g: Float, b: Float, a: Float, arc: Float) {
        var px = cx + rad; var py = cy
        for (s in 1..segs) {
            val ang = (s.toFloat() / segs) * (PI.toFloat() * 2f)
            val nx = cx + cos(ang) * rad; val ny = cy + sin(ang) * rad
            pushActorTri(cx, cy, z, arc, px, py, z, arc, nx, ny, z, arc, r, g, b, a)
            px = nx; py = ny
        }
    }

    private fun pushActorRingXY(cx: Float, cy: Float, z: Float, rad: Float, thick: Float, segs: Int, r: Float, g: Float, b: Float, a: Float, arc: Float) {
        val rIn = max(0.005f, rad - thick * 0.5f)
        val rOut = rad + thick * 0.5f
        var c0 = 1f; var s0 = 0f
        for (s in 1..segs) {
            val ang = (s.toFloat() / segs) * (PI.toFloat() * 2f)
            val c1 = cos(ang); val s1 = sin(ang)
            pushActorTri(cx + c0 * rIn, cy + s0 * rIn, z, arc, cx + c0 * rOut, cy + s0 * rOut, z, arc, cx + c1 * rOut, cy + s1 * rOut, z, arc, r, g, b, a)
            pushActorTri(cx + c0 * rIn, cy + s0 * rIn, z, arc, cx + c1 * rOut, cy + s1 * rOut, z, arc, cx + c1 * rIn, cy + s1 * rIn, z, arc, r, g, b, a)
            c0 = c1; s0 = s1
        }
    }

    private fun pushActorBeaconBox(cx: Float, cy: Float, cz: Float, hw: Float, r: Float, g: Float, b: Float, a: Float) {
        val x0 = cx - hw; val x1 = cx + hw
        val y0 = cy - hw; val y1 = cy + hw
        val z0 = cz - hw; val z1 = cz + hw
        fun q(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, dx: Float, dy: Float, dz: Float, ex: Float, ey: Float, ez: Float, sh: Float) {
            pushActorTri(ax, ay, az, -1f, bx, by, bz, -1f, dx, dy, dz, -1f, r * sh, g * sh, b * sh, a)
            pushActorTri(ax, ay, az, -1f, dx, dy, dz, -1f, ex, ey, ez, -1f, r * sh, g * sh, b * sh, a)
        }
        q(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 1.0f)
        q(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0.88f)
        q(x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 0.76f)
        q(x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1, 0.62f)
        q(x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, 0.68f)
    }

    // ==================== Pass 5 特效半透明批次 ====================

    private fun pushFxTri(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float, r: Float, g: Float, b: Float, a: Float) {
        if (fxAlphaTriVerts + 3 > MAX_ENV_TRI_VERTS) return
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x0, y0, z0, r, g, b, a, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x1, y1, z1, r, g, b, a, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x2, y2, z2, r, g, b, a, 0f)
    }

    private fun pushFxQuad(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float, r: Float, g: Float, b: Float, a: Float) {
        pushFxTri(x0, y0, z0, x1, y1, z1, x2, y2, z2, r, g, b, a)
        pushFxTri(x0, y0, z0, x2, y2, z2, x3, y3, z3, r, g, b, a)
    }

    private fun pushFxGradientQuad(
        x0: Float, y0: Float, z0: Float, r0: Float, g0: Float, b0: Float, a0: Float,
        x1: Float, y1: Float, z1: Float, r1: Float, g1: Float, b1: Float, a1: Float,
        x2: Float, y2: Float, z2: Float, r2: Float, g2: Float, b2: Float, a2: Float,
        x3: Float, y3: Float, z3: Float, r3: Float, g3: Float, b3: Float, a3: Float
    ) {
        if (fxAlphaTriVerts + 6 > MAX_ENV_TRI_VERTS) return
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x0, y0, z0, r0, g0, b0, a0, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x1, y1, z1, r1, g1, b1, a1, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x2, y2, z2, r2, g2, b2, a2, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x0, y0, z0, r0, g0, b0, a0, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x2, y2, z2, r2, g2, b2, a2, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x3, y3, z3, r3, g3, b3, a3, 0f)
    }

    private fun pushFxDiscXY(cx: Float, cy: Float, z: Float, rad: Float, segs: Int, r: Float, g: Float, b: Float, a: Float) {
        var px = cx + rad; var py = cy
        for (s in 1..segs) {
            val ang = (s.toFloat() / segs) * (PI.toFloat() * 2f)
            val nx = cx + cos(ang) * rad; val ny = cy + sin(ang) * rad
            pushFxTri(cx, cy, z, px, py, z, nx, ny, z, r, g, b, a)
            px = nx; py = ny
        }
    }

    private fun pushFxRingXY(cx: Float, cy: Float, z: Float, rad: Float, thick: Float, segs: Int, r: Float, g: Float, b: Float, a: Float) {
        val rIn = max(0.005f, rad - thick * 0.5f)
        val rOut = rad + thick * 0.5f
        var c0 = 1f; var s0 = 0f
        for (s in 1..segs) {
            val ang = (s.toFloat() / segs) * (PI.toFloat() * 2f)
            val c1 = cos(ang); val s1 = sin(ang)
            pushFxQuad(
                cx + c0 * rIn, cy + s0 * rIn, z,
                cx + c0 * rOut, cy + s0 * rOut, z,
                cx + c1 * rOut, cy + s1 * rOut, z,
                cx + c1 * rIn, cy + s1 * rIn, z,
                r, g, b, a
            )
            c0 = c1; s0 = s1
        }
    }

    private fun pushFxBox(cx: Float, cy: Float, z0: Float, z1: Float, hw: Float, r: Float, g: Float, b: Float, a: Float) {
        val x0 = cx - hw; val x1 = cx + hw
        val y0 = cy - hw; val y1 = cy + hw
        pushFxQuad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, a)
        if (projBlend > 0.05f && z1 - z0 > 0.02f) {
            val sa = a * 0.55f
            pushFxQuad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, b, sa)
            pushFxQuad(x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, r, g, b, sa)
            pushFxQuad(x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1, r, g, b, sa)
            pushFxQuad(x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, r, g, b, sa)
        }
    }

    // ==================== VBO 提交与双遍绘制管线 ====================

    private fun bindPrimUniforms() {
        GLES20.glUseProgram(progPrim)
        GLES20.glUniformMatrix4fv(uPrimMvp, 1, false, vpMatrix, 0)
        GLES20.glUniform2f(uPrimFocusXY, camFocusX, camFocusY)
        GLES20.glUniform1f(uPrimFogSpan, worldHalfSpan * 2.2f)
    }

    private fun flushEnvLines(src: FloatArray, vertCount: Int, lineWidthPx: Float) {
        if (vertCount <= 0) return
        envLineBuf.clear()
        envLineBuf.put(src, 0, vertCount * FLOATS_PER_VERT)
        envLineBuf.position(0)

        bindPrimUniforms()
        GLES20.glLineWidth(lineWidthPx)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboEnvLineId)
        GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, vertCount * STRIDE_VERT, envLineBuf)

        GLES20.glEnableVertexAttribArray(aPrimPos)
        GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
        GLES20.glEnableVertexAttribArray(aPrimColor)
        GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
        if (aPrimArc >= 0) {
            GLES20.glEnableVertexAttribArray(aPrimArc)
            GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
        }

        GLES20.glDrawArrays(GLES20.GL_LINES, 0, vertCount)

        GLES20.glDisableVertexAttribArray(aPrimPos)
        GLES20.glDisableVertexAttribArray(aPrimColor)
        if (aPrimArc >= 0) GLES20.glDisableVertexAttribArray(aPrimArc)
    }

    private fun flushEnvTriangles(src: FloatArray, vertCount: Int) {
        if (vertCount <= 0) return
        envTriBuf.clear()
        envTriBuf.put(src, 0, vertCount * FLOATS_PER_VERT)
        envTriBuf.position(0)

        bindPrimUniforms()

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboEnvTriId)
        GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, vertCount * STRIDE_VERT, envTriBuf)

        GLES20.glEnableVertexAttribArray(aPrimPos)
        GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
        GLES20.glEnableVertexAttribArray(aPrimColor)
        GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
        if (aPrimArc >= 0) {
            GLES20.glEnableVertexAttribArray(aPrimArc)
            GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
        }

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertCount)

        GLES20.glDisableVertexAttribArray(aPrimPos)
        GLES20.glDisableVertexAttribArray(aPrimColor)
        if (aPrimArc >= 0) GLES20.glDisableVertexAttribArray(aPrimArc)
    }

    private fun uploadActorVbos() {
        if (actorLineVerts > 0) {
            actorLineBuf.clear()
            actorLineBuf.put(actorLineArray, 0, actorLineVerts * FLOATS_PER_VERT)
            actorLineBuf.position(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
            GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, actorLineVerts * STRIDE_VERT, actorLineBuf)
        }
        if (actorTriVerts > 0) {
            actorTriBuf.clear()
            actorTriBuf.put(actorTriArray, 0, actorTriVerts * FLOATS_PER_VERT)
            actorTriBuf.position(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
            GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, actorTriVerts * STRIDE_VERT, actorTriBuf)
        }
    }

    private fun drawActorBatchesOccluded(lineWidthPx: Float) {
        GLES20.glUseProgram(progOccluded)
        GLES20.glUniformMatrix4fv(uOccMvp, 1, false, vpMatrix, 0)
        GLES20.glUniform1f(uOccTime, shaderClockSec)

        if (actorLineVerts > 0) {
            GLES20.glLineWidth(lineWidthPx)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
            GLES20.glEnableVertexAttribArray(aOccPos)
            GLES20.glVertexAttribPointer(aOccPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aOccColor)
            GLES20.glVertexAttribPointer(aOccColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            GLES20.glEnableVertexAttribArray(aOccArc)
            GLES20.glVertexAttribPointer(aOccArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, actorLineVerts)
        }

        if (actorTriVerts > 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
            GLES20.glEnableVertexAttribArray(aOccPos)
            GLES20.glVertexAttribPointer(aOccPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aOccColor)
            GLES20.glVertexAttribPointer(aOccColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            GLES20.glEnableVertexAttribArray(aOccArc)
            GLES20.glVertexAttribPointer(aOccArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, actorTriVerts)
        }

        GLES20.glDisableVertexAttribArray(aOccPos)
        GLES20.glDisableVertexAttribArray(aOccColor)
        GLES20.glDisableVertexAttribArray(aOccArc)
    }

    private fun drawActorBatchesVisible(lineWidthPx: Float) {
        bindPrimUniforms()

        if (actorLineVerts > 0) {
            GLES20.glLineWidth(lineWidthPx)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
            GLES20.glEnableVertexAttribArray(aPrimPos)
            GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aPrimColor)
            GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            if (aPrimArc >= 0) {
                GLES20.glEnableVertexAttribArray(aPrimArc)
                GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            }
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, actorLineVerts)
        }

        if (actorTriVerts > 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
            GLES20.glEnableVertexAttribArray(aPrimPos)
            GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aPrimColor)
            GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            if (aPrimArc >= 0) {
                GLES20.glEnableVertexAttribArray(aPrimArc)
                GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, actorTriVerts)
        }

        GLES20.glDisableVertexAttribArray(aPrimPos)
        GLES20.glDisableVertexAttribArray(aPrimColor)
        if (aPrimArc >= 0) GLES20.glDisableVertexAttribArray(aPrimArc)
    }

    private fun buildProgram(vsSrc: String, fsSrc: String): Int {
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vsSrc)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fsSrc)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src)
        GLES20.glCompileShader(sh)
        return sh
    }
}
