package com.radiomaster.egogcs.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import com.radiomaster.egogcs.model.GcsSharedHub
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * 零字符串颜色解析 + 脏状态按需重绘的 DJI Pilot 2 三分区全向避障姿态球 (HSI)
 */
class DjiHsiRadarView(context: Context, private val hub: GcsSharedHub) : View(context) {

    companion object {
        private const val COL_RED = -0x00c4d0     // #FF3B30
        private const val COL_AMBER = -0x005500   // #FFAB00
        private const val COL_GREEN = -0xff198a   // #00E676
        private const val COL_BLUE = -0xe76f01    // #1890FF
        private const val COL_CARD_N = -0x00b2b1  // #FF4D4F
        private const val COL_SKY = -0xe9cdB1     // #16324F
        private const val COL_GND = -0xd5dde5     // #2A221B
    }

    var rangeMeters: Float = 4.0f
        private set
    var northUpMode: Boolean = false
        private set
    private var rotBlend: Float = 0f
    private var modeAnim: ValueAnimator? = null

    private var lastYaw = -999f
    private var lastRoll = -999f
    private var lastPitch = -999f
    private var lastRadarChecksum = -999f

    private val d = resources.displayMetrics.density

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.BUTT
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(3.5f * d, 3.5f * d), 0f)
    }
    private val cardinalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9.5f * d
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val pillTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 8.2f * d
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val clipPath = Path()
    private val workPath = Path()
    private val rectOuter = RectF()
    private val rectInner = RectF()
    private val pillRect = RectF()

    fun invalidateIfChanged() {
        val s = hub.latestSnapshot
        var sum = 0f
        val r = s.radarSmooth60
        var i = 0
        while (i < 60) {
            sum += r[i]
            i += 4
        }
        if (abs(s.yaw - lastYaw) > 0.004f ||
            abs(s.smoothRoll - lastRoll) > 0.003f ||
            abs(s.smoothPitch - lastPitch) > 0.003f ||
            abs(sum - lastRadarChecksum) > 0.02f
        ) {
            lastYaw = s.yaw
            lastRoll = s.smoothRoll
            lastPitch = s.smoothPitch
            lastRadarChecksum = sum
            invalidate()
        }
    }

    fun cycleMode(): String {
        val label: String
        if (!northUpMode && rangeMeters == 4.0f) {
            rangeMeters = 8.0f
            label = "HSI 姿态球：机头朝上 · 雷达量程 8m"
        } else if (!northUpMode && rangeMeters == 8.0f) {
            northUpMode = true
            rangeMeters = 6.0f
            animateNorthBlend(1f)
            label = "HSI 姿态球：北向固定模式 · 量程 6m"
        } else {
            northUpMode = false
            rangeMeters = 4.0f
            animateNorthBlend(0f)
            label = "HSI 姿态球：机头朝上 · 雷达量程 4m"
        }
        lastYaw = -999f
        invalidate()
        return label
    }

    private fun animateNorthBlend(target: Float) {
        modeAnim?.cancel()
        modeAnim = ValueAnimator.ofFloat(rotBlend, target).apply {
            duration = 320L
            interpolator = AnimHelper.EASE_OUT_EXPO
            addUpdateListener { a ->
                rotBlend = a.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val snap = hub.latestSnapshot
        val cx = width * 0.5f
        val cy = height * 0.5f
        val rFull = min(width, height) * 0.48f
        val rBezelIn = rFull * 0.80f
        val rRadarMax = rFull * 0.77f
        val rAttCore = rFull * 0.34f

        var dYaw = (PI.toFloat() * 0.5f) - snap.yaw
        while (dYaw > PI.toFloat()) dYaw -= (PI * 2.0).toFloat()
        while (dYaw < -PI.toFloat()) dYaw += (PI * 2.0).toFloat()
        val refYaw = snap.yaw + dYaw * rotBlend

        fun worldToCanvasRad(wAng: Float): Float = -PI.toFloat() * 0.5f - (wAng - refYaw)

        fillPaint.color = Color.argb(245, 20, 24, 31)
        canvas.drawCircle(cx, cy, rFull, fillPaint)
        fillPaint.color = Color.argb(242, 10, 13, 17)
        canvas.drawCircle(cx, cy, rBezelIn, fillPaint)

        strokePaint.color = Color.argb(58, 255, 255, 255)
        strokePaint.strokeWidth = 1.1f * d
        canvas.drawCircle(cx, cy, rFull, strokePaint)
        strokePaint.color = Color.argb(36, 255, 255, 255)
        strokePaint.strokeWidth = 0.85f * d
        canvas.drawCircle(cx, cy, rBezelIn, strokePaint)

        val rMidRing = rAttCore + (rRadarMax - rAttCore) * 0.5f
        dashPaint.color = Color.argb(28, 255, 255, 255)
        dashPaint.strokeWidth = 0.75f * d
        canvas.drawCircle(cx, cy, rMidRing, dashPaint)

        val noseRad = worldToCanvasRad(snap.yaw)
        val noseDeg = Math.toDegrees(noseRad.toDouble()).toFloat()
        rectOuter.set(cx - rRadarMax, cy - rRadarMax, cx + rRadarMax, cy + rRadarMax)
        rectInner.set(cx - rAttCore, cy - rAttCore, cx + rAttCore, cy + rAttCore)
        workPath.reset()
        workPath.arcTo(rectOuter, noseDeg - 42f, 84f)
        workPath.arcTo(rectInner, noseDeg + 42f, -84f)
        workPath.close()
        fillPaint.color = Color.argb(20, 24, 144, 255)
        canvas.drawPath(workPath, fillPaint)

        val bins = snap.radarSmooth60
        val nBins = bins.size
        var nearestHit = 9.9f
        val spanR = rRadarMax - rAttCore
        val sweepDeg = 360f / nBins + 0.65f
        rectOuter.set(cx - rRadarMax, cy - rRadarMax, cx + rRadarMax, cy + rRadarMax)

        for (i in 0 until nBins) {
            val dist = bins[i]
            if (dist < nearestHit) nearestHit = dist
            if (dist > rangeMeters) continue

            val wAng = -PI.toFloat() + (i + 0.5f) * (PI.toFloat() * 2f / nBins)
            val cDeg = Math.toDegrees(worldToCanvasRad(wAng).toDouble()).toFloat()
            val norm = ((dist - 0.25f) / max(0.5f, rangeMeters - 0.25f)).coerceIn(0f, 1f)
            val rHit = rAttCore + 2.5f * d + norm * (spanR - 3.5f * d)

            val strokeCol: Int
            val fillCol: Int
            if (dist < 1.25f) {
                strokeCol = COL_RED
                fillCol = Color.argb(88, 255, 59, 48)
            } else if (dist < 2.35f) {
                strokeCol = COL_AMBER
                fillCol = Color.argb(54, 255, 171, 0)
            } else {
                strokeCol = COL_GREEN
                fillCol = Color.argb(54, 0, 230, 118)
            }

            rectInner.set(cx - rHit, cy - rHit, cx + rHit, cy + rHit)
            workPath.reset()
            workPath.arcTo(rectOuter, cDeg - sweepDeg * 0.5f, sweepDeg)
            workPath.arcTo(rectInner, cDeg + sweepDeg * 0.5f, -sweepDeg)
            workPath.close()
            fillPaint.color = fillCol
            canvas.drawPath(workPath, fillPaint)

            strokePaint.color = strokeCol
            strokePaint.strokeWidth = 2.0f * d
            canvas.drawArc(rectInner, cDeg - sweepDeg * 0.46f, sweepDeg * 0.92f, false, strokePaint)
        }

        canvas.save()
        clipPath.reset()
        clipPath.addCircle(cx, cy, rAttCore, Path.Direction.CW)
        canvas.clipPath(clipPath)

        canvas.translate(cx, cy)
        canvas.rotate(Math.toDegrees(snap.smoothRoll.toDouble()).toFloat())
        val pitchOffset = (snap.smoothPitch / 0.42f).coerceIn(-1f, 1f) * (rAttCore * 0.62f)

        fillPaint.color = COL_SKY
        canvas.drawRect(-rAttCore * 1.5f, -rAttCore * 2f, rAttCore * 1.5f, pitchOffset, fillPaint)
        fillPaint.color = COL_GND
        canvas.drawRect(-rAttCore * 1.5f, pitchOffset, rAttCore * 1.5f, rAttCore * 2f, fillPaint)

        strokePaint.color = Color.argb(215, 0, 230, 118)
        strokePaint.strokeWidth = 1.25f * d
        canvas.drawLine(-rAttCore * 1.2f, pitchOffset, rAttCore * 1.2f, pitchOffset, strokePaint)

        strokePaint.color = Color.argb(115, 255, 255, 255)
        strokePaint.strokeWidth = 0.85f * d
        val rungGap = rAttCore * 0.30f
        canvas.drawLine(-rAttCore * 0.38f, pitchOffset - rungGap, rAttCore * 0.38f, pitchOffset - rungGap, strokePaint)
        canvas.drawLine(-rAttCore * 0.38f, pitchOffset + rungGap, rAttCore * 0.38f, pitchOffset + rungGap, strokePaint)
        canvas.restore()

        strokePaint.color = Color.argb(90, 255, 255, 255)
        strokePaint.strokeWidth = 1.1f * d
        canvas.drawCircle(cx, cy, rAttCore, strokePaint)

        var deg = 0
        while (deg < 360) {
            val wAng = Math.toRadians((90 - deg).toDouble()).toFloat()
            val cRad = worldToCanvasRad(wAng)
            val isCard = (deg % 90 == 0)
            val is30 = (deg % 30 == 0)

            if (!isCard) {
                val r0 = if (is30) rBezelIn + 1.4f * d else rBezelIn + 2.8f * d
                val r1 = if (is30) rFull - 2.2f * d else rFull - 3.6f * d
                strokePaint.color = if (is30) Color.argb(145, 255, 255, 255) else Color.argb(62, 255, 255, 255)
                strokePaint.strokeWidth = (if (is30) 1.1f else 0.75f) * d
                canvas.drawLine(cx + cos(cRad) * r0, cy + sin(cRad) * r0, cx + cos(cRad) * r1, cy + sin(cRad) * r1, strokePaint)
            } else {
                val rTxt = (rBezelIn + rFull) * 0.5f
                val tx = cx + cos(cRad) * rTxt
                val ty = cy + sin(cRad) * rTxt + 3.2f * d
                val lbl = when (deg) {
                    0 -> "N"
                    90 -> "E"
                    180 -> "S"
                    else -> "W"
                }
                cardinalPaint.color = if (deg == 0) COL_CARD_N else Color.argb(228, 255, 255, 255)
                canvas.drawText(lbl, tx, ty, cardinalPaint)
            }
            deg += 10
        }

        workPath.reset()
        workPath.moveTo(cx, cy - rBezelIn + 1.6f * d)
        workPath.lineTo(cx - 3.0f * d, cy - rBezelIn - 3.0f * d)
        workPath.lineTo(cx + 3.0f * d, cy - rBezelIn - 3.0f * d)
        workPath.close()
        fillPaint.color = Color.WHITE
        canvas.drawPath(workPath, fillPaint)

        val goalAng = worldToCanvasRad(atan2(snap.goalY - snap.uavY, snap.goalX - snap.uavX))
        val gx = cx + cos(goalAng) * (rBezelIn - 1.2f * d)
        val gy = cy + sin(goalAng) * (rBezelIn - 1.2f * d)

        dashPaint.color = Color.argb(168, 0, 230, 118)
        dashPaint.strokeWidth = 1.2f * d
        canvas.drawLine(
            cx + cos(goalAng) * (rAttCore * 0.65f), cy + sin(goalAng) * (rAttCore * 0.65f),
            gx, gy, dashPaint
        )

        canvas.save()
        canvas.translate(gx, gy)
        canvas.rotate(45f)
        val dm = 3.0f * d
        fillPaint.color = COL_GREEN
        canvas.drawRect(-dm, -dm, dm, dm, fillPaint)
        strokePaint.color = Color.WHITE
        strokePaint.strokeWidth = 1.0f * d
        canvas.drawRect(-dm, -dm, dm, dm, strokePaint)
        canvas.restore()

        val hSpd = hypot(snap.vx, snap.vy)
        if (hSpd > 0.15f) {
            val vAng = worldToCanvasRad(atan2(snap.vy, snap.vx))
            val vLen = min(rRadarMax * 0.85f, rAttCore + (hSpd / max(1f, hub.maxVel)) * (rRadarMax - rAttCore) * 0.75f)
            strokePaint.color = COL_BLUE
            strokePaint.strokeWidth = 1.6f * d
            canvas.drawLine(cx, cy, cx + cos(vAng) * vLen, cy + sin(vAng) * vLen, strokePaint)
        }

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(Math.toDegrees((noseRad + PI.toFloat() * 0.5f).toDouble()).toFloat())
        workPath.reset()
        workPath.moveTo(0f, -8.5f * d)
        workPath.lineTo(6.4f * d, 5.8f * d)
        workPath.lineTo(0f, 2.5f * d)
        workPath.lineTo(-6.4f * d, 5.8f * d)
        workPath.close()
        fillPaint.color = Color.WHITE
        canvas.drawPath(workPath, fillPaint)
        strokePaint.color = Color.argb(220, 12, 15, 19)
        strokePaint.strokeWidth = 1.1f * d
        canvas.drawPath(workPath, strokePaint)
        canvas.restore()

        val pillTxt = if (nearestHit <= rangeMeters) {
            String.format(Locale.US, "避障 %.1fm", nearestHit)
        } else {
            "${if (northUpMode) "北向" else "机头"} ${rangeMeters.toInt()}m"
        }
        pillTextPaint.color = when {
            nearestHit < 1.25f -> COL_RED
            nearestHit < 2.35f -> COL_AMBER
            else -> Color.argb(195, 255, 255, 255)
        }
        val pw = 44f * d
        val ph = 11.5f * d
        pillRect.set(cx - pw * 0.5f, cy + rBezelIn - ph - 2f * d, cx + pw * 0.5f, cy + rBezelIn - 2f * d)
        fillPaint.color = Color.argb(210, 10, 12, 16)
        canvas.drawRoundRect(pillRect, 3.5f * d, 3.5f * d, fillPaint)
        canvas.drawText(pillTxt, cx, pillRect.centerY() + 2.8f * d, pillTextPaint)
    }
}

/**
 * 航空级防重叠顶部水平航向带 (脏检查按需重绘 + 预缓存刻度字符串数组)
 */
class DjiCompassTapeView(context: Context, private val hub: GcsSharedHub) : View(context) {

    companion object {
        private val DEG_LABELS = Array(12) { idx ->
            when (val deg = idx * 30) {
                0 -> "N"
                90 -> "E"
                180 -> "S"
                270 -> "W"
                else -> String.format(Locale.US, "%03d", deg)
            }
        }
        private val OCTANTS = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    }

    private var lastYaw = -999f
    private var lastGoalAng = -999f

    private val density = resources.displayMetrics.density
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9.2f * density
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val readoutBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(238, 12, 15, 20)
    }
    private val readoutStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.0f * density
        color = Color.argb(165, 0, 230, 118)
    }
    private val readoutTxtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 10.2f * density
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
        isFakeBoldText = true
        color = -0xff198a
    }
    private val lubberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = -0xff198a
        style = Paint.Style.FILL
    }
    private val goalCaretPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = -0x964801
        style = Paint.Style.FILL
    }
    private val lubberPath = Path()
    private val badgeRect = RectF()

    fun invalidateIfChanged() {
        val s = hub.latestSnapshot
        val ga = atan2(s.goalY - s.uavY, s.goalX - s.uavX)
        if (abs(s.yaw - lastYaw) > 0.0025f || abs(ga - lastGoalAng) > 0.01f) {
            lastYaw = s.yaw
            lastGoalAng = ga
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val snap = hub.latestSnapshot
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 4f || h <= 4f) return

        val yawDeg = Math.toDegrees(snap.yaw.toDouble()).toFloat()
        var heading = (90f - yawDeg) % 360f
        if (heading < 0f) heading += 360f

        val center = w * 0.5f
        val pxPerDeg = 1.75f * density
        val padX = 5f * density

        canvas.save()
        canvas.clipRect(padX, 1f, w - padX, h - 1f)

        val halfSpanDeg = ((w * 0.5f) / pxPerDeg).toInt() + 10
        val startD = ((floor((heading - halfSpanDeg) / 10f)).toInt()) * 10
        val endD = ((ceil((heading + halfSpanDeg) / 10f)).toInt()) * 10

        var deg = startD
        while (deg <= endD) {
            val x = center + (deg - heading) * pxPerDeg
            if (x >= padX && x <= w - padX) {
                val edgeDist = min(x - padX, (w - padX) - x)
                val edgeFade = (edgeDist / (18f * density)).coerceIn(0f, 1f)
                val norm = ((deg % 360) + 360) % 360
                val cardinal = (norm % 90 == 0)
                val is30 = (norm % 30 == 0)

                val tickBaseAlpha = if (cardinal) 220 else if (is30) 150 else 80
                tickPaint.color = Color.argb((tickBaseAlpha * edgeFade).roundToInt(), 255, 255, 255)
                tickPaint.strokeWidth = (if (cardinal) 1.4f else 0.95f) * density
                val tickTop = h - (if (is30) 6.8f else 3.8f) * density
                canvas.drawLine(x, tickTop, x, h - 1.2f * density, tickPaint)

                if (is30) {
                    val distFromCenter = abs(x - center)
                    val centerMask = ((distFromCenter - 29f * density) / (9f * density)).coerceIn(0f, 1f)
                    val finalAlpha = edgeFade * centerMask
                    if (finalAlpha > 0.04f) {
                        val label = DEG_LABELS[(norm / 30) % 12]
                        txtPaint.color = when {
                            norm == 0 -> Color.argb((255 * finalAlpha).roundToInt(), 255, 77, 79)
                            cardinal -> Color.argb((245 * finalAlpha).roundToInt(), 255, 255, 255)
                            else -> Color.argb((185 * finalAlpha).roundToInt(), 210, 220, 232)
                        }
                        canvas.drawText(label, x, 12.2f * density, txtPaint)
                    }
                }
            }
            deg += 10
        }

        val goalWorldDeg = Math.toDegrees(atan2((snap.goalY - snap.uavY).toDouble(), (snap.goalX - snap.uavX).toDouble())).toFloat()
        var goalHeading = (90f - goalWorldDeg) % 360f
        if (goalHeading < 0f) goalHeading += 360f
        var diffGoal = goalHeading - heading
        while (diffGoal > 180f) diffGoal -= 360f
        while (diffGoal < -180f) diffGoal += 360f
        val gx = (center + diffGoal * pxPerDeg).coerceIn(padX + 4f * density, w - padX - 4f * density)
        lubberPath.reset()
        lubberPath.moveTo(gx, h - 1.2f * density)
        lubberPath.lineTo(gx - 2.8f * density, h - 5.2f * density)
        lubberPath.lineTo(gx + 2.8f * density, h - 5.2f * density)
        lubberPath.close()
        canvas.drawPath(lubberPath, goalCaretPaint)

        canvas.restore()

        val hdgInt = heading.roundToInt() % 360
        val octant = OCTANTS[((hdgInt + 22) % 360) / 45]
        val boxW = 54f * density
        val boxH = 16.5f * density
        badgeRect.set(center - boxW * 0.5f, 2.2f * density, center + boxW * 0.5f, 2.2f * density + boxH)
        canvas.drawRoundRect(badgeRect, 4.5f * density, 4.5f * density, readoutBgPaint)
        canvas.drawRoundRect(badgeRect, 4.5f * density, 4.5f * density, readoutStrokePaint)
        canvas.drawText(String.format(Locale.US, "%03d° %s", hdgInt, octant), center, badgeRect.centerY() + 3.5f * density, readoutTxtPaint)

        lubberPath.reset()
        lubberPath.moveTo(center, badgeRect.bottom + 4.2f * density)
        lubberPath.lineTo(center - 3.2f * density, badgeRect.bottom + 0.4f * density)
        lubberPath.lineTo(center + 3.2f * density, badgeRect.bottom + 0.4f * density)
        lubberPath.close()
        canvas.drawPath(lubberPath, lubberPaint)
    }
}
