package com.radiomaster.egogcs.ros

import com.radiomaster.egogcs.engine.EgoSimEngine
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.TopicConfig
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.EOFException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

class TcpRosNativeClient(
    private val hub: GcsSharedHub,
    private val engine: EgoSimEngine,
    private val onStateToast: (String) -> Unit
) : RosTransport {

    override val protocolId: String = "tcpros"

    companion object {
        private const val CALLER_ID = "/ego_pilot_android"
        private const val POSE_STAMPED_MD5 = "d3812c3cbc69362b77dc0b19b345f8f5"
    }

    private class StreamScratch(initBytes: Int) {
        var frameBytes = ByteArray(initBytes)
        val cloudXyzi = FloatArray(8016 * 4)
        val inflateXyz = FloatArray(1520 * 3)
        val pathXyz = FloatArray(820 * 3)

        fun ensureFrameCapacity(required: Int): ByteArray {
            if (required > frameBytes.size) {
                var nextCap = frameBytes.size
                while (nextCap < required) nextCap = nextCap shl 1
                frameBytes = ByteArray(nextCap)
            }
            return frameBytes
        }
    }

    @Volatile private var active = false
    @Volatile var topics = TopicConfig()

    private val ioPool = Executors.newCachedThreadPool { r ->
        Thread(r, "TcpRosNativeIO").apply { isDaemon = true }
    }
    private val openSockets = CopyOnWriteArrayList<Socket>()
    private var slaveRpcServer: ServerSocket? = null
    private var pubTcpServer: ServerSocket? = null
    private val goalSubscribers = CopyOnWriteArrayList<BufferedOutputStream>()
    private val goalPacketLock = Any()
    private val goalPacketBuf = ByteBuffer.allocate(128).order(ByteOrder.LITTLE_ENDIAN)
    private var goalSeq = 1

    override fun connect(cfg: TopicConfig) {
        topics = cfg.copy()
        disconnect(silent = true)
        active = true

        hub.isRosMode = true
        hub.connectionLevel = 1
        hub.connectionLabel = "正在直连 roscore..."

        ioPool.execute {
            try {
                val masterUri = cfg.masterUri.trim().removeSuffix("/")
                val masterHost = URI(masterUri).host ?: throw IllegalArgumentException("Master IP 无效")
                val localIp = detectLocalWifiIp(masterHost)

                startGoalPublisherServer(masterUri, localIp, cfg.goalTopic)

                val pingXml = xmlRpcCall(masterUri, "getUri", listOf(CALLER_ID))
                if (!pingXml.contains("<int>1</int>") && !pingXml.contains("<i4>1</i4>")) {
                    throw IllegalStateException("roscore 未就绪")
                }

                hub.rosConnected = true
                hub.connectionLevel = 0
                hub.connectionLabel = "TCPROS · FAST-LIO"
                onStateToast("已通过原生 TCPROS 直连 $masterUri")

                val subPairs = mutableListOf<Pair<String, String>>()
                if (cfg.odomTopic.isNotBlank()) subPairs.add(cfg.odomTopic.trim() to "odom")
                if (cfg.fastLioCloudTopic.isNotBlank()) subPairs.add(cfg.fastLioCloudTopic.trim() to "fastlio_cloud")
                if (cfg.fastLioPathTopic.isNotBlank() && cfg.fastLioPathTopic.trim() != cfg.optimalTopic.trim()) {
                    subPairs.add(cfg.fastLioPathTopic.trim() to "fastlio_path")
                }
                if (cfg.optimalTopic.isNotBlank()) subPairs.add(cfg.optimalTopic.trim() to "optimal")
                if (cfg.inflateTopic.isNotBlank() && cfg.inflateTopic.trim() != cfg.fastLioCloudTopic.trim()) {
                    subPairs.add(cfg.inflateTopic.trim() to "inflate")
                }
                subPairs.add("/mavros/state" to "state")
                subPairs.add("/mavros/battery" to "bat")

                for ((tName, kind) in subPairs) {
                    ioPool.execute { subscribeTopicLoop(masterUri, masterHost, localIp, tName, kind) }
                }
            } catch (e: Exception) {
                if (active) {
                    hub.rosConnected = false
                    hub.connectionLevel = 2
                    hub.connectionLabel = "roscore 连接失败"
                    onStateToast("TCPROS 直连失败: ${e.localizedMessage ?: "请检查 ROS_MASTER_URI 与 ROS_IP"}")
                }
            }
        }
    }

    override fun disconnect(silent: Boolean) {
        active = false
        hub.rosConnected = false
        for (s in openSockets) {
            try { s.close() } catch (_: Throwable) {}
        }
        openSockets.clear()
        goalSubscribers.clear()
        try { slaveRpcServer?.close() } catch (_: Throwable) {}
        try { pubTcpServer?.close() } catch (_: Throwable) {}
        slaveRpcServer = null
        pubTcpServer = null

        if (!silent) {
            if (hub.isRosMode) {
                hub.connectionLevel = 2
                hub.connectionLabel = "TCPROS 已断开"
            } else {
                hub.connectionLevel = 0
                hub.connectionLabel = "正常飞行 (DEMO)"
            }
        }
    }

    override fun setParamAsync(paramName: String, value: Float) {
        if (!active || !hub.rosConnected) return
        val masterUri = topics.masterUri.trim().removeSuffix("/")
        ioPool.execute {
            try {
                val body = buildString {
                    append("<?xml version=\"1.0\"?><methodCall><methodName>setParam</methodName><params>")
                    append("<param><value><string>$CALLER_ID</string></value></param>")
                    append("<param><value><string>${escapeXml(paramName)}</string></value></param>")
                    append("<param><value><double>$value</double></value></param>")
                    append("</params></methodCall>")
                }
                postXml(masterUri, body)
            } catch (_: Throwable) {}
        }
    }

    override fun publishGoal(gx: Float, gy: Float, gz: Float, curX: Float, curY: Float) {
        if (!active || goalSubscribers.isEmpty()) return
        ioPool.execute {
            synchronized(goalPacketLock) {
                val frameBytes = "world".toByteArray(Charsets.US_ASCII)
                val payloadLen = 16 + frameBytes.size + 56
                goalPacketBuf.clear()
                goalPacketBuf.putInt(payloadLen)
                goalPacketBuf.putInt(goalSeq++)
                val nowMs = System.currentTimeMillis()
                goalPacketBuf.putInt((nowMs / 1000L).toInt())
                goalPacketBuf.putInt(((nowMs % 1000L) * 1_000_000L).toInt())
                goalPacketBuf.putInt(frameBytes.size)
                goalPacketBuf.put(frameBytes)

                val yaw = atan2((gy - curY).toDouble(), (gx - curX).toDouble())
                goalPacketBuf.putDouble(gx.toDouble())
                goalPacketBuf.putDouble(gy.toDouble())
                goalPacketBuf.putDouble(gz.toDouble())
                goalPacketBuf.putDouble(0.0)
                goalPacketBuf.putDouble(0.0)
                goalPacketBuf.putDouble(sin(yaw * 0.5))
                goalPacketBuf.putDouble(cos(yaw * 0.5))
                val totalBytes = 4 + payloadLen
                val packetCopy = goalPacketBuf.array()
                for (out in goalSubscribers) {
                    try {
                        synchronized(out) {
                            out.write(packetCopy, 0, totalBytes)
                            out.flush()
                        }
                    } catch (_: Throwable) {
                        goalSubscribers.remove(out)
                    }
                }
            }
        }
    }

    private fun subscribeTopicLoop(masterUri: String, masterHost: String, localIp: String, topic: String, kind: String) {
        val initSize = if (kind == "fastlio_cloud" || kind == "inflate") 262_144 else 4096
        val scratch = StreamScratch(initSize)

        while (active) {
            try {
                val slavePort = slaveRpcServer?.localPort ?: 0
                val callerApi = "http://$localIp:$slavePort/"
                val regResp = xmlRpcCall(masterUri, "registerSubscriber", listOf(CALLER_ID, topic, "*", callerApi))
                val pubUris = extractHttpUris(regResp)

                if (pubUris.isEmpty()) {
                    Thread.sleep(1500L)
                    continue
                }

                val pubUri = rewriteHostIfLocal(pubUris[0], masterHost)
                val reqBody = buildString {
                    append("<?xml version=\"1.0\"?><methodCall><methodName>requestTopic</methodName><params>")
                    append("<param><value><string>$CALLER_ID</string></value></param>")
                    append("<param><value><string>${escapeXml(topic)}</string></value></param>")
                    append("<param><value><array><data><value><array><data><value><string>TCPROS</string></value></data></array></value></data></array></value></param>")
                    append("</params></methodCall>")
                }
                val topicResp = postXml(pubUri, reqBody)
                val endpoint = parseRequestTopicEndpoint(topicResp, masterHost)
                if (endpoint == null) {
                    Thread.sleep(1500L)
                    continue
                }

                streamTcpRosTopic(endpoint.first, endpoint.second, topic, kind, scratch)
            } catch (_: Throwable) {
                if (active) {
                    try { Thread.sleep(1500L) } catch (_: InterruptedException) { break }
                }
            }
        }
    }

    private fun streamTcpRosTopic(host: String, port: Int, topic: String, kind: String, scratch: StreamScratch) {
        val sock = Socket()
        openSockets.add(sock)
        try {
            sock.tcpNoDelay = true
            sock.receiveBufferSize = if (kind == "fastlio_cloud") 2 * 1024 * 1024 else 512 * 1024
            sock.connect(InetSocketAddress(host, port), 4000)

            val out = BufferedOutputStream(sock.getOutputStream())
            val bufSz = if (kind == "fastlio_cloud") 131072 else 32768
            val inp = DataInputStream(BufferedInputStream(sock.getInputStream(), bufSz))

            val hdr = encodeTcpRosHeader(
                listOf(
                    "callerid=$CALLER_ID",
                    "topic=$topic",
                    "md5sum=*",
                    "type=*",
                    "tcp_nodelay=1"
                )
            )
            out.write(hdr)
            out.flush()

            val hdrLen = readFrameIntoScratch(inp, scratch, maxFrame = 65536)
            if (hdrLen <= 0) return
            val hdrFields = decodeTcpRosHeader(scratch.frameBytes, hdrLen)
            val msgType = hdrFields["type"] ?: ""
            val msgMd5 = hdrFields["md5sum"] ?: ""
            val isNoeticBattery = msgMd5.startsWith("4ddae")

            var lastInflateMs = 0L
            while (active && !sock.isClosed) {
                val frameLen = readFrameIntoScratch(inp, scratch, maxFrame = 12 * 1024 * 1024)
                if (frameLen < 0) break
                val buf = scratch.frameBytes
                when (kind) {
                    "odom" -> decodeNativeOdometry(buf, frameLen)
                    "fastlio_cloud" -> decodeNativeFastLioCloud(buf, frameLen, scratch)
                    "fastlio_path" -> decodeNativePath(buf, frameLen, scratch, isGlobalLioPath = true)
                    "optimal" -> {
                        if (msgType.contains("Path")) decodeNativePath(buf, frameLen, scratch, isGlobalLioPath = false)
                        else decodeNativeMarker(buf, frameLen, scratch)
                    }
                    "inflate" -> {
                        val now = System.currentTimeMillis()
                        if (now - lastInflateMs >= 90L) {
                            lastInflateMs = now
                            decodeNativeInflateCloud(buf, frameLen, scratch)
                        }
                    }
                    "state" -> decodeNativeMavrosState(buf, frameLen)
                    "bat" -> decodeNativeBattery(buf, frameLen, isNoeticBattery)
                }
            }
        } finally {
            openSockets.remove(sock)
            try { sock.close() } catch (_: Throwable) {}
        }
    }

    private fun skipStdHeader(bb: ByteBuffer): Boolean {
        if (bb.remaining() < 16) return false
        bb.position(bb.position() + 12)
        val frameLen = bb.int
        if (frameLen < 0 || bb.remaining() < frameLen) return false
        bb.position(bb.position() + frameLen)
        return true
    }

    private fun skipRosString(bb: ByteBuffer): Boolean {
        if (bb.remaining() < 4) return false
        val len = bb.int
        if (len < 0 || bb.remaining() < len) return false
        bb.position(bb.position() + len)
        return true
    }

    private fun readRosString(bb: ByteBuffer): String? {
        if (bb.remaining() < 4) return null
        val len = bb.int
        if (len < 0 || bb.remaining() < len) return null
        val start = bb.position()
        val str = String(bb.array(), bb.arrayOffset() + start, len, Charsets.UTF_8)
        bb.position(start + len)
        return str
    }

    private fun decodeNativeOdometry(bytes: ByteArray, length: Int) {
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (!skipStdHeader(bb)) return
        if (!skipRosString(bb)) return
        if (bb.remaining() < 344) return
        val px = bb.double.toFloat()
        val py = bb.double.toFloat()
        val pz = bb.double.toFloat()
        val qx = bb.double
        val qy = bb.double
        val qz = bb.double
        val qw = bb.double
        bb.position(bb.position() + 288)

        var vx = 0f; var vy = 0f; var vz = 0f
        if (bb.remaining() >= 24) {
            vx = bb.double.toFloat()
            vy = bb.double.toFloat()
            vz = bb.double.toFloat()
        }
        val yaw = atan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz)).toFloat()
        engine.onRosOdometry(px, py, pz, vx, vy, vz, yaw)
    }

    private fun decodeNativeMarker(bytes: ByteArray, length: Int, scratch: StreamScratch) {
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (!skipStdHeader(bb)) return
        if (!skipRosString(bb)) return
        if (bb.remaining() < 121) return
        bb.position(bb.position() + 117)
        val ptCount = bb.int
        if (ptCount <= 0 || ptCount > 10000 || bb.remaining() < ptCount * 24) return

        val stride = max(1, ptCount / 400)
        val flat = scratch.pathXyz
        var outCnt = 0
        for (i in 0 until ptCount) {
            val px = bb.double.toFloat()
            val py = bb.double.toFloat()
            val pz = bb.double.toFloat()
            if ((i % stride == 0 || i == ptCount - 1) && outCnt < 410) {
                flat[outCnt * 3] = px
                flat[outCnt * 3 + 1] = py
                flat[outCnt * 3 + 2] = pz
                outCnt++
            }
        }
        engine.onRosOptimalPath(flat, outCnt)
    }

    private fun decodeNativePath(bytes: ByteArray, length: Int, scratch: StreamScratch, isGlobalLioPath: Boolean) {
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (!skipStdHeader(bb)) return
        if (bb.remaining() < 4) return
        val count = bb.int
        if (count <= 0 || count > 200_000) return

        val maxCap = if (isGlobalLioPath) 800 else 400
        val stride = max(1, count / maxCap)
        val flat = scratch.pathXyz
        var valid = 0
        for (i in 0 until count) {
            if (!skipStdHeader(bb)) break
            if (bb.remaining() < 56) break
            val px = bb.double.toFloat()
            val py = bb.double.toFloat()
            val pz = bb.double.toFloat()
            bb.position(bb.position() + 32)
            if ((i % stride == 0 || i == count - 1) && valid < 815) {
                flat[valid * 3] = px
                flat[valid * 3 + 1] = py
                flat[valid * 3 + 2] = pz
                valid++
            }
        }
        if (valid > 0) {
            if (isGlobalLioPath) engine.onRosFastLioPath(flat, valid)
            else engine.onRosOptimalPath(flat, valid)
        }
    }

    private fun decodeNativeFastLioCloud(bytes: ByteArray, length: Int, scratch: StreamScratch) {
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (!skipStdHeader(bb)) return
        if (bb.remaining() < 12) return
        bb.int; bb.int
        val fieldCount = bb.int
        if (fieldCount < 0 || fieldCount > 64) return

        var offX = 0; var offY = 4; var offZ = 8
        var offInten = -1
        var intenType = 7
        for (f in 0 until fieldCount) {
            val name = readRosString(bb) ?: return
            if (bb.remaining() < 9) return
            val offset = bb.int
            val dtype = bb.get().toInt() and 0xFF
            bb.int
            when (name) {
                "x" -> offX = offset
                "y" -> offY = offset
                "z" -> offZ = offset
                "intensity", "reflectivity" -> {
                    offInten = offset
                    intenType = dtype
                }
            }
        }
        if (bb.remaining() < 13) return
        val bigEndian = bb.get().toInt() != 0
        val pointStep = bb.int
        bb.int
        val dataLen = bb.int
        if (pointStep < 12 || dataLen <= 0 || bb.remaining() < dataLen) return

        val dataStart = bb.position()
        val cloudView = ByteBuffer.wrap(bytes, dataStart, dataLen)
            .order(if (bigEndian) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN)

        val totalPts = dataLen / pointStep
        val stride = max(1, totalPts / 8000)
        val xyzi = scratch.cloudXyzi
        var outCnt = 0
        var p = 0
        val reqTail = max(max(offX, max(offY, offZ)) + 4, if (offInten >= 0) offInten + 4 else 12)

        while (p < totalPts && outCnt < 8010) {
            val pos = dataStart + p * pointStep
            if (pos + reqTail > dataStart + dataLen) break
            val px = cloudView.getFloat(pos + offX)
            val py = cloudView.getFloat(pos + offY)
            val pz = cloudView.getFloat(pos + offZ)
            if (px.isFinite() && py.isFinite() && pz.isFinite()) {
                val normInten = if (offInten >= 0) {
                    val rawI = when (intenType) {
                        2 -> (cloudView.get(pos + offInten).toInt() and 0xFF) / 255f
                        4 -> (cloudView.getShort(pos + offInten).toInt() and 0xFFFF) / 65535f
                        else -> {
                            val fv = cloudView.getFloat(pos + offInten)
                            if (fv > 1.5f) (fv / 255f) else fv
                        }
                    }
                    rawI.coerceIn(0.05f, 1.0f)
                } else {
                    ((pz + 0.5f) / 3.5f).coerceIn(0.05f, 1.0f)
                }
                val dst = outCnt * 4
                xyzi[dst] = px
                xyzi[dst + 1] = py
                xyzi[dst + 2] = pz
                xyzi[dst + 3] = normInten
                outCnt++
            }
            p += stride
        }
        if (outCnt > 0) {
            engine.onRosFastLioCloud(xyzi, outCnt)
        }
    }

    private fun decodeNativeInflateCloud(bytes: ByteArray, length: Int, scratch: StreamScratch) {
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (!skipStdHeader(bb)) return
        if (bb.remaining() < 12) return
        bb.int; bb.int
        val fieldCount = bb.int
        if (fieldCount < 0 || fieldCount > 64) return

        var offX = 0; var offY = 4; var offZ = 8
        for (f in 0 until fieldCount) {
            val name = readRosString(bb) ?: return
            if (bb.remaining() < 9) return
            val offset = bb.int
            bb.get(); bb.int
            when (name) {
                "x" -> offX = offset
                "y" -> offY = offset
                "z" -> offZ = offset
            }
        }
        if (bb.remaining() < 13) return
        val bigEndian = bb.get().toInt() != 0
        val pointStep = bb.int
        bb.int
        val dataLen = bb.int
        if (pointStep < 12 || dataLen <= 0 || bb.remaining() < dataLen) return

        val dataStart = bb.position()
        val cloudView = ByteBuffer.wrap(bytes, dataStart, dataLen)
            .order(if (bigEndian) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN)

        val totalPts = dataLen / pointStep
        val stride = max(1, totalPts / 1500)
        val flat = scratch.inflateXyz
        var outCnt = 0
        var p = 0
        val reqTail = max(offX, max(offY, offZ)) + 4
        while (p < totalPts && outCnt < 1515) {
            val pos = dataStart + p * pointStep
            if (pos + reqTail > dataStart + dataLen) break
            val px = cloudView.getFloat(pos + offX)
            val py = cloudView.getFloat(pos + offY)
            val pz = cloudView.getFloat(pos + offZ)
            if (px.isFinite() && py.isFinite() && pz.isFinite()) {
                flat[outCnt * 3] = px
                flat[outCnt * 3 + 1] = py
                flat[outCnt * 3 + 2] = pz
                outCnt++
            }
            p += stride
        }
        engine.onRosInflatedCloud(flat, outCnt)
    }

    private fun decodeNativeMavrosState(bytes: ByteArray, length: Int) {
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (!skipStdHeader(bb)) return
        if (bb.remaining() < 5) return
        bb.get()
        val armed = bb.get().toInt() != 0
        bb.get(); bb.get()
        val mode = readRosString(bb) ?: "OFFBOARD"
        engine.onRosMavrosState(mode, armed)
    }

    private fun decodeNativeBattery(bytes: ByteArray, length: Int, isNoetic: Boolean) {
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (!skipStdHeader(bb)) return
        if (bb.remaining() < 12) return

        val basePos = bb.position()
        val volt = bb.getFloat(basePos)
        if (!volt.isFinite() || volt <= 1.0f) return

        val rawCurrent = if (isNoetic && bb.remaining() >= 12) {
            bb.getFloat(basePos + 8)
        } else {
            bb.getFloat(basePos + 4)
        }
        val amps = if (rawCurrent.isFinite()) abs(rawCurrent) else 0f

        val rawPctOffset = if (isNoetic) 24 else 20
        val pct = if (bb.remaining() >= rawPctOffset + 4) {
            val pVal = bb.getFloat(basePos + rawPctOffset)
            if (pVal.isFinite() && pVal > 0f) {
                (if (pVal <= 1.05f) pVal * 100f else pVal).roundToInt().coerceIn(0, 100)
            } else -1
        } else -1

        val finalPct = if (pct in 0..100) {
            pct
        } else {
            val cells = if (volt > 18.0f) 6f else 4f
            (((volt / cells - 3.50f) / (4.18f - 3.50f)) * 100f).roundToInt().coerceIn(0, 100)
        }
        engine.onRosBattery(volt, finalPct, amps)
    }

    private fun startGoalPublisherServer(masterUri: String, localIp: String, goalTopic: String) {
        val tcpSrv = ServerSocket(0)
        val rpcSrv = ServerSocket(0)
        pubTcpServer = tcpSrv
        slaveRpcServer = rpcSrv
        val tcpPort = tcpSrv.localPort
        val rpcPort = rpcSrv.localPort

        ioPool.execute {
            val handshakeScratch = StreamScratch(4096)
            while (active && !tcpSrv.isClosed) {
                try {
                    val client = tcpSrv.accept()
                    client.tcpNoDelay = true
                    openSockets.add(client)
                    ioPool.execute {
                        try {
                            val inp = DataInputStream(BufferedInputStream(client.getInputStream()))
                            val out = BufferedOutputStream(client.getOutputStream())
                            readFrameIntoScratch(inp, handshakeScratch, 65536)
                            val reply = encodeTcpRosHeader(
                                listOf(
                                    "callerid=$CALLER_ID",
                                    "topic=$goalTopic",
                                    "type=geometry_msgs/PoseStamped",
                                    "md5sum=$POSE_STAMPED_MD5",
                                    "latching=1"
                                )
                            )
                            out.write(reply)
                            out.flush()
                            goalSubscribers.add(out)
                        } catch (_: Throwable) {}
                    }
                } catch (_: Throwable) { break }
            }
        }

        ioPool.execute {
            while (active && !rpcSrv.isClosed) {
                try {
                    val sock = rpcSrv.accept()
                    ioPool.execute {
                        try {
                            val reqBuf = ByteArray(4096)
                            val n = sock.getInputStream().read(reqBuf)
                            val reqStr = if (n > 0) String(reqBuf, 0, n, Charsets.UTF_8) else ""
                            val xmlResp = if (reqStr.contains("requestTopic")) {
                                "<?xml version=\"1.0\"?><methodResponse><params><param><value><array><data>" +
                                    "<value><int>1</int></value><value><string>ready</string></value>" +
                                    "<value><array><data><value><string>TCPROS</string></value>" +
                                    "<value><string>$localIp</string></value>" +
                                    "<value><int>$tcpPort</int></value></data></array></value>" +
                                    "</data></array></value></param></params></methodResponse>"
                            } else {
                                "<?xml version=\"1.0\"?><methodResponse><params><param><value><array><data>" +
                                    "<value><int>1</int></value><value><string>ok</string></value><value><int>0</int></value>" +
                                    "</data></array></value></param></params></methodResponse>"
                            }
                            val bodyBytes = xmlResp.toByteArray(Charsets.UTF_8)
                            val httpHeader = "HTTP/1.1 200 OK\r\nContent-Type: text/xml\r\nContent-Length: ${bodyBytes.size}\r\nConnection: close\r\n\r\n"
                            val out = sock.getOutputStream()
                            out.write(httpHeader.toByteArray(Charsets.UTF_8))
                            out.write(bodyBytes)
                            out.flush()
                        } catch (_: Throwable) {
                        } finally {
                            try { sock.close() } catch (_: Throwable) {}
                        }
                    }
                } catch (_: Throwable) { break }
            }
        }

        if (goalTopic.isNotBlank()) {
            try {
                xmlRpcCall(masterUri, "registerPublisher", listOf(CALLER_ID, goalTopic, "geometry_msgs/PoseStamped", "http://$localIp:$rpcPort/"))
            } catch (_: Throwable) {}
        }
    }

    private fun readFrameIntoScratch(inp: DataInputStream, scratch: StreamScratch, maxFrame: Int): Int {
        val b0 = inp.read()
        if (b0 < 0) return -1
        val b1 = inp.read(); val b2 = inp.read(); val b3 = inp.read()
        if ((b1 or b2 or b3) < 0) throw EOFException()
        val len = (b0 and 0xFF) or ((b1 and 0xFF) shl 8) or ((b2 and 0xFF) shl 16) or ((b3 and 0xFF) shl 24)
        if (len < 0 || len > maxFrame) throw IllegalStateException("Frame size out of bounds: $len")
        val target = scratch.ensureFrameCapacity(len)
        inp.readFully(target, 0, len)
        return len
    }

    private fun encodeTcpRosHeader(fields: List<String>): ByteArray {
        val encoded = fields.map { it.toByteArray(Charsets.UTF_8) }
        val payloadLen = encoded.sumOf { 4 + it.size }
        val bb = ByteBuffer.allocate(4 + payloadLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(payloadLen)
        for (f in encoded) {
            bb.putInt(f.size)
            bb.put(f)
        }
        return bb.array()
    }

    private fun decodeTcpRosHeader(bytes: ByteArray, length: Int): Map<String, String> {
        val map = mutableMapOf<String, String>()
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        while (bb.remaining() >= 4) {
            val fLen = bb.int
            if (fLen <= 0 || bb.remaining() < fLen) break
            val start = bb.position()
            val str = String(bytes, start, fLen, Charsets.UTF_8)
            bb.position(start + fLen)
            val eq = str.indexOf('=')
            if (eq > 0) map[str.substring(0, eq)] = str.substring(eq + 1)
        }
        return map
    }

    private fun xmlRpcCall(uri: String, method: String, stringArgs: List<String>): String {
        val xml = buildString {
            append("<?xml version=\"1.0\"?><methodCall><methodName>$method</methodName><params>")
            for (arg in stringArgs) {
                append("<param><value><string>${escapeXml(arg)}</string></value></param>")
            }
            append("</params></methodCall>")
        }
        return postXml(uri, xml)
    }

    private fun postXml(uri: String, xmlBody: String): String {
        val conn = (URL(uri).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 3500
            readTimeout = 4000
            doOutput = true
            setRequestProperty("Content-Type", "text/xml")
        }
        return try {
            val bytes = xmlBody.toByteArray(Charsets.UTF_8)
            conn.outputStream.use { it.write(bytes) }
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun extractHttpUris(xml: String): List<String> {
        val regex = Regex("http://[^<\\s\"']+")
        return regex.findAll(xml).map { it.value }.toList()
    }

    private fun rewriteHostIfLocal(pubUri: String, masterHost: String): String {
        return try {
            val u = URI(pubUri)
            val h = u.host ?: ""
            if (h == "localhost" || h == "127.0.0.1" || !h.contains('.')) {
                "http://$masterHost:${u.port}${u.path ?: "/"}"
            } else {
                pubUri
            }
        } catch (_: Throwable) {
            pubUri
        }
    }

    private fun parseRequestTopicEndpoint(xml: String, fallbackHost: String): Pair<String, Int>? {
        val strRegex = Regex("<string>\\s*([^<]+?)\\s*</string>")
        val intRegex = Regex("<(?:int|i4)>\\s*(\\d+)\\s*</(?:int|i4)>")
        val strs = strRegex.findAll(xml).map { it.groupValues[1] }.toList()
        val ints = intRegex.findAll(xml).mapNotNull { it.groupValues[1].toIntOrNull() }.toList()

        val tcpIdx = strs.indexOf("TCPROS")
        if (tcpIdx < 0 || ints.size < 2) return null
        val rawHost = if (tcpIdx + 1 < strs.size) strs[tcpIdx + 1] else fallbackHost
        val host = if (rawHost == "localhost" || rawHost == "127.0.0.1" || !rawHost.contains('.')) fallbackHost else rawHost
        val port = ints.last()
        return if (port in 1..65535) host to port else null
    }

    private fun detectLocalWifiIp(remoteHost: String): String {
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(remoteHost, 11311), 1500)
                val addr = probe.localAddress?.hostAddress
                if (!addr.isNullOrBlank() && addr != "127.0.0.1") return addr
            }
        } catch (_: Throwable) {}
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val nif = interfaces.nextElement()
                if (!nif.isUp || nif.isLoopback) continue
                val addrs = nif.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: continue
                }
            }
        } catch (_: Throwable) {}
        return "127.0.0.1"
    }

    private fun escapeXml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}
