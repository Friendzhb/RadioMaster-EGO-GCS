package com.radiomaster.egogcs.ui

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.PathInterpolator
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

object AnimHelper {

    val EASE_OUT_EXPO = PathInterpolator(0.22f, 1f, 0.36f, 1f)
    private var toastHideRunnable: Runnable? = null

    @SuppressLint("ClickableViewAccessibility")
    fun attachSpringTouch(view: View) {
        val scaleXAnim = SpringAnimation(view, DynamicAnimation.SCALE_X, 1f).apply {
            spring = SpringForce(1f).apply {
                stiffness = SpringForce.STIFFNESS_MEDIUM
                dampingRatio = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY
            }
        }
        val scaleYAnim = SpringAnimation(view, DynamicAnimation.SCALE_Y, 1f).apply {
            spring = SpringForce(1f).apply {
                stiffness = SpringForce.STIFFNESS_MEDIUM
                dampingRatio = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY
            }
        }

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    scaleXAnim.animateToFinalPosition(0.92f)
                    scaleYAnim.animateToFinalPosition(0.92f)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    scaleXAnim.animateToFinalPosition(1.0f)
                    scaleYAnim.animateToFinalPosition(1.0f)
                }
            }
            false
        }
    }

    fun animateDrawer(
        drawer: View,
        shiftViews: List<View>,
        centerShiftViews: List<View>,
        open: Boolean,
        drawerWidthPx: Float
    ) {
        if (open) drawer.visibility = View.VISIBLE
        // 滑动期间临时提升至 GPU 离屏硬件纹理层，杜绝子控件 EditText/SeekBar 反复重排掉帧
        drawer.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        val finalTx = if (open) 0f else drawerWidthPx + 32f
        SpringAnimation(drawer, DynamicAnimation.TRANSLATION_X, finalTx).apply {
            spring = SpringForce(finalTx).apply {
                stiffness = 380f
                dampingRatio = 0.84f
            }
            addEndListener { _, _, _, _ ->
                drawer.setLayerType(View.LAYER_TYPE_NONE, null)
                if (!open) drawer.visibility = View.INVISIBLE
            }
            start()
        }

        drawer.animate()
            .alpha(if (open) 1f else 0f)
            .setDuration(210L)
            .setInterpolator(EASE_OUT_EXPO)
            .start()

        val targetShift = if (open) -(drawerWidthPx + 12f) else 0f
        for (sv in shiftViews) {
            SpringAnimation(sv, DynamicAnimation.TRANSLATION_X, targetShift).apply {
                spring = SpringForce(targetShift).apply {
                    stiffness = 380f
                    dampingRatio = 0.84f
                }
                start()
            }
        }

        val halfShift = if (open) -(drawerWidthPx * 0.50f) else 0f
        for (cv in centerShiftViews) {
            SpringAnimation(cv, DynamicAnimation.TRANSLATION_X, halfShift).apply {
                spring = SpringForce(halfShift).apply {
                    stiffness = 380f
                    dampingRatio = 0.86f
                }
                start()
            }
        }
    }

    fun animateTabSwitch(glider: View, tabIndex: Int, tabWidthPx: Float, panels: List<View>, density: Float) {
        ObjectAnimator.ofFloat(glider, View.TRANSLATION_X, tabIndex * tabWidthPx).apply {
            duration = 260L
            interpolator = EASE_OUT_EXPO
            start()
        }

        for (i in panels.indices) {
            val p = panels[i]
            if (i == tabIndex) {
                p.visibility = View.VISIBLE
                p.alpha = 0f
                p.translationY = 10f * density
                p.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(220L)
                    .setInterpolator(EASE_OUT_EXPO)
                    .start()
            } else {
                p.visibility = View.GONE
            }
        }
    }

    fun showDjiToast(banner: TextView, msg: String, density: Float) {
        banner.text = msg
        banner.visibility = View.VISIBLE
        toastHideRunnable?.let { banner.removeCallbacks(it) }

        banner.animate().cancel()
        banner.translationY = -10f * density
        banner.alpha = 0f
        banner.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(200L)
            .setInterpolator(EASE_OUT_EXPO)
            .start()

        val hideTask = Runnable {
            banner.animate()
                .translationY(-8f * density)
                .alpha(0f)
                .setDuration(190L)
                .withEndAction { banner.visibility = View.INVISIBLE }
                .start()
        }
        toastHideRunnable = hideTask
        banner.postDelayed(hideTask, 2300L)
    }
}
