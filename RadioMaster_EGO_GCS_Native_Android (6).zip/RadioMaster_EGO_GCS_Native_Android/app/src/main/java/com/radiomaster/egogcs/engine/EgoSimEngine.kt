package com.radiomaster.egogcs.engine

import android.os.SystemClock
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.RenderSnapshot
import java.util.ArrayDeque
import java.util.Random
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 零 GC 四缓冲后台物理、FAST-LIO 体素融合与三维实体障碍/遮挡感知引擎：
 * - 输出完整三维圆柱/墙体实体参数 (obsPrimitives) 与实机三维膨胀体素，修复开启点云时实体柱被隐藏导致缺乏 3D 感的问题；
 * - 支持单击地图三维插针净空检测、动态高程升降与连续多航点规划。
 */
class EgoSimEngine(private val hub: GcsSharedHub) {

    private data class Obstacle(
        val cx: Float,
        val cy: Float,
        val rx: Float,
        val ry: Float,
        val h: Float,
        val isCircle: Boolean
    )

    data class PinInspectResult(
        val x: Float,
        val y: Float,
        val z: Float,
        val distFromUav: Float,
        val clearance: Float,
        val isSafe: Boolean
    )

    companion object {
        private const val GRID_RES = 0.25f
        private const val MAP_HALF = 8.0f
        private const val GRID_N = 64
        private const val GRID_CELLS = GRID_N * GRID_N
        private const val MAX_WAYPOINT_QUEUE = 16
    }

    val voxelMap = FastLioVoxelMap()

    @Volatile var onRosWaypointAdvanced: ((gx: Float, gy: Float, gz: Float, curX: Float, curY: Float) -> Unit)? = null
    @Volatile private var asyncReplanPending: Boolean = false

    private var executor: ScheduledExecutorService? = null
    private val rng = Random()
    private val lock = Any()

    private val snapshotRing = Array(4) { RenderSnapshot() }
    private var snapshotWriteIdx = 0

    private var obstacles = mutableListOf<Obstacle>()
    private val distField = FloatArray(GRID_CELLS)
    private val occGrid = IntArray(GRID_CELLS)

    private val cachedGridVoxels = FloatArray(GRID_CELLS * 4)
    private var cachedGridVoxelCount = 0
    private var lastBuiltInflation = -1f

    private var astarSearchEpoch = 1
    private val astarVisitStamp = IntArray(GRID_CELLS)
    private val astarClosedStamp = IntArray(GRID_CELLS)
    private val astarGScore = FloatArray(GRID_CELLS)
    private val astarParent = IntArray(GRID_CELLS)
    private val heapNodes = IntArray(GRID_CELLS + 16)
    private val heapF = FloatArray(GRID_CELLS + 16)
    private val revXScratch = FloatArray(512)
    private val revYScratch = FloatArray(512)
    private val cumScratch = FloatArray(600)
    private val extCtrlScratch = FloatArray(24 * 3)

    private var homeX = -5.5f
    private var homeY = -4.2f
    private var rosHomeCaptured = false

    private var uavX = -5.5f
    private var uavY = -4.2f
    private var uavZ = 1.2f
    private var vx = 0f
    private var vy = 0f
    private var vz = 0f
    private var ax = 0f
    private var ay = 0f
    private var yaw = 0.65f
    private var prevYaw = 0.65f
    private var smoothRoll = 0f
    private var smoothPitch = 0f
    private val rawBins60 = FloatArray(60) { 9.5f }
    private val smoothBins60 = FloatArray(60) { 9.5f }

    private var goalX = 5.2f
    private var goalY = 3.8f
    private var goalZ = 1.2f
    private var fsmState = "EXEC_TRAJ"
    private var solveMs = 0.4f
    private var trajLen = 6.0f

    private var hasPreviewPin = false
    private var previewX = 0f
    private var previewY = 0f
    private var previewZ = 1.2f
    private var previewClearance = 9.5f
    private var previewSafe = true

    private val stagedWaypoints = ArrayDeque<FloatArray>()
    private val waypointQueue = ArrayDeque<FloatArray>()

    private val astarBuf = FloatArray(600 * 3)
    private var astarCount = 0
    private val ctrlBuf = FloatArray(16 * 3)
    private var ctrlCount = 0
    private val bsplineBuf = FloatArray(240 * 3)
    private var bsplineCount = 0

    private val trailRing = FloatArray(240 * 3)
    private var trailCount = 0

    private val demoScanBuf = FloatArray(720 * 4)
    private var demoLidarAcc = 0f
    private var demoRosettePhase = 0f

    private val rosVoxelsBuf = FloatArray(1600 * 3)
    private var rosVoxelCount = 0
    private val rosNearScanBuf = FloatArray(920 * 3)
    private var rosNearScanCount = 0
    private val rosPathBuf = FloatArray(420 * 3)
    private var rosPathCount = 0
    private val rosLioPathBuf = FloatArray(820 * 3)
    private var rosLioPathCount = 0

    private var rosPx4Mode = "OFFBOARD"
    private var rosArmed = true
    private var hasLiveBatteryTelemetry = false
    private var rosBatVolt = 16.2f
    private var rosBatCurrentAmps = 12.6f
    private var rosBatPct = 86

    private var rosOdomCounter = 0
    private var rosOdomHz = 0
    private var rosCloudCounter = 0
    private var rosCloudHz = 0
    private var lastCloudScanPts = 0
    private var lastHzTickMs = SystemClock.elapsedRealtime()

    private var replanTimer = 0f
    private var lastTickNs = System.nanoTime()

    init {
        setScenePreset("pillars")
    }

    fun start() {
        if (executor != null) return
        lastTickNs = System.nanoTime()
        executor = Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "EgoFastLioWorker").apply {
                isDaemon = true
                priority = Thread.NORM_PRIORITY + 1
            }
        }.also { exec ->
            exec.scheduleAtFixedRate({ safeTick() }, 0, 20, TimeUnit.MILLISECONDS)
        }
    }

    fun stop() {
        executor?.shutdownNow()
        executor = null
    }

    fun requestReplanAsync() {
        asyncReplanPending = true
    }

    fun resetRosSessionState() {
        synchronized(lock) {
            rosHomeCaptured = false
            hasLiveBatteryTelemetry = false
            hasPreviewPin = false
            stagedWaypoints.clear()
            waypointQueue.clear()
        }
    }

    fun clearVoxelMap() {
        voxelMap.clear(hub.mapVoxelSize)
        synchronized(lock) {
            rosLioPathCount = 0
        }
    }

    fun clearWaypointQueue() {
        synchronized(lock) {
            hasPreviewPin = false
            stagedWaypoints.clear()
            waypointQueue.clear()
        }
    }

    fun clearPreviewPin() {
        synchronized(lock) {
            hasPreviewPin = false
        }
    }

    fun hasActivePreviewPin(): Boolean {
        synchronized(lock) {
            return hasPreviewPin
        }
    }

    fun routeStatusSummary(): Triple<Int, Boolean, Float> {
        synchronized(lock) {
            return if (stagedWaypoints.isNotEmpty()) {
                Triple(stagedWaypoints.size, true, computeStagedRouteLengthLocked())
            } else {
                Triple(waypointQueue.size, false, 0f)
            }
        }
    }

    private fun evaluatePointClearanceLocked(tx: Float, ty: Float, tz: Float): Pair<Float, Boolean> {
        if (!hub.isRosMode) {
            var minClear = 9.5f
            for (i in 0 until obstacles.size) {
                val ob = obstacles[i]
                val d2d = signedDistToObs(tx, ty, ob)
                val d3d = if (tz <= ob.h + 0.18f) {
                    d2d
                } else {
                    hypot(max(0f, d2d), tz - ob.h)
                }
                if (d3d < minClear) minClear = d3d
            }
            val safe = minClear > max(0.12f, hub.obstaclesInflation * 0.65f)
            return max(0f, minClear) to safe
        } else {
            var minD = 9.5f
            for (i in 0 until rosVoxelCount) {
                val dx = rosVoxelsBuf[i * 3] - tx
                val dy = rosVoxelsBuf[i * 3 + 1] - ty
                val dz = rosVoxelsBuf[i * 3 + 2] - tz
                if (abs(dz) <= 0.75f) {
                    val d = hypot(dx, dy)
                    if (d < minD) minD = d
                }
            }
            for (i in 0 until rosNearScanCount) {
                val dx = rosNearScanBuf[i * 3] - tx
                val dy = rosNearScanBuf[i * 3 + 1] - ty
                val dz = rosNearScanBuf[i * 3 + 2] - tz
                if (abs(dz) <= 0.75f) {
                    val d = hypot(dx, dy)
                    if (d < minD) minD = d
                }
            }
            return minD to (minD > 0.28f)
        }
    }

    private fun computeStagedRouteLengthLocked(): Float {
        if (stagedWaypoints.isEmpty()) return 0f
        var sum = 0f
        var px = uavX
        var py = uavY
        var pz = uavZ
        for (wp in stagedWaypoints) {
            sum += hypot(hypot(wp[0] - px, wp[1] - py), wp[2] - pz)
            px = wp[0]; py = wp[1]; pz = wp[2]
        }
        return sum
    }

    fun placePreviewPin(wx: Float, wy: Float): PinInspectResult {
        synchronized(lock) {
            val tx = if (!hub.isRosMode) wx.coerceIn(-7.6f, 7.6f) else wx
            val ty = if (!hub.isRosMode) wy.coerceIn(-7.6f, 7.6f) else wy
            val tz = hub.goalZ
            val (clr, safe) = evaluatePointClearanceLocked(tx, ty, tz)

            hasPreviewPin = true
            previewX = tx
            previewY = ty
            previewZ = tz
            previewClearance = clr
            previewSafe = safe

            val dist = hypot(hypot(tx - uavX, ty - uavY), tz - uavZ)
            return PinInspectResult(tx, ty, tz, dist, clr, safe)
        }
    }

    fun nudgeGoalZ(delta: Float): Pair<Float, PinInspectResult?> {
        synchronized(lock) {
            val nextZ = (hub.goalZ + delta).coerceIn(0.4f, 4.0f)
            hub.goalZ = nextZ
            if (hasPreviewPin) {
                previewZ = nextZ
                val (clr, safe) = evaluatePointClearanceLocked(previewX, previewY, previewZ)
                previewClearance = clr
                previewSafe = safe
                val dist = hypot(hypot(previewX - uavX, previewY - uavY), previewZ - uavZ)
                return nextZ to PinInspectResult(previewX, previewY, previewZ, dist, clr, safe)
            } else {
                goalZ = nextZ
                stagedWaypoints.peekLast()?.let { it[2] = nextZ }
                if (!hub.isRosMode) asyncReplanPending = true
                return nextZ to null
            }
        }
    }

    fun confirmFlyImmediate(directWx: Float? = null, directWy: Float? = null): FloatArray? {
        synchronized(lock) {
            val tx: Float
            val ty: Float
            val tz: Float
            if (directWx != null && directWy != null) {
                tx = if (!hub.isRosMode) directWx.coerceIn(-7.6f, 7.6f) else directWx
                ty = if (!hub.isRosMode) directWy.coerceIn(-7.6f, 7.6f) else directWy
                tz = hub.goalZ
                val (_, safe) = evaluatePointClearanceLocked(tx, ty, tz)
                if (!hub.isRosMode && !safe) return null
            } else {
                if (!hasPreviewPin) return null
                if (!hub.isRosMode && !previewSafe) return null
                tx = previewX
                ty = previewY
                tz = previewZ
            }

            hasPreviewPin = false
            hub.autoPatrol = false
            stagedWaypoints.clear()
            waypointQueue.clear()
            goalX = tx
            goalY = ty
            goalZ = tz
            fsmState = "GEN_NEW_TRAJ"
            if (!hub.isRosMode) asyncReplanPending = true
            return floatArrayOf(goalX, goalY, goalZ, uavX, uavY)
        }
    }

    fun appendPreviewPinToRoute(): Triple<Boolean, Int, Float> {
        synchronized(lock) {
            if (!hasPreviewPin) return Triple(false, stagedWaypoints.size, computeStagedRouteLengthLocked())
            if (!hub.isRosMode && !previewSafe) return Triple(false, stagedWaypoints.size, computeStagedRouteLengthLocked())

            if (stagedWaypoints.size >= MAX_WAYPOINT_QUEUE) {
                stagedWaypoints.pollFirst()
            }
            stagedWaypoints.addLast(floatArrayOf(previewX, previewY, previewZ))
            hasPreviewPin = false
            return Triple(true, stagedWaypoints.size, computeStagedRouteLengthLocked())
        }
    }

    fun undoLastWaypoint(): Triple<Int, Boolean, Float> {
        synchronized(lock) {
            if (stagedWaypoints.isNotEmpty()) {
                stagedWaypoints.pollLast()
                return Triple(stagedWaypoints.size, true, computeStagedRouteLengthLocked())
            }
            if (waypointQueue.isNotEmpty()) {
                waypointQueue.pollLast()
                return Triple(waypointQueue.size, false, 0f)
            }
            return Triple(0, false, 0f)
        }
    }

    fun commitStagedRoute(): Pair<FloatArray, Int>? {
        synchronized(lock) {
            if (stagedWaypoints.isEmpty()) return null
            hasPreviewPin = false
            hub.autoPatrol = false
            waypointQueue.clear()
            val first = stagedWaypoints.pollFirst() ?: return null
            val total = 1 + stagedWaypoints.size
            while (stagedWaypoints.isNotEmpty()) {
                waypointQueue.addLast(stagedWaypoints.pollFirst()!!)
            }
            goalX = first[0]
            goalY = first[1]
            goalZ = first[2]
            fsmState = "GEN_NEW_TRAJ"
            if (!hub.isRosMode) asyncReplanPending = true
            return floatArrayOf(goalX, goalY, goalZ, uavX, uavY) to total
        }
    }

    fun setScenePreset(preset: String) {
        synchronized(lock) {
            val list = mutableListOf<Obstacle>()
            when (preset) {
                "pillars" -> {
                    val raw = arrayOf(
                        floatArrayOf(-3.2f, -1.8f, 0.44f, 2.7f),
                        floatArrayOf(-1.2f, -3.4f, 0.50f, 2.3f),
                        floatArrayOf(-2.4f,  1.8f, 0.52f, 2.9f),
                        floatArrayOf(-0.2f,  0.1f, 0.58f, 3.1f),
                        floatArrayOf( 1.8f, -2.0f, 0.48f, 2.5f),
                        floatArrayOf( 2.2f,  1.6f, 0.54f, 3.0f),
                        floatArrayOf(-4.2f,  3.4f, 0.48f, 2.2f),
                        floatArrayOf( 4.0f, -0.4f, 0.50f, 2.8f),
                        floatArrayOf( 0.3f,  3.5f, 0.48f, 2.6f),
                        floatArrayOf( 3.8f, -3.8f, 0.52f, 2.1f),
                        floatArrayOf(-0.6f, -1.9f, 0.38f, 1.9f)
                    )
                    for (r in raw) list.add(Obstacle(r[0], r[1], r[2], r[2], r[3], true))
                }
                "corridor" -> {
                    list.add(Obstacle(-2.2f, -1.8f, 0.38f, 3.4f, 2.9f, false))
                    list.add(Obstacle( 1.8f,  1.8f, 0.38f, 3.4f, 2.9f, false))
                    list.add(Obstacle(-0.2f,  4.6f, 3.5f,  0.35f, 2.7f, false))
                    list.add(Obstacle( 0.2f, -4.6f, 3.5f,  0.35f, 2.7f, false))
                }
                "utrap" -> {
                    list.add(Obstacle( 1.4f,  0.0f, 0.40f, 2.4f, 2.9f, false))
                    list.add(Obstacle(-0.4f,  2.2f, 1.8f,  0.40f, 2.9f, false))
                    list.add(Obstacle(-0.4f, -2.2f, 1.8f,  0.40f, 2.9f, false))
                    list.add(Obstacle(-3.6f, -2.8f, 0.52f, 0.52f, 2.4f, true))
                    list.add(Obstacle( 3.8f,  2.8f, 0.56f, 0.56f, 2.6f, true))
                }
                else -> {
                    for (i in 0 until 11) {
                        val rx = (rng.nextFloat() - 0.5f) * 10.4f
                        val ry = (rng.nextFloat() - 0.5f) * 9.6f
                        if (hypot(rx - uavX, ry - uavY) < 1.8f) continue
                        if (hypot(rx - goalX, ry - goalY) < 1.6f) continue
                        val rad = 0.38f + rng.nextFloat() * 0.32f
                        list.add(Obstacle(rx, ry, rad, rad, 1.8f + rng.nextFloat() * 1.4f, rng.nextFloat() > 0.35f))
                    }
                }
            }
            obstacles = list
            hasPreviewPin = false
            stagedWaypoints.clear()
            waypointQueue.clear()
            voxelMap.clear(hub.mapVoxelSize)
            rebuildOccupancyLocked(hub.obstaclesInflation)
            replanLocked(true)
        }
    }

    fun triggerReturnToHome(): FloatArray {
        synchronized(lock) {
            hub.autoPatrol = false
            hasPreviewPin = false
            stagedWaypoints.clear()
            waypointQueue.clear()
            goalX = homeX
            goalY = homeY
            goalZ = hub.goalZ
            if (!hub.isRosMode) asyncReplanPending = true else fsmState = "GEN_NEW_TRAJ"
            return floatArrayOf(goalX, goalY, goalZ, uavX, uavY)
        }
    }

    fun triggerEmergencyHover() {
        synchronized(lock) {
            hub.autoPatrol = false
            hasPreviewPin = false
            stagedWaypoints.clear()
            waypointQueue.clear()
            goalX = uavX
            goalY = uavY
            goalZ = uavZ
            vx = 0f; vy = 0f; vz = 0f
            ax = 0f; ay = 0f
            bsplineCount = 0
            ctrlCount = 0
            fsmState = "EMERGENCY_STOP"
        }
    }

    fun clearTrail() {
        synchronized(lock) {
            trailCount = 0
            rosLioPathCount = 0
        }
    }

    fun onRosOdometry(x: Float, y: Float, z: Float, lvX: Float, lvY: Float, lvZ: Float, yawRad: Float) {
        var nextDispatched: FloatArray? = null
        synchronized(lock) {
            if (!rosHomeCaptured && x.isFinite() && y.isFinite()) {
                homeX = x
                homeY = y
                rosHomeCaptured = true
            }
            val dtEst = 0.02f
            ax = ((lvX - vx) / dtEst).coerceIn(-12f, 12f)
            ay = ((lvY - vy) / dtEst).coerceIn(-12f, 12f)
            uavX = x; uavY = y; uavZ = z
            vx = lvX; vy = lvY; vz = lvZ
            yaw = yawRad
            rosOdomCounter++
            appendTrailLocked(x, y, z)

            if (waypointQueue.isNotEmpty() && hypot(goalX - x, goalY - y) < 0.45f) {
                val nxt = waypointQueue.pollFirst()
                if (nxt != null) {
                    goalX = nxt[0]; goalY = nxt[1]; goalZ = nxt[2]
                    nextDispatched = floatArrayOf(goalX, goalY, goalZ, x, y)
                }
            }
        }
        nextDispatched?.let { d ->
            onRosWaypointAdvanced?.invoke(d[0], d[1], d[2], d[3], d[4])
        }
    }

    fun onRosFastLioCloud(xyzi: FloatArray, count: Int) {
        voxelMap.ensureVoxelResolution(hub.mapVoxelSize)
        voxelMap.insertScan(xyzi, count)

        synchronized(lock) {
            rosCloudCounter++
            lastCloudScanPts = count
            val step = max(1, count / 900)
            var nearCnt = 0
            var idx = 0
            val curZ = uavZ
            while (idx < count && nearCnt < 915) {
                val b = idx * 4
                val pz = xyzi[b + 2]
                if (abs(pz - curZ) <= 0.90f) {
                    val dst = nearCnt * 3
                    rosNearScanBuf[dst] = xyzi[b]
                    rosNearScanBuf[dst + 1] = xyzi[b + 1]
                    rosNearScanBuf[dst + 2] = pz
                    nearCnt++
                }
                idx += step
            }
            rosNearScanCount = nearCnt
            if (hasPreviewPin) {
                val (clr, safe) = evaluatePointClearanceLocked(previewX, previewY, previewZ)
                previewClearance = clr
                previewSafe = safe
            }
        }
    }

    fun onRosFastLioPath(flatXyz: FloatArray, count: Int) {
        val safeCnt = min(count, 815)
        synchronized(lock) {
            System.arraycopy(flatXyz, 0, rosLioPathBuf, 0, safeCnt * 3)
            rosLioPathCount = safeCnt
        }
    }

    fun onRosOptimalPath(flatXyz: FloatArray, count: Int) {
        val safeCnt = min(count, 415)
        synchronized(lock) {
            System.arraycopy(flatXyz, 0, rosPathBuf, 0, safeCnt * 3)
            rosPathCount = safeCnt
            if (safeCnt > 0) {
                trajLen = 0f
                for (i in 1 until safeCnt) {
                    val a = (i - 1) * 3; val b = i * 3
                    trajLen += hypot(
                        hypot(rosPathBuf[b] - rosPathBuf[a], rosPathBuf[b + 1] - rosPathBuf[a + 1]),
                        rosPathBuf[b + 2] - rosPathBuf[a + 2]
                    )
                }
                if (waypointQueue.isEmpty()) {
                    val endBase = (safeCnt - 1) * 3
                    goalX = rosPathBuf[endBase]
                    goalY = rosPathBuf[endBase + 1]
                    goalZ = rosPathBuf[endBase + 2]
                }
                fsmState = "EXEC_TRAJ"
            }
        }
    }

    fun onRosInflatedCloud(flatXyz: FloatArray, count: Int) {
        val safeCnt = min(count, 1580)
        synchronized(lock) {
            System.arraycopy(flatXyz, 0, rosVoxelsBuf, 0, safeCnt * 3)
            rosVoxelCount = safeCnt
        }
    }

    fun onRosMavrosState(mode: String, armed: Boolean) {
        synchronized(lock) {
            rosPx4Mode = mode
            rosArmed = armed
        }
    }

    fun onRosBattery(volt: Float, pct: Int, currentAmps: Float = 0f) {
        synchronized(lock) {
            hasLiveBatteryTelemetry = true
            rosBatVolt = volt
            rosBatPct = pct
            if (currentAmps >= 0.01f && currentAmps < 250f) {
                rosBatCurrentAmps = currentAmps
            }
        }
    }

    private fun safeTick() {
        try {
            val nowNs = System.nanoTime()
            val dt = ((nowNs - lastTickNs) * 1e-9f).coerceIn(0.002f, 0.05f)
            lastTickNs = nowNs

            voxelMap.ensureVoxelResolution(hub.mapVoxelSize)

            var simScanCount = 0
            synchronized(lock) {
                val infChanged = abs(hub.obstaclesInflation - lastBuiltInflation) > 0.005f
                if (infChanged) {
                    rebuildOccupancyLocked(hub.obstaclesInflation)
                }
                if (asyncReplanPending || infChanged) {
                    asyncReplanPending = false
                    if (!hasPreviewPin) goalZ = hub.goalZ
                    if (!hub.isRosMode) replanLocked(true)
                }

                if (!hub.isRosMode) {
                    stepDemoPhysicsLocked(dt)
                    demoLidarAcc += dt
                    if (demoLidarAcc >= 0.066f) {
                        demoLidarAcc = 0f
                        simScanCount = generateDemo3DLidarScanLocked()
                        lastCloudScanPts = simScanCount
                    }
                } else {
                    val nowMs = SystemClock.elapsedRealtime()
                    if (nowMs - lastHzTickMs >= 1000L) {
                        rosOdomHz = rosOdomCounter
                        rosCloudHz = rosCloudCounter
                        rosOdomCounter = 0
                        rosCloudCounter = 0
                        lastHzTickMs = nowMs
                    }
                }
                stepHsiFilterAndRadarLocked(dt)
                publishSnapshotLocked()
            }

            if (simScanCount > 0) {
                voxelMap.insertScan(demoScanBuf, simScanCount)
            }
        } catch (_: Throwable) {
        }
    }

    private fun generateDemo3DLidarScanLocked(): Int {
        var outCnt = 0
        val maxRange = 7.4f
        val azSteps = 52
        val elLevels = floatArrayOf(-0.22f, -0.10f, -0.02f, 0.06f, 0.16f, 0.28f, 0.42f)
        demoRosettePhase += 0.37f

        for (a in 0 until azSteps) {
            val az = yaw + demoRosettePhase + (a.toFloat() / azSteps) * (PI.toFloat() * 2f)
            val cosA = cos(az)
            val sinA = sin(az)

            for (eIdx in elLevels.indices) {
                if (outCnt >= 650) break
                val el = elLevels[eIdx] + sin(demoRosettePhase * 2.3f + a * 0.4f) * 0.04f
                val cosE = cos(el)
                val sinE = sin(el)
                val dirX = cosE * cosA
                val dirY = cosE * sinA
                val dirZ = sinE

                var t = 0.28f
                var hit = false
                var hitX = 0f; var hitY = 0f; var hitZ = 0f
                var hitIntensity = 0.5f

                for (step in 0 until 16) {
                    val wx = uavX + dirX * t
                    val wy = uavY + dirY * t
                    val wz = uavZ + dirZ * t

                    if (wz <= 0.02f && dirZ < -0.01f) {
                        val tGround = (0.01f - uavZ) / dirZ
                        if (tGround in 0.25f..maxRange) {
                            hitX = uavX + dirX * tGround
                            hitY = uavY + dirY * tGround
                            hitZ = 0.01f
                            hitIntensity = 0.22f
                            hit = true
                        }
                        break
                    }

                    if ((abs(wx) >= 7.85f || abs(wy) >= 7.85f) && wz in 0f..2.4f) {
                        hitX = wx.coerceIn(-7.88f, 7.88f)
                        hitY = wy.coerceIn(-7.88f, 7.88f)
                        hitZ = wz
                        hitIntensity = 0.48f
                        hit = true
                        break
                    }

                    var minSd = 99f
                    var hitObH = 0f
                    for (o in 0 until obstacles.size) {
                        val ob = obstacles[o]
                        if (wz > ob.h) {
                            val d2d = max(0f, signedDistToObs(wx, wy, ob))
                            val dz = wz - ob.h
                            val d3d = hypot(d2d, dz)
                            if (d3d < minSd) minSd = d3d
                        } else {
                            val d = signedDistToObs(wx, wy, ob)
                            if (d < minSd) {
                                minSd = d
                                hitObH = ob.h
                            }
                        }
                    }

                    if (minSd <= 0.045f && wz <= hitObH + 0.05f) {
                        hitX = wx + (rng.nextFloat() - 0.5f) * 0.022f
                        hitY = wy + (rng.nextFloat() - 0.5f) * 0.022f
                        hitZ = wz.coerceAtLeast(0.02f)
                        hitIntensity = (0.55f + (hitZ / 3.0f) * 0.42f).coerceIn(0.1f, 1.0f)
                        hit = true
                        break
                    }

                    t += max(0.15f, minSd * 0.84f)
                    if (t > maxRange || wz > 3.5f) break
                }

                if (hit) {
                    if (hitZ <= 0.04f && (a + eIdx) % 3 != 0) continue
                    val b = outCnt * 4
                    demoScanBuf[b] = hitX
                    demoScanBuf[b + 1] = hitY
                    demoScanBuf[b + 2] = hitZ
                    demoScanBuf[b + 3] = hitIntensity
                    outCnt++
                }
            }
        }
        return outCnt
    }

    private fun stepDemoPhysicsLocked(dt: Float) {
        replanTimer += dt
        if (replanTimer >= 0.14f) {
            replanTimer = 0f
            replanLocked(false)
        }

        val dxG = goalX - uavX
        val dyG = goalY - uavY
        val dzG = goalZ - uavZ
        val distGoal = hypot(hypot(dxG, dyG), dzG)

        if (distGoal < 0.30f) {
            if (waypointQueue.isNotEmpty()) {
                val nxt = waypointQueue.pollFirst()
                if (nxt != null) {
                    goalX = nxt[0]
                    goalY = nxt[1]
                    goalZ = nxt[2]
                    replanLocked(true)
                    return
                }
            }
            vx *= 0.82f; vy *= 0.82f; vz *= 0.82f
            ax = 0f; ay = 0f
            if (hub.autoPatrol && !hasPreviewPin && stagedWaypoints.isEmpty()) {
                pickRandomGoalLocked()
            } else {
                fsmState = "WAIT_TARGET"
            }
            return
        }

        var lookX = goalX
        var lookY = goalY
        var lookZ = goalZ
        if (bsplineCount > 2) {
            val idx = min(bsplineCount - 1, 7) * 3
            lookX = bsplineBuf[idx]
            lookY = bsplineBuf[idx + 1]
            lookZ = bsplineBuf[idx + 2]
        }

        val ex = lookX - uavX
        val ey = lookY - uavY
        val ez = lookZ - uavZ
        val dLook = max(1e-4f, hypot(hypot(ex, ey), ez))

        val desSpeed = min(hub.maxVel, distGoal * 1.65f)
        val desVx = (ex / dLook) * desSpeed
        val desVy = (ey / dLook) * desSpeed
        val desVz = (ez * 2.2f).coerceIn(-1.5f, 1.5f)

        var dvx = desVx - vx
        var dvy = desVy - vy
        var dvz = desVz - vz
        val maxDv = hub.maxAcc * dt * 2.2f
        val dvNorm = hypot(hypot(dvx, dvy), dvz)
        if (dvNorm > maxDv && dvNorm > 1e-5f) {
            val scale = maxDv / dvNorm
            dvx *= scale; dvy *= scale; dvz *= scale
        }

        ax = dvx / max(dt, 0.008f)
        ay = dvy / max(dt, 0.008f)
        vx += dvx; vy += dvy; vz += dvz
        uavX += vx * dt; uavY += vy * dt; uavZ += vz * dt

        if (hypot(vx, vy) > 0.12f) {
            val targetYaw = atan2(vy, vx)
            var diff = targetYaw - yaw
            while (diff > PI.toFloat()) diff -= (PI * 2.0).toFloat()
            while (diff < -PI.toFloat()) diff += (PI * 2.0).toFloat()
            yaw += diff * min(1.0f, dt * 6.5f)
        }

        appendTrailLocked(uavX, uavY, uavZ)
    }

    private fun pickRandomGoalLocked() {
        for (attempt in 0 until 40) {
            val gx = (rng.nextFloat() - 0.5f) * 12.2f
            val gy = (rng.nextFloat() - 0.5f) * 10.6f
            if (hypot(gx - uavX, gy - uavY) < 4.5f) continue
            val ix = clampGrid(gx)
            val iy = clampGrid(gy)
            if (distField[iy * GRID_N + ix] > hub.obstaclesInflation + 0.45f) {
                goalX = gx
                goalY = gy
                // 赋予巡航轻微三维高度起伏，增强三维轨迹立体观感
                goalZ = (hub.goalZ + (rng.nextFloat() - 0.5f) * 0.55f).coerceIn(0.6f, 2.5f)
                replanLocked(true)
                return
            }
        }
    }

    private fun appendTrailLocked(x: Float, y: Float, z: Float) {
        if (trailCount > 0) {
            val last = (trailCount - 1) * 3
            if (hypot(x - trailRing[last], y - trailRing[last + 1]) < 0.14f) return
        }
        if (trailCount == 240) {
            System.arraycopy(trailRing, 3, trailRing, 0, 239 * 3)
            trailCount = 239
        }
        val base = trailCount * 3
        trailRing[base] = x
        trailRing[base + 1] = y
        trailRing[base + 2] = z
        trailCount++
    }

    private fun signedDistToObs(wx: Float, wy: Float, ob: Obstacle): Float {
        if (ob.isCircle) {
            return hypot(wx - ob.cx, wy - ob.cy) - ob.rx
        }
        val dx = abs(wx - ob.cx) - ob.rx
        val dy = abs(wy - ob.cy) - ob.ry
        return hypot(max(dx, 0f), max(dy, 0f)) + min(max(dx, dy), 0f)
    }

    private fun rebuildOccupancyLocked(infR: Float) {
        lastBuiltInflation = infR
        var vCount = 0
        for (gy in 0 until GRID_N) {
            val wy = -MAP_HALF + (gy + 0.5f) * GRID_RES
            for (gx in 0 until GRID_N) {
                val wx = -MAP_HALF + (gx + 0.5f) * GRID_RES
                var minD = 99f
                for (i in 0 until obstacles.size) {
                    val ob = obstacles[i]
                    val d = signedDistToObs(wx, wy, ob)
                    if (d < minD) minD = d
                }
                val idx = gy * GRID_N + gx
                distField[idx] = minD
                if (minD <= 0.02f) {
                    occGrid[idx] = 2
                } else if (minD <= infR) {
                    occGrid[idx] = 1
                    // 仅保留膨胀外圈安全边界带供半透明警示渲染，核心实体交由 obsPrimitives 高精度三维圆柱/墙体渲染
                    if (minD >= infR - GRID_RES * 1.15f) {
                        val b = vCount * 4
                        cachedGridVoxels[b] = wx
                        cachedGridVoxels[b + 1] = wy
                        cachedGridVoxels[b + 2] = 0.22f
                        cachedGridVoxels[b + 3] = 1f
                        vCount++
                    }
                } else {
                    occGrid[idx] = 0
                }
            }
        }
        cachedGridVoxelCount = vCount
    }

    private fun clampGrid(w: Float): Int {
        return floor((w + MAP_HALF) / GRID_RES).toInt().coerceIn(0, GRID_N - 1)
    }

    private fun replanLocked(isNew: Boolean) {
        val t0 = SystemClock.elapsedRealtimeNanos()
        val distGoal = hypot(hypot(goalX - uavX, goalY - uavY), goalZ - uavZ)
        if (distGoal < 0.22f) {
            fsmState = "WAIT_TARGET"
            astarCount = 0; ctrlCount = 0; bsplineCount = 0; trajLen = 0f
            return
        }
        fsmState = if (isNew) "GEN_NEW_TRAJ" else if (distGoal > 1.2f) "REPLAN_TRAJ" else "EXEC_TRAJ"

        val sx = clampGrid(uavX); val sy = clampGrid(uavY)
        val gx = clampGrid(goalX); val gy = clampGrid(goalY)
        val startIdx = sy * GRID_N + sx
        val goalIdx = gy * GRID_N + gx

        astarSearchEpoch++
        if (astarSearchEpoch >= Int.MAX_VALUE - 4) {
            astarVisitStamp.fill(0)
            astarClosedStamp.fill(0)
            astarSearchEpoch = 1
        }
        val ep = astarSearchEpoch

        astarVisitStamp[startIdx] = ep
        astarGScore[startIdx] = 0f
        astarParent[startIdx] = -1

        var heapSize = 0
        fun heapPush(node: Int, fVal: Float) {
            var cur = ++heapSize
            while (cur > 1) {
                val p = cur ushr 1
                if (heapF[p] <= fVal) break
                heapNodes[cur] = heapNodes[p]
                heapF[cur] = heapF[p]
                cur = p
            }
            heapNodes[cur] = node
            heapF[cur] = fVal
        }

        fun heapPop(): Int {
            val top = heapNodes[1]
            val lastN = heapNodes[heapSize]
            val lastF = heapF[heapSize]
            heapSize--
            var cur = 1
            while ((cur shl 1) <= heapSize) {
                var child = cur shl 1
                if (child + 1 <= heapSize && heapF[child + 1] < heapF[child]) child++
                if (lastF <= heapF[child]) break
                heapNodes[cur] = heapNodes[child]
                heapF[cur] = heapF[child]
                cur = child
            }
            if (heapSize > 0) {
                heapNodes[cur] = lastN
                heapF[cur] = lastF
            }
            return top
        }

        heapPush(startIdx, hypot((gx - sx).toFloat(), (gy - sy).toFloat()))

        val dxArr = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)
        val dyArr = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)
        val costArr = floatArrayOf(1f, 1f, 1f, 1f, 1.414f, 1.414f, 1.414f, 1.414f)

        var bestIdx = startIdx
        var bestH = 1e9f
        var iter = 0
        while (heapSize > 0 && iter < 4096) {
            iter++
            val cIdx = heapPop()
            if (astarClosedStamp[cIdx] == ep) continue
            astarClosedStamp[cIdx] = ep
            if (cIdx == goalIdx) {
                bestIdx = goalIdx
                break
            }

            val cx = cIdx % GRID_N
            val cy = cIdx / GRID_N
            val hVal = hypot((gx - cx).toFloat(), (gy - cy).toFloat())
            if (hVal < bestH) {
                bestH = hVal
                bestIdx = cIdx
            }

            val baseG = astarGScore[cIdx]
            for (d in 0 until 8) {
                val nx = cx + dxArr[d]
                val ny = cy + dyArr[d]
                if (nx !in 0 until GRID_N || ny !in 0 until GRID_N) continue
                val nIdx = ny * GRID_N + nx
                if (astarClosedStamp[nIdx] == ep) continue
                val occ = occGrid[nIdx]
                if (occ == 2 && nIdx != startIdx) continue

                var pen = if (occ == 1) 8.0f else 0.0f
                val clr = distField[nIdx]
                if (clr > 0f && clr < lastBuiltInflation + 0.45f) {
                    pen += (lastBuiltInflation + 0.45f - clr) * 2.5f
                }
                val tg = baseG + costArr[d] + pen
                if (astarVisitStamp[nIdx] != ep || tg < astarGScore[nIdx]) {
                    astarVisitStamp[nIdx] = ep
                    astarGScore[nIdx] = tg
                    astarParent[nIdx] = cIdx
                    if (heapSize < GRID_CELLS + 8) {
                        heapPush(nIdx, tg + hypot((gx - nx).toFloat(), (gy - ny).toFloat()))
                    }
                }
            }
        }

        val reachedGoal = (astarVisitStamp[goalIdx] == ep && astarParent[goalIdx] != -1)
        var rLen = 0
        var tr = if (reachedGoal) goalIdx else bestIdx
        while (tr != -1 && rLen < 495) {
            val px = tr % GRID_N
            val py = tr / GRID_N
            revXScratch[rLen] = -MAP_HALF + (px + 0.5f) * GRID_RES
            revYScratch[rLen] = -MAP_HALF + (py + 0.5f) * GRID_RES
            rLen++
            if (tr == startIdx) break
            tr = if (astarVisitStamp[tr] == ep) astarParent[tr] else -1
        }

        if (rLen < 2) {
            astarBuf[0] = uavX; astarBuf[1] = uavY; astarBuf[2] = uavZ
            astarBuf[3] = goalX; astarBuf[4] = goalY; astarBuf[5] = goalZ
            astarCount = 2
        } else {
            astarCount = rLen
            for (i in 0 until rLen) {
                val src = rLen - 1 - i
                astarBuf[i * 3] = revXScratch[src]
                astarBuf[i * 3 + 1] = revYScratch[src]
                astarBuf[i * 3 + 2] = goalZ
            }
            astarBuf[0] = uavX; astarBuf[1] = uavY; astarBuf[2] = uavZ
            if (reachedGoal) {
                astarBuf[(rLen - 1) * 3] = goalX
                astarBuf[(rLen - 1) * 3 + 1] = goalY
            }
        }

        cumScratch[0] = 0f
        for (i in 1 until astarCount) {
            val dx = astarBuf[i * 3] - astarBuf[(i - 1) * 3]
            val dy = astarBuf[i * 3 + 1] - astarBuf[(i - 1) * 3 + 1]
            cumScratch[i] = cumScratch[i - 1] + hypot(dx, dy)
        }
        val horizon = min(cumScratch[astarCount - 1], 7.5f)
        val numCtrl = 13
        ctrlCount = numCtrl
        for (k in 0 until numCtrl) {
            val targetS = (horizon * k) / (numCtrl - 1)
            var seg = 0
            while (seg < astarCount - 2 && cumScratch[seg + 1] < targetS) seg++
            val segLen = max(1e-5f, cumScratch[seg + 1] - cumScratch[seg])
            val ratio = ((targetS - cumScratch[seg]) / segLen).coerceIn(0f, 1f)
            ctrlBuf[k * 3] = astarBuf[seg * 3] + (astarBuf[(seg + 1) * 3] - astarBuf[seg * 3]) * ratio
            ctrlBuf[k * 3 + 1] = astarBuf[seg * 3 + 1] + (astarBuf[(seg + 1) * 3 + 1] - astarBuf[seg * 3 + 1]) * ratio
            ctrlBuf[k * 3 + 2] = uavZ + (goalZ - uavZ) * (k.toFloat() / (numCtrl - 1))
        }

        val safeMargin = lastBuiltInflation + 0.32f
        for (it in 0 until 20) {
            for (c in 1 until numCtrl - 1) {
                val b = c * 3
                val sxForce = 0.5f * (ctrlBuf[b - 3] + ctrlBuf[b + 3]) - ctrlBuf[b]
                val syForce = 0.5f * (ctrlBuf[b - 2] + ctrlBuf[b + 4]) - ctrlBuf[b + 1]
                val szForce = 0.5f * (ctrlBuf[b - 1] + ctrlBuf[b + 5]) - ctrlBuf[b + 2]

                var bestD = 99f
                var gradX = 0f
                var gradY = 0f
                val wx = ctrlBuf[b]
                val wy = ctrlBuf[b + 1]
                for (o in 0 until obstacles.size) {
                    val ob = obstacles[o]
                    if (ctrlBuf[b + 2] > ob.h + 0.25f) continue
                    val d = signedDistToObs(wx, wy, ob)
                    if (d < bestD) {
                        bestD = d
                        val eps = 0.04f
                        val dx = signedDistToObs(wx + eps, wy, ob) - d
                        val dy = signedDistToObs(wx, wy + eps, ob) - d
                        val norm = max(1e-5f, hypot(dx, dy))
                        gradX = dx / norm
                        gradY = dy / norm
                    }
                }
                var rx = 0f
                var ry = 0f
                if (bestD < safeMargin) {
                    val push = (safeMargin - bestD) * 0.42f
                    rx = gradX * push
                    ry = gradY * push
                }
                ctrlBuf[b] += 0.34f * sxForce + rx
                ctrlBuf[b + 1] += 0.34f * syForce + ry
                ctrlBuf[b + 2] += 0.35f * szForce
            }
        }

        val extCount = numCtrl + 4
        for (i in 0 until extCount) {
            val srcIdx = (i - 2).coerceIn(0, numCtrl - 1) * 3
            extCtrlScratch[i * 3] = ctrlBuf[srcIdx]
            extCtrlScratch[i * 3 + 1] = ctrlBuf[srcIdx + 1]
            extCtrlScratch[i * 3 + 2] = ctrlBuf[srcIdx + 2]
        }

        var outPts = 0
        val segSteps = 6
        for (i in 0 until extCount - 3) {
            val p0 = i * 3; val p1 = (i + 1) * 3; val p2 = (i + 2) * 3; val p3 = (i + 3) * 3
            for (s in 0 until segSteps) {
                val t = s.toFloat() / segSteps
                val t2 = t * t
                val t3 = t2 * t
                val b0 = (1f - 3f * t + 3f * t2 - t3) / 6f
                val b1 = (4f - 6f * t2 + 3f * t3) / 6f
                val b2 = (1f + 3f * t + 3f * t2 - 3f * t3) / 6f
                val b3 = t3 / 6f
                val dst = outPts * 3
                bsplineBuf[dst] = b0 * extCtrlScratch[p0] + b1 * extCtrlScratch[p1] + b2 * extCtrlScratch[p2] + b3 * extCtrlScratch[p3]
                bsplineBuf[dst + 1] = b0 * extCtrlScratch[p0 + 1] + b1 * extCtrlScratch[p1 + 1] + b2 * extCtrlScratch[p2 + 1] + b3 * extCtrlScratch[p3 + 1]
                bsplineBuf[dst + 2] = b0 * extCtrlScratch[p0 + 2] + b1 * extCtrlScratch[p1 + 2] + b2 * extCtrlScratch[p2 + 2] + b3 * extCtrlScratch[p3 + 2]
                outPts++
            }
        }
        val lastC = (numCtrl - 1) * 3
        bsplineBuf[outPts * 3] = ctrlBuf[lastC]
        bsplineBuf[outPts * 3 + 1] = ctrlBuf[lastC + 1]
        bsplineBuf[outPts * 3 + 2] = ctrlBuf[lastC + 2]
        outPts++
        bsplineCount = outPts

        var arc = 0f
        for (m in 1 until outPts) {
            val a = (m - 1) * 3; val b = m * 3
            arc += hypot(hypot(bsplineBuf[b] - bsplineBuf[a], bsplineBuf[b + 1] - bsplineBuf[a + 1]), bsplineBuf[b + 2] - bsplineBuf[a + 2])
        }
        trajLen = arc
        val elapsedMs = (SystemClock.elapsedRealtimeNanos() - t0) * 1e-6f
        solveMs = elapsedMs.coerceIn(0.18f, 4.9f)
    }

    private fun publishSnapshotLocked() {
        snapshotWriteIdx = (snapshotWriteIdx + 1) and 3
        val frame = snapshotRing[snapshotWriteIdx]

        val zMax = hub.zSliceMax
        val showInf = hub.showInflate

        // 1. 导出高精度三维实体圆柱/墙体几何 (不再被 showFastLioMap 屏蔽，确保强烈 3D 体积感与真实视线遮挡)
        if (!hub.isRosMode && hub.showCore) {
            val obCnt = min(obstacles.size, 24)
            for (i in 0 until obCnt) {
                val ob = obstacles[i]
                val b = i * 6
                frame.obsPrimitives[b] = ob.cx
                frame.obsPrimitives[b + 1] = ob.cy
                frame.obsPrimitives[b + 2] = ob.rx
                frame.obsPrimitives[b + 3] = ob.ry
                frame.obsPrimitives[b + 4] = min(ob.h, zMax)
                frame.obsPrimitives[b + 5] = if (ob.isCircle) 1f else 0f
            }
            frame.obsPrimitiveCount = obCnt
        } else {
            frame.obsPrimitiveCount = 0
        }

        // 2. 导出膨胀安全边界 / 实机三维占据体素
        var outVoxCnt = 0
        val outVoxels = frame.voxels
        if (!hub.isRosMode && showInf) {
            for (i in 0 until cachedGridVoxelCount) {
                if (outVoxCnt >= 4090) break
                val b = i * 4
                val wx = cachedGridVoxels[b]
                val wy = cachedGridVoxels[b + 1]
                val dst = outVoxCnt * 4
                outVoxels[dst] = wx
                outVoxels[dst + 1] = wy
                outVoxels[dst + 2] = cachedGridVoxels[b + 2]
                val inLocal = abs(wx - uavX) <= 4.2f && abs(wy - uavY) <= 4.2f
                outVoxels[dst + 3] = if (inLocal) 0f else 1f
                outVoxCnt++
            }
        } else if (hub.isRosMode && showInf && rosVoxelCount > 0) {
            for (i in 0 until rosVoxelCount) {
                if (outVoxCnt >= 4090) break
                val h = rosVoxelsBuf[i * 3 + 2]
                if (h > zMax) continue
                val dst = outVoxCnt * 4
                outVoxels[dst] = rosVoxelsBuf[i * 3]
                outVoxels[dst + 1] = rosVoxelsBuf[i * 3 + 1]
                outVoxels[dst + 2] = h
                outVoxels[dst + 3] = 3f
                outVoxCnt++
            }
        }
        frame.voxelCount = outVoxCnt

        val uxIdx = clampGrid(uavX)
        val uyIdx = clampGrid(uavY)
        var minRadar = 9.5f
        for (b in smoothBins60) if (b < minRadar) minRadar = b
        val clearance = if (!hub.isRosMode) max(0f, distField[uyIdx * GRID_N + uxIdx]) else minRadar

        if (!hub.isRosMode) {
            val bsCnt = min(bsplineCount, 415)
            System.arraycopy(bsplineBuf, 0, frame.bsplinePts, 0, bsCnt * 3)
            frame.bsplineCount = bsCnt

            val asCnt = min(astarCount, 595)
            System.arraycopy(astarBuf, 0, frame.astarPts, 0, asCnt * 3)
            frame.astarCount = asCnt

            if (hub.showCtrlPts) {
                val ctCnt = min(ctrlCount, 22)
                System.arraycopy(ctrlBuf, 0, frame.ctrlPts, 0, ctCnt * 3)
                frame.ctrlCount = ctCnt
            } else {
                frame.ctrlCount = 0
            }
            frame.lioPathCount = 0
        } else {
            val rpCnt = min(rosPathCount, 415)
            System.arraycopy(rosPathBuf, 0, frame.bsplinePts, 0, rpCnt * 3)
            frame.bsplineCount = rpCnt
            frame.astarCount = 0
            frame.ctrlCount = 0

            val lpCnt = min(rosLioPathCount, 815)
            if (lpCnt > 1) {
                System.arraycopy(rosLioPathBuf, 0, frame.lioPathPts, 0, lpCnt * 3)
                frame.lioPathCount = lpCnt
            } else {
                frame.lioPathCount = 0
            }
        }

        val trCnt = min(trailCount, 240)
        System.arraycopy(trailRing, 0, frame.trailPts, 0, trCnt * 3)
        frame.trailCount = trCnt

        frame.hasPreviewPin = hasPreviewPin
        frame.previewX = previewX
        frame.previewY = previewY
        frame.previewZ = previewZ
        frame.previewClearance = previewClearance
        frame.previewSafe = previewSafe

        var wi = 0
        if (stagedWaypoints.isNotEmpty()) {
            for (wp in stagedWaypoints) {
                if (wi >= 16) break
                frame.waypointQueuePts[wi * 3] = wp[0]
                frame.waypointQueuePts[wi * 3 + 1] = wp[1]
                frame.waypointQueuePts[wi * 3 + 2] = wp[2]
                wi++
            }
            frame.waypointQueueCount = wi
            frame.isRouteStagedOnly = true
            frame.stagedRouteArcLen = computeStagedRouteLengthLocked()
        } else {
            for (wp in waypointQueue) {
                if (wi >= 16) break
                frame.waypointQueuePts[wi * 3] = wp[0]
                frame.waypointQueuePts[wi * 3 + 1] = wp[1]
                frame.waypointQueuePts[wi * 3 + 2] = wp[2]
                wi++
            }
            frame.waypointQueueCount = wi
            frame.isRouteStagedOnly = false
            frame.stagedRouteArcLen = 0f
        }

        System.arraycopy(smoothBins60, 0, frame.radarSmooth60, 0, 60)

        frame.uavX = uavX
        frame.uavY = uavY
        frame.uavZ = uavZ
        frame.vx = vx
        frame.vy = vy
        frame.vz = vz
        frame.ax = ax
        frame.ay = ay
        frame.yaw = yaw
        frame.smoothRoll = smoothRoll
        frame.smoothPitch = smoothPitch
        frame.homeX = homeX
        frame.homeY = homeY
        frame.goalX = goalX
        frame.goalY = goalY
        frame.goalZ = goalZ
        frame.fsmState = fsmState
        frame.px4Mode = if (hub.isRosMode) rosPx4Mode else "OFFBOARD"
        frame.armed = if (hub.isRosMode) rosArmed else true

        val useRealBat = hub.isRosMode || hasLiveBatteryTelemetry
        frame.batVolt = if (useRealBat) rosBatVolt else 16.24f
        frame.batCurrentAmps = if (useRealBat) rosBatCurrentAmps else (11.2f + hypot(vx, vy) * 2.4f + abs(vz) * 1.6f)
        frame.batPct = if (useRealBat) rosBatPct else 86

        frame.txBatPct = hub.txBatPct
        frame.txBatVolt = hub.txBatVolt
        frame.txCurrentAmps = hub.txCurrentAmps

        frame.odomHz = if (hub.isRosMode) rosOdomHz else 50
        frame.cloudHz = if (hub.isRosMode) rosCloudHz else 15
        frame.cloudScanPts = lastCloudScanPts
        frame.mapPointCount = voxelMap.pointCount
        frame.solveMs = solveMs
        frame.minClearance = clearance
        frame.trajLength = trajLen

        hub.latestSnapshot = frame
    }

    private fun stepHsiFilterAndRadarLocked(dt: Float) {
        val cosY = cos(yaw)
        val sinY = sin(yaw)
        val vFwd = vx * cosY + vy * sinY
        val vLeft = -vx * sinY + vy * cosY
        val aFwd = ax * cosY + ay * sinY
        val aLeft = -ax * sinY + ay * cosY

        var yawDiff = yaw - prevYaw
        while (yawDiff > PI.toFloat()) yawDiff -= (PI * 2.0).toFloat()
        while (yawDiff < -PI.toFloat()) yawDiff += (PI * 2.0).toFloat()
        prevYaw = yaw
        val yawRate = yawDiff / max(dt, 0.008f)

        val targetPitch = (-(aFwd * 0.055f + vFwd * 0.065f)).coerceIn(-0.38f, 0.38f)
        val targetRoll = (-(aLeft * 0.055f + vFwd * yawRate * 0.085f + vLeft * 0.04f)).coerceIn(-0.48f, 0.48f)
        val kAtt = 1f - exp(-dt * 8.5f)
        smoothPitch += (targetPitch - smoothPitch) * kAtt
        smoothRoll += (targetRoll - smoothRoll) * kAtt

        val numBins = 60
        val maxR = 8.2f
        for (i in 0 until numBins) rawBins60[i] = 9.5f

        if (!hub.isRosMode) {
            for (b in 0 until numBins) {
                val wAng = -PI.toFloat() + (b.toFloat() / numBins) * (PI.toFloat() * 2f)
                val dx = cos(wAng)
                val dy = sin(wAng)
                var t = 0.18f
                var hitD = 9.5f
                for (st in 0 until 8) {
                    val wx = uavX + dx * t
                    val wy = uavY + dy * t
                    var minOb = 99f
                    for (o in 0 until obstacles.size) {
                        val ob = obstacles[o]
                        if (ob.h < uavZ - 0.55f) continue
                        val d = signedDistToObs(wx, wy, ob)
                        if (d < minOb) minOb = d
                    }
                    if (minOb <= 0.06f) {
                        hitD = t
                        break
                    }
                    t += max(0.16f, minOb * 0.88f)
                    if (t > maxR) break
                }
                rawBins60[b] = hitD
            }
        } else {
            accumulateRadarBinsFromFlatXyz(rosVoxelsBuf, rosVoxelCount, numBins, maxR)
            accumulateRadarBinsFromFlatXyz(rosNearScanBuf, rosNearScanCount, numBins, maxR)
        }

        val kRad = 1f - exp(-dt * 14f)
        for (j in 0 until numBins) {
            val prev = rawBins60[(j + numBins - 1) % numBins]
            val curr = rawBins60[j]
            val next = rawBins60[(j + 1) % numBins]
            val filtered = min(curr, (prev + curr + next) / 3f)
            smoothBins60[j] += (filtered - smoothBins60[j]) * kRad
        }
    }

    private fun accumulateRadarBinsFromFlatXyz(pts: FloatArray, count: Int, numBins: Int, maxR: Float) {
        for (p in 0 until count) {
            val pz = pts[p * 3 + 2]
            if (abs(pz - uavZ) > 0.85f) continue
            val rx = pts[p * 3] - uavX
            val ry = pts[p * 3 + 1] - uavY
            val dist = hypot(rx, ry)
            if (dist < 0.22f || dist > maxR) continue
            val ang = atan2(ry, rx)
            var binIdx = floor(((ang + PI.toFloat()) / (PI.toFloat() * 2f)) * numBins).toInt() % numBins
            if (binIdx < 0) binIdx += numBins
            if (dist < rawBins60[binIdx]) rawBins60[binIdx] = dist
        }
    }
}
