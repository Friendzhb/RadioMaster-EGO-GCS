package com.radiomaster.egogcs.ros

import android.util.Base64
import com.radiomaster.egogcs.engine.EgoSimEngine
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.TopicConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

class RosBridgeClient(
    private val hub: GcsSharedHub,
    private val engine: EgoSimEngine,
    private val onStateToast: (String) -> Unit
) : RosTransport {

    override val protocolId: String = "rosbridge"

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(5, TimeUnit.SECONDS)
        .build()

    @Volatile private var ws: WebSocket? = null
    @Volatile var topics = TopicConfig()

    private val reuseXyzi = FloatArray(6016 * 4)
    private val reuseInflate = FloatArray(1420 * 3)
    private val reusePath = FloatArray(820 * 3)

    override fun connect(cfg: TopicConfig) {
        topics = cfg.copy()
        disconnect(silent = true)

        hub.isRosMode = true
        hub.connectionLevel = 1
        hub.connectionLabel = "正在连接机载电脑..."

        val req = try {
            Request.Builder().url(cfg.wsUrl.trim()).build()
        } catch (e: Exception) {
            hub.connectionLevel = 2
            hub.connectionLabel = "WS 地址无效"
            onStateToast("WebSocket 地址格式有误")
            return
        }

        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                hub.rosConnected = true
                hub.connectionLevel = 0
                hub.connectionLabel = "WS · FAST-LIO"
                subscribeAll(webSocket, topics)
                onStateToast("已连接机载 rosbridge: ${cfg.wsUrl}")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                parseRosPacket(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                hub.rosConnected = false
                if (hub.isRosMode) {
                    hub.connectionLevel = 2
                    hub.connectionLabel = "未连接机载电脑"
                }
                onStateToast("ROS1 连接失败: ${t.localizedMessage ?: "网络不可达"}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                hub.rosConnected = false
                if (hub.isRosMode) {
                    hub.connectionLevel = 2
                    hub.connectionLabel = "ROS1 已断开"
                }
            }
        })
    }

    override fun disconnect(silent: Boolean) {
        try {
            ws?.cancel()
        } catch (_: Throwable) {}
        ws = null
        hub.rosConnected = false
        if (!silent) {
            if (hub.isRosMode) {
                hub.connectionLevel = 2
                hub.connectionLabel = "ROS1 已断开"
            } else {
                hub.connectionLevel = 0
                hub.connectionLabel = "正常飞行 (DEMO)"
            }
        }
    }

    fun resubscribeIfConnected(cfg: TopicConfig) {
        topics = cfg.copy()
        val active = ws
        if (hub.rosConnected && active != null) {
            subscribeAll(active, topics)
        }
    }

    override fun setParamAsync(paramName: String, value: Float) {
        val active = ws ?: return
        if (!hub.rosConnected) return
        val pkt = JSONObject()
            .put("op", "call_service")
            .put("service", "/rosapi/set_param")
            .put("args", JSONObject().put("name", paramName).put("value", value.toString()))
        active.send(pkt.toString())
    }

    override fun publishGoal(gx: Float, gy: Float, gz: Float, curX: Float, curY: Float) {
        val active = ws ?: return
        if (!hub.rosConnected) return
        val yaw = atan2((gy - curY).toDouble(), (gx - curX).toDouble())
        val pkt = JSONObject().apply {
            put("op", "publish")
            put("topic", topics.goalTopic)
            put("msg", JSONObject().apply {
                put("header", JSONObject().put("frame_id", "world"))
                put("pose", JSONObject().apply {
                    put("position", JSONObject()
                        .put("x", gx.toDouble())
                        .put("y", gy.toDouble())
                        .put("z", gz.toDouble()))
                    put("orientation", JSONObject()
                        .put("x", 0.0)
                        .put("y", 0.0)
                        .put("z", sin(yaw * 0.5))
                        .put("w", cos(yaw * 0.5)))
                })
            })
        }
        active.send(pkt.toString())
    }

    private fun subscribeAll(webSocket: WebSocket, cfg: TopicConfig) {
        val subs = mutableListOf(
            cfg.odomTopic to 25,
            cfg.fastLioCloudTopic to 80,
            cfg.optimalTopic to 50,
            "/mavros/state" to 500,
            "/mavros/battery" to 800
        )
        if (cfg.fastLioPathTopic.isNotBlank() && cfg.fastLioPathTopic != cfg.optimalTopic) {
            subs.add(cfg.fastLioPathTopic to 250)
        }
        if (cfg.inflateTopic.isNotBlank() && cfg.inflateTopic != cfg.fastLioCloudTopic) {
            subs.add(cfg.inflateTopic to 150)
        }
        for ((topic, rate) in subs) {
            if (topic.isNotBlank()) {
                val obj = JSONObject()
                    .put("op", "subscribe")
                    .put("topic", topic)
                    .put("throttle_rate", rate)
                webSocket.send(obj.toString())
            }
        }
    }

    private fun parseRosPacket(raw: String) {
        try {
            val root = JSONObject(raw)
            if (root.optString("op") != "publish") return
            val topic = root.optString("topic")
            val msg = root.optJSONObject("msg") ?: return

            when (topic) {
                topics.odomTopic -> {
                    val poseObj = msg.optJSONObject("pose")?.optJSONObject("pose") ?: return
                    val pos = poseObj.optJSONObject("position") ?: return
                    val ori = poseObj.optJSONObject("orientation")
                    val x = pos.optDouble("x", 0.0).toFloat()
                    val y = pos.optDouble("y", 0.0).toFloat()
                    val z = pos.optDouble("z", 0.0).toFloat()

                    var yaw = 0f
                    if (ori != null) {
                        val ox = ori.optDouble("x", 0.0)
                        val oy = ori.optDouble("y", 0.0)
                        val oz = ori.optDouble("z", 0.0)
                        val ow = ori.optDouble("w", 1.0)
                        yaw = atan2(2.0 * (ow * oz + ox * oy), 1.0 - 2.0 * (oy * oy + oz * oz)).toFloat()
                    }
                    val lin = msg.optJSONObject("twist")?.optJSONObject("twist")?.optJSONObject("linear")
                    val vx = (lin?.optDouble("x", 0.0) ?: 0.0).toFloat()
                    val vy = (lin?.optDouble("y", 0.0) ?: 0.0).toFloat()
                    val vz = (lin?.optDouble("z", 0.0) ?: 0.0).toFloat()
                    engine.onRosOdometry(x, y, z, vx, vy, vz, yaw)
                }

                topics.fastLioCloudTopic -> decodeBinaryPointCloud2(msg, isFastLioGlobal = true)
                topics.fastLioPathTopic -> decodePathOrMarker(msg, isGlobalLio = true)
                topics.optimalTopic -> decodePathOrMarker(msg, isGlobalLio = false)
                topics.inflateTopic -> decodeBinaryPointCloud2(msg, isFastLioGlobal = false)

                "/mavros/state" -> {
                    val mode = msg.optString("mode", "OFFBOARD")
                    val armed = msg.optBoolean("armed", false)
                    engine.onRosMavrosState(mode, armed)
                }

                "/mavros/battery" -> {
                    val volt = msg.optDouble("voltage", 16.0).toFloat()
                    val rawCurr = msg.optDouble("current", 0.0).toFloat()
                    val amps = if (rawCurr.isFinite()) abs(rawCurr) else 0f
                    val rawPct = msg.optDouble("percentage", 0.85)
                    val pct = if (rawPct <= 1.0) (rawPct * 100.0).roundToInt() else rawPct.roundToInt()
                    engine.onRosBattery(volt, pct.coerceIn(0, 100), amps)
                }
            }
        } catch (_: Throwable) {
        }
    }

    private fun decodePathOrMarker(msg: JSONObject, isGlobalLio: Boolean) {
        val ptsArr: JSONArray? = msg.optJSONArray("points") ?: msg.optJSONArray("poses")
        if (ptsArr != null && ptsArr.length() > 0) {
            val n = ptsArr.length()
            val maxCap = if (isGlobalLio) 800 else 400
            val stride = max(1, n / maxCap)
            var valid = 0
            var i = 0
            while (i < n && valid < 815) {
                val item = ptsArr.optJSONObject(i)
                if (item != null) {
                    val p = item.optJSONObject("pose")?.optJSONObject("position") ?: item
                    reusePath[valid * 3] = p.optDouble("x", 0.0).toFloat()
                    reusePath[valid * 3 + 1] = p.optDouble("y", 0.0).toFloat()
                    reusePath[valid * 3 + 2] = p.optDouble("z", 0.0).toFloat()
                    valid++
                }
                i += stride
            }
            if (valid > 0) {
                if (isGlobalLio) engine.onRosFastLioPath(reusePath, valid)
                else engine.onRosOptimalPath(reusePath, valid)
            }
        }
    }

    private fun decodeBinaryPointCloud2(msg: JSONObject, isFastLioGlobal: Boolean) {
        val dataB64 = msg.optString("data", "")
        val pointStep = msg.optInt("point_step", 0)
        val fields = msg.optJSONArray("fields")
        if (dataB64.isEmpty() || pointStep < 12 || fields == null) return

        val rawBytes = try {
            Base64.decode(dataB64, Base64.DEFAULT)
        } catch (_: IllegalArgumentException) {
            return
        }
        var offX = 0; var offY = 4; var offZ = 8
        var offInten = -1
        for (i in 0 until fields.length()) {
            val f = fields.optJSONObject(i) ?: continue
            when (f.optString("name")) {
                "x" -> offX = f.optInt("offset", 0)
                "y" -> offY = f.optInt("offset", 4)
                "z" -> offZ = f.optInt("offset", 8)
                "intensity", "reflectivity" -> offInten = f.optInt("offset", -1)
            }
        }
        val order = if (msg.optBoolean("is_bigendian", false)) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN
        val bb = ByteBuffer.wrap(rawBytes).order(order)
        val total = rawBytes.size / pointStep

        if (isFastLioGlobal) {
            val stride = max(1, total / 6000)
            var count = 0
            var p = 0
            val req = max(max(offX, max(offY, offZ)) + 4, if (offInten >= 0) offInten + 4 else 12)
            while (p < total && count < 6010) {
                val base = p * pointStep
                if (base + req > rawBytes.size) break
                val px = bb.getFloat(base + offX)
                val py = bb.getFloat(base + offY)
                val pz = bb.getFloat(base + offZ)
                if (px.isFinite() && py.isFinite() && pz.isFinite()) {
                    val inten = if (offInten >= 0) {
                        val fv = bb.getFloat(base + offInten)
                        (if (fv > 1.5f) fv / 255f else fv).coerceIn(0.05f, 1.0f)
                    } else {
                        ((pz + 0.5f) / 3.5f).coerceIn(0.05f, 1.0f)
                    }
                    val dst = count * 4
                    reuseXyzi[dst] = px
                    reuseXyzi[dst + 1] = py
                    reuseXyzi[dst + 2] = pz
                    reuseXyzi[dst + 3] = inten
                    count++
                }
                p += stride
            }
            if (count > 0) engine.onRosFastLioCloud(reuseXyzi, count)
        } else {
            val stride = max(1, total / 1400)
            var count = 0
            var p = 0
            while (p < total && count < 1415) {
                val base = p * pointStep
                if (base + max(offX, max(offY, offZ)) + 4 > rawBytes.size) break
                val px = bb.getFloat(base + offX)
                val py = bb.getFloat(base + offY)
                val pz = bb.getFloat(base + offZ)
                if (px.isFinite() && py.isFinite() && pz.isFinite()) {
                    reuseInflate[count * 3] = px
                    reuseInflate[count * 3 + 1] = py
                    reuseInflate[count * 3 + 2] = pz
                    count++
                }
                p += stride
            }
            engine.onRosInflatedCloud(reuseInflate, count)
        }
    }
}
