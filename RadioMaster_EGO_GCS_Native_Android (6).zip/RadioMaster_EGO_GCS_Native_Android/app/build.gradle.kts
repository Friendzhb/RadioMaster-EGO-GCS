plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.radiomaster.egogcs"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.radiomaster.egogcs"
        minSdk = 26 // 原生兼容 RadioMaster AX12 (Android 9.0 / API 28)
        targetSdk = 34
        versionCode = 2
        versionName = "2.0.0-native"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // Google 官方物理弹簧动画库：提供抽屉阻尼滑出、标签切换与按键回弹 60FPS 物理动效
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
    // OkHttp 原生异步 WebSocket：独立 I/O 线程池收发 rosbridge 二进制点云与轨迹
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
