# EGO Pilot · 纯原生 Kotlin + OpenGL ES 真三维立体建图与遮挡透视虚线地面站

本工程为 **100% 纯原生 Kotlin + [OpenGL ES](https://developer.android.com/develop/ui/views/graphics/opengl/about-opengl) 硬件加速安卓应用（无任何 WebView 或 HTML 套壳文件）**，专为 [RadioMaster AX12](https://radiomasterrc.com/products/ax12-android-radio-controller)（MediaTek MT8788 八核处理器、ARM Mali-G72 GPU、4GB RAM、`1280×720` 1000nits 5 英寸高亮触控屏，见 [AX12 规格手册](https://manuals.plus/radiomaster/ax12-android-radio-controller-manual)）打造，视觉与空间交互参考 [DJI FlightHub 2 三维航线投影](https://enterprise.dji.com/flighthub-2) 与 [DJI Fly 交互规范](https://support.dji.com/help/content?customId=en-us03400006562&spaceId=34&re=US&lang=en&documentType=artical&paperDocType=paper)。

## 1. 真三维空间纵深感与硬件遮挡透视动画 (`GlPointCloudMapView.kt`)

1. **五重三维空间立体感构建**：
   - **天际大气穹顶与远景深度雾**：随相机俯仰动态响应的地平线大气辉光与指数距离雾，清晰拉开近景障碍与远景空间层次。
   - **定向太阳/天光法线明暗 + 垂直环境光遮蔽 (AO)**：圆柱与墙体具备顶面高光、向阳亮面、背光暗面、底部落地接触暗影以及 `1m / 2m` 高度等高刻度环。
   - **点云球面微浮雕与单遍 [Eye-Dome Lighting](https://www.researchgate.net/publication/320616607_Eye-Dome_Lighting_a_non-photorealistic_shading_technique) 轮廓加深**：每个 LiDAR 点在片元着色器中按三维半球法线计算漫反射与边缘加深，消除扁平色块感。
   - **三维轨迹高程垂幕 (Altitude Drop-Curtain)**：局部 B 样条轨迹下方投射渐变半透明垂幕、等距高程标尺肋与地面投影暗轨。
2. **视线遮挡半透明避让与硬件双遍透视虚线 ([OpenGL Depth Testing](https://learnopengl.com/Advanced-OpenGL/Depth-testing))**：
   - **相机→无人机视线隧道平滑融化动画**：挡在相机与飞机连线上的柱体或墙面在约 `180ms` 内平滑融化为 `24%` 磨砂半透明玻璃体并亮起青色高光棱线；遮挡视线的点云墙面自动执行 `2×2` 屏幕空间网格抖动镂空。
   - **`GL_GREATER` + `GL_LEQUAL` 逐像素硬件遮挡分离**：未被遮挡的轨迹与无人机保持实心高亮；一旦轨迹、多航点连线或选点光柱穿入墙体/柱林/点云后方，硬件深度逆测试自动将其逐像素化作**世界空间等距向前流动的霓虹透视虚线**，被遮挡的无人机自动切换为全息扫描轮廓与脉冲声呐定位环。

## 2. 直觉式触控与 AX12 双路电压电流遥测

- **单击三维插针净空预检 + 底部智能指令坞**：单击地面先立起弹性落针光柱并实时评估三维障碍净空，可在指令坞直接调高、点“立即飞往”或“加航点”（长按地面 `0.4s` 快捷直飞）；接入实机自动隐藏仿真按钮。
- **零串口冲突双路电源监控 (`Ax12HardwareBridge.kt`)**：在不触碰官方独占串口 `/dev/ttyS0`（见 [ax12-research](https://github.com/rmeadomavic/ax12-research) 与 [Flyshark 分析](https://github.com/rmeadomavic/ax12-research/blob/main/docs/software/flyshark-app.md)）的前提下，通过 [BatteryManager](https://developer.android.com/reference/android/os/BatteryManager) 读取遥控器本机电量/电压/电流，并通过 [`/mavros/battery`](https://docs.ros.org/en/noetic/api/sensor_msgs/html/msg/BatteryState.html) 与 [ELRS Backpack](https://github.com/rmeadomavic/ax12-research/blob/main/docs/hardware/elrs-backpack.md) [MAVLink](https://mavlink.io/en/messages/common.html) `UDP :14550` 采集飞机电压与实时放电电流。

## 3. 机载带宽建议与云端自动构建

集成原生 [TCPROS](https://wiki.ros.org/ROS/TCPROS)（`:11311`）局域网寻机、[FAST-LIO2](https://github.com/hku-mars/fast_lio)（建议机载 [laserMapping.cpp](https://github.com/hku-mars/FAST_LIO/blob/main/src/laserMapping.cpp) 配置 `dense_publish_en: false`）与 [EGO-Planner](https://github.com/ZJU-FAST-Lab/ego-planner)。将压缩包上传至仓库即可通过 [GitHub Actions](https://docs.github.com/actions) 自动构建 `.apk`。
