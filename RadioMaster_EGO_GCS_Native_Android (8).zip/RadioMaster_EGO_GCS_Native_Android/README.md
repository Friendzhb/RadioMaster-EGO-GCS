# EGO Pilot · 纯原生 Kotlin + OpenGL ES 实时三维姿态与无碰撞座舱地面站

本工程为 **100% 纯原生 Kotlin + [OpenGL ES](https://developer.android.com/develop/ui/views/graphics/opengl/about-opengl) 硬件加速安卓应用（无任何 WebView、无 HTML 套壳文件、全界面零 Emoji 表情符号）**，专为 [RadioMaster AX12](https://radiomasterrc.com/products/ax12-android-radio-controller)（MediaTek MT8788 八核处理器、ARM Mali-G72 GPU、4GB RAM、5.5 英寸 `1280×720` 1000nits 高亮触控屏，见 [AX12 规格手册](https://manuals.plus/radiomaster/ax12-android-radio-controller-manual)）打造，界面架构与设置逻辑对标 [DJI Pilot 2](https://dl.djicdn.com/downloads/matrice-30-series/20230922UM/Matrice30_Series_User_Manual_v2.0_EN.pdf)、[DJI Fly 系统设置规范](https://support.dji.com/help/content?customId=en-us03400006562&spaceId=34&re=US&lang=en&documentType=artical&paperDocType=paper) 与 [QGroundControl Settings View](https://docs.qgroundcontrol.com/Stable_V5.1/en/qgc-user-guide/settings_view/settings_view.html)。

## 1. 全界面响应式五区无碰撞对齐架构与标准四大飞控设置 (`MainActivity.kt` + `GcsSettingsModal.kt`)

- **全分辨率零重叠对齐设计**：针对 `640×360dp` 至 `853×480dp` 横屏比例重构紧凑 36dp 顶栏、顶部居中统一流式堆栈（航向罗盘 + 回中/遮挡提示 + 消息横幅自动流式排布）、左右对称等高 94dp 双仪表底栏（左下 HSI 避障球 + 右下三维实时姿态视窗）及空间互斥避让协调器，修复矢量图标字体度量 (`GcsIcons.kt`) 与实测标签滑块对齐，彻底消除控件重叠、换行截断与基线错位。
- **主流商业无人机四大设置分类 (`GcsSettingsModal.kt`)**：收敛为飞手实战刚需的 **「飞行安全 · 感知与飞控 · 通信链路 · 显示与通用」** 四大分类（涵盖膨胀安全半径、近障/低电告警、更新返航点 H、平稳/标准/敏捷三档速度模式、默认高度与步幅、TCPROS/rosbridge 协议与话题模板、四套环境光照主题及 60 帧/省电 30 帧策略）。

## 2. 无人机三维实时姿态视窗与针对 AX12 的全链路性能优化

- **右下角三维实时姿态视窗与可替换矢量模型 (`UavAttitudeHudView.kt` + `DroneVectorModel.kt`)**：实时解算实机 `/Odometry` 单位四元数 `(qw, qx, qy, qz)` 与仿真气动姿态，支持追尾地平、等轴陀螺与迎面正视三视角切换；机体独立封装于 `DroneVectorModel.kt`，便于后续直接替换为自定义矢量无人机模型。
- **9 路专用 VBO 与稳态零 GC 管线 (`GlPointCloudMapView.kt` + `FastHudFormatter.kt`)**：拆分 9 路独立持久化 VBO 消除 Mali-G72 分块渲染器 Buffer Ghosting，结合齐次视锥剔除、视线隧道平方距离剪枝、256 段三角查表与 `FastHudFormatter` 原始整型脏检查，实现高帧低功耗运行。

## 3. 真实 EGO-Planner 三维膨胀体素透视与原生 ROS1 话题监控

- **真实 `/grid_map/occupancy_inflate` 三维膨胀体素块与 [OpenGL Depth Testing](https://learnopengl.com/Advanced-OpenGL/Depth-testing) 双遍遮挡透视**：还原真实 [EGO-Planner](https://github.com/ZJU-FAST-Lab/ego-planner/issues/106) 离散三维膨胀占据体素块，视线走廊内自动羽化为半透明线框，被遮挡轨迹自动切换为向前流动的霓虹虚线，融合 [Eye-Dome Lighting](https://www.researchgate.net/publication/320616607_Eye-Dome_Lighting_a_non-photorealistic_shading_technique) 点云浮雕。
- **原生 ROS1 话题监控与双路电源遥测**：通过 [ROS Master XML-RPC API](https://wiki.ros.org/ROS/Master_API) 与 [TCPROS Connection Header](https://wiki.ros.org/ROS/Connection%20Header) 支持话题列表浏览、单次截取、持续读取与一键绑定通道；零串口冲突（不触碰 `/dev/ttyS0`，见 [ax12-research](https://github.com/rmeadomavic/ax12-research) 与 [Flyshark 分析](https://github.com/rmeadomavic/ax12-research/blob/main/docs/software/flyshark-app.md)），兼容 [BatteryManager](https://developer.android.com/reference/android/os/BatteryManager)、[`/mavros/battery`](https://docs.ros.org/en/noetic/api/sensor_msgs/html/msg/BatteryState.html)、[ELRS Backpack](https://github.com/rmeadomavic/ax12-research/blob/main/docs/hardware/elrs-backpack.md) [MAVLink](https://mavlink.io/en/messages/common.html) `UDP :14550`、原生 [TCPROS](https://wiki.ros.org/ROS/TCPROS) 与 [FAST-LIO2](https://github.com/hku-mars/fast_lio)（见 [laserMapping.cpp](https://github.com/hku-mars/FAST_LIO/blob/main/src/laserMapping.cpp)），上传压缩包至仓库即可通过 [GitHub Actions](https://docs.github.com/actions) 自动构建发布 APK。
