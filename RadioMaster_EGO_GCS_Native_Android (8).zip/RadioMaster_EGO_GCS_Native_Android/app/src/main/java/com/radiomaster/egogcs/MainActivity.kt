package com.radiomaster.egogcs

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.radiomaster.egogcs.engine.EgoSimEngine
import com.radiomaster.egogcs.hw.Ax12HardwareBridge
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.RenderSnapshot
import com.radiomaster.egogcs.model.TopicConfig
import com.radiomaster.egogcs.ros.DiscoveredDrone
import com.radiomaster.egogcs.ros.LanDroneScanner
import com.radiomaster.egogcs.ros.RosBridgeClient
import com.radiomaster.egogcs.ros.RosConnectionManager
import com.radiomaster.egogcs.ros.RosTopicEntry
import com.radiomaster.egogcs.ros.RosTopicInspector
import com.radiomaster.egogcs.ros.TcpRosNativeClient
import com.radiomaster.egogcs.ros.TopicEchoSnapshot
import com.radiomaster.egogcs.ros.TopicEchoState
import com.radiomaster.egogcs.ui.AnimHelper
import com.radiomaster.egogcs.ui.DjiCompassTapeView
import com.radiomaster.egogcs.ui.DjiHsiRadarView
import com.radiomaster.egogcs.ui.FastHudFormatter
import com.radiomaster.egogcs.ui.GcsIcons
import com.radiomaster.egogcs.ui.GcsIcons.Type
import com.radiomaster.egogcs.ui.GcsSettingsModal
import com.radiomaster.egogcs.ui.GcsTheme
import com.radiomaster.egogcs.ui.GcsTheme.Role
import com.radiomaster.egogcs.ui.GlPointCloudMapView
import com.radiomaster.egogcs.ui.UavAttitudeHudView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * 全界面响应式防重叠对齐 + 精简务实飞控设置版地面站主控座舱 (`MainActivity`)：
 * 1. 五区无碰撞航空布局：紧凑 36dp 顶栏、顶部居中统一堆栈 (航向罗盘 + 回中/遮挡提示 + 消息横幅永不互叠)、
 *    左侧安全操控栏、右侧紧凑相机条与对称等高 94dp 双仪表底栏 (HSI 避障球 + 三维实时姿态视窗)；
 * 2. 空间互斥协调器 (`syncBottomHudAvoidance`)：窄横屏下弹出底部选点指令坞或展开宽屏抽屉时，自动让位次级数字面板，
 *    从几何上彻底根除 `640×360dp` 至 `853×480dp` 全分辨率范围内的任何控件重叠或错位；
 * 3. 对标 DJI Pilot 2 / DJI Fly / QGroundControl 的四大核心飞控设置（飞行安全 · 感知与飞控 · 通信链路 · 显示与通用）。
 */
class MainActivity : Activity() {

    private val hub = GcsSharedHub()
    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var simEngine: EgoSimEngine
    private lateinit var hwBridge: Ax12HardwareBridge
    private lateinit var rosManager: RosConnectionManager
    private lateinit var topicInspector: RosTopicInspector
    private lateinit var settingsModal: GcsSettingsModal
    private val lanScanner = LanDroneScanner()
    private val fileIoExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "PcdExportIO").apply { isDaemon = true }
    }

    private lateinit var cockpitRoot: FrameLayout
    private lateinit var topBarView: LinearLayout
    private lateinit var topCenterStack: LinearLayout
    private lateinit var leftSafetyRail: LinearLayout
    private lateinit var bottomLeftCluster: LinearLayout

    private lateinit var mapView: GlPointCloudMapView
    private lateinit var hsiView: DjiHsiRadarView
    private lateinit var attitudeHudView: UavAttitudeHudView
    private lateinit var hdTelemetryBox: LinearLayout
    private lateinit var rightCamStack: LinearLayout
    private lateinit var compassView: DjiCompassTapeView
    private lateinit var recenterBanner: TextView
    private lateinit var occlusionBadge: TextView
    private lateinit var toastBanner: TextView

    private lateinit var topBatFill: View
    private lateinit var statusAccent: View
    private lateinit var accentGreen: GradientDrawable
    private lateinit var accentAmber: GradientDrawable
    private lateinit var accentRed: GradientDrawable
    private var lastAppliedConnLevel = -1
    private var lastIsRosModeUi = false
    private var lastHudThemeId = -1
    private var lastPx4ModeStr = ""
    private var lastArmedFlag = true
    private var lastConnLabelStr = ""
    private var lastFsmStateStr = ""
    private var lastBatBarPx = -1
    private var lastOccludedHudState = false
    private var lastBatDangerLevel = -1
    private var lastClearanceWarnLevel = -1

    // 顶栏精简控件
    private lateinit var tvModeBadge: TextView
    private lateinit var tvConnStatus: TextView
    private lateinit var quickSlotsContainer: LinearLayout
    private var quickPillMission: TextView? = null
    private var quickPillTopics: TextView? = null
    private lateinit var tvClearanceTop: TextView
    private lateinit var tvHzTop: TextView
    private lateinit var tvBatTop: TextView
    private lateinit var btnMenuToggle: TextView
    private lateinit var btnSettingsToggle: ImageView

    // 左侧飞行安全操控栏
    private lateinit var btnBrake: TextView
    private lateinit var btnRth: TextView
    private lateinit var demoControlGroup: LinearLayout
    private lateinit var btnPatrol: TextView
    private lateinit var btnDemoScene: TextView

    // 底部中央智能选点/航线指令坞
    private lateinit var commandDock: LinearLayout
    private lateinit var tvDockHeader: TextView
    private lateinit var dockPinRow: LinearLayout
    private lateinit var tvDockAltVal: TextView
    private lateinit var btnDockFlyNow: TextView
    private lateinit var dockRouteRow: LinearLayout
    private lateinit var btnDockStartRoute: TextView
    private lateinit var btnDockUndo: TextView
    private lateinit var btnDockOpenOrchestrate: TextView
    private lateinit var btnDockClearRoute: TextView
    private var dockLogicalActive = false

    // 右侧精简相机栏 + 图层快捷浮窗
    private lateinit var btn3DRef: TextView
    private lateinit var btnFollowRef: TextView
    private lateinit var btnXrayRef: TextView
    private lateinit var btnLayerPopupToggle: TextView
    private lateinit var layerQuickPopover: LinearLayout
    private var layerPopoverOpen = false
    private val colorSegBtns = mutableListOf<TextView>()
    private lateinit var popSwitchInflate: TextView
    private lateinit var popSwitchCloud: TextView
    private lateinit var popSwitchBox: TextView
    private lateinit var popSwitchCtrl: TextView
    private lateinit var btnClearMapInPopover: TextView

    private var rthConfirmPending = false
    private val resetRthConfirmRunnable = Runnable {
        rthConfirmPending = false
        if (::btnRth.isInitialized) {
            styleRthDefault()
        }
    }

    private var clearMapConfirmPending = false
    private val resetClearMapConfirmRunnable = Runnable {
        clearMapConfirmPending = false
        if (::btnClearMapInPopover.isInitialized) {
            val pal = GcsTheme.of(hub.themeId)
            btnClearMapInPopover.setTextColor(pal.textPrimary)
            GcsIcons.bind(btnClearMapInPopover, Type.TRASH, "清建图", d, iconDp = 11.5f)
            btnClearMapInPopover.background = glassBg(dp(6f))
        }
    }

    private lateinit var tvOsdH: TextView
    private lateinit var tvOsdHs: TextView
    private lateinit var tvOsdD: TextView
    private lateinit var tvOsdMapPts: TextView
    private lateinit var tvOsdSubXyz: TextView

    // 四标签主作业抽屉 (连接 | 航线 | 话题 | 状态)
    private lateinit var drawerRoot: LinearLayout
    private lateinit var tabRowRef: LinearLayout
    private lateinit var tabGlider: FrameLayout
    private lateinit var tabGliderBar: View
    private val tabBtns = mutableListOf<TextView>()
    private val tabPanels = mutableListOf<View>()
    private var drawerOpen = false
    private var drawerWideMode = false
    private var activeTabIndex = 0

    // Tab 0 (连接)
    private lateinit var segModeDemoBtn: TextView
    private lateinit var segModeRosBtn: TextView
    private lateinit var demoSectionInConn: LinearLayout
    private lateinit var rosSectionInConn: LinearLayout
    private val demoSceneSegBtns = mutableListOf<TextView>()
    private lateinit var tvScanStatus: TextView
    private lateinit var btnDrawerScan: TextView
    private lateinit var discoveredListContainer: LinearLayout
    private lateinit var segProtoTcpBtn: TextView
    private lateinit var segProtoWsBtn: TextView
    private lateinit var wrapMasterUri: LinearLayout
    private lateinit var wrapWsUrl: LinearLayout
    private lateinit var inpMasterUri: EditText
    private lateinit var inpWsUrl: EditText
    private lateinit var btnExpandTopicMap: TextView
    private lateinit var topicMapAccordionBody: LinearLayout
    private var topicMapExpanded = false
    private lateinit var inpOdom: EditText
    private lateinit var inpFastLioCloud: EditText
    private lateinit var inpFastLioPath: EditText
    private lateinit var inpInflate: EditText
    private lateinit var inpOptimal: EditText
    private lateinit var inpGoal: EditText

    // Tab 1 (航线编排)
    private val loopModeSegBtns = mutableListOf<TextView>()
    private val finishActSegBtns = mutableListOf<TextView>()
    private lateinit var tvWaypointQueueSummary: TextView
    private lateinit var waypointListContainer: LinearLayout
    private lateinit var btnOrchPrimaryExecute: TextView

    // Tab 2 (话题)
    private lateinit var topicListPage: LinearLayout
    private lateinit var topicDetailPage: LinearLayout
    private lateinit var inpTopicFilter: EditText
    private lateinit var tvTopicSourceHint: TextView
    private lateinit var topicItemsContainer: LinearLayout
    private var cachedTopicEntries: List<RosTopicEntry> = emptyList()
    private var selectedTopicEntry: RosTopicEntry? = null
    private lateinit var tvDetailTopicName: TextView
    private lateinit var tvDetailTopicType: TextView
    private lateinit var btnWideTerminal: TextView
    private lateinit var btnBindTopicChannel: TextView
    private lateinit var tvDetailStatusStrip: TextView
    private lateinit var tvDetailMetricsStrip: TextView
    private lateinit var tvDetailPayloadConsole: TextView
    private lateinit var btnDetailStreamToggle: TextView
    private var isDetailCurrentlyStreaming = false

    // Tab 3 (状态)
    private lateinit var tvUavPowerCard: TextView
    private lateinit var tvTxPowerCard: TextView
    private lateinit var tvMapPtsCard: TextView
    private lateinit var tvCloudRateCard: TextView
    private lateinit var tvPosX: TextView
    private lateinit var tvPosY: TextView
    private lateinit var tvPosZ: TextView
    private lateinit var tvVelNorm: TextView
    private lateinit var tvRollPitch: TextView
    private lateinit var tvQuatSummary: TextView
    private lateinit var tvYaw: TextView
    private lateinit var tvGoalDist: TextView
    private lateinit var tvClearanceCard: TextView
    private lateinit var tvSolveCard: TextView
    private lateinit var tvVoxelCount: TextView
    private lateinit var tvTrajLen: TextView

    private val discoveredDrones = mutableListOf<DiscoveredDrone>()
    private val sceneCycle = arrayOf("pillars" to "体素柱阵", "corridor" to "错位走廊", "utrap" to "U型陷阱", "random" to "随机体素")
    private var sceneIdx = 0

    private var lastBackMs = 0L
    private var d = 1f
    private var screenWidthDp = 640f
    private var screenHeightDp = 360f

    companion object {
        private const val TAB_CONN = 0
        private const val TAB_ORCHESTRATE = 1
        private const val TAB_TOPICS = 2
        private const val TAB_STATUS = 3
        private const val TAB_COUNT = 4
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dm = resources.displayMetrics
        d = dm.density
        screenWidthDp = dm.widthPixels / d
        screenHeightDp = dm.heightPixels / d

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersiveFullscreen()

        accentGreen = roundedColor(Color.parseColor("#00E676"), dp(2f))
        accentAmber = roundedColor(Color.parseColor("#FFAB00"), dp(2f))
        accentRed = roundedColor(Color.parseColor("#FF3B30"), dp(2f))

        simEngine = EgoSimEngine(hub).apply {
            onRosWaypointAdvanced = { gx, gy, gz, curX, curY ->
                rosManager.publishGoal(gx, gy, gz, curX, curY)
                runOnUiThread {
                    refreshCommandDockUi()
                    refreshWaypointOrchestratorList()
                    AnimHelper.showDjiToast(
                        toastBanner,
                        String.format(Locale.US, "航线推进 -> 下一站 (%.1f, %.1f)", gx, gy),
                        d
                    )
                }
            }
        }

        hwBridge = Ax12HardwareBridge(this, hub, simEngine)

        val wsClient = RosBridgeClient(hub, simEngine) { msg ->
            runOnUiThread { AnimHelper.showDjiToast(toastBanner, msg, d) }
        }
        val tcpClient = TcpRosNativeClient(hub, simEngine) { msg ->
            runOnUiThread { AnimHelper.showDjiToast(toastBanner, msg, d) }
        }
        rosManager = RosConnectionManager(hub, tcpClient, wsClient)
        topicInspector = RosTopicInspector(hub, rosManager, wsClient)

        GcsSettingsModal.loadPersistedSettings(this, hub)
        loadSavedTopics()

        settingsModal = GcsSettingsModal(
            context = this,
            hub = hub,
            getCurrentTopicConfig = { rosManager.topics },
            onThemeChanged = { animate ->
                applyActiveThemeLive(animate)
                AnimHelper.showDjiToast(toastBanner, "已切换主题：${GcsTheme.of(hub.themeId).name}", d)
            },
            onFlightKinematicsChanged = { inf, vel, acc, gz ->
                applyFlightParametersToEngine(inf, vel, acc, gz)
            },
            onVisualSettingsChanged = {
                syncCameraControlLabels()
                syncLayerPopoverControls()
                if (!hub.xrayOcclusionEnabled && lastOccludedHudState) {
                    updateOcclusionHudVisibility(false)
                }
            },
            onApplyTopicPreset = { key -> applyNamedTopicPreset(key, quiet = false) },
            onProtocolChanged = { pKey ->
                rosManager.topics.protocol = pKey
                syncProtoInputsVisibility()
                saveCurrentTopics(quiet = true)
            },
            onJumpToConnDrawer = {
                syncConnModeSectionsUi(showRosEditor = true)
                topicMapExpanded = true
                topicMapAccordionBody.visibility = View.VISIBLE
                toggleOrJumpDrawerTab(TAB_CONN)
            },
            onSetHomeHere = {
                val h = simEngine.setHomeToCurrentUav()
                mapView.spawnRipple(h[0], h[1])
                AnimHelper.showDjiToast(toastBanner, String.format(Locale.US, "已更新返航点 H -> (%.2f, %.2f)", h[0], h[1]), d)
            },
            onExportPcd = { exportCurrentPointCloudPcd() },
            onClearMapAndTrail = {
                simEngine.clearVoxelMap()
                simEngine.clearTrail()
                AnimHelper.showDjiToast(toastBanner, "已清空全局点云建图与历史飞行航迹", d)
            },
            onFactoryResetApplied = {
                applyFlightParametersToEngine(0.30f, 2.0f, 3.0f, 1.2f)
                applyActiveThemeLive(animate = true)
                syncCameraControlLabels()
                syncLayerPopoverControls()
                syncMissionStrategyButtons()
                refreshWaypointOrchestratorList()
            },
            onShowToast = { msg -> AnimHelper.showDjiToast(toastBanner, msg, d) }
        )

        setContentView(buildNativeDjiCockpit())
        applyActiveThemeLive(animate = false)
        syncCameraControlLabels()
        syncLayerPopoverControls()
        syncMissionStrategyButtons()
        refreshWaypointOrchestratorList()
        syncConnModeSectionsUi(showRosEditor = hub.isRosMode)
        syncModeSpecificControls(force = true)
        syncBottomHudAvoidance()
        simEngine.start()
        hwBridge.start()

        if (hub.autoConnectDiscovered) {
            triggerLanScan(silentIfEmpty = true, autoOpenConnTabOnEmpty = false)
        }
    }

    override fun onResume() {
        super.onResume()
        applyImmersiveFullscreen()
        mapView.startLoop()
    }

    override fun onPause() {
        topicInspector.stopActiveSession()
        isDetailCurrentlyStreaming = false
        syncDetailStreamButtonUi()
        mapView.stopLoop()
        super.onPause()
    }

    override fun onDestroy() {
        uiHandler.removeCallbacksAndMessages(null)
        topicInspector.shutdown()
        lanScanner.cancelScan()
        hwBridge.stop()
        mapView.stopLoop()
        rosManager.shutdown()
        simEngine.stop()
        fileIoExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveFullscreen()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveFullscreen() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
    }

    private fun hideSoftKeyboard() {
        currentFocus?.let { v ->
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(v.windowToken, 0)
            v.clearFocus()
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::settingsModal.isInitialized && settingsModal.isOpen) {
            setSettingsModalOpen(false)
            return
        }
        if (layerPopoverOpen) {
            setLayerPopoverVisible(false)
            return
        }
        if (drawerOpen) {
            if (activeTabIndex == TAB_TOPICS && topicDetailPage.visibility == View.VISIBLE) {
                exitTopicDetailToList()
                return
            }
            setDrawerOpenState(false)
            return
        }
        if (simEngine.hasActivePreviewPin()) {
            simEngine.clearPreviewPin()
            refreshCommandDockUi()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBackMs < 1800L) {
            super.onBackPressed()
        } else {
            lastBackMs = now
            AnimHelper.showDjiToast(toastBanner, "再按一次返回键退出地面站", d)
        }
    }

    // ==================== 全栈实时换肤与空间防碰撞协调器 ====================

    private fun applyActiveThemeLive(animate: Boolean) {
        val pal = GcsTheme.of(hub.themeId)
        GcsTheme.applyTree(cockpitRoot, pal, d)
        settingsModal.applyModalThemeColors()

        tabGliderBar.background = roundedColor(pal.accent, dp(2f))
        toastBanner.setTextColor(pal.textPrimary)
        toastBanner.background = GradientDrawable().apply {
            setColor(pal.modalCardFill)
            cornerRadius = dp(6f).toFloat()
            setStroke(dp(1f), pal.secondaryAccent)
        }

        commandDock.background = GradientDrawable().apply {
            setColor(pal.glassPopoverFill)
            cornerRadius = dp(9f).toFloat()
            setStroke(dp(1f), pal.accentStroke)
        }

        btnBrake.background = pillBg(
            Color.argb(if (pal.isLight) 42 else 78, 255, 59, 48),
            Color.parseColor("#FF3B30")
        )
        btnBrake.setTextColor(Color.parseColor(if (pal.isLight) "#D32F2F" else "#FF6961"))
        btnBrake.invalidate()

        if (!rthConfirmPending) styleRthDefault()
        styleDemoScenePill()
        syncPatrolPillUi()
        syncTopQuickSlotsVisual()
        syncMenuButtonVisual()
        syncSettingsGearVisual()
        syncCameraControlLabels()
        syncLayerPopoverControls()
        syncTabHeaderColors()
        syncConnModeSectionsUi(showRosEditor = hub.isRosMode || rosSectionInConn.visibility == View.VISIBLE)
        syncProtoInputsVisibility()
        syncDemoSceneSegButtons()
        syncMissionStrategyButtons()
        refreshWaypointOrchestratorList()
        if (cachedTopicEntries.isNotEmpty()) renderFilteredTopicRows()

        lastBatDangerLevel = -1
        lastClearanceWarnLevel = -1
        lastHudThemeId = -1
        hsiView.invalidate()
        compassView.invalidate()
        attitudeHudView.invalidate()

        if (animate) {
            AnimHelper.animateThemeCrossfade(
                listOf(topBarView, topCenterStack, leftSafetyRail, bottomLeftCluster, rightCamStack, attitudeHudView, drawerRoot, layerQuickPopover)
            )
        }
    }

    private fun styleRthDefault() {
        val pal = GcsTheme.of(hub.themeId)
        btnRth.setTextColor(if (pal.isLight) Color.rgb(185, 102, 0) else Color.WHITE)
        GcsIcons.bind(btnRth, Type.HOME_RTH, "返航起点", d, iconDp = 12f)
        btnRth.background = pillBg(Color.argb(if (pal.isLight) 38 else 48, 255, 171, 0), Color.parseColor("#FFAB00"))
        btnRth.invalidate()
    }

    private fun styleDemoScenePill() {
        if (!::btnDemoScene.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        btnDemoScene.setTextColor(pal.textPrimary)
        btnDemoScene.background = pillBg(pal.glassFill, pal.accentStroke)
        btnDemoScene.invalidate()
    }

    private fun syncTabHeaderColors() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in tabBtns.indices) {
            tabBtns[i].setTextColor(if (i == activeTabIndex) pal.textPrimary else pal.textMuted)
            tabBtns[i].invalidate()
        }
    }

    private fun normalDrawerWidthPx(): Int {
        val w = resources.displayMetrics.widthPixels
        return min(dp(336f), (w * 0.50f).roundToInt())
    }

    private fun wideDrawerWidthPx(): Int {
        val w = resources.displayMetrics.widthPixels
        return min(dp(456f), (w * 0.70f).roundToInt())
    }

    private fun currentDrawerWidthPx(): Int =
        if (drawerWideMode && activeTabIndex == TAB_TOPICS && topicDetailPage.visibility == View.VISIBLE) {
            wideDrawerWidthPx()
        } else {
            normalDrawerWidthPx()
        }

    /**
     * 计算抽屉展开时左侧剩余地图可视区的精确中心偏移，保证顶部航向堆栈既不碰左安全栏也不碰右抽屉
     */
    private fun computeOpenMapCenterOffsetPx(drawerWidthPx: Int): Float {
        val totalW = cockpitRoot.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val leftSafeEdge = (leftSafetyRail.right.takeIf { it > 0 } ?: dp(96f)) + dp(8f)
        val rightDrawerEdge = totalW - drawerWidthPx - dp(14f)
        val targetCenter = ((leftSafeEdge + rightDrawerEdge) * 0.5f)
            .coerceIn(leftSafeEdge + dp(94f).toFloat(), (totalW * 0.5f))
        return targetCenter - totalW * 0.5f
    }

    /**
     * 底部与侧翼组件防重叠协调器：
     * - 展开抽屉时自动收起底部中央指令坞 (避免与抽屉或左仪表碰撞)，并在宽屏终端或超窄屏下自动避让左下数字框；
     * - 抽屉关闭且底部指令坞弹出时，在宽度 < 780dp 的屏幕上平滑避让左下数字框，保留左侧 HSI 球 + 中央指令坞 + 右侧姿态视窗三段式无碰撞对称排布。
     */
    private fun syncBottomHudAvoidance() {
        if (!::hdTelemetryBox.isInitialized || !::attitudeHudView.isInitialized || !::commandDock.isInitialized) return
        val totalW = cockpitRoot.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val drawerLeftEdge = totalW - currentDrawerWidthPx() - dp(12f)
        val bottomClusterRightApprox = dp(264f)

        val hideTelemetryForDock = (!drawerOpen && dockLogicalActive && screenWidthDp < 780f)
        val hideTelemetryForDrawer = (drawerOpen && drawerLeftEdge < bottomClusterRightApprox + dp(10f))
        val shouldHideTelemetry = hideTelemetryForDock || hideTelemetryForDrawer

        if (shouldHideTelemetry) {
            if (hdTelemetryBox.visibility == View.VISIBLE) {
                hdTelemetryBox.animate().cancel()
                hdTelemetryBox.animate()
                    .alpha(0f)
                    .setDuration(130L)
                    .withEndAction {
                        if (hdTelemetryBox.alpha < 0.05f) hdTelemetryBox.visibility = View.INVISIBLE
                    }
                    .start()
            }
        } else {
            if (hdTelemetryBox.visibility != View.VISIBLE || hdTelemetryBox.alpha < 0.95f) {
                hdTelemetryBox.animate().cancel()
                hdTelemetryBox.visibility = View.VISIBLE
                hdTelemetryBox.animate()
                    .alpha(1f)
                    .setDuration(160L)
                    .start()
            }
        }

        val hideAttitudeForPopover = (layerPopoverOpen && screenHeightDp < 395f)
        if (!drawerOpen) {
            if (hideAttitudeForPopover) {
                attitudeHudView.animate().cancel()
                attitudeHudView.animate()
                    .alpha(0f)
                    .setDuration(130L)
                    .withEndAction {
                        if (layerPopoverOpen) attitudeHudView.visibility = View.INVISIBLE
                    }
                    .start()
            } else if (attitudeHudView.visibility != View.VISIBLE || attitudeHudView.alpha < 0.95f) {
                attitudeHudView.animate().cancel()
                attitudeHudView.visibility = View.VISIBLE
                attitudeHudView.translationX = 0f
                attitudeHudView.animate()
                    .alpha(1f)
                    .setDuration(170L)
                    .start()
            }
        }
    }

    // ==================== 四级互斥菜单状态机 ====================

    private fun setSettingsModalOpen(open: Boolean, jumpCategory: Int? = null) {
        hideSoftKeyboard()
        if (open) {
            if (layerPopoverOpen) setLayerPopoverVisible(false)
            if (drawerOpen) setDrawerOpenState(false)
        }
        settingsModal.setVisible(open, jumpCategory)
        syncSettingsGearVisual()
        AnimHelper.animateGearRotation(btnSettingsToggle, open)
    }

    private fun syncSettingsGearVisual() {
        if (!::btnSettingsToggle.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        val active = ::settingsModal.isInitialized && settingsModal.isOpen
        btnSettingsToggle.setImageDrawable(
            GcsIcons.drawable(
                Type.SETTINGS_GEAR,
                dp(13.5f),
                if (active) pal.accentBright else pal.textPrimary
            )
        )
        btnSettingsToggle.background = if (active) {
            pillBg(pal.accentSoftFill, pal.accent)
        } else {
            glassBg(dp(6f))
        }
    }

    private fun toggleOrJumpDrawerTab(targetTab: Int) {
        hideSoftKeyboard()
        if (::settingsModal.isInitialized && settingsModal.isOpen) {
            setSettingsModalOpen(false)
        }
        if (layerPopoverOpen) {
            setLayerPopoverVisible(false)
        }
        if (!drawerOpen) {
            switchTab(targetTab, animatePanel = false)
            setDrawerOpenState(true)
        } else if (activeTabIndex == targetTab) {
            setDrawerOpenState(false)
        } else {
            switchTab(targetTab, animatePanel = true)
        }
    }

    private fun setDrawerOpenState(open: Boolean) {
        if (drawerOpen == open) return
        drawerOpen = open
        hideSoftKeyboard()
        if (open) {
            if (layerPopoverOpen) setLayerPopoverVisible(false)
            if (::settingsModal.isInitialized && settingsModal.isOpen) setSettingsModalOpen(false)
        }
        val prevWidthPx = drawerRoot.layoutParams.width
        if (!open) {
            topicInspector.stopActiveSession()
            isDetailCurrentlyStreaming = false
            syncDetailStreamButtonUi()
            if (drawerWideMode) {
                setWideTerminalMode(false, applyImmediately = true)
            }
        } else if (activeTabIndex == TAB_ORCHESTRATE) {
            refreshWaypointOrchestratorList()
        }
        syncMenuButtonVisual()

        val activeW = currentDrawerWidthPx()
        val animW = maxOf(activeW, prevWidthPx).toFloat()
        val centerShiftPx = computeOpenMapCenterOffsetPx(activeW)
        val activePanel = tabPanels.getOrNull(activeTabIndex)

        AnimHelper.animateDrawer(
            drawer = drawerRoot,
            rightEdgeViews = listOf(rightCamStack, attitudeHudView),
            centerShiftViews = listOf(topCenterStack),
            open = drawerOpen,
            drawerWidthPx = animW,
            centerOffsetPx = centerShiftPx,
            activePanelForCascade = activePanel,
            density = d
        )
        refreshCommandDockUi()
        syncBottomHudAvoidance()
    }

    private fun syncMenuButtonVisual() {
        if (!::btnMenuToggle.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        if (drawerOpen) {
            btnMenuToggle.setTextColor(pal.accentBright)
            GcsIcons.bind(btnMenuToggle, Type.CLOSE_X, "收起", d, iconDp = 11.5f, gapDp = 3.5f)
            btnMenuToggle.background = pillBg(pal.accentSoftFill, pal.accent)
        } else {
            btnMenuToggle.setTextColor(pal.textPrimary)
            GcsIcons.bind(btnMenuToggle, Type.MENU_BARS, "菜单", d, iconDp = 11.5f, gapDp = 3.5f)
            btnMenuToggle.background = glassBg(dp(6f))
        }
        btnMenuToggle.invalidate()
        syncTopQuickSlotsVisual()
    }

    private fun syncTopQuickSlotsVisual() {
        val pal = GcsTheme.of(hub.themeId)
        quickPillMission?.let { pill ->
            val onOrch = drawerOpen && activeTabIndex == TAB_ORCHESTRATE
            pill.setTextColor(if (pal.isLight) Color.rgb(180, 98, 0) else Color.parseColor("#FFD54F"))
            pill.background = pillBg(
                if (onOrch) Color.argb(85, 255, 171, 0) else Color.argb(if (pal.isLight) 26 else 36, 255, 171, 0),
                if (onOrch) Color.parseColor("#FFAB00") else Color.argb(130, 255, 171, 0)
            )
            pill.invalidate()
        }
        quickPillTopics?.let { pill ->
            val onTopics = drawerOpen && activeTabIndex == TAB_TOPICS
            pill.setTextColor(if (pal.isLight) pal.accent else Color.parseColor("#64FFDA"))
            pill.background = pillBg(
                if (onTopics) pal.accentSoftFill else Color.argb(if (pal.isLight) 22 else 38, 0, 200, 235),
                if (onTopics) pal.accent else Color.argb(125, 0, 190, 230)
            )
            pill.invalidate()
        }
    }

    private fun setWideTerminalMode(wide: Boolean, applyImmediately: Boolean = true) {
        drawerWideMode = wide
        if (::btnWideTerminal.isInitialized) {
            val pal = GcsTheme.of(hub.themeId)
            btnWideTerminal.setTextColor(if (wide) pal.accentBright else pal.textPrimary)
            GcsIcons.bind(
                btnWideTerminal,
                if (wide) Type.COLLAPSE_WIDTH else Type.EXPAND_WIDTH,
                if (wide) "标准" else "宽屏",
                d,
                iconDp = 11f
            )
            btnWideTerminal.background = if (wide) {
                pillBg(pal.accentSoftFill, pal.accent)
            } else {
                glassBg(dp(6f))
            }
        }
        if (applyImmediately) {
            val newW = currentDrawerWidthPx()
            val lp = drawerRoot.layoutParams as FrameLayout.LayoutParams
            lp.width = newW
            drawerRoot.layoutParams = lp
            drawerRoot.post { syncMeasuredTabGlider(animate = false) }
            if (drawerOpen) {
                topCenterStack.translationX = computeOpenMapCenterOffsetPx(newW)
            }
            syncBottomHudAvoidance()
        }
    }

    /**
     * 基于实际测量的标签按钮坐标精确对齐底部高亮滑块，彻底消除硬编码宽度带来的偏移错位
     */
    private fun syncMeasuredTabGlider(animate: Boolean) {
        if (!::tabGlider.isInitialized || activeTabIndex !in tabBtns.indices) return
        val targetBtn = tabBtns[activeTabIndex]
        val btnW = targetBtn.width
        if (btnW <= 0) return

        val gLp = tabGlider.layoutParams as FrameLayout.LayoutParams
        if (gLp.width != btnW) {
            gLp.width = btnW
            tabGlider.layoutParams = gLp
        }
        val barW = (btnW * 0.58f).roundToInt().coerceAtLeast(dp(18f))
        val bLp = tabGliderBar.layoutParams as FrameLayout.LayoutParams
        if (bLp.width != barW) {
            bLp.width = barW
            tabGliderBar.layoutParams = bLp
        }

        val targetX = targetBtn.left.toFloat()
        if (animate) {
            AnimHelper.animateTabSwitch(tabGlider, targetX, tabPanels, activeTabIndex, d)
        } else {
            tabGlider.translationX = targetX
        }
    }

    private fun switchTab(idx: Int, animatePanel: Boolean = true) {
        hideSoftKeyboard()
        if (activeTabIndex == TAB_TOPICS && idx != TAB_TOPICS) {
            topicInspector.stopActiveSession()
            isDetailCurrentlyStreaming = false
            syncDetailStreamButtonUi()
            if (drawerWideMode) setWideTerminalMode(false, applyImmediately = true)
        }
        activeTabIndex = idx
        val curW = currentDrawerWidthPx()
        if (drawerRoot.layoutParams.width != curW) {
            val lp = drawerRoot.layoutParams as FrameLayout.LayoutParams
            lp.width = curW
            drawerRoot.layoutParams = lp
        }
        syncTabHeaderColors()

        val targetBtn = tabBtns.getOrNull(idx)
        if (animatePanel && targetBtn != null && targetBtn.width > 0) {
            syncMeasuredTabGlider(animate = true)
        } else {
            for (i in tabPanels.indices) {
                tabPanels[i].visibility = if (i == idx) View.VISIBLE else View.GONE
                tabPanels[i].alpha = 1f
                tabPanels[i].translationY = 0f
            }
            tabRowRef.post { syncMeasuredTabGlider(animate = false) }
        }
        syncMenuButtonVisual()

        when (idx) {
            TAB_TOPICS -> if (cachedTopicEntries.isEmpty()) refreshRosTopicList()
            TAB_ORCHESTRATE -> refreshWaypointOrchestratorList()
            TAB_CONN -> syncConnModeSectionsUi(showRosEditor = hub.isRosMode || rosSectionInConn.visibility == View.VISIBLE)
        }
    }

    private fun setLayerPopoverVisible(show: Boolean) {
        if (layerPopoverOpen == show) return
        layerPopoverOpen = show
        if (show) {
            if (drawerOpen) setDrawerOpenState(false)
            if (::settingsModal.isInitialized && settingsModal.isOpen) setSettingsModalOpen(false)
        }
        val pal = GcsTheme.of(hub.themeId)
        btnLayerPopupToggle.setTextColor(pal.textPrimary)
        btnLayerPopupToggle.background = camPillBg(show)
        GcsIcons.bind(
            btnLayerPopupToggle,
            Type.LAYERS,
            "图层",
            d,
            iconDp = 11.5f,
            gapDp = 3f,
            trailing = if (show) Type.CHEVRON_UP else Type.CHEVRON_DOWN,
            trailDp = 9f
        )
        if (show) syncLayerPopoverControls()
        AnimHelper.animatePopover(layerQuickPopover, show, d)
        syncBottomHudAvoidance()
    }

    // ==================== 膨胀透视与相机标签同步 ====================

    private fun setXrayOcclusionState(enabled: Boolean, showToast: Boolean = true) {
        hub.xrayOcclusionEnabled = enabled
        GcsSettingsModal.persistAllSettings(this, hub)
        syncCameraControlLabels()
        if (!enabled && lastOccludedHudState) {
            updateOcclusionHudVisibility(false)
        }
        if (showToast) {
            AnimHelper.showDjiToast(
                toastBanner,
                if (enabled) "视线遮挡透视已开启：挡视野体素半透明化" else "已切换为实心膨胀体素模式",
                d
            )
        }
    }

    private fun syncCameraControlLabels() {
        val pal = GcsTheme.of(hub.themeId)
        val is3D = mapView.is3DMode
        btn3DRef.setTextColor(pal.textPrimary)
        GcsIcons.bind(btn3DRef, Type.CUBE_3D, if (is3D) "3D视图" else "2D俯视", d, iconDp = 11.5f, gapDp = 3f)
        btn3DRef.background = camPillBg(is3D)

        val fMode = mapView.followMode
        val followTxt = when (fMode) {
            2 -> "追尾"
            0 -> "漫游"
            else -> "环视"
        }
        btnFollowRef.setTextColor(pal.textPrimary)
        GcsIcons.bind(btnFollowRef, Type.COMPASS_AIM, followTxt, d, iconDp = 11.5f, gapDp = 3f)
        btnFollowRef.background = camPillBg(fMode != 0)
        recenterBanner.visibility = if (fMode == 0) View.VISIBLE else View.GONE
        recenterBanner.setTextColor(pal.accentBright)
        recenterBanner.background = pillBg(pal.glassPopoverFill, pal.accent)

        val xrayOn = hub.xrayOcclusionEnabled
        btnXrayRef.setTextColor(pal.textPrimary)
        GcsIcons.bind(
            btnXrayRef,
            if (xrayOn) Type.XRAY_EYE else Type.XRAY_OFF,
            if (xrayOn) "透视" else "实景",
            d,
            iconDp = 11.5f,
            gapDp = 3f
        )
        btnXrayRef.background = camPillBg(xrayOn)
    }

    private fun syncLayerPopoverControls() {
        val pal = GcsTheme.of(hub.themeId)
        if (colorSegBtns.size == 3) {
            for (i in 0..2) {
                val sel = (hub.pointColorMode == i)
                colorSegBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
                colorSegBtns[i].background = roundedColor(
                    if (sel) pal.accent else Color.TRANSPARENT,
                    dp(5f)
                )
            }
        }
        if (::popSwitchInflate.isInitialized) {
            styleMiniChip(popSwitchInflate, "膨胀体素", hub.showInflate)
            styleMiniChip(popSwitchCloud, "激光点云", hub.showFastLioMap)
            styleMiniChip(popSwitchBox, "局部8m框", hub.showLocalBox)
            styleMiniChip(popSwitchCtrl, "控制点", hub.showCtrlPts)
        }
    }

    private fun styleMiniChip(tv: TextView, label: String, active: Boolean) {
        val pal = GcsTheme.of(hub.themeId)
        tv.setTextColor(if (active) pal.textPrimary else pal.textMuted)
        GcsIcons.bind(tv, if (active) Type.CHECK else null, label, d, iconDp = 10.5f, gapDp = 3f)
        tv.background = pillBg(
            if (active) pal.accentSoftFill else pal.wellFill,
            if (active) pal.accent else pal.cardStroke
        )
        tv.invalidate()
    }

    private fun updateOcclusionHudVisibility(occluded: Boolean) {
        if (occluded == lastOccludedHudState) return
        lastOccludedHudState = occluded
        val pal = GcsTheme.of(hub.themeId)
        occlusionBadge.setTextColor(if (pal.isLight) pal.accent else Color.parseColor("#64FFDA"))
        occlusionBadge.background = pillBg(pal.glassPopoverFill, pal.accent)

        occlusionBadge.animate().cancel()
        if (occluded) {
            occlusionBadge.visibility = View.VISIBLE
            occlusionBadge.alpha = 0f
            occlusionBadge.translationY = -dp(4f).toFloat()
            occlusionBadge.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(180L)
                .setInterpolator(AnimHelper.EASE_OUT_EXPO)
                .start()
        } else {
            occlusionBadge.animate()
                .alpha(0f)
                .translationY(-dp(3f).toFloat())
                .setDuration(165L)
                .withEndAction {
                    if (!lastOccludedHudState) {
                        occlusionBadge.visibility = View.GONE
                    }
                }
                .start()
        }
    }

    private fun syncPatrolPillUi() {
        val pal = GcsTheme.of(hub.themeId)
        btnPatrol.setTextColor(if (hub.autoPatrol) pal.secondaryAccent else pal.textMuted)
        GcsIcons.bind(
            btnPatrol,
            if (hub.autoPatrol) Type.PLAY else Type.PAUSE,
            if (hub.autoPatrol) "巡航: 开" else "巡航: 关",
            d,
            iconDp = 11f
        )
        btnPatrol.background = pillBg(
            if (hub.autoPatrol) Color.argb(if (pal.isLight) 36 else 48, Color.red(pal.secondaryAccent), Color.green(pal.secondaryAccent), Color.blue(pal.secondaryAccent)) else pal.glassFill,
            if (hub.autoPatrol) pal.secondaryAccent else pal.glassStroke
        )
        btnPatrol.invalidate()
    }

    private fun syncModeSpecificControls(force: Boolean = false) {
        val rosNow = hub.isRosMode
        if (!force && rosNow == lastIsRosModeUi) return
        lastIsRosModeUi = rosNow
        demoControlGroup.visibility = if (!rosNow) View.VISIBLE else View.GONE
    }

    private fun refreshCommandDockUi(latestPin: EgoSimEngine.PinInspectResult? = null, pulseDock: Boolean = false) {
        val pal = GcsTheme.of(hub.themeId)
        val snap = hub.latestSnapshot
        val hasPin = latestPin != null || simEngine.hasActivePreviewPin()
        val (routeCnt, isStaged, arcLen) = simEngine.routeStatusSummary()

        // 侧边抽屉展开期间不在地图底部重复叠加悬浮指令坞，避免与抽屉或左仪表发生挤压
        if (drawerOpen) {
            dockLogicalActive = false
            AnimHelper.animateCommandDock(commandDock, show = false, density = d)
            syncBottomHudAvoidance()
            return
        }

        if (hasPin) {
            dockLogicalActive = true
            val px = latestPin?.x ?: snap.previewX
            val py = latestPin?.y ?: snap.previewY
            val pz = latestPin?.z ?: hub.goalZ
            val dist = latestPin?.distFromUav ?: hypot(hypot(px - snap.uavX, py - snap.uavY), pz - snap.uavZ)
            val clr = latestPin?.clearance ?: snap.previewClearance
            val safe = latestPin?.isSafe ?: snap.previewSafe

            dockPinRow.visibility = View.VISIBLE
            dockRouteRow.visibility = View.GONE
            AnimHelper.animateCommandDock(commandDock, show = true, density = d, pulseOnUpdate = pulseDock)
            syncBottomHudAvoidance()

            setTextIfChanged(tvDockAltVal, String.format(Locale.US, "高 %.1fm", pz))
            if (safe) {
                tvDockHeader.setTextColor(pal.accentBright)
                val routeHint = if (isStaged && routeCnt > 0) " · 航线$routeCnt" else ""
                GcsIcons.bind(
                    tvDockHeader,
                    Type.TARGET_PIN,
                    String.format(Locale.US, "(%.1f, %.1f) 距%.1fm 净空%.1fm%s", px, py, dist, clr, routeHint),
                    d,
                    iconDp = 11.5f
                )
                btnDockFlyNow.alpha = 1.0f
            } else {
                tvDockHeader.setTextColor(Color.parseColor("#FF5252"))
                GcsIcons.bind(
                    tvDockHeader,
                    Type.WARNING,
                    String.format(Locale.US, "贴近障碍 (净空 %.2fm) · 请重选或调高", clr),
                    d,
                    iconDp = 11.5f
                )
                btnDockFlyNow.alpha = if (hub.isRosMode) 0.9f else 0.45f
            }
            return
        }

        if (routeCnt > 0) {
            dockLogicalActive = true
            dockPinRow.visibility = View.GONE
            dockRouteRow.visibility = View.VISIBLE
            AnimHelper.animateCommandDock(commandDock, show = true, density = d, pulseOnUpdate = pulseDock)
            syncBottomHudAvoidance()

            val loopTag = when (hub.routeLoopMode) {
                1 -> " · 循环"
                2 -> " · 往返"
                else -> ""
            }
            if (isStaged) {
                tvDockHeader.setTextColor(if (pal.isLight) Color.rgb(185, 102, 0) else Color.parseColor("#FFD54F"))
                GcsIcons.bind(
                    tvDockHeader,
                    Type.ROUTE_NODES,
                    String.format(Locale.US, "待飞航线：%d 站 · %.1fm%s", routeCnt, arcLen, loopTag),
                    d,
                    iconDp = 11.5f
                )
                btnDockStartRoute.visibility = View.VISIBLE
                GcsIcons.bind(btnDockStartRoute, Type.PLAY, "启动($routeCnt)", d, iconDp = 11f)
                GcsIcons.bind(btnDockClearRoute, Type.TRASH, "清空", d, iconDp = 11f)
            } else {
                tvDockHeader.setTextColor(pal.secondaryAccent)
                GcsIcons.bind(
                    tvDockHeader,
                    Type.SEND_FLY,
                    "航线执行中 · 剩余 $routeCnt 站$loopTag",
                    d,
                    iconDp = 11.5f
                )
                btnDockStartRoute.visibility = View.GONE
                GcsIcons.bind(btnDockClearRoute, Type.STOP_SQUARE, "终止", d, iconDp = 11f)
            }
            return
        }

        dockLogicalActive = false
        AnimHelper.animateCommandDock(commandDock, show = false, density = d)
        syncBottomHudAvoidance()
    }

    private fun adjustTargetAltitudeByStep(sign: Float) {
        val delta = sign * hub.altStepMeters
        val (_, pinInfo) = simEngine.nudgeGoalZ(delta)
        GcsSettingsModal.persistAllSettings(this, hub)
        mapView.triggerPinSpringAnim()
        refreshCommandDockUi(pinInfo, pulseDock = true)
    }

    private fun handleRthButtonTap() {
        if (hub.rthDoubleConfirm && !rthConfirmPending) {
            rthConfirmPending = true
            AnimHelper.triggerHaptic(btnRth)
            btnRth.setTextColor(Color.WHITE)
            GcsIcons.bind(btnRth, Type.WARNING, "再点返航", d, iconDp = 11.5f)
            btnRth.background = pillBg(Color.argb(175, 255, 145, 0), Color.parseColor("#FFD54F"))
            AnimHelper.showDjiToast(toastBanner, "防误触保护：2.5 秒内再次点击确认避障返航 H", d)
            uiHandler.removeCallbacks(resetRthConfirmRunnable)
            uiHandler.postDelayed(resetRthConfirmRunnable, 2500L)
            return
        }

        uiHandler.removeCallbacks(resetRthConfirmRunnable)
        resetRthConfirmRunnable.run()
        AnimHelper.triggerHaptic(btnRth, HapticFeedbackConstants.LONG_PRESS)

        val rth = simEngine.triggerReturnToHome()
        syncPatrolPillUi()
        refreshCommandDockUi()
        refreshWaypointOrchestratorList()
        mapView.spawnRipple(rth[0], rth[1])
        rosManager.publishGoal(rth[0], rth[1], rth[2], rth[3], rth[4])
        AnimHelper.showDjiToast(toastBanner, String.format(Locale.US, "一键返航：正在飞回起飞点 H (%.1f, %.1f)", rth[0], rth[1]), d)
    }

    private fun handleClearMapTap() {
        if (!clearMapConfirmPending) {
            clearMapConfirmPending = true
            AnimHelper.triggerHaptic(btnClearMapInPopover)
            btnClearMapInPopover.setTextColor(Color.WHITE)
            GcsIcons.bind(btnClearMapInPopover, Type.WARNING, "再点清图", d, iconDp = 11.5f)
            btnClearMapInPopover.background = pillBg(Color.argb(165, 255, 59, 48), Color.parseColor("#FF6961"))
            AnimHelper.showDjiToast(toastBanner, "2.5 秒内再次点击确认清空点云建图", d)
            uiHandler.removeCallbacks(resetClearMapConfirmRunnable)
            uiHandler.postDelayed(resetClearMapConfirmRunnable, 2500L)
            return
        }
        uiHandler.removeCallbacks(resetClearMapConfirmRunnable)
        resetClearMapConfirmRunnable.run()
        AnimHelper.triggerHaptic(btnClearMapInPopover, HapticFeedbackConstants.LONG_PRESS)
        simEngine.clearVoxelMap()
        setLayerPopoverVisible(false)
        AnimHelper.showDjiToast(toastBanner, "已清空全局 FAST-LIO 点云地图", d)
    }

    private fun executeEmergencyHover(viewForHaptic: View) {
        uiHandler.removeCallbacks(resetRthConfirmRunnable)
        resetRthConfirmRunnable.run()
        AnimHelper.triggerHaptic(viewForHaptic, HapticFeedbackConstants.LONG_PRESS)

        simEngine.triggerEmergencyHover()
        syncPatrolPillUi()
        refreshCommandDockUi()
        refreshWaypointOrchestratorList()
        val s = hub.latestSnapshot
        mapView.spawnRipple(s.uavX, s.uavY)
        rosManager.publishGoal(s.uavX, s.uavY, s.uavZ, s.uavX, s.uavY)
        AnimHelper.showDjiToast(toastBanner, "紧急制动：已清空待飞路线并下发原地悬停", d)
    }

    // ==================== 五区无重叠主座舱装配 ====================

    private fun buildNativeDjiCockpit(): View {
        cockpitRoot = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }

        mapView = GlPointCloudMapView(
            context = this,
            hub = hub,
            voxelMap = simEngine.voxelMap,
            onHudTick = { snap -> updateHudReadouts(snap) },
            onInterceptDrawerClose = {
                when {
                    ::settingsModal.isInitialized && settingsModal.isOpen -> {
                        setSettingsModalOpen(false)
                        true
                    }
                    layerPopoverOpen -> {
                        setLayerPopoverVisible(false)
                        true
                    }
                    drawerOpen -> {
                        setDrawerOpenState(false)
                        true
                    }
                    else -> false
                }
            },
            onSingleTapPreviewPin = { wx, wy ->
                val wasAlreadyVisible = commandDock.visibility == View.VISIBLE
                val info = simEngine.placePreviewPin(wx, wy)
                refreshCommandDockUi(info, pulseDock = wasAlreadyVisible)
            },
            onLongPressQuickFly = { wx, wy ->
                val dispatched = simEngine.confirmFlyImmediate(wx, wy)
                if (dispatched == null) {
                    AnimHelper.showDjiToast(toastBanner, "长按目标位于障碍物内部，已安全拦截", d)
                } else {
                    syncPatrolPillUi()
                    refreshCommandDockUi()
                    refreshWaypointOrchestratorList()
                    rosManager.publishGoal(dispatched[0], dispatched[1], dispatched[2], dispatched[3], dispatched[4])
                    AnimHelper.showDjiToast(
                        toastBanner,
                        String.format(Locale.US, "长按直飞 -> (%.1f, %.1f, %.1fm)", dispatched[0], dispatched[1], dispatched[2]),
                        d
                    )
                }
            },
            onFollowStateChanged = { _, toastMsg ->
                runOnUiThread {
                    syncCameraControlLabels()
                    if (toastMsg != null) {
                        AnimHelper.showDjiToast(toastBanner, toastMsg, d)
                    }
                }
            }
        )
        cockpitRoot.addView(mapView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // 顶部细长电量进度条 (0..2dp)
        val batTrack = FrameLayout(this).apply { setBackgroundColor(Color.argb(38, 128, 140, 160)) }
        topBatFill = View(this).apply { setBackgroundColor(Color.parseColor("#00E676")) }
        batTrack.addView(topBatFill, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.86f).roundToInt(), MATCH_PARENT))
        cockpitRoot.addView(batTrack, FrameLayout.LayoutParams(MATCH_PARENT, dp(2f), Gravity.TOP))

        // 1. 紧凑顶栏 (y = 2..38dp, 保证 640dp 横屏零溢出挤压)
        topBarView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8f), dp(2f), dp(8f), 0)
            GcsTheme.markRole(this, Role.TOP_GRADIENT_BAR)
        }

        tvModeBadge = TextView(this).apply {
            text = "OFFBOARD · ARMED"
            isSingleLine = true
            includeFontPadding = false
            gravity = Gravity.CENTER_VERTICAL
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6.5f), dp(4f), dp(6.5f), dp(4f))
            GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 5.5f)
        }
        topBarView.addView(tvModeBadge)

        val statusCapsule = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6.5f), dp(4f), dp(7f), dp(4f))
            GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 5.5f)
            setOnClickListener { toggleOrJumpDrawerTab(TAB_CONN) }
        }
        AnimHelper.attachSpringTouch(statusCapsule)
        statusAccent = View(this).apply { background = accentGreen }
        lastAppliedConnLevel = 0
        statusCapsule.addView(statusAccent, LinearLayout.LayoutParams(dp(3f), dp(11f)).apply { rightMargin = dp(5f) })
        tvConnStatus = TextView(this).apply {
            text = "仿真演练 | EXEC_TRAJ"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(if (screenWidthDp >= 720f) 152f else 122f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
        }
        statusCapsule.addView(tvConnStatus)
        topBarView.addView(statusCapsule, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(4.5f) })

        quickSlotsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = if (screenWidthDp >= 590f) View.VISIBLE else View.GONE
        }
        val mPill = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(7f), dp(4f), dp(7f), dp(4f))
            GcsIcons.bind(this, Type.ROUTE_NODES, "航线", d, iconDp = 11.5f, gapDp = 3f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                toggleOrJumpDrawerTab(TAB_ORCHESTRATE)
            }
        }
        AnimHelper.attachSpringTouch(mPill)
        quickPillMission = mPill
        quickSlotsContainer.addView(mPill, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(4.5f) })

        val tPill = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(7f), dp(4f), dp(7f), dp(4f))
            GcsIcons.bind(this, Type.RADAR_SIGNAL, "话题", d, iconDp = 11.5f, gapDp = 3f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                val willOpen = !(drawerOpen && activeTabIndex == TAB_TOPICS)
                toggleOrJumpDrawerTab(TAB_TOPICS)
                if (willOpen) refreshRosTopicList()
            }
        }
        AnimHelper.attachSpringTouch(tPill)
        quickPillTopics = tPill
        quickSlotsContainer.addView(tPill, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(4f) })
        topBarView.addView(quickSlotsContainer)

        topBarView.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val rightCluster = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6.5f), dp(4f), dp(6.5f), dp(4f))
            GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 5.5f)
            setOnClickListener { toggleOrJumpDrawerTab(TAB_STATUS) }
        }
        AnimHelper.attachSpringTouch(rightCluster)
        tvClearanceTop = monoLabel("避障1.4m", "#00E676", 9.8f)
        tvHzTop = monoLabel(" | 60fps | ", "#FFFFFF", 9.8f, Role.TEXT_SECONDARY).apply {
            visibility = if (screenWidthDp >= 650f) View.VISIBLE else View.GONE
        }
        tvBatTop = monoLabel("16.2V·12.6A | 控92%", "#00E676", 9.8f)
        rightCluster.addView(tvClearanceTop)
        rightCluster.addView(tvHzTop)
        rightCluster.addView(tvBatTop)
        topBarView.addView(rightCluster)

        btnMenuToggle = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(7.5f), dp(4f), dp(7.5f), dp(4f))
            GcsIcons.bind(this, Type.MENU_BARS, "菜单", d, iconDp = 11.5f, gapDp = 3.5f)
            setOnClickListener { setDrawerOpenState(!drawerOpen) }
        }
        AnimHelper.attachSpringTouch(btnMenuToggle)
        topBarView.addView(btnMenuToggle, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(4.5f) })

        btnSettingsToggle = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER
            contentDescription = "系统设置"
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                setSettingsModalOpen(!settingsModal.isOpen)
            }
        }
        AnimHelper.attachSpringTouch(btnSettingsToggle)
        topBarView.addView(btnSettingsToggle, LinearLayout.LayoutParams(dp(28f), dp(26f)).apply { leftMargin = dp(4f) })

        cockpitRoot.addView(topBarView, FrameLayout.LayoutParams(MATCH_PARENT, dp(36f), Gravity.TOP))

        // 2. 顶部居中统一流式堆栈 (航向罗盘 + 回中提示 + 遮挡透视提示 + Toast，垂直流式排布绝不互叠)
        topCenterStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        compassView = DjiCompassTapeView(this, hub).apply {
            GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 6.5f)
        }
        topCenterStack.addView(compassView, LinearLayout.LayoutParams(dp(184f), dp(24f)))

        recenterBanner = TextView(this).apply {
            visibility = View.GONE
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(236f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9.5f), dp(3.5f), dp(9.5f), dp(3.5f))
            GcsIcons.bind(this, Type.COMPASS_AIM, "视角已漫游 · 点击回中", d, iconDp = 11.5f, gapDp = 3.5f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                mapView.recenterLockDrone()
                syncCameraControlLabels()
            }
        }
        AnimHelper.attachSpringTouch(recenterBanner)
        topCenterStack.addView(recenterBanner, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            topMargin = dp(3f)
        })

        occlusionBadge = TextView(this).apply {
            visibility = View.GONE
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(248f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9f), dp(3f), dp(9f), dp(3f))
            GcsIcons.bind(this, Type.XRAY_EYE, "视线受阻 · 已开启体素透视", d, iconDp = 11f, gapDp = 3.5f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                setXrayOcclusionState(!hub.xrayOcclusionEnabled)
            }
        }
        AnimHelper.attachSpringTouch(occlusionBadge)
        topCenterStack.addView(occlusionBadge, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            topMargin = dp(3f)
        })

        toastBanner = TextView(this).apply {
            visibility = View.GONE
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(308f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10f), dp(4.5f), dp(10f), dp(4.5f))
        }
        topCenterStack.addView(toastBanner, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            topMargin = dp(4f)
        })

        cockpitRoot.addView(topCenterStack, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(40f)
        })

        // 3. 左侧飞行安全操控区 (紧凑 84dp 宽度，底部留足 90dp+ 净空)
        leftSafetyRail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        btnBrake = createActionPill(Type.BRAKE_HOLD, "紧急悬停", "#FF3B30", true).apply {
            setOnClickListener { executeEmergencyHover(it) }
        }
        leftSafetyRail.addView(btnBrake)

        btnRth = createActionPill(Type.HOME_RTH, "返航起点", "#FFAB00", true).apply {
            setOnClickListener { handleRthButtonTap() }
        }
        leftSafetyRail.addView(btnRth, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(5f) })

        demoControlGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        btnPatrol = createActionPill(Type.PLAY, "巡航: 开", "#00E676", true).apply {
            setOnClickListener {
                hub.autoPatrol = !hub.autoPatrol
                if (hub.autoPatrol) simEngine.clearPreviewPin()
                syncPatrolPillUi()
                refreshCommandDockUi()
                if (hub.autoPatrol) AnimHelper.showDjiToast(toastBanner, "已恢复仿真连续避障巡航", d)
            }
        }
        btnDemoScene = createActionPill(Type.CUBE_3D, "场景: 体素柱阵", "#69B7FF", false).apply {
            setOnClickListener {
                applyDemoSceneByIndex((sceneIdx + 1) % sceneCycle.size)
            }
        }
        demoControlGroup.addView(btnPatrol, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(5f) })
        demoControlGroup.addView(btnDemoScene, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(5f) })
        leftSafetyRail.addView(demoControlGroup)

        cockpitRoot.addView(leftSafetyRail, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            leftMargin = dp(10f)
            topMargin = dp(42f)
        })

        // 4. 左下角 HSI 避障球 (94x94dp) 与紧凑飞行仪表框
        bottomLeftCluster = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        hsiView = DjiHsiRadarView(this, hub).apply {
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                val msg = cycleMode()
                AnimHelper.showDjiToast(toastBanner, msg, d)
            }
        }
        AnimHelper.attachSpringTouch(hsiView)
        bottomLeftCluster.addView(hsiView, LinearLayout.LayoutParams(dp(94f), dp(94f)))

        hdTelemetryBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8.5f), dp(5.5f), dp(8.5f), dp(5.5f))
            GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 7.5f)
            setOnClickListener {
                mapView.recenterLockDrone()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, "已回中锁定无人机视角", d)
            }
        }
        AnimHelper.attachSpringTouch(hdTelemetryBox)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvOsdH = monoLabel("H 1.2m", "#FFFFFF", 13f, Role.TEXT_PRIMARY)
        tvOsdHs = monoLabel("  HS 0.0m/s", "#FFFFFF", 13f, Role.TEXT_PRIMARY)
        row1.addView(tvOsdH); row1.addView(tvOsdHs)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvOsdD = monoLabel("D 3.8m", "#FFFFFF", 13f, Role.TEXT_PRIMARY)
        tvOsdMapPts = monoLabel("  MAP 0", "#69B7FF", 11.2f, Role.TEXT_ACCENT)
        row2.addView(tvOsdD); row2.addView(tvOsdMapPts)

        tvOsdSubXyz = monoLabel("X -5.50  Y -4.20  YAW 37°", "#B8C0CC", 8.8f, Role.TEXT_MUTED).apply {
            setPadding(0, dp(2f), 0, 0)
        }
        hdTelemetryBox.addView(row1)
        hdTelemetryBox.addView(row2, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(2f) })
        hdTelemetryBox.addView(tvOsdSubXyz)
        bottomLeftCluster.addView(hdTelemetryBox, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })

        cockpitRoot.addView(bottomLeftCluster, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = dp(10f)
            bottomMargin = dp(8f)
        })

        // 5. 底部中央上下文选点/航线指令坞
        commandDock = buildContextualCommandDock()
        commandDock.visibility = View.GONE
        cockpitRoot.addView(commandDock, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(8f)
        })

        // 6. 右侧紧凑相机控制条 (y = 42..183dp, 绝不压盖下方 258..352dp 的三维姿态视窗)
        rightCamStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        btn3DRef = createCamPillBtn(Type.CUBE_3D, "3D视图", true).apply {
            setOnClickListener {
                val now3D = mapView.toggle3D2DWithAnimation()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, if (now3D) "已切换至 3D 透视地图" else "已切换至 2D 正射俯视地图", d)
            }
        }
        btnFollowRef = createCamPillBtn(Type.COMPASS_AIM, "环视", true).apply {
            setOnClickListener {
                val (_, tip) = mapView.cycleFollowMode()
                syncCameraControlLabels()
                AnimHelper.showDjiToast(toastBanner, tip, d)
            }
        }
        btnXrayRef = createCamPillBtn(Type.XRAY_EYE, "透视", hub.xrayOcclusionEnabled).apply {
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                setXrayOcclusionState(!hub.xrayOcclusionEnabled)
            }
        }
        btnLayerPopupToggle = createCamPillBtn(Type.LAYERS, "图层", false, trailing = Type.CHEVRON_DOWN).apply {
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                setLayerPopoverVisible(!layerPopoverOpen)
            }
        }

        val zoomPair = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 13f)
        }
        val btnZOut = TextView(this).apply {
            text = "-"
            includeFontPadding = false
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                mapView.zoomBy(0.80f)
            }
        }
        val btnZIn = TextView(this).apply {
            text = "+"
            includeFontPadding = false
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                mapView.zoomBy(1.25f)
            }
        }
        zoomPair.addView(btnZOut, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        zoomPair.addView(View(this).apply { GcsTheme.markRole(this, Role.DIVIDER) }, LinearLayout.LayoutParams(1, MATCH_PARENT))
        zoomPair.addView(btnZIn, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))

        val pillW = dp(66f)
        val pillH = dp(25.5f)
        rightCamStack.addView(btn3DRef, LinearLayout.LayoutParams(pillW, pillH))
        rightCamStack.addView(btnFollowRef, LinearLayout.LayoutParams(pillW, pillH).apply { topMargin = dp(4f) })
        rightCamStack.addView(btnXrayRef, LinearLayout.LayoutParams(pillW, pillH).apply { topMargin = dp(4f) })
        rightCamStack.addView(btnLayerPopupToggle, LinearLayout.LayoutParams(pillW, pillH).apply { topMargin = dp(4f) })
        rightCamStack.addView(zoomPair, LinearLayout.LayoutParams(pillW, dp(25f)).apply { topMargin = dp(4f) })

        cockpitRoot.addView(rightCamStack, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(10f)
            topMargin = dp(42f)
        })

        // 7. 右下角无人机三维实时姿态视窗 (124x94dp, 与左下 HSI 94x94dp 底边严丝合缝对称对齐)
        attitudeHudView = UavAttitudeHudView(this, hub).apply {
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                val tip = cycleInspectCamera()
                AnimHelper.showDjiToast(toastBanner, tip, d)
            }
        }
        AnimHelper.attachSpringTouch(attitudeHudView)
        cockpitRoot.addView(attitudeHudView, FrameLayout.LayoutParams(dp(124f), dp(94f), Gravity.BOTTOM or Gravity.END).apply {
            rightMargin = dp(10f)
            bottomMargin = dp(8f)
        })

        // 8. 紧凑图层浮窗
        layerQuickPopover = buildLayerQuickPopover()
        layerQuickPopover.visibility = View.GONE
        cockpitRoot.addView(layerQuickPopover, FrameLayout.LayoutParams(dp(212f), WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(82f)
            topMargin = dp(42f)
        })

        // 9. 右侧自适应滑出作业抽屉
        val drawerW = normalDrawerWidthPx()
        drawerRoot = buildSlideOverDrawer(drawerW)
        drawerRoot.visibility = View.INVISIBLE
        drawerRoot.translationX = (drawerW + dp(24f)).toFloat()
        cockpitRoot.addView(drawerRoot, FrameLayout.LayoutParams(drawerW, MATCH_PARENT, Gravity.END).apply {
            topMargin = dp(40f)
            rightMargin = dp(8f)
            bottomMargin = dp(8f)
        })

        // 10. 居中模态设置中心 (置于最顶层，遮罩覆盖全屏)
        val modalRoot = settingsModal.buildModalView()
        cockpitRoot.addView(modalRoot, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        return cockpitRoot
    }

    private fun buildLayerQuickPopover(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9f), dp(8f), dp(9f), dp(8f))
            GcsTheme.markRole(this, Role.GLASS_POPOVER, cornerDp = 9f)
            isClickable = true
        }

        card.addView(TextView(this).apply {
            text = "点云配色方案"
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(3.5f))
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        })

        val colorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val cNames = listOf("高程彩虹", "反射强度", "战术翠绿")
        colorSegBtns.clear()
        for (i in cNames.indices) {
            val b = TextView(this).apply {
                text = cNames[i]
                isSingleLine = true
                includeFontPadding = false
                gravity = Gravity.CENTER
                minimumHeight = dp(24f)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
                typeface = Typeface.DEFAULT_BOLD
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hub.pointColorMode = i
                    GcsSettingsModal.persistAllSettings(this@MainActivity, hub)
                    syncLayerPopoverControls()
                }
            }
            colorSegBtns.add(b)
            colorRow.addView(b, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        card.addView(colorRow)

        card.addView(TextView(this).apply {
            text = "地图图层显示"
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6f), 0, dp(3.5f))
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        })

        val g1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        popSwitchInflate = createPopoverToggleChip {
            hub.showInflate = !hub.showInflate
            GcsSettingsModal.persistAllSettings(this, hub)
            syncLayerPopoverControls()
        }
        popSwitchCloud = createPopoverToggleChip {
            hub.showFastLioMap = !hub.showFastLioMap
            GcsSettingsModal.persistAllSettings(this, hub)
            syncLayerPopoverControls()
        }
        g1.addView(popSwitchInflate, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        g1.addView(popSwitchCloud, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4.5f) })
        card.addView(g1)

        val g2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        popSwitchBox = createPopoverToggleChip {
            hub.showLocalBox = !hub.showLocalBox
            GcsSettingsModal.persistAllSettings(this, hub)
            syncLayerPopoverControls()
        }
        popSwitchCtrl = createPopoverToggleChip {
            hub.showCtrlPts = !hub.showCtrlPts
            GcsSettingsModal.persistAllSettings(this, hub)
            syncLayerPopoverControls()
        }
        g2.addView(popSwitchBox, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        g2.addView(popSwitchCtrl, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4.5f) })
        card.addView(g2, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4.5f) })

        val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnResetCam = createSmallIconBtn(Type.UNDO, "复位") {
            mapView.resetCameraSmooth()
            syncCameraControlLabels()
            setLayerPopoverVisible(false)
            AnimHelper.showDjiToast(toastBanner, "已复位默认三维跟随视角", d)
        }
        val btnClearTrail = createSmallIconBtn(Type.ERASER, "清轨迹") {
            simEngine.clearTrail()
            setLayerPopoverVisible(false)
            AnimHelper.showDjiToast(toastBanner, "已清空历史飞行航迹", d)
        }
        btnClearMapInPopover = createSmallIconBtn(Type.TRASH, "清建图") {
            handleClearMapTap()
        }
        actRow.addView(btnResetCam, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        actRow.addView(btnClearTrail, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.1f).apply { leftMargin = dp(4f) })
        actRow.addView(btnClearMapInPopover, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.1f).apply { leftMargin = dp(4f) })
        card.addView(actRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6f) })

        return card
    }

    private fun createPopoverToggleChip(onClick: () -> Unit): TextView = TextView(this).apply {
        gravity = Gravity.CENTER
        isSingleLine = true
        includeFontPadding = false
        minimumHeight = dp(25f)
        setPadding(dp(5f), dp(4f), dp(5f), dp(4f))
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
        typeface = Typeface.DEFAULT_BOLD
        setOnClickListener {
            AnimHelper.triggerHaptic(it)
            onClick()
        }
    }

    private fun buildContextualCommandDock(): LinearLayout {
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(9f), dp(6f), dp(9f), dp(6f))
            isClickable = true
        }

        tvDockHeader = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = dp(288f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(4f))
            GcsIcons.bind(this, Type.TARGET_PIN, "选点预览", d, iconDp = 11.5f)
        }
        dock.addView(tvDockHeader)

        dockPinRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        btnDockFlyNow = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            gravity = Gravity.CENTER
            minimumHeight = dp(27f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9f), dp(4.5f), dp(9f), dp(4.5f))
            background = roundedColor(Color.parseColor("#00B865"), dp(5.5f))
            GcsIcons.bind(this, Type.SEND_FLY, "立即飞往", d, iconDp = 11.5f, gapDp = 3.5f)
            setOnClickListener {
                val dispatched = simEngine.confirmFlyImmediate()
                if (dispatched == null) {
                    AnimHelper.triggerHaptic(it, HapticFeedbackConstants.LONG_PRESS)
                    AnimHelper.showDjiToast(toastBanner, "选点位于障碍物内部，请重选或调高高度", d)
                } else {
                    AnimHelper.triggerHaptic(it, HapticFeedbackConstants.LONG_PRESS)
                    syncPatrolPillUi()
                    refreshCommandDockUi()
                    refreshWaypointOrchestratorList()
                    rosManager.publishGoal(dispatched[0], dispatched[1], dispatched[2], dispatched[3], dispatched[4])
                    AnimHelper.showDjiToast(
                        toastBanner,
                        String.format(Locale.US, "已下发指点飞行 -> (%.1f, %.1f, %.1fm)", dispatched[0], dispatched[1], dispatched[2]),
                        d
                    )
                }
            }
        }
        AnimHelper.attachSpringTouch(btnDockFlyNow)

        val btnAddRoute = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            gravity = Gravity.CENTER
            minimumHeight = dp(27f)
            setTextColor(Color.rgb(215, 130, 0))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8f), dp(4.5f), dp(8f), dp(4.5f))
            background = pillBg(Color.argb(46, 255, 171, 0), Color.parseColor("#FFAB00"))
            GcsIcons.bind(this, Type.PLUS_NODE, "加航点", d, iconDp = 11.5f, gapDp = 3f)
            setOnClickListener {
                val (ok, total, _) = simEngine.appendPreviewPinToRoute()
                if (!ok) {
                    AnimHelper.showDjiToast(toastBanner, "选点位于障碍内部，无法加入航线", d)
                } else {
                    AnimHelper.triggerHaptic(it)
                    refreshCommandDockUi(pulseDock = true)
                    refreshWaypointOrchestratorList()
                    AnimHelper.showDjiToast(toastBanner, "已加入航点 #$total", d)
                }
            }
        }
        AnimHelper.attachSpringTouch(btnAddRoute)

        val altInline = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(27f)
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 5.5f)
        }
        val btnMinus = TextView(this).apply {
            text = "-"
            includeFontPadding = false
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(7.5f), dp(3.5f), dp(7.5f), dp(3.5f))
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                adjustTargetAltitudeByStep(-1f)
            }
        }
        tvDockAltVal = monoLabel(String.format(Locale.US, "高 %.1fm", hub.goalZ), "#69B7FF", 9.8f, Role.TEXT_ACCENT)
        val btnPlus = TextView(this).apply {
            text = "+"
            includeFontPadding = false
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(7.5f), dp(3.5f), dp(7.5f), dp(3.5f))
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                adjustTargetAltitudeByStep(+1f)
            }
        }
        altInline.addView(btnMinus)
        altInline.addView(tvDockAltVal)
        altInline.addView(btnPlus)

        val btnCancelPin = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER
            setImageDrawable(GcsIcons.drawable(Type.CLOSE_X, dp(12.5f), Color.rgb(130, 145, 165)))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 5.5f)
            setOnClickListener {
                simEngine.clearPreviewPin()
                refreshCommandDockUi()
            }
        }

        dockPinRow.addView(btnDockFlyNow)
        dockPinRow.addView(btnAddRoute, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(5f) })
        dockPinRow.addView(altInline, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(5f) })
        dockPinRow.addView(btnCancelPin, LinearLayout.LayoutParams(dp(27f), dp(27f)).apply { leftMargin = dp(5f) })
        dock.addView(dockPinRow)

        dockRouteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }

        btnDockStartRoute = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            gravity = Gravity.CENTER
            minimumHeight = dp(27f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9.5f), dp(4.5f), dp(9.5f), dp(4.5f))
            background = roundedColor(Color.parseColor("#00B865"), dp(5.5f))
            GcsIcons.bind(this, Type.PLAY, "启动航线", d, iconDp = 11f)
            setOnClickListener {
                startCommittedRouteExecution(it)
            }
        }
        AnimHelper.attachSpringTouch(btnDockStartRoute)

        btnDockOpenOrchestrate = createSmallIconBtn(Type.ROUTE_NODES, "航点") {
            if (!drawerOpen || activeTabIndex != TAB_ORCHESTRATE) {
                toggleOrJumpDrawerTab(TAB_ORCHESTRATE)
            }
        }

        btnDockUndo = createSmallIconBtn(Type.UNDO, "撤点") {
            val (rem, _, _) = simEngine.undoLastWaypoint()
            refreshCommandDockUi(pulseDock = true)
            refreshWaypointOrchestratorList()
            AnimHelper.showDjiToast(toastBanner, "已撤销末尾航点，剩余 $rem 站", d)
        }

        btnDockClearRoute = createSmallIconBtn(Type.TRASH, "清空") {
            val (_, isStaged, _) = simEngine.routeStatusSummary()
            if (isStaged) {
                simEngine.clearWaypointQueue()
                refreshCommandDockUi()
                refreshWaypointOrchestratorList()
                AnimHelper.showDjiToast(toastBanner, "已清空待执行航线", d)
            } else {
                executeEmergencyHover(btnDockClearRoute)
            }
        }

        dockRouteRow.addView(btnDockStartRoute, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(5f) })
        dockRouteRow.addView(btnDockOpenOrchestrate, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(5f) })
        dockRouteRow.addView(btnDockUndo)
        dockRouteRow.addView(btnDockClearRoute, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(5f) })
        dock.addView(dockRouteRow)

        return dock
    }

    private fun startCommittedRouteExecution(sourceView: View) {
        val committed = simEngine.commitStagedRoute()
        if (committed != null) {
            val (firstGoal, totalPts) = committed
            AnimHelper.triggerHaptic(sourceView, HapticFeedbackConstants.LONG_PRESS)
            mapView.recenterLockDrone()
            syncCameraControlLabels()
            syncPatrolPillUi()
            refreshCommandDockUi(pulseDock = true)
            refreshWaypointOrchestratorList()
            mapView.spawnRipple(firstGoal[0], firstGoal[1])
            rosManager.publishGoal(firstGoal[0], firstGoal[1], firstGoal[2], firstGoal[3], firstGoal[4])
            val modeLabel = when (hub.routeLoopMode) {
                1 -> "闭合循环"
                2 -> "往返巡航"
                else -> "单次推进"
            }
            AnimHelper.showDjiToast(toastBanner, "航线已启动：共 $totalPts 站 ($modeLabel)", d)
        }
    }

    // ==================== 四标签主作业抽屉 (连接 | 航线 | 话题 | 状态) ====================

    private fun buildSlideOverDrawer(drawerWidthPx: Int): LinearLayout {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            GcsTheme.markRole(this, Role.GLASS_DRAWER, cornerDp = 11f)
            isClickable = true
            isFocusable = true
        }

        val tabBarWrap = FrameLayout(this).apply {
            GcsTheme.markRole(this, Role.MODAL_HEADER)
        }
        tabRowRef = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tabDefs = listOf(
            Type.LINK to "连接",
            Type.ROUTE_NODES to "航线",
            Type.RADAR_SIGNAL to "话题",
            Type.TELEMETRY_PULSE to "状态"
        )

        tabBtns.clear()
        for (i in tabDefs.indices) {
            val (ic, title) = tabDefs[i]
            val tb = TextView(this).apply {
                gravity = Gravity.CENTER
                isSingleLine = true
                includeFontPadding = false
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.6f)
                typeface = Typeface.DEFAULT_BOLD
                GcsIcons.bind(this, ic, title, d, iconDp = 12f, gapDp = 3.5f)
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    switchTab(i)
                }
            }
            tabBtns.add(tb)
            tabRowRef.addView(tb, LinearLayout.LayoutParams(0, dp(35f), 1f))
        }

        val btnCloseDrawer = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER
            setImageDrawable(GcsIcons.drawable(Type.CLOSE_X, dp(13.5f), Color.rgb(140, 155, 175)))
            setPadding(dp(8f), 0, dp(9f), 0)
            setOnClickListener { setDrawerOpenState(false) }
        }
        tabRowRef.addView(btnCloseDrawer, LinearLayout.LayoutParams(dp(32f), dp(35f)))
        tabBarWrap.addView(tabRowRef, FrameLayout.LayoutParams(MATCH_PARENT, dp(35f)))

        val initSlotW = ((drawerWidthPx - dp(32f)) / TAB_COUNT.toFloat()).roundToInt().coerceAtLeast(dp(40f))
        tabGlider = FrameLayout(this).apply {
            tabGliderBar = View(this@MainActivity).apply {
                background = roundedColor(Color.parseColor("#1890FF"), dp(2f))
            }
            addView(tabGliderBar, FrameLayout.LayoutParams((initSlotW * 0.58f).roundToInt(), dp(2.5f), Gravity.CENTER))
        }
        tabBarWrap.addView(tabGlider, FrameLayout.LayoutParams(initSlotW, dp(3f), Gravity.BOTTOM or Gravity.START))

        tabRowRef.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            syncMeasuredTabGlider(animate = false)
        }

        container.addView(tabBarWrap, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        container.addView(View(this).apply { GcsTheme.markRole(this, Role.DIVIDER) }, LinearLayout.LayoutParams(MATCH_PARENT, 1))

        val bodyHost = FrameLayout(this)
        val pConn = buildConnPanel()
        val pOrchestrate = buildOrchestrationPanel()
        val pTopics = buildTopicInspectorPanel()
        val pStatus = buildTelemetryPanel()
        pOrchestrate.visibility = View.GONE
        pTopics.visibility = View.GONE
        pStatus.visibility = View.GONE

        tabPanels.clear()
        tabPanels.addAll(listOf(pConn, pOrchestrate, pTopics, pStatus))
        bodyHost.addView(pConn)
        bodyHost.addView(pOrchestrate)
        bodyHost.addView(pTopics)
        bodyHost.addView(pStatus)
        container.addView(bodyHost, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        return container
    }

    // ==================== Tab 0: 连接与工作模式面板 ====================

    private fun buildConnPanel(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), dp(9f), dp(10f), dp(10f))
        }

        val modeSegBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2.5f), dp(2.5f), dp(2.5f), dp(2.5f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 7f)
        }
        segModeDemoBtn = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(29f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            GcsIcons.bind(this, Type.CUBE_3D, "内置仿真演练", d, iconDp = 12f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                if (hub.isRosMode) {
                    topicInspector.stopActiveSession()
                    rosManager.switchToDemoMode()
                    simEngine.clearVoxelMap()
                    simEngine.clearWaypointQueue()
                    simEngine.requestReplanAsync()
                    cachedTopicEntries = emptyList()
                    syncModeSpecificControls(force = true)
                    refreshCommandDockUi()
                    refreshWaypointOrchestratorList()
                    AnimHelper.showDjiToast(toastBanner, "已切换回三维膨胀体素仿真演练", d)
                }
                syncConnModeSectionsUi(showRosEditor = false)
            }
        }
        segModeRosBtn = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(29f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            GcsIcons.bind(this, Type.DRONE_QUAD, "实机 ROS1 联飞", d, iconDp = 12.5f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                syncConnModeSectionsUi(showRosEditor = true)
            }
        }
        modeSegBar.addView(segModeDemoBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        modeSegBar.addView(segModeRosBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        col.addView(modeSegBar)

        demoSectionInConn = sectionCard("内置三维膨胀体素仿真环境").apply {
            val desc = TextView(this@MainActivity).apply {
                text = "当前运行本地三维避障与激光点云建图引擎，可切换测试障碍场景或接入真机："
                includeFontPadding = false
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
                setPadding(0, 0, 0, dp(6.5f))
                GcsTheme.markRole(this, Role.TEXT_MUTED)
            }
            addView(desc)

            val sceneRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            demoSceneSegBtns.clear()
            for (i in sceneCycle.indices) {
                val sb = TextView(this@MainActivity).apply {
                    text = sceneCycle[i].second
                    isSingleLine = true
                    includeFontPadding = false
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                    minimumHeight = dp(28f)
                    setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
                    setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
                    typeface = Typeface.DEFAULT_BOLD
                    setOnClickListener {
                        AnimHelper.triggerHaptic(it)
                        applyDemoSceneByIndex(i)
                    }
                }
                demoSceneSegBtns.add(sb)
                sceneRow.addView(sb, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                    if (i > 0) leftMargin = dp(4f)
                })
            }
            addView(sceneRow)

            val jumpScanBtn = TextView(this@MainActivity).apply {
                gravity = Gravity.CENTER
                isSingleLine = true
                includeFontPadding = false
                minimumHeight = dp(30f)
                setPadding(dp(8f), dp(5f), dp(8f), dp(5f))
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
                typeface = Typeface.DEFAULT_BOLD
                GcsTheme.markRole(this, Role.TEXT_ACCENT)
                background = pillBg(Color.argb(42, 24, 144, 255), Color.argb(115, 24, 144, 255))
                GcsIcons.bind(this, Type.SEARCH, "接入真机 · 扫描局域网无人机", d, iconDp = 11.5f, trailing = Type.CHEVRON_RIGHT)
                setOnClickListener {
                    syncConnModeSectionsUi(showRosEditor = true)
                    triggerLanScan(silentIfEmpty = false, autoOpenConnTabOnEmpty = false)
                }
            }
            AnimHelper.attachSpringTouch(jumpScanBtn)
            addView(jumpScanBtn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })
        }
        col.addView(demoSectionInConn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        rosSectionInConn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        val scanCard = sectionCard("1. 局域网自动寻机 (探测 11311 / 9090)")
        val scanOptRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnDrawerScan = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(30f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedColor(Color.parseColor("#00B865"), dp(6f))
            GcsIcons.bind(this, Type.SEARCH, "扫描局域网飞机", d, iconDp = 12f)
            setOnClickListener { triggerLanScan(silentIfEmpty = false, autoOpenConnTabOnEmpty = false) }
        }
        AnimHelper.attachSpringTouch(btnDrawerScan)

        val btnOpenLinkPrefs = createSmallIconBtn(Type.SETTINGS_GEAR, "链路设置") {
            setSettingsModalOpen(true, jumpCategory = GcsSettingsModal.CAT_COMMS)
        }
        scanOptRow.addView(btnDrawerScan, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.35f))
        scanOptRow.addView(btnOpenLinkPrefs, LinearLayout.LayoutParams(0, WRAP_CONTENT, 0.85f).apply { leftMargin = dp(5f) })
        scanCard.addView(scanOptRow)

        tvScanStatus = TextView(this).apply {
            text = "支持同一 Wi-Fi / 机载 Ubuntu 热点 (10.42.0.1) 自动探测"
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.4f)
            setPadding(0, dp(5f), 0, dp(2f))
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        }
        scanCard.addView(tvScanStatus)

        discoveredListContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scanCard.addView(discoveredListContainer)
        rosSectionInConn.addView(scanCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        val cfg = rosManager.topics
        val directCard = sectionCard("2. 手动地址直连")
        val protoSeg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        segProtoTcpBtn = TextView(this).apply {
            text = "原生 TCPROS (:11311)"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            minimumHeight = dp(26f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener {
                rosManager.topics.protocol = "tcpros"
                syncProtoInputsVisibility()
            }
        }
        segProtoWsBtn = TextView(this).apply {
            text = "rosbridge (:9090)"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            minimumHeight = dp(26f)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener {
                rosManager.topics.protocol = "rosbridge"
                syncProtoInputsVisibility()
            }
        }
        protoSeg.addView(segProtoTcpBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        protoSeg.addView(segProtoWsBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        directCard.addView(protoSeg)

        wrapMasterUri = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inpMasterUri = labeledInput(wrapMasterUri, "机载 ROS_MASTER_URI", cfg.masterUri)
        directCard.addView(wrapMasterUri)

        wrapWsUrl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inpWsUrl = labeledInput(wrapWsUrl, "机载 rosbridge WebSocket 地址", cfg.wsUrl)
        directCard.addView(wrapWsUrl)

        val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnConn = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(31f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedColor(Color.parseColor("#1890FF"), dp(6f))
            GcsIcons.bind(this, Type.LINK, "立即连接机载 ROS1", d, iconDp = 12f)
            setOnClickListener {
                hideSoftKeyboard()
                saveCurrentTopics(quiet = true)
                connectWithConfig(rosManager.topics)
            }
        }
        AnimHelper.attachSpringTouch(btnConn)
        val btnDisc = createSmallIconBtn(null, "断开") {
            topicInspector.stopActiveSession()
            rosManager.disconnectAll(silent = false)
            AnimHelper.showDjiToast(toastBanner, "已断开机载 ROS1 连接", d)
        }
        actRow.addView(btnConn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        actRow.addView(btnDisc, LinearLayout.LayoutParams(dp(60f), WRAP_CONTENT).apply { leftMargin = dp(6f) })
        directCard.addView(actRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(7f) })
        rosSectionInConn.addView(directCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        val topicCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9f), dp(7.5f), dp(9f), dp(7.5f))
            GcsTheme.markRole(this, Role.SECTION_CARD, cornerDp = 8f)
        }
        btnExpandTopicMap = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(2f), 0, dp(2f))
            GcsTheme.markRole(this, Role.TEXT_ACCENT)
            GcsIcons.bind(this, Type.SLIDERS, "高级话题映射配置", d, iconDp = 11.5f, trailing = Type.CHEVRON_DOWN)
            setOnClickListener {
                topicMapExpanded = !topicMapExpanded
                topicMapAccordionBody.visibility = if (topicMapExpanded) View.VISIBLE else View.GONE
                if (topicMapExpanded) AnimHelper.animateStaggeredChildren(topicMapAccordionBody, d)
                GcsIcons.bind(
                    btnExpandTopicMap,
                    Type.SLIDERS,
                    if (topicMapExpanded) "高级话题映射配置 (点击收起)" else "高级话题映射配置",
                    d,
                    iconDp = 11.5f,
                    trailing = if (topicMapExpanded) Type.CHEVRON_UP else Type.CHEVRON_DOWN
                )
            }
        }
        topicCard.addView(btnExpandTopicMap)

        topicMapAccordionBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(6f), 0, 0)
        }
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow.addView(createSmallIconBtn(null, "FAST-LIO") {
            applyNamedTopicPreset("fastlio", quiet = false)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        presetRow.addView(createSmallIconBtn(null, "VINS") {
            applyNamedTopicPreset("vins", quiet = false)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4f) })
        presetRow.addView(createSmallIconBtn(null, "Swarm_0") {
            applyNamedTopicPreset("swarm0", quiet = false)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4f) })
        topicMapAccordionBody.addView(presetRow)

        inpOdom = labeledInput(topicMapAccordionBody, "里程计位姿 (/Odometry)", cfg.odomTopic)
        inpInflate = labeledInput(topicMapAccordionBody, "三维膨胀地图 (/grid_map/occupancy_inflate)", cfg.inflateTopic)
        inpFastLioCloud = labeledInput(topicMapAccordionBody, "激光点云 (/cloud_registered)", cfg.fastLioCloudTopic)
        inpOptimal = labeledInput(topicMapAccordionBody, "局部轨迹 (/ego_planner_node/optimal_list)", cfg.optimalTopic)
        inpFastLioPath = labeledInput(topicMapAccordionBody, "全局轨迹 (/path)", cfg.fastLioPathTopic)
        inpGoal = labeledInput(topicMapAccordionBody, "目标发布 (/move_base_simple/goal)", cfg.goalTopic)

        val saveAndCopyRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        saveAndCopyRow.addView(createSmallIconBtn(Type.DOWNLOAD, "保存映射") {
            hideSoftKeyboard()
            saveCurrentTopics(quiet = false)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        saveAndCopyRow.addView(createSmallIconBtn(Type.COPY, "复制稀疏YAML") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("fastlio_yaml", "publish:\n  path_en: true\n  scan_publish_en: true\n  dense_publish_en: false"))
            AnimHelper.showDjiToast(toastBanner, "已复制 FAST-LIO 稀疏点云配置", d)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.15f).apply { leftMargin = dp(5f) })
        topicMapAccordionBody.addView(saveAndCopyRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(7f) })

        topicCard.addView(topicMapAccordionBody)
        rosSectionInConn.addView(topicCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        col.addView(rosSectionInConn)
        syncProtoInputsVisibility()
        syncDemoSceneSegButtons()

        sv.addView(col)
        return sv
    }

    private fun applyNamedTopicPreset(presetKey: String, quiet: Boolean) {
        when (presetKey) {
            "fastlio" -> {
                inpOdom.setText("/Odometry")
                inpFastLioCloud.setText("/cloud_registered")
                inpFastLioPath.setText("/path")
                inpInflate.setText("/grid_map/occupancy_inflate")
                inpOptimal.setText("/ego_planner_node/optimal_list")
                inpGoal.setText("/move_base_simple/goal")
            }
            "vins" -> {
                inpOdom.setText("/vins_estimator/imu_propagate")
                inpFastLioCloud.setText("")
                inpFastLioPath.setText("")
                inpInflate.setText("/grid_map/occupancy_inflate")
                inpOptimal.setText("/ego_planner_node/optimal_list")
                inpGoal.setText("/move_base_simple/goal")
            }
            "swarm0" -> {
                inpOdom.setText("/Odometry")
                inpFastLioCloud.setText("/cloud_registered")
                inpFastLioPath.setText("/path")
                inpInflate.setText("/drone_0_ego_planner_node/grid_map/occupancy_inflate")
                inpOptimal.setText("/drone_0_ego_planner_node/optimal_list")
                inpGoal.setText("/move_base_simple/goal")
            }
        }
        saveCurrentTopics(quiet = quiet)
    }

    private fun applyDemoSceneByIndex(newIdx: Int) {
        sceneIdx = newIdx
        val pair = sceneCycle[sceneIdx]
        simEngine.setScenePreset(pair.first)
        GcsIcons.bind(btnDemoScene, Type.CUBE_3D, "场景: ${pair.second}", d, iconDp = 11f)
        syncDemoSceneSegButtons()
        refreshCommandDockUi()
        refreshWaypointOrchestratorList()
        AnimHelper.showDjiToast(toastBanner, "已切换仿真场景: ${pair.second}", d)
    }

    private fun syncDemoSceneSegButtons() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in demoSceneSegBtns.indices) {
            val active = (i == sceneIdx)
            demoSceneSegBtns[i].setTextColor(if (active) pal.textPrimary else pal.textMuted)
            demoSceneSegBtns[i].background = pillBg(
                if (active) pal.accentSoftFill else pal.wellFill,
                if (active) pal.accent else pal.cardStroke
            )
        }
    }

    private fun syncConnModeSectionsUi(showRosEditor: Boolean) {
        if (!::segModeDemoBtn.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        val changed = (rosSectionInConn.visibility == View.VISIBLE) != showRosEditor
        demoSectionInConn.visibility = if (showRosEditor) View.GONE else View.VISIBLE
        rosSectionInConn.visibility = if (showRosEditor) View.VISIBLE else View.GONE
        if (changed && drawerOpen) {
            AnimHelper.animateStaggeredChildren(if (showRosEditor) rosSectionInConn else demoSectionInConn, d)
        }

        segModeDemoBtn.setTextColor(if (!showRosEditor) Color.WHITE else pal.textMuted)
        segModeDemoBtn.background = roundedColor(
            if (!showRosEditor) Color.parseColor("#00B865") else Color.TRANSPARENT,
            dp(5.5f)
        )
        segModeDemoBtn.invalidate()

        segModeRosBtn.setTextColor(if (showRosEditor) Color.WHITE else pal.textMuted)
        segModeRosBtn.background = roundedColor(
            if (showRosEditor) pal.accent else Color.TRANSPARENT,
            dp(5.5f)
        )
        segModeRosBtn.invalidate()
    }

    private fun syncProtoInputsVisibility() {
        if (!::segProtoTcpBtn.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        val isTcp = rosManager.topics.protocol == "tcpros"
        wrapMasterUri.visibility = if (isTcp) View.VISIBLE else View.GONE
        wrapWsUrl.visibility = if (isTcp) View.GONE else View.VISIBLE

        segProtoTcpBtn.setTextColor(if (isTcp) Color.WHITE else pal.textMuted)
        segProtoTcpBtn.background = roundedColor(if (isTcp) pal.accent else Color.TRANSPARENT, dp(5f))
        segProtoWsBtn.setTextColor(if (!isTcp) Color.WHITE else pal.textMuted)
        segProtoWsBtn.background = roundedColor(if (!isTcp) pal.accent else Color.TRANSPARENT, dp(5f))
    }

    // ==================== Tab 1: 纯粹专注的航线任务编排面板 ====================

    private fun buildOrchestrationPanel(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), dp(9f), dp(10f), dp(10f))
        }

        val tplCard = sectionCard("智能几何航线模板 (自动避让三维膨胀障碍)")
        val tplRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tplRow1.addView(createSmallIconBtn(Type.GRID_2X2, "矩形巡检") {
            val (cnt, len) = simEngine.generateMissionTemplate("rect")
            refreshCommandDockUi(pulseDock = true)
            refreshWaypointOrchestratorList()
            AnimHelper.showDjiToast(toastBanner, String.format(Locale.US, "已生成矩形巡检航线：%d 站 (%.1fm)", cnt, len), d)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        tplRow1.addView(createSmallIconBtn(Type.ROUTE_NODES, "S型扫掠") {
            val (cnt, len) = simEngine.generateMissionTemplate("zigzag")
            refreshCommandDockUi(pulseDock = true)
            refreshWaypointOrchestratorList()
            AnimHelper.showDjiToast(toastBanner, String.format(Locale.US, "已生成 S 型扫掠航线：%d 站 (%.1fm)", cnt, len), d)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4.5f) })
        tplRow1.addView(createSmallIconBtn(Type.LOOP_CYCLE, "环绕巡检") {
            val (cnt, len) = simEngine.generateMissionTemplate("orbit")
            refreshCommandDockUi(pulseDock = true)
            refreshWaypointOrchestratorList()
            AnimHelper.showDjiToast(toastBanner, String.format(Locale.US, "已生成环绕巡检航线：%d 站 (%.1fm)", cnt, len), d)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4.5f) })
        tplCard.addView(tplRow1)

        val tplRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tplRow2.addView(createSmallIconBtn(Type.PLUS_NODE, "采集当前机位为航点") {
            val (_, total, _) = simEngine.appendCurrentUavAsWaypoint()
            refreshCommandDockUi(pulseDock = true)
            refreshWaypointOrchestratorList()
            AnimHelper.showDjiToast(toastBanner, "已采集当前机位为航点 #$total", d)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.35f))
        tplRow2.addView(createSmallIconBtn(Type.SLIDERS, "速度与高度设置") {
            setSettingsModalOpen(true, jumpCategory = GcsSettingsModal.CAT_CONTROL)
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(5f) })
        tplCard.addView(tplRow2, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(5.5f) })
        col.addView(tplCard)

        val strategyCard = sectionCard("航线循环与完航动作")
        val loopSeg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val loopNames = listOf("单次直达", "闭合循环", "往返巡航")
        loopModeSegBtns.clear()
        for (i in loopNames.indices) {
            val b = TextView(this).apply {
                text = loopNames[i]
                isSingleLine = true
                includeFontPadding = false
                gravity = Gravity.CENTER
                minimumHeight = dp(25f)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
                typeface = Typeface.DEFAULT_BOLD
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hub.routeLoopMode = i
                    GcsSettingsModal.persistAllSettings(this@MainActivity, hub)
                    syncMissionStrategyButtons()
                    refreshCommandDockUi()
                }
            }
            loopModeSegBtns.add(b)
            loopSeg.addView(b, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        strategyCard.addView(loopSeg)

        val finishSeg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        val finNames = listOf("完航末点悬停", "完航自动返航 H")
        finishActSegBtns.clear()
        for (i in finNames.indices) {
            val b = TextView(this).apply {
                text = finNames[i]
                isSingleLine = true
                includeFontPadding = false
                gravity = Gravity.CENTER
                minimumHeight = dp(25f)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
                typeface = Typeface.DEFAULT_BOLD
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hub.routeFinishAction = i
                    GcsSettingsModal.persistAllSettings(this@MainActivity, hub)
                    syncMissionStrategyButtons()
                }
            }
            finishActSegBtns.add(b)
            finishSeg.addView(b, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        strategyCard.addView(finishSeg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4.5f) })
        col.addView(strategyCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        val queueCard = sectionCard("航点序列队列 (点击航点平滑运镜预览)")
        val qTopBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tvWaypointQueueSummary = TextView(this).apply {
            text = "当前暂无航点"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        }
        val btnReverse = createSmallIconBtn(Type.SWAP_ORDER, "倒序") {
            if (simEngine.reverseOrchestratedWaypoints()) {
                refreshCommandDockUi(pulseDock = true)
                refreshWaypointOrchestratorList()
                AnimHelper.showDjiToast(toastBanner, "已倒置航点执行顺序", d)
            }
        }
        val btnClearAllWp = createSmallIconBtn(Type.TRASH, "清空") {
            simEngine.clearWaypointQueue()
            refreshCommandDockUi()
            refreshWaypointOrchestratorList()
            AnimHelper.showDjiToast(toastBanner, "已清空全部航点", d)
        }
        qTopBar.addView(tvWaypointQueueSummary, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        qTopBar.addView(btnReverse)
        qTopBar.addView(btnClearAllWp, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(4f) })
        queueCard.addView(qTopBar)

        waypointListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(5.5f), 0, dp(4f))
        }
        queueCard.addView(waypointListContainer)

        btnOrchPrimaryExecute = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(32f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.8f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedColor(Color.parseColor("#00B865"), dp(6f))
            GcsIcons.bind(this, Type.PLAY, "启动编排航线", d, iconDp = 11.5f)
            setOnClickListener {
                val (cnt, isStaged, _) = simEngine.routeStatusSummary()
                if (cnt <= 0) {
                    AnimHelper.showDjiToast(toastBanner, "请先在地图选点加入航线或点击上方模板", d)
                } else if (isStaged) {
                    startCommittedRouteExecution(it)
                    setDrawerOpenState(false)
                } else {
                    executeEmergencyHover(it)
                }
            }
        }
        AnimHelper.attachSpringTouch(btnOrchPrimaryExecute)
        queueCard.addView(btnOrchPrimaryExecute, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4f) })
        col.addView(queueCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        sv.addView(col)
        return sv
    }

    private fun syncMissionStrategyButtons() {
        val pal = GcsTheme.of(hub.themeId)
        for (i in loopModeSegBtns.indices) {
            val sel = (hub.routeLoopMode == i)
            loopModeSegBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
            loopModeSegBtns[i].background = roundedColor(
                if (sel) pal.accent else Color.TRANSPARENT,
                dp(5f)
            )
        }
        for (i in finishActSegBtns.indices) {
            val sel = (hub.routeFinishAction == i)
            finishActSegBtns[i].setTextColor(if (sel) Color.WHITE else pal.textMuted)
            finishActSegBtns[i].background = roundedColor(
                if (sel) Color.parseColor("#00B865") else Color.TRANSPARENT,
                dp(5f)
            )
        }
    }

    private fun refreshWaypointOrchestratorList() {
        if (!::waypointListContainer.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        waypointListContainer.removeAllViews()
        val (isStaged, nodes) = simEngine.snapshotOrchestratedWaypoints()
        val (_, _, arcLen) = simEngine.routeStatusSummary()

        if (nodes.isEmpty()) {
            setTextIfChanged(tvWaypointQueueSummary, "暂无航点 · 点地图加航点或选上方模板")
            btnOrchPrimaryExecute.alpha = 0.55f
            GcsIcons.bind(btnOrchPrimaryExecute, Type.PLAY, "暂无待执行航点", d, iconDp = 11.5f)
            btnOrchPrimaryExecute.background = roundedColor(Color.rgb(66, 78, 96), dp(6f))
            return
        }

        btnOrchPrimaryExecute.alpha = 1.0f
        if (isStaged) {
            setTextIfChanged(
                tvWaypointQueueSummary,
                String.format(Locale.US, "待飞 %d 站 · 总长 %.1fm", nodes.size, arcLen)
            )
            GcsIcons.bind(btnOrchPrimaryExecute, Type.PLAY, "启动编排航线 (${nodes.size}站)", d, iconDp = 11.5f)
            btnOrchPrimaryExecute.background = roundedColor(Color.parseColor("#00B865"), dp(6f))
        } else {
            setTextIfChanged(tvWaypointQueueSummary, "执行中 · 剩余 ${nodes.size} 站")
            GcsIcons.bind(btnOrchPrimaryExecute, Type.STOP_SQUARE, "终止航线并悬停", d, iconDp = 11.5f)
            btnOrchPrimaryExecute.background = roundedColor(Color.parseColor("#FF3B30"), dp(6f))
        }

        for (i in nodes.indices) {
            val wp = nodes[i]
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(7f), dp(5f), dp(7f), dp(5f))
                background = roundedColor(pal.wellFill, dp(6f))
            }

            val infoTv = TextView(this).apply {
                isSingleLine = true
                includeFontPadding = false
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (wp.isSafe) pal.textPrimary else Color.parseColor("#FF5252"))
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
                typeface = Typeface.MONOSPACE
                GcsIcons.bind(
                    this,
                    if (wp.isSafe) Type.STATUS_DOT else Type.WARNING,
                    String.format(Locale.US, "#%d (%.1f,%.1f) %.1fm", i + 1, wp.x, wp.y, wp.z),
                    d,
                    iconDp = 9.5f,
                    gapDp = 3.5f
                )
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    mapView.focusWorldPointSmooth(wp.x, wp.y)
                    syncCameraControlLabels()
                    AnimHelper.pulseViewSubtle(row)
                }
            }

            fun tinySquareIcon(ic: Type, enabled: Boolean, onTap: () -> Unit): ImageView = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER
                setImageDrawable(
                    GcsIcons.drawable(
                        ic,
                        dp(11f),
                        if (enabled) pal.textPrimary else pal.textHint
                    )
                )
                background = roundedColor(if (enabled) pal.cardFill else Color.TRANSPARENT, dp(4.5f))
                isEnabled = enabled
                setOnClickListener {
                    if (enabled) {
                        AnimHelper.triggerHaptic(it)
                        onTap()
                    }
                }
            }

            fun tinyTextStepBtn(lbl: String, onTap: () -> Unit): TextView = TextView(this).apply {
                text = lbl
                includeFontPadding = false
                gravity = Gravity.CENTER
                setTextColor(pal.accentBright)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
                typeface = Typeface.DEFAULT_BOLD
                background = roundedColor(pal.accentSoftFill, dp(4.5f))
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    onTap()
                }
            }

            val btnUp = tinySquareIcon(Type.ARROW_UP, i > 0) {
                if (simEngine.moveOrchestratedWaypoint(i, -1)) {
                    refreshCommandDockUi()
                    refreshWaypointOrchestratorList()
                }
            }
            val btnDown = tinySquareIcon(Type.ARROW_DOWN, i < nodes.lastIndex) {
                if (simEngine.moveOrchestratedWaypoint(i, +1)) {
                    refreshCommandDockUi()
                    refreshWaypointOrchestratorList()
                }
            }
            val btnZMinus = tinyTextStepBtn("-") {
                simEngine.nudgeOrchestratedWaypointZ(i, -hub.altStepMeters)
                refreshCommandDockUi()
                refreshWaypointOrchestratorList()
            }
            val btnZPlus = tinyTextStepBtn("+") {
                simEngine.nudgeOrchestratedWaypointZ(i, +hub.altStepMeters)
                refreshCommandDockUi()
                refreshWaypointOrchestratorList()
            }
            val btnDel = tinySquareIcon(Type.CLOSE_X, true) {
                simEngine.removeOrchestratedWaypointAt(i)
                refreshCommandDockUi()
                refreshWaypointOrchestratorList()
            }

            row.addView(infoTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(btnZMinus, LinearLayout.LayoutParams(dp(21f), dp(21f)).apply { leftMargin = dp(2.5f) })
            row.addView(btnZPlus, LinearLayout.LayoutParams(dp(21f), dp(21f)).apply { leftMargin = dp(2f) })
            row.addView(btnUp, LinearLayout.LayoutParams(dp(21f), dp(21f)).apply { leftMargin = dp(3f) })
            row.addView(btnDown, LinearLayout.LayoutParams(dp(21f), dp(21f)).apply { leftMargin = dp(2f) })
            row.addView(btnDel, LinearLayout.LayoutParams(dp(21f), dp(21f)).apply { leftMargin = dp(3f) })

            waypointListContainer.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                if (i > 0) topMargin = dp(4f)
            })
        }
    }

    private fun applyFlightParametersToEngine(inf: Float, vel: Float, acc: Float, gz: Float) {
        hub.obstaclesInflation = inf
        hub.maxVel = vel
        hub.maxAcc = acc
        val deltaZ = gz - hub.goalZ
        val (_, pinInfo) = simEngine.nudgeGoalZ(deltaZ)

        simEngine.requestReplanAsync()
        rosManager.setParamDebounced("/ego_planner_node/grid_map/obstacles_inflation", inf)
        rosManager.setParamDebounced("/ego_planner_node/manager/max_vel", vel)
        rosManager.setParamDebounced("/ego_planner_node/manager/max_acc", acc)
        refreshCommandDockUi(pinInfo)
    }

    // ==================== Tab 2: ROS1 话题监控 + 单次截取/持续读取 ====================

    private fun buildTopicInspectorPanel(): View {
        val host = FrameLayout(this)

        topicListPage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), dp(9f), dp(10f), dp(9f))
        }

        val topFilterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        inpTopicFilter = EditText(this).apply {
            hint = "过滤话题 (如 grid_map / mavros)..."
            setSingleLine(true)
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.MONOSPACE
            setPadding(dp(8f), dp(5f), dp(8f), dp(5f))
            GcsTheme.markRole(this, Role.INPUT_BOX, cornerDp = 6f)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    renderFilteredTopicRows()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        val btnRefreshTopics = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(30f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9f), dp(5f), dp(9f), dp(5f))
            background = roundedColor(Color.parseColor("#1890FF"), dp(6f))
            GcsIcons.bind(this, Type.REFRESH, "刷新", d, iconDp = 11.5f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                hideSoftKeyboard()
                refreshRosTopicList()
            }
        }
        AnimHelper.attachSpringTouch(btnRefreshTopics)

        topFilterRow.addView(inpTopicFilter, LinearLayout.LayoutParams(0, dp(30f), 1f))
        topFilterRow.addView(btnRefreshTopics, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(5f) })
        topicListPage.addView(topFilterRow)

        tvTopicSourceHint = TextView(this).apply {
            text = "点击话题可执行单次截取、持续读取或一键绑定通道"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.4f)
            setPadding(dp(2f), dp(4.5f), 0, dp(4.5f))
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        }
        topicListPage.addView(tvTopicSourceHint)

        val listScroll = ScrollView(this)
        topicItemsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listScroll.addView(topicItemsContainer)
        topicListPage.addView(listScroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        topicDetailPage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(10f), dp(8f), dp(10f), dp(9f))
        }

        val detailNavRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnBackList = createSmallIconBtn(Type.CHEVRON_LEFT, "列表") {
            exitTopicDetailToList()
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6f), 0, dp(5f), 0)
        }
        tvDetailTopicName = TextView(this).apply {
            text = "/grid_map/occupancy_inflate"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.MONOSPACE
            GcsTheme.markRole(this, Role.TEXT_PRIMARY)
        }
        tvDetailTopicType = TextView(this).apply {
            text = "sensor_msgs/PointCloud2"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 8.8f)
            typeface = Typeface.MONOSPACE
            GcsTheme.markRole(this, Role.TEXT_ACCENT)
        }
        titleCol.addView(tvDetailTopicName)
        titleCol.addView(tvDetailTopicType)

        btnWideTerminal = createSmallIconBtn(Type.EXPAND_WIDTH, "宽屏") {
            setWideTerminalMode(!drawerWideMode, applyImmediately = true)
        }
        val btnCopyEcho = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER
            setImageDrawable(GcsIcons.drawable(Type.COPY, dp(13f), Color.rgb(120, 160, 210)))
            GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 6f)
            setOnClickListener {
                AnimHelper.triggerHaptic(it)
                val entry = selectedTopicEntry
                val clipText = buildString {
                    append("Topic: ${entry?.name ?: tvDetailTopicName.text}\n")
                    append("Type: ${entry?.type ?: tvDetailTopicType.text}\n")
                    append("${tvDetailMetricsStrip.text}\n---\n")
                    append(tvDetailPayloadConsole.text)
                }
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ros_topic_echo", clipText))
                AnimHelper.showDjiToast(toastBanner, "已复制当前话题数据", d)
            }
        }
        AnimHelper.attachSpringTouch(btnCopyEcho)

        detailNavRow.addView(btnBackList)
        detailNavRow.addView(titleCol, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        detailNavRow.addView(btnWideTerminal)
        detailNavRow.addView(btnCopyEcho, LinearLayout.LayoutParams(dp(28f), dp(27f)).apply { leftMargin = dp(4f) })
        topicDetailPage.addView(detailNavRow)

        val actionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnOnce = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(30f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedColor(Color.parseColor("#1890FF"), dp(6f))
            GcsIcons.bind(this, Type.CAPTURE_FRAME, "截取一次", d, iconDp = 12f)
            setOnClickListener {
                val entry = selectedTopicEntry ?: return@setOnClickListener
                AnimHelper.triggerHaptic(it)
                isDetailCurrentlyStreaming = false
                syncDetailStreamButtonUi()
                topicInspector.captureOnce(entry.name, entry.type) { snap ->
                    runOnUiThread { applyTopicEchoSnapshot(snap) }
                }
            }
        }
        AnimHelper.attachSpringTouch(btnOnce)

        btnDetailStreamToggle = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            minimumHeight = dp(30f)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedColor(Color.parseColor("#00B865"), dp(6f))
            GcsIcons.bind(this, Type.PLAY, "持续读取", d, iconDp = 11.5f)
            setOnClickListener {
                val entry = selectedTopicEntry ?: return@setOnClickListener
                AnimHelper.triggerHaptic(it, HapticFeedbackConstants.LONG_PRESS)
                if (isDetailCurrentlyStreaming) {
                    topicInspector.stopActiveSession()
                    isDetailCurrentlyStreaming = false
                    syncDetailStreamButtonUi()
                    tvDetailStatusStrip.setTextColor(Color.rgb(215, 130, 0))
                    GcsIcons.bind(tvDetailStatusStrip, Type.PAUSE, "已暂停持续读取", d, iconDp = 11f)
                } else {
                    isDetailCurrentlyStreaming = true
                    syncDetailStreamButtonUi()
                    topicInspector.startContinuous(entry.name, entry.type) { snap ->
                        runOnUiThread { applyTopicEchoSnapshot(snap) }
                    }
                }
            }
        }
        AnimHelper.attachSpringTouch(btnDetailStreamToggle)

        actionBar.addView(btnOnce, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        actionBar.addView(btnDetailStreamToggle, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.1f).apply { leftMargin = dp(5f) })
        topicDetailPage.addView(actionBar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6f) })

        btnBindTopicChannel = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            minimumHeight = dp(27f)
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            visibility = View.GONE
            setTextColor(Color.rgb(215, 130, 0))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
            typeface = Typeface.DEFAULT_BOLD
            background = pillBg(Color.argb(42, 255, 171, 0), Color.argb(135, 255, 171, 0))
            GcsIcons.bind(this, Type.LINK, "绑定为地面站通道", d, iconDp = 11f)
            setOnClickListener {
                val entry = selectedTopicEntry ?: return@setOnClickListener
                AnimHelper.triggerHaptic(it)
                bindInspectedTopicToGcs(entry)
            }
        }
        AnimHelper.attachSpringTouch(btnBindTopicChannel)
        topicDetailPage.addView(btnBindTopicChannel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(5f) })

        val telemetryStripCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7.5f), dp(5f), dp(7.5f), dp(5f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 6f)
        }
        tvDetailStatusStrip = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(Color.parseColor("#00B865"))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.5f)
            typeface = Typeface.DEFAULT_BOLD
            GcsIcons.bind(this, Type.STATUS_DOT, "准备就绪", d, iconDp = 10.5f)
        }
        tvDetailMetricsStrip = monoLabel("频率: -- Hz  |  带宽: -- KB/s  |  已收: 0 帧", "#B8C6D8", 9.0f, Role.TEXT_MUTED).apply {
            setPadding(0, dp(2f), 0, 0)
        }
        telemetryStripCard.addView(tvDetailStatusStrip)
        telemetryStripCard.addView(tvDetailMetricsStrip)
        topicDetailPage.addView(telemetryStripCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(5f) })

        val consoleScroll = ScrollView(this).apply {
            setPadding(dp(8f), dp(7f), dp(8f), dp(7f))
            GcsTheme.markRole(this, Role.CONSOLE_BOX, cornerDp = 6.5f)
        }
        tvDetailPayloadConsole = TextView(this).apply {
            text = "# 尚未读取数据"
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
            typeface = Typeface.MONOSPACE
            setLineSpacing(dp(1.5f).toFloat(), 1.0f)
            setTextIsSelectable(true)
            GcsTheme.markRole(this, Role.TEXT_CONSOLE)
        }
        consoleScroll.addView(tvDetailPayloadConsole)
        topicDetailPage.addView(consoleScroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(5f) })

        host.addView(topicListPage, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        host.addView(topicDetailPage, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        return host
    }

    private fun updateSmartBindButtonForTopic(entry: RosTopicEntry) {
        val t = entry.type
        val n = entry.name.lowercase(Locale.US)
        val label: String? = when {
            t.contains("Odometry") -> "一键设为「里程计位姿」话题"
            t.contains("PointCloud2") && (n.contains("inflate") || n.contains("occupancy") || n.contains("grid")) ->
                "一键设为「EGO 三维膨胀地图」话题"
            t.contains("PointCloud2") ->
                "一键设为「FAST-LIO 激光点云」话题"
            t.contains("Marker") -> "一键设为「EGO 局部规划轨迹」话题"
            t.contains("Path") && n.contains("optimal") -> "一键设为「EGO 局部规划轨迹」话题"
            t.contains("Path") -> "一键设为「FAST-LIO 全局轨迹」话题"
            t.contains("PoseStamped") -> "一键设为「指点飞行目标发布」话题"
            else -> null
        }
        if (label != null) {
            GcsIcons.bind(btnBindTopicChannel, Type.LINK, label, d, iconDp = 11f)
            btnBindTopicChannel.visibility = View.VISIBLE
        } else {
            btnBindTopicChannel.visibility = View.GONE
        }
    }

    private fun bindInspectedTopicToGcs(entry: RosTopicEntry) {
        val t = entry.type
        val name = entry.name
        val roleDesc: String
        when {
            t.contains("Odometry") -> {
                inpOdom.setText(name)
                roleDesc = "里程计位姿"
            }
            t.contains("PointCloud2") -> {
                val curInf = inpInflate.text.toString().trim()
                val preferInflate = (name.contains("inflate", true) || name.contains("occupancy", true) || name.contains("grid", true))
                if (preferInflate && curInf != name) {
                    inpInflate.setText(name)
                    roleDesc = "EGO 三维膨胀体素地图"
                } else if (!preferInflate && inpFastLioCloud.text.toString().trim() != name) {
                    inpFastLioCloud.setText(name)
                    roleDesc = "FAST-LIO 世界系点云"
                } else if (curInf != name) {
                    inpInflate.setText(name)
                    roleDesc = "EGO 三维膨胀体素地图"
                } else {
                    inpFastLioCloud.setText(name)
                    roleDesc = "FAST-LIO 世界系点云"
                }
            }
            t.contains("Marker") || (t.contains("Path") && name.contains("optimal", true)) -> {
                inpOptimal.setText(name)
                roleDesc = "EGO 局部规划轨迹"
            }
            t.contains("Path") -> {
                inpFastLioPath.setText(name)
                roleDesc = "FAST-LIO 全局轨迹"
            }
            t.contains("PoseStamped") -> {
                inpGoal.setText(name)
                roleDesc = "指点目标发布"
            }
            else -> return
        }
        saveCurrentTopics(quiet = true)
        AnimHelper.showDjiToast(toastBanner, "已将 $name 设为「$roleDesc」", d)
    }

    private fun refreshRosTopicList() {
        if (!::tvTopicSourceHint.isInitialized) return
        GcsIcons.bind(tvTopicSourceHint, Type.REFRESH, "正在查询活跃 ROS1 话题...", d, iconDp = 10.5f)
        topicInspector.fetchTopicsAsync { list, hint ->
            runOnUiThread {
                cachedTopicEntries = list
                GcsIcons.bind(tvTopicSourceHint, Type.RADAR_SIGNAL, "$hint · 点击进入监控", d, iconDp = 10.5f)
                renderFilteredTopicRows()
                AnimHelper.animateStaggeredChildren(topicItemsContainer, d)
            }
        }
    }

    private fun renderFilteredTopicRows() {
        if (!::topicItemsContainer.isInitialized) return
        val pal = GcsTheme.of(hub.themeId)
        topicItemsContainer.removeAllViews()
        val kw = inpTopicFilter.text?.toString()?.trim()?.lowercase(Locale.US) ?: ""
        val filtered = if (kw.isEmpty()) {
            cachedTopicEntries
        } else {
            cachedTopicEntries.filter {
                it.name.lowercase(Locale.US).contains(kw) || it.type.lowercase(Locale.US).contains(kw)
            }
        }

        if (filtered.isEmpty()) {
            topicItemsContainer.addView(TextView(this).apply {
                text = if (cachedTopicEntries.isEmpty()) "暂无可用话题，请连接 roscore 或点击「刷新」" else "没有匹配 \"$kw\" 的话题"
                setTextColor(pal.textMuted)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
                setPadding(dp(4f), dp(14f), dp(4f), dp(14f))
            })
            return
        }

        for (entry in filtered) {
            val activePub = entry.publisherCount > 0
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8.5f), dp(6.5f), dp(8.5f), dp(6.5f))
                background = GradientDrawable().apply {
                    setColor(pal.wellFill)
                    cornerRadius = dp(6.5f).toFloat()
                    setStroke(1, if (activePub) pal.accentStroke else pal.cardStroke)
                }
                setOnClickListener {
                    AnimHelper.triggerHaptic(it)
                    hideSoftKeyboard()
                    openTopicDetail(entry)
                }
            }
            AnimHelper.attachSpringTouch(row)

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val nameTv = TextView(this).apply {
                text = entry.name
                isSingleLine = true
                includeFontPadding = false
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setTextColor(pal.textPrimary)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
                typeface = Typeface.MONOSPACE
            }
            val metaTv = TextView(this).apply {
                isSingleLine = true
                includeFontPadding = false
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (activePub) pal.secondaryAccent else pal.textMuted)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.0f)
                typeface = Typeface.MONOSPACE
                GcsIcons.bind(
                    this,
                    if (activePub) Type.STATUS_DOT else Type.STATUS_RING,
                    "${entry.type}  [${entry.publisherCount} pub]",
                    d,
                    iconDp = 9f,
                    gapDp = 3.5f
                )
            }
            col.addView(nameTv)
            col.addView(metaTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(1.5f) })

            val enterHint = TextView(this).apply {
                isSingleLine = true
                includeFontPadding = false
                setTextColor(pal.accentBright)
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
                typeface = Typeface.DEFAULT_BOLD
                GcsIcons.bind(this, null, "查看", d, trailing = Type.CHEVRON_RIGHT, trailDp = 10f)
            }

            row.addView(col, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(enterHint, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6f) })
            topicItemsContainer.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(4.5f) })
        }
    }

    private fun openTopicDetail(entry: RosTopicEntry) {
        selectedTopicEntry = entry
        topicListPage.visibility = View.GONE
        topicDetailPage.visibility = View.VISIBLE
        AnimHelper.animateStaggeredChildren(topicDetailPage, d)
        setTextIfChanged(tvDetailTopicName, entry.name)
        setTextIfChanged(tvDetailTopicType, entry.type)
        updateSmartBindButtonForTopic(entry)

        isDetailCurrentlyStreaming = false
        syncDetailStreamButtonUi()
        topicInspector.captureOnce(entry.name, entry.type) { snap ->
            runOnUiThread { applyTopicEchoSnapshot(snap) }
        }
    }

    private fun exitTopicDetailToList() {
        topicInspector.stopActiveSession()
        isDetailCurrentlyStreaming = false
        syncDetailStreamButtonUi()
        if (drawerWideMode) {
            setWideTerminalMode(false, applyImmediately = true)
        }
        topicDetailPage.visibility = View.GONE
        topicListPage.visibility = View.VISIBLE
        AnimHelper.animateStaggeredChildren(topicListPage, d)
    }

    private fun syncDetailStreamButtonUi() {
        if (!::btnDetailStreamToggle.isInitialized) return
        if (isDetailCurrentlyStreaming) {
            GcsIcons.bind(btnDetailStreamToggle, Type.STOP_SQUARE, "停止读取", d, iconDp = 11f)
            btnDetailStreamToggle.background = roundedColor(Color.parseColor("#FF3B30"), dp(6f))
        } else {
            GcsIcons.bind(btnDetailStreamToggle, Type.PLAY, "持续读取", d, iconDp = 11.5f)
            btnDetailStreamToggle.background = roundedColor(Color.parseColor("#00B865"), dp(6f))
        }
    }

    private fun applyTopicEchoSnapshot(snap: TopicEchoSnapshot) {
        if (selectedTopicEntry?.name != snap.topic) return
        val pal = GcsTheme.of(hub.themeId)
        isDetailCurrentlyStreaming = snap.isStreaming
        syncDetailStreamButtonUi()
        if (selectedTopicEntry != null && snap.msgType.isNotBlank() && snap.msgType != "unknown") {
            val updated = selectedTopicEntry!!.copy(type = snap.msgType)
            selectedTopicEntry = updated
            updateSmartBindButtonForTopic(updated)
        }
        setTextIfChanged(tvDetailTopicType, "${snap.msgType} · ${snap.publisherNode}")

        val (stColor, stIcon) = when (snap.state) {
            TopicEchoState.WARNING -> Color.parseColor("#FF5252") to Type.WARNING
            TopicEchoState.STREAMING -> pal.secondaryAccent to Type.STATUS_DOT
            TopicEchoState.CAPTURED -> pal.accentBright to Type.CAPTURE_FRAME
            TopicEchoState.PAUSED -> Color.rgb(215, 130, 0) to Type.PAUSE
            TopicEchoState.CONNECTING -> Color.rgb(215, 130, 0) to Type.REFRESH
        }
        tvDetailStatusStrip.setTextColor(stColor)
        GcsIcons.bind(tvDetailStatusStrip, stIcon, "${snap.statusText} [${snap.timestampText}]", d, iconDp = 10.5f)

        setTextIfChanged(
            tvDetailMetricsStrip,
            String.format(
                Locale.US,
                "%.1f Hz | %.1f KB/s | 已收 %d 帧 (%d B)",
                snap.hz,
                snap.kbps,
                snap.receivedCount,
                snap.lastFrameBytes
            )
        )
        setTextIfChanged(tvDetailPayloadConsole, snap.bodyText)
    }

    // ==================== Tab 3: 状态与双电源遥测面板 ====================

    private fun buildTelemetryPanel(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), dp(9f), dp(10f), dp(10f))
        }

        tvUavPowerCard = monoLabel("16.24V · 12.6A (86%)", "#00B865", 11.5f)
        tvTxPowerCard = monoLabel("8.08V · 1.05A (92%)", "#69B7FF", 11.5f, Role.TEXT_ACCENT)
        val pwrCard = sectionCard("双路电源遥测 (飞机 + 遥控器本机)")
        pwrCard.addView(twoColRow("无人机动力电池", tvUavPowerCard, "遥控双 21700 电池", tvTxPowerCard))
        val btnSafetyThresholds = createSmallIconBtn(Type.SHIELD_SAFE, "调整低电量与避障告警阈值") {
            setSettingsModalOpen(true, jumpCategory = GcsSettingsModal.CAT_SAFETY)
        }
        pwrCard.addView(btnSafetyThresholds, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(5.5f) })
        col.addView(pwrCard)

        tvPosX = monoLabel("0.00 m", "#FFFFFF", 12f, Role.TEXT_PRIMARY)
        tvPosY = monoLabel("0.00 m", "#FFFFFF", 12f, Role.TEXT_PRIMARY)
        tvPosZ = monoLabel("1.20 m", "#FFFFFF", 12f, Role.TEXT_PRIMARY)
        tvVelNorm = monoLabel("0.00 m/s", "#FFFFFF", 12f, Role.TEXT_PRIMARY)
        tvRollPitch = monoLabel("R +0.0° · P +0.0°", "#69B7FF", 11f, Role.TEXT_ACCENT)
        tvQuatSummary = monoLabel("1.00,0.00,0.00,0.00", "#FFFFFF", 10f, Role.TEXT_PRIMARY)
        tvYaw = monoLabel("0.0°", "#FFFFFF", 12f, Role.TEXT_PRIMARY)
        tvGoalDist = monoLabel("0.00 m", "#FFFFFF", 12f, Role.TEXT_PRIMARY)

        val poseCard = sectionCard("无人机实时里程计与姿态 (/Odometry)")
        poseCard.addView(twoColRow("位置 X", tvPosX, "位置 Y", tvPosY))
        poseCard.addView(twoColRow("高度 Z", tvPosZ, "合速度 |V|", tvVelNorm))
        poseCard.addView(twoColRow("横滚 / 俯仰", tvRollPitch, "偏航 Yaw", tvYaw))
        poseCard.addView(twoColRow("姿态四元数", tvQuatSummary, "目标距离", tvGoalDist))
        col.addView(poseCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        tvClearanceCard = monoLabel("1.45 m", "#00B865", 12f)
        tvSolveCard = monoLabel("0.4 ms", "#69B7FF", 12f, Role.TEXT_ACCENT)
        tvVoxelCount = monoLabel("1620 blks", "#FFFFFF", 12f, Role.TEXT_PRIMARY)
        tvTrajLen = monoLabel("6.2 m", "#FFFFFF", 12f, Role.TEXT_PRIMARY)

        val egoCard = sectionCard("EGO 膨胀体素与局部规划")
        egoCard.addView(twoColRow("最近障碍净空", tvClearanceCard, "规划耗时", tvSolveCard))
        egoCard.addView(twoColRow("膨胀体素数", tvVoxelCount, "轨迹弧长", tvTrajLen))
        col.addView(egoCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        tvMapPtsCard = monoLabel("0 / 300k", "#00B865", 12f)
        tvCloudRateCard = monoLabel("15 Hz · 0 pts", "#69B7FF", 12f, Role.TEXT_ACCENT)
        val lioCard = sectionCard("FAST-LIO 三维点云建图统计")
        lioCard.addView(twoColRow("累积体素点", tvMapPtsCard, "点云流帧率", tvCloudRateCard))
        val btnExportInDrawer = createSmallIconBtn(Type.DOWNLOAD, "导出标准 .pcd 三维点云文件") {
            exportCurrentPointCloudPcd()
        }
        lioCard.addView(btnExportInDrawer, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(5.5f) })
        col.addView(lioCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8f) })

        sv.addView(col)
        return sv
    }

    // ==================== 局域网寻机与连接管理 ====================

    private fun triggerLanScan(silentIfEmpty: Boolean, autoOpenConnTabOnEmpty: Boolean) {
        if (lanScanner.isScanning) {
            lanScanner.cancelScan()
            GcsIcons.bind(btnDrawerScan, Type.SEARCH, "扫描局域网飞机", d, iconDp = 12f)
            setTextIfChanged(tvScanStatus, "扫描已停止")
            return
        }

        discoveredDrones.clear()
        discoveredListContainer.removeAllViews()
        GcsIcons.bind(btnDrawerScan, Type.STOP_SQUARE, "扫描中 (点此停止)", d, iconDp = 11f)
        setTextIfChanged(tvScanStatus, "正在并发探测局域网 ROS1 机载电脑...")
        if (!silentIfEmpty) {
            AnimHelper.showDjiToast(toastBanner, "正在搜索局域网 ROS1 无人机...", d)
        }

        var autoConnectedThisRun = false

        lanScanner.startScan(
            baseConfig = rosManager.topics.copy(),
            onProgress = { _, hint ->
                runOnUiThread { setTextIfChanged(tvScanStatus, hint) }
            },
            onDroneFound = { drone ->
                runOnUiThread {
                    discoveredDrones.add(drone)
                    addDiscoveredDroneRow(drone)

                    if (hub.autoConnectDiscovered && !hub.rosConnected && !autoConnectedThisRun) {
                        autoConnectedThisRun = true
                        applyDiscoveredDroneAndConnect(drone, fromAuto = true)
                    }
                }
            },
            onComplete = { allFound, subnet ->
                runOnUiThread {
                    GcsIcons.bind(btnDrawerScan, Type.SEARCH, "重新扫描飞机", d, iconDp = 12f)
                    if (allFound.isEmpty()) {
                        setTextIfChanged(tvScanStatus, "在 $subnet 未发现开放 11311 或 9090 的设备")
                        if (!silentIfEmpty) {
                            AnimHelper.showDjiToast(toastBanner, "未搜到无人机，请确认同网段或手动输入 IP", d)
                            if (autoOpenConnTabOnEmpty) toggleOrJumpDrawerTab(TAB_CONN)
                        }
                    } else {
                        setTextIfChanged(tvScanStatus, "扫描完成 ($subnet)：发现 ${allFound.size} 台设备")
                        if (!autoConnectedThisRun && !silentIfEmpty) {
                            AnimHelper.showDjiToast(toastBanner, "发现 ${allFound.size} 台无人机，请点选连接", d)
                        }
                    }
                }
            }
        )
    }

    private fun addDiscoveredDroneRow(drone: DiscoveredDrone) {
        val pal = GcsTheme.of(hub.themeId)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8.5f), dp(6.5f), dp(8.5f), dp(6.5f))
            background = GradientDrawable().apply {
                setColor(pal.wellFill)
                cornerRadius = dp(6f).toFloat()
                setStroke(1, pal.secondaryAccent)
            }
        }

        val infoCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val protoTag = if (drone.protocol == "tcpros") "TCPROS:${drone.port}" else "WS:${drone.port}"
        val titleTv = TextView(this).apply {
            isSingleLine = true
            includeFontPadding = false
            setTextColor(pal.textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.6f)
            typeface = Typeface.MONOSPACE
            GcsIcons.bind(this, Type.DRONE_QUAD, "${drone.ip} · ${drone.rttMs}ms", d, iconDp = 12f)
        }
        val subTv = TextView(this).apply {
            text = "$protoTag | ${drone.stackSummary}"
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(pal.secondaryAccent)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.2f)
        }
        infoCol.addView(titleTv)
        infoCol.addView(subTv)

        val btnBind = TextView(this).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            includeFontPadding = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9.5f), dp(5f), dp(9.5f), dp(5f))
            background = roundedColor(pal.accent, dp(5f))
            GcsIcons.bind(this, Type.LINK, "连接", d, iconDp = 11f)
            setOnClickListener { applyDiscoveredDroneAndConnect(drone, fromAuto = false) }
        }
        AnimHelper.attachSpringTouch(btnBind)

        row.addView(infoCol, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(btnBind, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(7f) })
        discoveredListContainer.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(5f) })
        AnimHelper.pulseViewSubtle(row)
    }

    private fun applyDiscoveredDroneAndConnect(drone: DiscoveredDrone, fromAuto: Boolean) {
        val sc = drone.suggestedConfig
        rosManager.topics.protocol = sc.protocol
        syncProtoInputsVisibility()

        inpMasterUri.setText(sc.masterUri)
        inpWsUrl.setText(sc.wsUrl)
        inpOdom.setText(sc.odomTopic)
        inpFastLioCloud.setText(sc.fastLioCloudTopic)
        inpFastLioPath.setText(sc.fastLioPathTopic)
        inpInflate.setText(sc.inflateTopic)
        inpOptimal.setText(sc.optimalTopic)
        inpGoal.setText(sc.goalTopic)

        saveCurrentTopics(quiet = true)
        connectWithConfig(rosManager.topics)
        if (!fromAuto && drawerOpen) {
            setDrawerOpenState(false)
        }

        val prefix = if (fromAuto) "已自动连接" else "已连接"
        AnimHelper.showDjiToast(toastBanner, "$prefix ${drone.ip} (${drone.rttMs}ms)", d)
    }

    private fun connectWithConfig(cfg: TopicConfig) {
        topicInspector.stopActiveSession()
        cachedTopicEntries = emptyList()
        simEngine.resetRosSessionState()
        simEngine.clearVoxelMap()
        rosManager.connect(cfg)
        syncConnModeSectionsUi(showRosEditor = true)
        syncModeSpecificControls(force = true)
        refreshCommandDockUi()
        refreshWaypointOrchestratorList()
    }

    private fun exportCurrentPointCloudPcd() {
        fileIoExecutor.execute {
            try {
                val baseDir = getExternalFilesDir("maps") ?: File(filesDir, "maps")
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val outFile = File(baseDir, "fastlio_map_$stamp.pcd")
                val exported = simEngine.voxelMap.exportBinaryPcd(outFile)
                runOnUiThread {
                    if (exported <= 0) {
                        AnimHelper.showDjiToast(toastBanner, "当前点云地图为空", d)
                    } else {
                        AnimHelper.showDjiToast(toastBanner, "已保存 $exported 点至 maps/${outFile.name}", d)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    AnimHelper.showDjiToast(toastBanner, "导出失败: ${e.localizedMessage ?: "存储不可写"}", d)
                }
            }
        }
    }

    private fun setTextIfChanged(tv: TextView, newText: String) {
        if (!TextUtils.equals(tv.text, newText)) {
            tv.text = newText
        }
    }

    private fun updateHudReadouts(s: RenderSnapshot) {
        hsiView.invalidateIfChanged()
        compassView.invalidateIfChanged()
        if (!drawerOpen && attitudeHudView.visibility == View.VISIBLE) {
            attitudeHudView.tickAndInvalidate()
        }
        syncModeSpecificControls()
        updateOcclusionHudVisibility(hub.droneCurrentlyOccluded && hub.xrayOcclusionEnabled && mapView.is3DMode)

        val curTheme = hub.themeId
        val pal = GcsTheme.of(curTheme)
        if (curTheme != lastHudThemeId) {
            lastHudThemeId = curTheme
            tvModeBadge.setTextColor(pal.textPrimary)
            lastClearanceWarnLevel = -1
            lastBatDangerLevel = -1
        }

        val spd = sqrt(s.vx * s.vx + s.vy * s.vy + s.vz * s.vz)
        val dgx = s.goalX - s.uavX
        val dgy = s.goalY - s.uavY
        val dgz = s.goalZ - s.uavZ
        val distGoal = sqrt(dgx * dgx + dgy * dgy + dgz * dgz)
        val yawDeg = s.yaw * 57.29578f

        if (s.px4Mode != lastPx4ModeStr || s.armed != lastArmedFlag) {
            lastPx4ModeStr = s.px4Mode
            lastArmedFlag = s.armed
            tvModeBadge.text = "${s.px4Mode} · ${if (s.armed) "ARMED" else "DISARM"}"
        }
        val curConnLbl = hub.connectionLabel
        if (curConnLbl != lastConnLabelStr || s.fsmState != lastFsmStateStr) {
            lastConnLabelStr = curConnLbl
            lastFsmStateStr = s.fsmState
            tvConnStatus.text = "$curConnLbl | ${s.fsmState}"
        }

        val lv = hub.connectionLevel
        if (lv != lastAppliedConnLevel) {
            lastAppliedConnLevel = lv
            statusAccent.background = when (lv) {
                1 -> accentAmber
                2 -> accentRed
                else -> accentGreen
            }
        }

        if (!s.hasPreviewPin && (s.waypointQueueCount > 0 || commandDock.visibility == View.VISIBLE)) {
            refreshCommandDockUi()
        }

        val clrLevel = when {
            s.minClearance <= hub.warnClearanceMeters * 0.65f -> 2
            s.minClearance <= hub.warnClearanceMeters -> 1
            else -> 0
        }
        if (clrLevel != lastClearanceWarnLevel) {
            lastClearanceWarnLevel = clrLevel
            tvClearanceTop.setTextColor(
                when (clrLevel) {
                    2 -> Color.parseColor("#FF3B30")
                    1 -> Color.rgb(225, 132, 0)
                    else -> pal.secondaryAccent
                }
            )
        }
        FastHudFormatter.setFixed1(tvClearanceTop, "避障", s.minClearance, "m")
        if (tvHzTop.visibility == View.VISIBLE) {
            FastHudFormatter.setTopHzFps(tvHzTop, hub.isRosMode, s.odomHz, hub.renderFps)
        }

        val batLevel = when {
            s.batPct <= maxOf(10, hub.lowBatWarnPct - 8) -> 2
            s.batPct <= hub.lowBatWarnPct -> 1
            else -> 0
        }
        if (batLevel != lastBatDangerLevel) {
            lastBatDangerLevel = batLevel
            val c = when (batLevel) {
                2 -> Color.parseColor("#FF3B30")
                1 -> Color.rgb(225, 132, 0)
                else -> pal.secondaryAccent
            }
            tvBatTop.setTextColor(c)
            topBatFill.setBackgroundColor(c)
        }
        FastHudFormatter.setTopBattery(tvBatTop, s.batVolt, s.batCurrentAmps, s.txBatPct)

        val batW = (resources.displayMetrics.widthPixels * (s.batPct.coerceIn(5, 100) / 100f)).roundToInt()
        if (batW != lastBatBarPx) {
            lastBatBarPx = batW
            AnimHelper.animateBarWidthSmooth(topBatFill, batW)
        }

        if (hdTelemetryBox.visibility == View.VISIBLE) {
            FastHudFormatter.setFixed1(tvOsdH, "H ", s.uavZ, "m")
            FastHudFormatter.setFixed1(tvOsdHs, "  HS ", spd, "m/s")
            FastHudFormatter.setFixed1(tvOsdD, "D ", distGoal, "m")
            FastHudFormatter.setCompactPoints(tvOsdMapPts, "  MAP ", s.mapPointCount, "")
            FastHudFormatter.setSubXyzYaw(tvOsdSubXyz, s.uavX, s.uavY, yawDeg)
        }

        if (drawerOpen && activeTabIndex == TAB_STATUS) {
            tvUavPowerCard.setTextColor(pal.secondaryAccent)
            tvClearanceCard.setTextColor(pal.secondaryAccent)
            tvMapPtsCard.setTextColor(pal.secondaryAccent)
            FastHudFormatter.setPowerDetail(tvUavPowerCard, s.batVolt, s.batCurrentAmps, 1, s.batPct)
            FastHudFormatter.setPowerDetail(tvTxPowerCard, s.txBatVolt, s.txCurrentAmps, 2, s.txBatPct)
            FastHudFormatter.setCompactPoints(tvMapPtsCard, "", s.mapPointCount, " / 300k")
            FastHudFormatter.setIntMetric(tvCloudRateCard, "", s.cloudHz, " Hz · ", s.cloudScanPts, " pts")
            FastHudFormatter.setFixed2(tvPosX, "", s.uavX, " m")
            FastHudFormatter.setFixed2(tvPosY, "", s.uavY, " m")
            FastHudFormatter.setFixed2(tvPosZ, "", s.uavZ, " m")
            FastHudFormatter.setFixed2(tvVelNorm, "", spd, " m/s")
            val rDeg = s.smoothRoll * 57.29578f
            val pDeg = s.smoothPitch * 57.29578f
            FastHudFormatter.setRollPitchPair(tvRollPitch, rDeg, pDeg)
            FastHudFormatter.setQuat4(tvQuatSummary, s.quatW, s.quatX, s.quatY, s.quatZ)
            FastHudFormatter.setFixed1(tvYaw, "", yawDeg, "°")
            FastHudFormatter.setFixed2(tvGoalDist, "", distGoal, " m")
            FastHudFormatter.setFixed2(tvClearanceCard, "", s.minClearance, " m")
            FastHudFormatter.setFixed2(tvSolveCard, "", s.solveMs, " ms")
            FastHudFormatter.setSingleInt(tvVoxelCount, "", s.voxelCount, " blks")
            FastHudFormatter.setFixed1(tvTrajLen, "", s.trajLength, " m")
        }
    }

    private fun loadSavedTopics() {
        val sp = getSharedPreferences(GcsSettingsModal.PREFS_NAME, Context.MODE_PRIVATE)
        val cfg = TopicConfig(
            protocol = sp.getString("protocol", "tcpros") ?: "tcpros",
            masterUri = sp.getString("masterUri", "http://192.168.1.100:11311") ?: "http://192.168.1.100:11311",
            wsUrl = sp.getString("wsUrl", "ws://192.168.1.100:9090") ?: "ws://192.168.1.100:9090",
            odomTopic = sp.getString("odom", "/Odometry") ?: "/Odometry",
            fastLioCloudTopic = sp.getString("fastLioCloud", "/cloud_registered") ?: "/cloud_registered",
            fastLioPathTopic = sp.getString("fastLioPath", "/path") ?: "/path",
            inflateTopic = sp.getString("inflate", "/grid_map/occupancy_inflate") ?: "/grid_map/occupancy_inflate",
            optimalTopic = sp.getString("optimal", "/ego_planner_node/optimal_list") ?: "/ego_planner_node/optimal_list",
            goalTopic = sp.getString("goal", "/move_base_simple/goal") ?: "/move_base_simple/goal"
        )
        rosManager.topics = cfg
    }

    private fun saveCurrentTopics(quiet: Boolean) {
        val cfg = TopicConfig(
            protocol = rosManager.topics.protocol,
            masterUri = inpMasterUri.text.toString().trim(),
            wsUrl = inpWsUrl.text.toString().trim(),
            odomTopic = inpOdom.text.toString().trim(),
            fastLioCloudTopic = inpFastLioCloud.text.toString().trim(),
            fastLioPathTopic = inpFastLioPath.text.toString().trim(),
            inflateTopic = inpInflate.text.toString().trim(),
            optimalTopic = inpOptimal.text.toString().trim(),
            goalTopic = inpGoal.text.toString().trim()
        )
        getSharedPreferences(GcsSettingsModal.PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString("protocol", cfg.protocol)
            .putString("masterUri", cfg.masterUri)
            .putString("wsUrl", cfg.wsUrl)
            .putString("odom", cfg.odomTopic)
            .putString("fastLioCloud", cfg.fastLioCloudTopic)
            .putString("fastLioPath", cfg.fastLioPathTopic)
            .putString("inflate", cfg.inflateTopic)
            .putString("optimal", cfg.optimalTopic)
            .putString("goal", cfg.goalTopic)
            .apply()
        rosManager.updateTopicsAndResubscribe(cfg)
        if (!quiet) AnimHelper.showDjiToast(toastBanner, "话题配置已保存生效", d)
    }

    // ==================== 零基线偏移原子组件工具 ====================

    private fun dp(v: Float): Int = (v * d).roundToInt()

    private fun glassBg(radiusPx: Int): GradientDrawable {
        val pal = GcsTheme.of(hub.themeId)
        return GradientDrawable().apply {
            setColor(pal.glassFill)
            cornerRadius = radiusPx.toFloat()
            setStroke(maxOf(1, dp(0.85f)), pal.glassStroke)
        }
    }

    private fun pillBg(fillCol: Int, strokeCol: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fillCol)
        cornerRadius = dp(18f).toFloat()
        setStroke(maxOf(1, dp(0.9f)), strokeCol)
    }

    private fun roundedColor(col: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(col)
        cornerRadius = radiusPx.toFloat()
    }

    private fun camPillBg(active: Boolean): GradientDrawable {
        val pal = GcsTheme.of(hub.themeId)
        return GradientDrawable().apply {
            cornerRadius = dp(14f).toFloat()
            setColor(if (active) pal.accentSoftFill else pal.glassFill)
            setStroke(maxOf(1, dp(0.9f)), if (active) pal.accent else pal.glassStroke)
        }
    }

    private fun monoLabel(txt: String, hexCol: String, sizeDp: Float, themeRole: Role? = null): TextView = TextView(this).apply {
        text = txt
        isSingleLine = true
        includeFontPadding = false
        ellipsize = TextUtils.TruncateAt.END
        setTextColor(Color.parseColor(hexCol))
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, sizeDp)
        typeface = Typeface.MONOSPACE
        if (themeRole != null) {
            GcsTheme.markRole(this, themeRole)
        }
    }

    private fun createActionPill(icon: Type, label: String, accentHex: String, active: Boolean): TextView = TextView(this).apply {
        val pal = GcsTheme.of(hub.themeId)
        isSingleLine = true
        includeFontPadding = false
        gravity = Gravity.CENTER
        minimumHeight = dp(26.5f)
        setTextColor(pal.textPrimary)
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.2f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(9.5f), dp(4.5f), dp(10f), dp(4.5f))
        val ac = Color.parseColor(accentHex)
        background = pillBg(if (active) Color.argb(52, Color.red(ac), Color.green(ac), Color.blue(ac)) else pal.glassFill, ac)
        GcsIcons.bind(this, icon, label, d, iconDp = 11.5f, gapDp = 3.5f)
        AnimHelper.attachSpringTouch(this)
    }

    private fun createCamPillBtn(icon: Type, txt: String, active: Boolean, trailing: Type? = null): TextView = TextView(this).apply {
        val pal = GcsTheme.of(hub.themeId)
        isSingleLine = true
        includeFontPadding = false
        gravity = Gravity.CENTER
        setTextColor(pal.textPrimary)
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.6f)
        typeface = Typeface.DEFAULT_BOLD
        background = camPillBg(active)
        GcsIcons.bind(this, icon, txt, d, iconDp = 11.5f, gapDp = 3f, trailing = trailing, trailDp = 9f)
        AnimHelper.attachSpringTouch(this)
    }

    private fun createSmallIconBtn(icon: Type?, txt: String, onClick: () -> Unit): TextView = TextView(this).apply {
        isSingleLine = true
        includeFontPadding = false
        ellipsize = TextUtils.TruncateAt.END
        gravity = Gravity.CENTER
        minimumHeight = dp(27f)
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.8f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(7.5f), dp(4.5f), dp(7.5f), dp(4.5f))
        GcsTheme.markRole(this, Role.GLASS_PANEL, cornerDp = 5.5f)
        setTextColor(GcsTheme.of(hub.themeId).textPrimary)
        GcsIcons.bind(this, icon, txt, d, iconDp = 11f, gapDp = 3.5f)
        setOnClickListener {
            AnimHelper.triggerHaptic(it)
            onClick()
        }
        AnimHelper.attachSpringTouch(this)
    }

    private fun sectionCard(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(9.5f), dp(8f), dp(9.5f), dp(8.5f))
        GcsTheme.markRole(this, Role.SECTION_CARD, cornerDp = 8f)
        addView(TextView(this@MainActivity).apply {
            text = title
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(5.5f))
            GcsTheme.markRole(this, Role.TEXT_SECONDARY)
        })
    }

    private fun twoColRow(lbl1: String, val1: TextView, lbl2: String, val2: TextView): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2.5f), 0, dp(2.5f))
        }
        fun cell(l: String, v: TextView): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6.5f), dp(4.5f), dp(6.5f), dp(4.5f))
            GcsTheme.markRole(this, Role.WELL_TRACK, cornerDp = 5f)
            addView(TextView(this@MainActivity).apply {
                text = l
                isSingleLine = true
                includeFontPadding = false
                ellipsize = TextUtils.TruncateAt.END
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.0f)
                setPadding(0, 0, 0, dp(1.5f))
                GcsTheme.markRole(this, Role.TEXT_MUTED)
            })
            addView(v)
        }
        row.addView(cell(lbl1, val1), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(cell(lbl2, val2), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(5f) })
        return row
    }

    private fun labeledInput(parent: LinearLayout, title: String, initVal: String): EditText {
        parent.addView(TextView(this).apply {
            text = title
            isSingleLine = true
            includeFontPadding = false
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9.4f)
            setPadding(0, dp(5f), 0, dp(2f))
            GcsTheme.markRole(this, Role.TEXT_MUTED)
        })
        return EditText(this).apply {
            setText(initVal)
            setSingleLine(true)
            includeFontPadding = false
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10.6f)
            typeface = Typeface.MONOSPACE
            setPadding(dp(7.5f), dp(4.5f), dp(7.5f), dp(4.5f))
            GcsTheme.markRole(this, Role.INPUT_BOX, cornerDp = 5f)
            parent.addView(this, LinearLayout.LayoutParams(MATCH_PARENT, dp(29f)))
        }
    }
}
