package com.radiomaster.egogcs.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.animation.OvershootInterpolator
import com.radiomaster.egogcs.engine.FastLioVoxelMap
import com.radiomaster.egogcs.model.GcsSharedHub
import com.radiomaster.egogcs.model.RenderSnapshot
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * 航空级真三维膨胀体素地图 (/grid_map/occupancy_inflate) + 硬件 Z-Buffer 视线隧道透视与流动虚线引擎：
 *
 * 1. 真实 EGO-Planner 三维膨胀体素块渲染 (RViz PointCloud2 Boxes 风格 + 三面朝向背面剔除)：
 *    - 不再把障碍物理想化为光滑圆柱，而是将 `/grid_map/occupancy_inflate` 的每个膨胀占据点渲染为带高度彩虹色谱与法线明暗的 3D 立方体素块；
 *    - 采用相机朝向三面剔除 (3-Face View Culling)，每个三维体素仅提交朝向相机的 <=3 个面 (18 顶点)，4096 体素同屏稳跑 60FPS。
 * 2. 膨胀地图视线隧道透视 (Inflated Voxel Sight-Tunnel X-Ray) + 被遮挡轨迹流动虚线：
 *    - 阻挡「相机 -> 无人机」或「相机 -> 前方规划轨迹」视线的膨胀体素块自动平滑羽化为 15%~35% 全息磨砂线框体素，既保留膨胀安全边界体积感知，又让视野豁然通透；
 *    - 配合硬件深度逆测试 (GL_GREATER)，凡处于膨胀体素块或点云后方的轨迹自动逐像素切换为向前流动的霓虹虚线，被遮挡无人机呈现全息扫描轮廓与声呐脉冲环。
 */
class GlPointCloudMapView(
    context: Context,
    private val hub: GcsSharedHub,
    private val voxelMap: FastLioVoxelMap,
    private val onHudTick: (RenderSnapshot) -> Unit,
    private val onInterceptDrawerClose: () -> Boolean,
    private val onSingleTapPreviewPin: (wx: Float, wy: Float) -> Unit,
    private val onLongPressQuickFly: (wx: Float, wy: Float) -> Unit,
    private val onFollowStateChanged: (followMode: Int, toastMsg: String?) -> Unit
) : GLSurfaceView(context), GLSurfaceView.Renderer {

    companion object {
        private const val MAX_ENV_LINE_VERTS = 36_000
        private const val MAX_ENV_TRI_VERTS = 96_000
        private const val MAX_GLASS_TRI_VERTS = 64_000
        private const val MAX_GLASS_LINE_VERTS = 28_000
        private const val MAX_FX_TRI_VERTS = 32_000
        private const val MAX_ACTOR_LINE_VERTS = 8_000
        private const val MAX_ACTOR_TRI_VERTS = 16_000

        // 8 floats per vertex (32 bytes, cache-aligned): x, y, z, r, g, b, a, arcDist
        private const val FLOATS_PER_VERT = 8
        private const val STRIDE_VERT = FLOATS_PER_VERT * 4

        // 256 段高精度单位圆查表，彻底消除每帧圆环/圆盘构建中的高频三角函数开销
        private const val LUT_N = 256
        private val COS_LUT = FloatArray(LUT_N + 1) { i -> cos((i.toFloat() / LUT_N) * (PI.toFloat() * 2f)) }
        private val SIN_LUT = FloatArray(LUT_N + 1) { i -> sin((i.toFloat() / LUT_N) * (PI.toFloat() * 2f)) }

        // 1. 天际大气穹顶着色器 (NDC 全屏渐变，随相机俯仰与 3D/2D 过渡动态响应)
        private const val SKY_VS = """
            attribute vec2 aNdcPos;
            varying vec2 vUv;
            void main() {
                vUv = aNdcPos * 0.5 + 0.5;
                gl_Position = vec4(aNdcPos, 0.999, 1.0);
            }
        """

        private const val SKY_FS = """
            precision mediump float;
            uniform float uHorizonY;
            uniform float uBlend3D;
            uniform vec3 uSkyFlat;
            uniform vec3 uSkyZenith;
            uniform vec3 uSkyHorizon;
            uniform vec3 uSkyGround;
            varying vec2 vUv;
            void main() {
                float above = smoothstep(uHorizonY - 0.08, 1.0, vUv.y);
                float band = exp(-abs(vUv.y - uHorizonY) * 10.5);
                vec3 sky3d = mix(uSkyGround, uSkyZenith, above) + uSkyHorizon * band * 0.52;
                gl_FragColor = vec4(mix(uSkyFlat, sky3d, uBlend3D), 1.0);
            }
        """

        // 2. 点云球体浮雕 + Eye-Dome 深度描边 + 视线隧道自动镂空着色器
        private const val POINT_CLOUD_VS = """
            uniform mat4 uMVP;
            uniform float uZMax;
            uniform float uPointScale;
            uniform float uZFlatten;
            uniform int uColorMode;
            uniform vec3 uEyePos;
            uniform vec3 uDronePos;
            uniform float uFogSpan;
            uniform int uXrayOn;
            attribute vec3 aPos;
            attribute float aMeta;
            varying vec4 vColor;
            varying float vLosFade;
            varying float vFog;

            vec3 heightRamp(float t) {
                float c = clamp(t, 0.0, 1.0);
                if (c < 0.33) {
                    float u = c / 0.33;
                    return mix(vec3(0.08, 0.56, 1.00), vec3(0.00, 0.90, 0.52), u);
                } else if (c < 0.68) {
                    float u = (c - 0.33) / 0.35;
                    return mix(vec3(0.00, 0.90, 0.52), vec3(1.00, 0.78, 0.08), u);
                } else {
                    float u = (c - 0.68) / 0.32;
                    return mix(vec3(1.00, 0.78, 0.08), vec3(1.00, 0.24, 0.20), u);
                }
            }

            void main() {
                if (aPos.z > uZMax) {
                    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
                    gl_PointSize = 0.0;
                    vColor = vec4(0.0);
                    vLosFade = 1.0;
                    vFog = 0.0;
                    return;
                }
                vec3 worldPos = vec3(aPos.x, aPos.y, aPos.z * uZFlatten);
                vec4 clip = uMVP * vec4(worldPos, 1.0);
                gl_Position = clip;
                float dist = max(1.8, clip.w);
                gl_PointSize = clamp(uPointScale / dist, 2.4, 9.2);

                vec3 rgb;
                if (uColorMode == 1) {
                    float it = clamp(aMeta, 0.0, 1.0);
                    rgb = mix(vec3(0.12, 0.68, 1.00), vec3(1.00, 0.48, 0.10), it);
                } else if (uColorMode == 2) {
                    float hz = clamp((aPos.z + 0.2) / 3.0, 0.15, 1.0);
                    rgb = vec3(0.05, 0.88, 0.48) * (0.45 + 0.55 * hz);
                } else {
                    float hz = clamp((aPos.z + 0.15) / max(0.8, uZMax), 0.0, 1.0);
                    rgb = heightRamp(hz);
                }

                vLosFade = 1.0;
                if (uXrayOn == 1 && worldPos.z > 0.15) {
                    vec3 seg = uDronePos - uEyePos;
                    float segLen2 = dot(seg, seg);
                    if (segLen2 > 0.25) {
                        float t = dot(worldPos - uEyePos, seg) / segLen2;
                        if (t > 0.08 && t < 0.95) {
                            vec3 closest = uEyePos + seg * t;
                            float dRay = length(worldPos - closest);
                            vLosFade = smoothstep(0.38, 1.35, dRay);
                        }
                    }
                }

                vFog = clamp((length(worldPos.xy - uDronePos.xy) - uFogSpan * 0.85) / max(6.0, uFogSpan * 1.4), 0.0, 0.68);
                float alpha = (aPos.z < 0.06) ? 0.48 : 0.92;
                vColor = vec4(rgb, alpha);
            }
        """

        private const val POINT_CLOUD_FS = """
            precision mediump float;
            uniform vec3 uFogColor;
            varying vec4 vColor;
            varying float vLosFade;
            varying float vFog;
            void main() {
                vec2 uv = gl_PointCoord - vec2(0.5);
                float r2 = dot(uv, uv);
                if (r2 > 0.25) discard;

                if (vLosFade < 0.75) {
                    vec2 cell = mod(floor(gl_FragCoord.xy), 2.0);
                    float bayer = (cell.x * 0.5 + cell.y * 0.25);
                    if (vLosFade < bayer + 0.24) discard;
                }

                float nz = sqrt(max(0.0, 1.0 - r2 * 4.0));
                vec3 norm = vec3(uv.x * 2.0, -uv.y * 2.0, nz);
                float diff = max(0.0, dot(norm, vec3(0.38, 0.48, 0.79)));
                float edlRim = 1.0 - smoothstep(0.15, 0.25, r2) * 0.42;
                vec3 litRgb = vColor.rgb * (0.58 + 0.56 * diff) * edlRim;
                vec3 fogRgb = mix(litRgb, uFogColor, vFog);
                gl_FragColor = vec4(fogRgb, vColor.a);
            }
        """

        // 3. 标准三维图元着色器 (带指数远景深度雾)
        private const val PRIM_VS = """
            uniform mat4 uMVP;
            uniform vec2 uFocusXY;
            uniform float uFogSpan;
            attribute vec3 aPos;
            attribute vec4 aColor;
            attribute float aArc;
            varying vec4 vColor;
            varying float vFog;
            void main() {
                gl_Position = uMVP * vec4(aPos, 1.0);
                vColor = aColor;
                float d = length(aPos.xy - uFocusXY);
                vFog = clamp((d - uFogSpan * 0.95) / max(8.0, uFogSpan * 1.5), 0.0, 0.65);
            }
        """

        private const val PRIM_FS = """
            precision mediump float;
            uniform vec3 uFogColor;
            varying vec4 vColor;
            varying float vFog;
            void main() {
                vec3 rgb = mix(vColor.rgb, uFogColor, vFog);
                gl_FragColor = vec4(rgb, vColor.a);
            }
        """

        // 4. 硬件深度遮挡 X-Ray 着色器 (仅在 GL_GREATER 即被膨胀体素块或点云挡住的像素上触发！)
        private const val OCCLUDED_VS = """
            uniform mat4 uMVP;
            attribute vec3 aPos;
            attribute vec4 aColor;
            attribute float aArc;
            varying vec4 vColor;
            varying float vArc;
            void main() {
                gl_Position = uMVP * vec4(aPos, 1.0);
                vColor = aColor;
                vArc = aArc;
            }
        """

        private const val OCCLUDED_FS = """
            precision mediump float;
            uniform float uTime;
            varying vec4 vColor;
            varying float vArc;
            void main() {
                if (vArc >= 0.0) {
                    float dash = fract(vArc * 2.5 - uTime * 2.2);
                    if (dash > 0.52) discard;
                    float edge = smoothstep(0.0, 0.08, dash) * (1.0 - smoothstep(0.44, 0.52, dash));
                    vec3 xrayRgb = mix(vColor.rgb, vec3(0.22, 0.95, 1.00), 0.48);
                    gl_FragColor = vec4(xrayRgb, clamp(vColor.a * 0.78 * (0.7 + 0.3 * edge), 0.22, 0.88));
                } else {
                    float scan = 0.64 + 0.36 * sin(uTime * 7.0 + gl_FragCoord.y * 0.45);
                    vec3 holoRgb = mix(vColor.rgb, vec3(0.10, 0.94, 1.00), 0.65);
                    gl_FragColor = vec4(holoRgb * scan, 0.82);
                }
            }
        """
    }

    private val density = resources.displayMetrics.density

    var is3DMode: Boolean = true
        private set
    @Volatile private var projBlend: Float = 1.0f
    private var blendAnimator: ValueAnimator? = null

    @Volatile private var pinAnimScale: Float = 1.0f
    private var pinAnimator: ValueAnimator? = null

    @Volatile var followMode: Int = 1
        private set

    @Volatile private var camYawDesired = 0.62f
    @Volatile private var camPitchDesired = 0.62f
    @Volatile private var worldHalfSpanDesired = 6.6f

    private var camYaw = 0.62f
    private var camPitch = 0.62f
    private var worldHalfSpan = 6.6f
    @Volatile private var camPanX = 0f
    @Volatile private var camPanY = 0f
    private var camFocusX = -5.5f
    private var camFocusY = -4.2f
    private var camFocusZ = 0.45f

    private var curEyeX = -8f
    private var curEyeY = -8f
    private var curEyeZ = 5f

    private val obsSmoothAlpha = FloatArray(24) { 0.94f }
    private val tmpVoxelRgb = FloatArray(3)
    private val uavTmpA = FloatArray(3)
    private val uavTmpB = FloatArray(3)
    private var droneOccludedBlend = 0f
    private var shaderClockSec = 0f

    private var viewportW = 1
    private var viewportH = 1
    private var lastFrameNs = System.nanoTime()
    private var hudSyncAcc = 0f
    private var fpsFrameCount = 0
    private var fpsTimeAcc = 0f

    private var multiTouchActive = false

    private val viewMatrix = FloatArray(16)
    private val projMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val glTmpInv16 = FloatArray(16)
    private val invVpLock = Any()
    private val sharedInvVp = FloatArray(16)
    private var invVpValid = false

    private val uiInvCopy16 = FloatArray(16)
    private val uiNearIn4 = FloatArray(4)
    private val uiFarIn4 = FloatArray(4)
    private val uiNearOut4 = FloatArray(4)
    private val uiFarOut4 = FloatArray(4)
    private val uiGroundOut2 = FloatArray(2)

    private val rippleLock = Any()
    private val rippleX = FloatArray(6)
    private val rippleY = FloatArray(6)
    private val rippleAge = FloatArray(6) { -1f }

    private val skyQuadBuf: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }

    // 环境批次数组 (地板网格、实心三维膨胀体素、视线隧道半透明透视膨胀体素、特效垂幕)
    private val groundLineArray = FloatArray(MAX_ENV_LINE_VERTS * FLOATS_PER_VERT)
    private var groundLineVerts = 0

    private val solidObsTriArray = FloatArray(MAX_ENV_TRI_VERTS * FLOATS_PER_VERT)
    private var solidObsTriVerts = 0
    private val solidObsEdgeArray = FloatArray(MAX_ENV_LINE_VERTS * FLOATS_PER_VERT)
    private var solidObsEdgeVerts = 0

    private val glassObsTriArray = FloatArray(MAX_GLASS_TRI_VERTS * FLOATS_PER_VERT)
    private var glassObsTriVerts = 0
    private val glassObsEdgeArray = FloatArray(MAX_GLASS_LINE_VERTS * FLOATS_PER_VERT)
    private var glassObsEdgeVerts = 0

    private val fxAlphaTriArray = FloatArray(MAX_FX_TRI_VERTS * FLOATS_PER_VERT)
    private var fxAlphaTriVerts = 0

    // 可被遮挡并自动切换实线/流动虚线的主角批次 (B样条轨迹、多航点航线、选点光柱、无人机)
    private val actorLineArray = FloatArray(MAX_ACTOR_LINE_VERTS * FLOATS_PER_VERT)
    private var actorLineVerts = 0
    private val actorTriArray = FloatArray(MAX_ACTOR_TRI_VERTS * FLOATS_PER_VERT)
    private var actorTriVerts = 0

    private val envLineBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ENV_LINE_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val envTriBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ENV_TRI_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val actorLineBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ACTOR_LINE_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val actorTriBuf: FloatBuffer = ByteBuffer.allocateDirect(MAX_ACTOR_TRI_VERTS * STRIDE_VERT)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()

    // Shader Programs & Handles
    private var progSky = 0
    private var aSkyPos = 0
    private var uSkyHorizonY = 0
    private var uSkyBlend3D = 0
    private var uSkyFlat = 0
    private var uSkyZenith = 0
    private var uSkyHorizon = 0
    private var uSkyGround = 0
    private var uCloudFogColor = 0
    private var uPrimFogColor = 0

    // 实时平滑过渡的 3D 主题大气与地面网格色彩缓冲 (零 GC 分配)
    private val curSkyFlat = floatArrayOf(0.043f, 0.051f, 0.066f)
    private val curSkyZenith = floatArrayOf(0.024f, 0.038f, 0.068f)
    private val curSkyHorizon = floatArrayOf(0.075f, 0.132f, 0.215f)
    private val curSkyGround = floatArrayOf(0.036f, 0.046f, 0.062f)
    private val curFogRgb = floatArrayOf(0.042f, 0.056f, 0.082f)
    private val curGridRgb = floatArrayOf(0.78f, 0.86f, 0.96f)
    private var curGridMajorAlpha = 0.19f
    private var curGridMinorAlpha = 0.065f
    private var themeInitialized = false

    private var progCloud = 0
    private var uCloudMvp = 0
    private var uCloudZMax = 0
    private var uCloudPointScale = 0
    private var uCloudZFlatten = 0
    private var uCloudColorMode = 0
    private var uCloudEyePos = 0
    private var uCloudDronePos = 0
    private var uCloudFogSpan = 0
    private var uCloudXrayOn = 0
    private var aCloudPos = 0
    private var aCloudMeta = 0

    private var progPrim = 0
    private var uPrimMvp = 0
    private var uPrimFocusXY = 0
    private var uPrimFogSpan = 0
    private var aPrimPos = 0
    private var aPrimColor = 0
    private var aPrimArc = 0

    private var progOccluded = 0
    private var uOccMvp = 0
    private var uOccTime = 0
    private var aOccPos = 0
    private var aOccColor = 0
    private var aOccArc = 0

    // 9 路独立持久化 VBO：每个渲染遍拥有专属显存缓冲区，杜绝 Mali-G72 TBDR 同帧重复覆写导致的 Buffer Ghosting 卡顿
    private var vboCloudId = 0
    private var vboGroundLineId = 0
    private var vboSolidTriId = 0
    private var vboSolidEdgeId = 0
    private var vboGlassTriId = 0
    private var vboGlassEdgeId = 0
    private var vboFxTriId = 0
    private var vboActorLineId = 0
    private var vboActorTriId = 0

    private val uiTickRunnable = Runnable {
        onHudTick(hub.latestSnapshot)
    }

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val factor = 1.0f / detector.scaleFactor.coerceIn(0.8f, 1.25f)
            worldHalfSpanDesired = (worldHalfSpanDesired * factor).coerceIn(2.2f, 65.0f)
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (e2.pointerCount >= 2) {
                if (followMode != 0) {
                    val s = hub.latestSnapshot
                    camPanX = s.uavX
                    camPanY = s.uavY
                    followMode = 0
                    onFollowStateChanged(0, null)
                }
                panCameraByScreenDelta(distanceX, distanceY)
                return true
            }

            if (scaleDetector.isInProgress) return true

            if (is3DMode && followMode != 0) {
                if (followMode == 2 && abs(distanceX) > abs(distanceY) * 1.4f && abs(distanceX) > 4f * density) {
                    followMode = 1
                    onFollowStateChanged(1, null)
                }
                if (followMode == 1) {
                    camYawDesired += distanceX * 0.0072f / density * 1.6f
                }
                camPitchDesired = (camPitchDesired + distanceY * 0.0062f / density * 1.6f).coerceIn(0.20f, 1.44f)
            } else {
                if (!is3DMode && followMode != 0 && hypot(distanceX, distanceY) > 6f * density) {
                    val s = hub.latestSnapshot
                    camPanX = s.uavX
                    camPanY = s.uavY
                    followMode = 0
                    onFollowStateChanged(0, null)
                }
                panCameraByScreenDelta(distanceX, distanceY)
            }
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (onInterceptDrawerClose()) return true
            if (hub.hapticFeedbackEnabled) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            recenterLockDrone()
            onFollowStateChanged(1, "已平滑回中并锁定跟随无人机")
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (onInterceptDrawerClose()) return true
            val world = unprojectToGroundUiThread(e.x, e.y) ?: return true
            if (hub.hapticFeedbackEnabled) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            spawnRipple(world[0], world[1])
            triggerPinSpringAnim()
            onSingleTapPreviewPin(world[0], world[1])
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (multiTouchActive || scaleDetector.isInProgress) return
            if (onInterceptDrawerClose()) return
            val world = unprojectToGroundUiThread(e.x, e.y) ?: return
            if (!hub.longPressQuickFlyEnabled) {
                if (hub.hapticFeedbackEnabled) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                spawnRipple(world[0], world[1])
                triggerPinSpringAnim()
                onSingleTapPreviewPin(world[0], world[1])
                return
            }
            if (hub.hapticFeedbackEnabled) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            spawnRipple(world[0], world[1])
            onLongPressQuickFly(world[0], world[1])
        }
    })

    private fun panCameraByScreenDelta(distanceX: Float, distanceY: Float) {
        val metersPerPx = (worldHalfSpan * 2.0f) / max(1f, viewportH.toFloat())
        val effY = camYaw * projBlend
        val cosY = cos(effY)
        val sinY = sin(effY)
        val dxScreen = distanceX * metersPerPx
        val dyScreen = -distanceY * metersPerPx
        camPanX += dxScreen * cosY - dyScreen * sinY
        camPanY += dxScreen * sinY + dyScreen * cosY
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        preserveEGLContextOnPause = true
        setRenderer(this)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> multiTouchActive = true
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> multiTouchActive = false
        }
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    fun startLoop() {
        onResume()
    }

    fun stopLoop() {
        onPause()
    }

    fun triggerPinSpringAnim() {
        pinAnimator?.cancel()
        pinAnimScale = 0.15f
        pinAnimator = ValueAnimator.ofFloat(0.15f, 1.0f).apply {
            duration = 260L
            interpolator = OvershootInterpolator(1.6f)
            addUpdateListener { anim -> pinAnimScale = anim.animatedValue as Float }
            start()
        }
    }

    private fun animateProjectionTo(target3D: Boolean) {
        if (is3DMode == target3D) return
        is3DMode = target3D
        blendAnimator?.cancel()
        blendAnimator = ValueAnimator.ofFloat(projBlend, if (target3D) 1f else 0f).apply {
            duration = 420L
            interpolator = AnimHelper.EASE_OUT_EXPO
            addUpdateListener { anim -> projBlend = anim.animatedValue as Float }
            start()
        }
    }

    fun toggle3D2DWithAnimation(): Boolean {
        animateProjectionTo(!is3DMode)
        return is3DMode
    }

    fun recenterLockDrone() {
        camPanX = 0f
        camPanY = 0f
        followMode = 1
    }

    fun cycleFollowMode(): Pair<Int, String> {
        followMode = when (followMode) {
            1 -> {
                camPanX = 0f; camPanY = 0f
                camPitchDesired = 0.44f
                2
            }
            2 -> {
                val s = hub.latestSnapshot
                camPanX = s.uavX
                camPanY = s.uavY
                0
            }
            else -> {
                camPanX = 0f; camPanY = 0f
                camPitchDesired = 0.62f
                1
            }
        }
        val tip = when (followMode) {
            2 -> "相机视角：机头低仰角追尾 (直观体验膨胀体素透视与虚线)"
            0 -> "相机视角：自由平移漫游 (双击屏幕可回中飞机)"
            else -> "相机视角：阻尼锁定飞机 · 360° 自由环视"
        }
        return followMode to tip
    }

    fun zoomBy(factor: Float) {
        worldHalfSpanDesired = (worldHalfSpanDesired / factor).coerceIn(2.2f, 65.0f)
    }

    fun resetCameraSmooth() {
        followMode = 1
        camYawDesired = 0.62f
        camPitchDesired = 0.62f
        worldHalfSpanDesired = 6.6f
        camPanX = 0f
        camPanY = 0f
        animateProjectionTo(true)
    }

    fun cycleColorMode(): Pair<Int, String> {
        val next = (hub.pointColorMode + 1) % 3
        hub.pointColorMode = next
        val tip = when (next) {
            1 -> "点云着色：LiDAR 反射率强度伪彩"
            2 -> "点云着色：战术翠绿高对比单色"
            else -> "点云着色：Z 轴高度彩虹伪彩"
        }
        return next to tip
    }

    fun spawnRipple(wx: Float, wy: Float) {
        synchronized(rippleLock) {
            for (i in rippleAge.indices) {
                if (rippleAge[i] < 0f || rippleAge[i] > 1.15f) {
                    rippleX[i] = wx
                    rippleY[i] = wy
                    rippleAge[i] = 0f
                    return
                }
            }
            rippleX[0] = wx; rippleY[0] = wy; rippleAge[0] = 0f
        }
    }

    private fun unprojectToGroundUiThread(sx: Float, sy: Float): FloatArray? {
        val vw = max(1, width).toFloat()
        val vh = max(1, height).toFloat()
        val ndcX = (sx / vw) * 2f - 1f
        val ndcY = 1f - (sy / vh) * 2f

        synchronized(invVpLock) {
            if (!invVpValid) return null
            System.arraycopy(sharedInvVp, 0, uiInvCopy16, 0, 16)
        }

        uiNearIn4[0] = ndcX; uiNearIn4[1] = ndcY; uiNearIn4[2] = -1f; uiNearIn4[3] = 1f
        uiFarIn4[0] = ndcX; uiFarIn4[1] = ndcY; uiFarIn4[2] = 1f; uiFarIn4[3] = 1f
        Matrix.multiplyMV(uiNearOut4, 0, uiInvCopy16, 0, uiNearIn4, 0)
        Matrix.multiplyMV(uiFarOut4, 0, uiInvCopy16, 0, uiFarIn4, 0)
        if (abs(uiNearOut4[3]) < 1e-6f || abs(uiFarOut4[3]) < 1e-6f) return null

        val nx = uiNearOut4[0] / uiNearOut4[3]
        val ny = uiNearOut4[1] / uiNearOut4[3]
        val nz = uiNearOut4[2] / uiNearOut4[3]
        val fx = uiFarOut4[0] / uiFarOut4[3]
        val fy = uiFarOut4[1] / uiFarOut4[3]
        val fz = uiFarOut4[2] / uiFarOut4[3]

        val dz = fz - nz
        if (abs(dz) < 1e-5f) return null
        val t = -nz / dz
        if (t < 0f || t > 1.5f) return null

        val wx = nx + t * (fx - nx)
        val wy = ny + t * (fy - ny)
        if (!hub.isRosMode) {
            uiGroundOut2[0] = wx.coerceIn(-7.6f, 7.6f)
            uiGroundOut2[1] = wy.coerceIn(-7.6f, 7.6f)
        } else {
            uiGroundOut2[0] = wx.coerceIn(-500f, 500f)
            uiGroundOut2[1] = wy.coerceIn(-500f, 500f)
        }
        return uiGroundOut2
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.038f, 0.048f, 0.065f, 1.0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        progSky = buildProgram(SKY_VS, SKY_FS)
        aSkyPos = GLES20.glGetAttribLocation(progSky, "aNdcPos")
        uSkyHorizonY = GLES20.glGetUniformLocation(progSky, "uHorizonY")
        uSkyBlend3D = GLES20.glGetUniformLocation(progSky, "uBlend3D")
        uSkyFlat = GLES20.glGetUniformLocation(progSky, "uSkyFlat")
        uSkyZenith = GLES20.glGetUniformLocation(progSky, "uSkyZenith")
        uSkyHorizon = GLES20.glGetUniformLocation(progSky, "uSkyHorizon")
        uSkyGround = GLES20.glGetUniformLocation(progSky, "uSkyGround")

        progCloud = buildProgram(POINT_CLOUD_VS, POINT_CLOUD_FS)
        uCloudMvp = GLES20.glGetUniformLocation(progCloud, "uMVP")
        uCloudZMax = GLES20.glGetUniformLocation(progCloud, "uZMax")
        uCloudPointScale = GLES20.glGetUniformLocation(progCloud, "uPointScale")
        uCloudZFlatten = GLES20.glGetUniformLocation(progCloud, "uZFlatten")
        uCloudColorMode = GLES20.glGetUniformLocation(progCloud, "uColorMode")
        uCloudEyePos = GLES20.glGetUniformLocation(progCloud, "uEyePos")
        uCloudDronePos = GLES20.glGetUniformLocation(progCloud, "uDronePos")
        uCloudFogSpan = GLES20.glGetUniformLocation(progCloud, "uFogSpan")
        uCloudXrayOn = GLES20.glGetUniformLocation(progCloud, "uXrayOn")
        uCloudFogColor = GLES20.glGetUniformLocation(progCloud, "uFogColor")
        aCloudPos = GLES20.glGetAttribLocation(progCloud, "aPos")
        aCloudMeta = GLES20.glGetAttribLocation(progCloud, "aMeta")

        progPrim = buildProgram(PRIM_VS, PRIM_FS)
        uPrimMvp = GLES20.glGetUniformLocation(progPrim, "uMVP")
        uPrimFocusXY = GLES20.glGetUniformLocation(progPrim, "uFocusXY")
        uPrimFogSpan = GLES20.glGetUniformLocation(progPrim, "uFogSpan")
        uPrimFogColor = GLES20.glGetUniformLocation(progPrim, "uFogColor")
        aPrimPos = GLES20.glGetAttribLocation(progPrim, "aPos")
        aPrimColor = GLES20.glGetAttribLocation(progPrim, "aColor")
        aPrimArc = GLES20.glGetAttribLocation(progPrim, "aArc")

        progOccluded = buildProgram(OCCLUDED_VS, OCCLUDED_FS)
        uOccMvp = GLES20.glGetUniformLocation(progOccluded, "uMVP")
        uOccTime = GLES20.glGetUniformLocation(progOccluded, "uTime")
        aOccPos = GLES20.glGetAttribLocation(progOccluded, "aPos")
        aOccColor = GLES20.glGetAttribLocation(progOccluded, "aColor")
        aOccArc = GLES20.glGetAttribLocation(progOccluded, "aArc")

        val bufs = IntArray(9)
        GLES20.glGenBuffers(9, bufs, 0)
        vboCloudId = bufs[0]
        vboGroundLineId = bufs[1]
        vboSolidTriId = bufs[2]
        vboSolidEdgeId = bufs[3]
        vboGlassTriId = bufs[4]
        vboGlassEdgeId = bufs[5]
        vboFxTriId = bufs[6]
        vboActorLineId = bufs[7]
        vboActorTriId = bufs[8]

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboCloudId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, FastLioVoxelMap.MAX_POINTS * FastLioVoxelMap.BYTES_PER_VERTEX, null, GLES20.GL_DYNAMIC_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboGroundLineId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ENV_LINE_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboSolidTriId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ENV_TRI_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboSolidEdgeId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ENV_LINE_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboGlassTriId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_GLASS_TRI_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboGlassEdgeId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_GLASS_LINE_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboFxTriId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_FX_TRI_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ACTOR_LINE_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, MAX_ACTOR_TRI_VERTS * STRIDE_VERT, null, GLES20.GL_STREAM_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        voxelMap.notifyGlContextRecreated()
        lastFrameNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportW = max(1, width)
        viewportH = max(1, height)
        GLES20.glViewport(0, 0, viewportW, viewportH)
    }

    override fun onDrawFrame(gl: GL10?) {
        val frameStartNs = System.nanoTime()
        val rawDt = (frameStartNs - lastFrameNs) * 1e-9f
        val dt = rawDt.coerceIn(0.001f, 0.05f)
        lastFrameNs = frameStartNs
        shaderClockSec = (shaderClockSec + dt) % 3600f

        fpsFrameCount++
        fpsTimeAcc += rawDt
        if (fpsTimeAcc >= 0.5f) {
            hub.renderFps = (fpsFrameCount / fpsTimeAcc).roundToInt().coerceIn(1, 120)
            fpsFrameCount = 0
            fpsTimeAcc = 0f
        }

        val snap = hub.latestSnapshot
        stepThemeAtmosphereBlend(dt)
        updateCameraMatrices(dt, snap)

        GLES20.glClearColor(curSkyFlat[0], curSkyFlat[1], curSkyFlat[2], 1.0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        // Pass 0: 3D 天际大气渐变背景穹顶
        drawSkyDomePass()

        groundLineVerts = 0
        solidObsTriVerts = 0
        solidObsEdgeVerts = 0
        glassObsTriVerts = 0
        glassObsEdgeVerts = 0
        fxAlphaTriVerts = 0
        actorLineVerts = 0
        actorTriVerts = 0

        buildSceneBatches(dt, snap)

        val zFlat = 0.08f + 0.92f * projBlend

        // Pass 1: 地面透视网格与世界参考系 (专属 vboGroundLineId)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDepthMask(false)
        flushEnvLines(vboGroundLineId, groundLineArray, groundLineVerts, max(1f, 1.15f * density))

        // Pass 2: 写入硬件 Z-Buffer 的三维遮挡层 (专属 vboSolidTriId / vboSolidEdgeId + 点云 + vboGlassTriId / vboGlassEdgeId)
        GLES20.glDepthMask(true)
        flushEnvTriangles(vboSolidTriId, solidObsTriArray, solidObsTriVerts)
        flushEnvLines(vboSolidEdgeId, solidObsEdgeArray, solidObsEdgeVerts, max(1f, 1.05f * density))

        val cloudVerts = voxelMap.syncToGpuVbo(vboCloudId)
        val pMode = hub.perfMode
        val drawCloudCnt = if (pMode == 2) min(cloudVerts, 90_000) else cloudVerts
        if (hub.showFastLioMap && drawCloudCnt > 0) {
            GLES20.glUseProgram(progCloud)
            GLES20.glUniformMatrix4fv(uCloudMvp, 1, false, vpMatrix, 0)
            GLES20.glUniform1f(uCloudZMax, hub.zSliceMax)
            val fovScale = (viewportH / 720f).coerceAtLeast(0.75f) * 34.0f * hub.pointSizeScale * density
            GLES20.glUniform1f(uCloudPointScale, fovScale * (0.35f + 0.65f * projBlend))
            GLES20.glUniform1f(uCloudZFlatten, zFlat)
            GLES20.glUniform1i(uCloudColorMode, hub.pointColorMode)
            GLES20.glUniform3f(uCloudEyePos, curEyeX, curEyeY, curEyeZ)
            GLES20.glUniform3f(uCloudDronePos, snap.uavX, snap.uavY, snap.uavZ * zFlat)
            GLES20.glUniform1f(uCloudFogSpan, worldHalfSpan * 2.2f)
            GLES20.glUniform1i(uCloudXrayOn, if (hub.xrayOcclusionEnabled) 1 else 0)
            GLES20.glUniform3f(uCloudFogColor, curFogRgb[0], curFogRgb[1], curFogRgb[2])

            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboCloudId)
            GLES20.glEnableVertexAttribArray(aCloudPos)
            GLES20.glVertexAttribPointer(aCloudPos, 3, GLES20.GL_FLOAT, false, FastLioVoxelMap.BYTES_PER_VERTEX, 0)
            GLES20.glEnableVertexAttribArray(aCloudMeta)
            GLES20.glVertexAttribPointer(aCloudMeta, 1, GLES20.GL_FLOAT, false, FastLioVoxelMap.BYTES_PER_VERTEX, 12)

            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, drawCloudCnt)

            GLES20.glDisableVertexAttribArray(aCloudPos)
            GLES20.glDisableVertexAttribArray(aCloudMeta)
        }

        // 处于「相机->无人机 / 前方轨迹」视线隧道内的膨胀体素：呈现磨砂全息透视方块 + 青色微光棱线
        if (glassObsTriVerts > 0) {
            flushEnvTriangles(vboGlassTriId, glassObsTriArray, glassObsTriVerts)
            flushEnvLines(vboGlassEdgeId, glassObsEdgeArray, glassObsEdgeVerts, max(1.1f, 1.25f * density))
        }

        uploadActorVbos()

        // Pass 3: 硬件深度逆测试 GL_GREATER 遮挡 X-Ray 遍 (被膨胀体素地图或点云遮挡的轨迹段自动变流动虚线)
        if (hub.xrayOcclusionEnabled) {
            GLES20.glDepthFunc(GLES20.GL_GREATER)
            GLES20.glDepthMask(false)
            drawActorBatchesOccluded(max(1.2f, 1.5f * density))
        }

        // Pass 4: 标准 GL_LEQUAL 可见前景遍
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDepthMask(true)
        drawActorBatchesVisible(max(1.2f, 1.5f * density))

        // Pass 5: 半透明高程垂幕与地面波纹 (专属 vboFxTriId)
        GLES20.glDepthMask(false)
        flushEnvTriangles(vboFxTriId, fxAlphaTriArray, fxAlphaTriVerts)
        GLES20.glDepthMask(true)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

        val hudInterval = if (pMode == 2) 0.140f else 0.095f
        hudSyncAcc += dt
        if (hudSyncAcc >= hudInterval) {
            hudSyncAcc = 0f
            post(uiTickRunnable)
        }

        val workMs = ((System.nanoTime() - frameStartNs) * 1e-6f).coerceIn(0.05f, 50f)
        hub.frameRenderMs += (workMs - hub.frameRenderMs) * 0.16f
        if (pMode == 2 && workMs < 29.5f) {
            SystemClock.sleep((31.0f - workMs).toLong().coerceIn(1L, 18L))
        }
    }

    private fun stepThemeAtmosphereBlend(dt: Float) {
        val pal = GcsTheme.of(hub.themeId)
        val k = if (!themeInitialized) {
            themeInitialized = true
            1.0f
        } else {
            1.0f - exp(-dt * 9.0f)
        }
        for (i in 0..2) {
            curSkyFlat[i] += (pal.glSkyFlat[i] - curSkyFlat[i]) * k
            curSkyZenith[i] += (pal.glSkyZenith[i] - curSkyZenith[i]) * k
            curSkyHorizon[i] += (pal.glSkyHorizon[i] - curSkyHorizon[i]) * k
            curSkyGround[i] += (pal.glSkyGround[i] - curSkyGround[i]) * k
            curFogRgb[i] += (pal.glFog[i] - curFogRgb[i]) * k
            curGridRgb[i] += (pal.glGridRgb[i] - curGridRgb[i]) * k
        }
        curGridMajorAlpha += (pal.glGridMajorAlpha - curGridMajorAlpha) * k
        curGridMinorAlpha += (pal.glGridMinorAlpha - curGridMinorAlpha) * k
    }

    private fun drawSkyDomePass() {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(progSky)
        val horizonUvY = (0.92f - camPitch * 0.34f).coerceIn(0.42f, 0.92f)
        GLES20.glUniform1f(uSkyHorizonY, horizonUvY)
        GLES20.glUniform1f(uSkyBlend3D, projBlend)
        GLES20.glUniform3f(uSkyFlat, curSkyFlat[0], curSkyFlat[1], curSkyFlat[2])
        GLES20.glUniform3f(uSkyZenith, curSkyZenith[0], curSkyZenith[1], curSkyZenith[2])
        GLES20.glUniform3f(uSkyHorizon, curSkyHorizon[0], curSkyHorizon[1], curSkyHorizon[2])
        GLES20.glUniform3f(uSkyGround, curSkyGround[0], curSkyGround[1], curSkyGround[2])

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        skyQuadBuf.position(0)
        GLES20.glEnableVertexAttribArray(aSkyPos)
        GLES20.glVertexAttribPointer(aSkyPos, 2, GLES20.GL_FLOAT, false, 0, skyQuadBuf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aSkyPos)
    }

    fun focusWorldPointSmooth(wx: Float, wy: Float) {
        followMode = 0
        camPanX = wx
        camPanY = wy
        spawnRipple(wx, wy)
        onFollowStateChanged(0, null)
    }

    private fun updateCameraMatrices(dt: Float, snap: RenderSnapshot) {
        val damp = hub.cameraDampingScale.coerceIn(0.45f, 2.0f)
        val kRot = 1f - exp(-dt * 10.5f * damp)
        val kZoom = 1f - exp(-dt * 13.0f * damp)

        if (followMode == 2) {
            val chaseYaw = snap.yaw - PI.toFloat() * 0.5f
            var diff = chaseYaw - camYaw
            while (diff > PI.toFloat()) diff -= (PI * 2.0).toFloat()
            while (diff < -PI.toFloat()) diff += (PI * 2.0).toFloat()
            camYaw += diff * (1f - exp(-dt * 6.5f))
            camYawDesired = camYaw
        } else {
            camYaw += (camYawDesired - camYaw) * kRot
        }
        camPitch += (camPitchDesired - camPitch) * kRot
        worldHalfSpan += (worldHalfSpanDesired - worldHalfSpan) * kZoom

        val b = projBlend
        val desFX = if (followMode != 0) snap.uavX + camPanX else camPanX
        val desFY = if (followMode != 0) snap.uavY + camPanY else camPanY
        val desFZ = if (followMode != 0) (snap.uavZ * 0.45f) * b else 0f
        val kPos = 1f - exp(-dt * 11.5f * damp)
        camFocusX += (desFX - camFocusX) * kPos
        camFocusY += (desFY - camFocusY) * kPos
        camFocusZ += (desFZ - camFocusZ) * kPos

        val effYaw = camYaw * b
        val effPitch = 1.568f * (1f - b) + camPitch * b
        val fovYDeg = 4.2f + 41.8f * b
        val halfFovRad = Math.toRadians((fovYDeg * 0.5f).toDouble()).toFloat()
        val camDist = worldHalfSpan / max(0.02f, tan(halfFovRad))

        val horizBack = camDist * cos(effPitch)
        curEyeX = camFocusX + sin(effYaw) * horizBack
        curEyeY = camFocusY - cos(effYaw) * horizBack
        curEyeZ = camFocusZ + camDist * sin(effPitch)

        Matrix.setLookAtM(
            viewMatrix, 0,
            curEyeX, curEyeY, curEyeZ,
            camFocusX, camFocusY, camFocusZ,
            0f, 0f, 1f
        )

        val aspect = viewportW.toFloat() / max(1f, viewportH.toFloat())
        val nearClip = max(0.25f, camDist * 0.04f)
        val farClip = camDist * 8.5f + 260f
        Matrix.perspectiveM(projMatrix, 0, fovYDeg, aspect, nearClip, farClip)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        if (Matrix.invertM(glTmpInv16, 0, vpMatrix, 0)) {
            synchronized(invVpLock) {
                System.arraycopy(glTmpInv16, 0, sharedInvVp, 0, 16)
                invVpValid = true
            }
        }

        synchronized(rippleLock) {
            for (i in rippleAge.indices) {
                if (rippleAge[i] >= 0f) {
                    rippleAge[i] += dt
                    if (rippleAge[i] > 1.15f) rippleAge[i] = -1f
                }
            }
        }
    }

    /**
     * 预计算视线向量后的平方距离快速剔除函数：
     * 先用无开方的平方距离过滤掉 97% 处于视线走廊外的体素，仅对走廊内极少数体素调用 sqrt 计算柔化过渡。
     */
    private fun distanceSqToPrecompSeg(
        px: Float, py: Float, pz: Float,
        sx: Float, sy: Float, sz: Float, invLen2: Float
    ): Float {
        if (invLen2 <= 0f) return 9999f
        val t = ((px - curEyeX) * sx + (py - curEyeY) * sy + (pz - curEyeZ) * sz) * invLen2
        if (t <= 0.05f || t >= 0.96f) return 9999f
        val cx = curEyeX + t * sx - px
        val cy = curEyeY + t * sy - py
        val cz = curEyeZ + t * sz - pz
        return cx * cx + cy * cy + cz * cz
    }

    private fun distanceFromSightRayToColumn(
        cx: Float, cy: Float, rx: Float, ry: Float, zBottom: Float, zTop: Float, isCircle: Boolean,
        uavX: Float, uavY: Float, uavZ: Float
    ): Float {
        val vxRay = uavX - curEyeX
        val vyRay = uavY - curEyeY
        val horizLen2 = vxRay * vxRay + vyRay * vyRay
        if (horizLen2 < 0.05f) return 99f

        val s = (((cx - curEyeX) * vxRay + (cy - curEyeY) * vyRay) / horizLen2).coerceIn(0.06f, 0.96f)
        val px = curEyeX + s * vxRay
        val py = curEyeY + s * vyRay
        val pz = curEyeZ + s * (uavZ - curEyeZ)

        val d2d = if (isCircle) {
            hypot(px - cx, py - cy) - rx
        } else {
            val dx = abs(px - cx) - rx
            val dy = abs(py - cy) - ry
            hypot(max(dx, 0f), max(dy, 0f)) + min(max(dx, dy), 0f)
        }
        val dz = when {
            pz > zTop -> pz - zTop
            pz < zBottom -> zBottom - pz
            else -> 0f
        }
        return hypot(max(0f, d2d), dz)
    }

    /**
     * RViz AxisColor 经典三维膨胀占据地图高度彩虹色谱 (蓝青 -> 翠绿 -> 琥珀 -> 珊瑚橙)
     */
    private fun computeInflateVoxelColor(vzRaw: Float, zMax: Float, inLocalWindow: Boolean, outRgb: FloatArray) {
        val t = (vzRaw / max(0.8f, zMax * 0.85f)).coerceIn(0f, 1f)
        var r: Float
        var g: Float
        var b: Float
        if (t < 0.35f) {
            val u = t / 0.35f
            r = 0.10f + (0.06f - 0.10f) * u
            g = 0.56f + (0.86f - 0.56f) * u
            b = 0.96f + (0.58f - 0.96f) * u
        } else if (t < 0.72f) {
            val u = (t - 0.35f) / 0.37f
            r = 0.06f + (0.98f - 0.06f) * u
            g = 0.86f + (0.72f - 0.86f) * u
            b = 0.58f + (0.14f - 0.58f) * u
        } else {
            val u = (t - 0.72f) / 0.28f
            r = 0.98f + (1.00f - 0.98f) * u
            g = 0.72f + (0.30f - 0.72f) * u
            b = 0.14f + (0.22f - 0.14f) * u
        }
        val boost = if (inLocalWindow) 1.0f else 0.74f
        outRgb[0] = r * boost
        outRgb[1] = g * boost
        outRgb[2] = b * boost
    }

    private fun buildSceneBatches(dt: Float, snap: RenderSnapshot) {
        val b = projBlend
        val zScale = 0.08f + 0.92f * b
        val uavScaledZ = snap.uavZ * zScale

        // 1. 透视地面网格与世界原点三维 XYZ 参考轴 (支持在系统设置中独立开关)
        if (hub.showGroundGrid) {
            val anchorX = floor(camFocusX / 4f) * 4f
            val anchorY = floor(camFocusY / 4f) * 4f
            val halfGrid = 14
            for (g in -halfGrid..halfGrid) {
                val gx = anchorX + g
                val gy = anchorY + g
                val majorX = (abs(gx.toInt()) % 4 == 0)
                val majorY = (abs(gy.toInt()) % 4 == 0)
                val fade = (1f - (abs(g) / 15.0f) * (abs(g) / 15.0f)).coerceAtLeast(0.12f)
                val aX = (if (majorX) curGridMajorAlpha else curGridMinorAlpha) * fade
                val aY = (if (majorY) curGridMajorAlpha else curGridMinorAlpha) * fade
                pushGroundLine(gx, anchorY - halfGrid, 0f, gx, anchorY + halfGrid, 0f, curGridRgb[0], curGridRgb[1], curGridRgb[2], aX)
                pushGroundLine(anchorX - halfGrid, gy, 0f, anchorX + halfGrid, gy, 0f, curGridRgb[0], curGridRgb[1], curGridRgb[2], aY)
            }
            pushGroundLine(0f, 0f, 0.008f, 1.1f, 0f, 0.008f, 1.0f, 0.30f, 0.28f, 0.65f)
            pushGroundLine(0f, 0f, 0.008f, 0f, 1.1f, 0.008f, 0.15f, 0.92f, 0.50f, 0.65f)
            if (b > 0.05f) {
                pushGroundLine(0f, 0f, 0.008f, 0f, 0f, 1.1f * zScale, 0.25f, 0.68f, 1.0f, 0.65f * b)
            }
        }

        drawHomePad3D(snap.homeX, snap.homeY)

        pushGroundCircle(snap.uavX, snap.uavY, 0.012f, 2.0f, 36, 0f, 0.90f, 0.46f, 0.22f)
        pushGroundCircle(snap.uavX, snap.uavY, 0.012f, 4.0f, 44, 1f, 1f, 1f, 0.10f)
        val fovL = snap.yaw + 0.56f
        val fovR = snap.yaw - 0.56f
        pushFxTri(
            snap.uavX, snap.uavY, 0.014f,
            snap.uavX + cos(fovL) * 3.8f, snap.uavY + sin(fovL) * 3.8f, 0.014f,
            snap.uavX + cos(fovR) * 3.8f, snap.uavY + sin(fovR) * 3.8f, 0.014f,
            0f, 0.90f, 0.46f, 0.075f
        )

        if (hub.showLocalBox) {
            pushGroundDashedRect(snap.uavX - 4f, snap.uavY - 4f, snap.uavX + 4f, snap.uavY + 4f, 0.018f, 0.09f, 0.56f, 1.0f, 0.45f)
        }

        synchronized(rippleLock) {
            for (i in rippleAge.indices) {
                val age = rippleAge[i]
                if (age >= 0f) {
                    val prog = (age / 1.15f).coerceIn(0f, 1f)
                    val rad = 0.22f + prog * 1.48f
                    val alpha = (1f - prog) * 0.82f
                    pushFxRingXY(rippleX[i], rippleY[i], 0.025f, rad, 0.045f, 28, 0f, 0.88f, 1.0f, alpha)
                }
            }
        }

        var droneBlockedThisFrame = false
        val xrayActive = (b > 0.15f && hub.xrayOcclusionEnabled)

        // 前瞻轨迹中点视线辅助锚点 (当膨胀障碍墙挡住前方规划拐弯轨迹时，同样对膨胀体素开启局部透视窗！)
        val hasAheadTrajProbe = snap.bsplineCount > 6
        val probeIdx = (snap.bsplineCount / 2).coerceIn(0, max(0, snap.bsplineCount - 1)) * 3
        val aheadX = if (hasAheadTrajProbe) snap.bsplinePts[probeIdx] else snap.uavX
        val aheadY = if (hasAheadTrajProbe) snap.bsplinePts[probeIdx + 1] else snap.uavY
        val aheadZ = if (hasAheadTrajProbe) snap.bsplinePts[probeIdx + 2] * zScale else uavScaledZ

        // 2. EGO-Planner 三维膨胀占据体素地图 (/grid_map/occupancy_inflate) 视锥剔除 + 平方距离视线隧道透视
        val vCnt = snap.voxelCount
        if (hub.showInflate && vCnt > 0) {
            val cullSpan = worldHalfSpan * 2.9f + 4.5f
            val vArr = snap.voxels
            val zMax = hub.zSliceMax
            val maxVoxBudget = when (hub.perfMode) {
                1 -> 4096
                2 -> 1400
                else -> 2800
            }
            val farStride = if (vCnt > maxVoxBudget) max(1, (vCnt + maxVoxBudget - 1) / maxVoxBudget) else 1

            // 预提取齐次裁剪矩阵分量，单次乘加剔除屏幕视锥外体素
            val m0 = vpMatrix[0]; val m4 = vpMatrix[4]; val m8 = vpMatrix[8]; val m12 = vpMatrix[12]
            val m1 = vpMatrix[1]; val m5 = vpMatrix[5]; val m9 = vpMatrix[9]; val m13 = vpMatrix[13]
            val m3 = vpMatrix[3]; val m7 = vpMatrix[7]; val m11 = vpMatrix[11]; val m15 = vpMatrix[15]

            // 预计算视线线段向量与逆长度平方
            val s1x = snap.uavX - curEyeX
            val s1y = snap.uavY - curEyeY
            val s1z = uavScaledZ - curEyeZ
            val s1Len2 = s1x * s1x + s1y * s1y + s1z * s1z
            val invS1Len2 = if (s1Len2 > 0.20f) 1.0f / s1Len2 else 0f

            val s2x = aheadX - curEyeX
            val s2y = aheadY - curEyeY
            val s2z = aheadZ - curEyeZ
            val s2Len2 = s2x * s2x + s2y * s2y + s2z * s2z
            val invS2Len2 = if (hasAheadTrajProbe && s2Len2 > 0.20f) 1.0f / s2Len2 else 0f

            for (i in 0 until vCnt) {
                val idx = i * 4
                val signedHalf = vArr[idx + 3]
                val inLocal = signedHalf > 0f
                if (!inLocal && farStride > 1 && (i % farStride != 0)) continue

                val vx = vArr[idx]
                val vy = vArr[idx + 1]
                if (abs(vx - camFocusX) > cullSpan || abs(vy - camFocusY) > cullSpan) continue

                val vzRaw = vArr[idx + 2]
                val hw = abs(signedHalf).coerceIn(0.04f, 0.20f)
                val vzCenter = vzRaw * zScale

                val wClip = m3 * vx + m7 * vy + m11 * vzCenter + m15
                val padClip = hw * 3.2f + 0.48f
                if (wClip < -padClip) continue
                val xClip = m0 * vx + m4 * vy + m8 * vzCenter + m12
                if (abs(xClip) > wClip + padClip) continue
                val yClip = m1 * vx + m5 * vy + m9 * vzCenter + m13
                if (abs(yClip) > wClip + padClip) continue

                val hh = hw * zScale
                val z0 = max(0.006f, vzCenter - hh)
                val z1 = vzCenter + hh

                computeInflateVoxelColor(vzRaw, zMax, inLocal, tmpVoxelRgb)

                var intoGlass = false
                var vAlpha = if (inLocal) 0.90f else 0.78f

                if (xrayActive) {
                    val dDroneSq = distanceSqToPrecompSeg(vx, vy, vzCenter, s1x, s1y, s1z, invS1Len2)
                    val blockR = hw * 1.65f + 0.14f
                    if (dDroneSq < blockR * blockR) {
                        droneBlockedThisFrame = true
                    }
                    val dAheadScaledSq = if (invS2Len2 > 0f) {
                        distanceSqToPrecompSeg(vx, vy, vzCenter, s2x, s2y, s2z, invS2Len2) * 1.4884f
                    } else 9999f

                    val minSq = min(dDroneSq, dAheadScaledSq)
                    val outerR = 0.88f + hw
                    if (minSq < outerR * outerR) {
                        intoGlass = true
                        val dMin = sqrt(minSq)
                        val innerR = 0.28f + hw
                        val t = ((dMin - innerR) / max(0.15f, outerR - innerR)).coerceIn(0f, 1f)
                        val smooth = t * t * (3f - 2f * t)
                        vAlpha = 0.15f + 0.73f * smooth
                    }
                }

                pushInflatedVoxel3Face(
                    vx, vy, z0, z1, hw,
                    tmpVoxelRgb[0], tmpVoxelRgb[1], tmpVoxelRgb[2],
                    vAlpha, intoGlass, b
                )
            }
        }

        // 可选几何内芯参考 (仅当用户在图层页手动开启时渲染)
        val kAlpha = 1f - exp(-dt * 10.5f)
        val obCnt = snap.obsPrimitiveCount
        val obArr = snap.obsPrimitives
        for (i in 0 until obCnt) {
            val base = i * 6
            val cx = obArr[base]
            val cy = obArr[base + 1]
            val rx = obArr[base + 2]
            val ry = obArr[base + 3]
            val h = obArr[base + 4] * zScale
            val isCyl = obArr[base + 5] > 0.5f

            val dSight = if (xrayActive) {
                distanceFromSightRayToColumn(cx, cy, rx, ry, 0f, h, isCyl, snap.uavX, snap.uavY, uavScaledZ)
            } else 99f
            if (dSight < 0.22f) droneBlockedThisFrame = true

            val targetAlpha = if (dSight < 0.52f) 0.22f + (dSight / 0.52f).coerceIn(0f, 1f) * 0.72f else 0.94f
            obsSmoothAlpha[i] += (targetAlpha - obsSmoothAlpha[i]) * kAlpha
            val curA = obsSmoothAlpha[i]
            val intoGlassPass = curA < 0.86f
            if (isCyl) {
                pushLit3DCylinder(cx, cy, rx, h, 18, curA, intoGlassPass, b)
            } else {
                pushLit3DBox(cx, cy, rx, ry, 0f, h, curA, intoGlassPass, b, drawHeightTicks = true)
            }
        }

        hub.droneCurrentlyOccluded = droneBlockedThisFrame
        val targetOccBlend = if (droneBlockedThisFrame) 1f else 0f
        droneOccludedBlend += (targetOccBlend - droneOccludedBlend) * (1f - exp(-dt * 9.0f))

        // 3. 历史航迹与 FAST-LIO 里程计全局路径 (归入 Actor 批次：被膨胀体素遮挡段自动变流动虚线)
        if (hub.showFlightTrail && snap.lioPathCount > 1) {
            pushActorRibbon3D(snap.lioPathPts, snap.lioPathCount, zScale, 0.036f, 0.16f, 0.76f, 1.0f, 0.88f)
        }
        if (hub.showFlightTrail && snap.trailCount > 1) {
            pushActorPolyline3D(snap.trailPts, snap.trailCount, zScale, 0.80f, 0.88f, 0.98f, 0.48f)
        }
        if (snap.astarCount > 1) {
            pushActorPolyline3D(snap.astarPts, snap.astarCount, 0.02f, 0.18f, 0.65f, 1.0f, 0.62f, fixedZ = 0.03f)
        }

        // 4. EGO-Planner 三维 B 样条轨迹 + 高程垂幕 + 被膨胀体素挡住时自动呈现流动虚线
        if (snap.bsplineCount > 1) {
            val pts = snap.bsplinePts
            if (hub.showTrajCurtain && b > 0.08f) {
                pushAltitudeCurtain(pts, snap.bsplineCount, zScale, 0.0f, 0.90f, 0.48f, 0.16f * b)
            }
            pushActorRibbon3D(pts, snap.bsplineCount, zScale, 0.052f, 0f, 0.94f, 0.50f, 0.98f)

            val shift = ((SystemClock.uptimeMillis() / 60L) % 8L).toInt()
            var chv = 4 + shift
            while (chv < snap.bsplineCount - 2) {
                val bp = (chv - 1) * 3; val bn = (chv + 1) * 3
                val x0 = pts[bp]; val y0 = pts[bp + 1]
                val x1 = pts[bn]; val y1 = pts[bn + 1]; val z1 = pts[bn + 2] * zScale + 0.018f
                val dx = x1 - x0; val dy = y1 - y0
                val len = hypot(dx, dy)
                if (len > 1e-4f) {
                    val ux = dx / len; val uy = dy / len
                    val px = -uy; val py = ux
                    val back = 0.16f; val wing = 0.12f
                    pushActorQuadSeg3D(x1 - ux * back + px * wing, y1 - uy * back + py * wing, z1, x1, y1, z1, 0.020f, 1f, 1f, 1f, 0.95f, -1f, -1f)
                    pushActorQuadSeg3D(x1 - ux * back - px * wing, y1 - uy * back - py * wing, z1, x1, y1, z1, 0.020f, 1f, 1f, 1f, 0.95f, -1f, -1f)
                }
                chv += 10
            }
        }

        if (snap.ctrlCount > 0) {
            for (c in 0 until snap.ctrlCount) {
                val bi = c * 3
                pushActorDiscXY(snap.ctrlPts[bi], snap.ctrlPts[bi + 1], snap.ctrlPts[bi + 2] * zScale + 0.02f, 0.052f, 8, 1f, 1f, 1f, 0.92f, -1f)
            }
        }

        // 5. 当前目标点立柱
        val gz = snap.goalZ * zScale
        if (b > 0.05f) {
            pushActorQuadSeg3D(snap.goalX, snap.goalY, 0.01f, snap.goalX, snap.goalY, gz, 0.022f, 0f, 0.92f, 0.48f, 0.85f, 0f, gz)
        }
        val pulseR = 0.24f + (sin(SystemClock.uptimeMillis() * 0.006).toFloat() + 1f) * 0.09f
        pushFxRingXY(snap.goalX, snap.goalY, 0.02f, pulseR, 0.035f, 20, 0f, 0.90f, 0.46f, 0.88f)
        val bob = sin(shaderClockSec * 3.4f) * 0.028f * b
        pushActorBeaconBox(snap.goalX, snap.goalY, gz + bob, 0.105f, 0f, 0.94f, 0.50f, 0.95f)

        // 6. 连续多航点航线链
        var lastRouteTipX = snap.uavX
        var lastRouteTipY = snap.uavY
        var lastRouteTipZ = uavScaledZ
        if (snap.waypointQueueCount > 0) {
            val isStaged = snap.isRouteStagedOnly
            var prevX = if (isStaged) snap.uavX else snap.goalX
            var prevY = if (isStaged) snap.uavY else snap.goalY
            var prevZ = if (isStaged) uavScaledZ else gz

            val lr = if (isStaged) 1.0f else 0.41f
            val lg = if (isStaged) 0.78f else 0.75f
            val lb = if (isStaged) 0.14f else 1.0f

            var cumRouteArc = 0f
            val wps = snap.waypointQueuePts
            for (w in 0 until snap.waypointQueueCount) {
                val wx = wps[w * 3]
                val wy = wps[w * 3 + 1]
                val wz = wps[w * 3 + 2] * zScale
                val segLen = hypot(hypot(wx - prevX, wy - prevY), wz - prevZ)
                pushActorQuadSeg3D(prevX, prevY, prevZ, wx, wy, wz, 0.030f, lr, lg, lb, 0.88f, cumRouteArc, cumRouteArc + segLen)
                cumRouteArc += segLen

                if (b > 0.05f) {
                    pushActorLine(wx, wy, 0.01f, wx, wy, wz, lr, lg, lb, 0.75f, 0f, wz)
                }
                pushFxRingXY(wx, wy, 0.02f, 0.21f, 0.032f, 18, lr, lg, lb, 0.85f)
                pushActorBeaconBox(wx, wy, wz, 0.092f, lr, lg, lb, 0.94f)
                prevX = wx; prevY = wy; prevZ = wz
            }
            if (snap.routeClosedLoop && snap.waypointQueueCount >= 2) {
                val fx = wps[0]
                val fy = wps[1]
                val fz = wps[2] * zScale
                val closeLen = hypot(hypot(fx - prevX, fy - prevY), fz - prevZ)
                pushActorLine(prevX, prevY, prevZ, fx, fy, fz, lr, lg, lb, 0.55f, cumRouteArc, cumRouteArc + closeLen)
            }
            if (isStaged) {
                lastRouteTipX = prevX; lastRouteTipY = prevY; lastRouteTipZ = prevZ
            }
        }

        // 7. 三维选点预览光柱
        if (snap.hasPreviewPin) {
            val animS = pinAnimScale
            val px = snap.previewX
            val py = snap.previewY
            val pz = snap.previewZ * zScale * animS.coerceAtLeast(0.1f)
            val pr = if (snap.previewSafe) 0.0f else 1.0f
            val pg = if (snap.previewSafe) 0.88f else 0.30f
            val pb = if (snap.previewSafe) 1.0f else 0.26f

            val linkLen = hypot(hypot(px - lastRouteTipX, py - lastRouteTipY), pz - lastRouteTipZ)
            pushActorQuadSeg3D(lastRouteTipX, lastRouteTipY, lastRouteTipZ, px, py, pz, 0.026f, pr, pg, pb, 0.86f, 0f, linkLen)

            if (b > 0.04f) {
                pushActorQuadSeg3D(px, py, 0.01f, px, py, pz, 0.028f, pr, pg, pb, 0.92f, 0f, pz)
                for (step in 1..3) {
                    val f = step / 4f
                    val rx = lastRouteTipX + (px - lastRouteTipX) * f
                    val ry = lastRouteTipY + (py - lastRouteTipY) * f
                    val rz = lastRouteTipZ + (pz - lastRouteTipZ) * f
                    pushGroundLine(rx, ry, 0.01f, rx, ry, rz, pr, pg, pb, 0.24f * b)
                }
            }
            val pinPulse = (0.26f + (sin(SystemClock.uptimeMillis() * 0.009).toFloat() + 1f) * 0.11f) * animS.coerceIn(0.4f, 1.2f)
            pushFxRingXY(px, py, 0.022f, pinPulse, 0.040f, 24, pr, pg, pb, 0.92f)
            pushGroundLine(px - 0.42f, py, 0.022f, px + 0.42f, py, 0.022f, pr, pg, pb, 0.78f)
            pushGroundLine(px, py - 0.42f, 0.022f, px, py + 0.42f, 0.022f, pr, pg, pb, 0.78f)
            pushActorBeaconBox(px, py, pz, 0.115f * animS.coerceIn(0.5f, 1.15f), pr, pg, pb, 0.96f)
        }

        // 8. 三维四旋翼无人机模型 + 遮挡状态下的全息脉冲定位环
        drawQuadrotor3D(snap, zScale, b)
    }

    /**
     * 高性能三面朝向剔除膨胀体素立方体绘制 (3-Face View-Culled Lit Inflated Voxel Cube)：
     * 每个膨胀体素仅向 VBO 压入朝向相机视点的 <=3 个可见面 (最多 18 顶点)，
     * 同时当进入视线透视玻璃态 (intoGlass=true) 时叠加全息微光顶框棱线，清晰保留膨胀边界轮廓感！
     */
    private fun pushInflatedVoxel3Face(
        cx: Float, cy: Float, z0: Float, z1: Float, hw: Float,
        baseR: Float, baseG: Float, baseB: Float,
        alpha: Float, intoGlass: Boolean, blend3D: Float
    ) {
        val x0 = cx - hw
        val x1 = cx + hw
        val y0 = cy - hw
        val y1 = cy + hw
        val cz = (z0 + z1) * 0.5f

        // 玻璃透视态向全息青色轻微偏移，强化「科技透视窗」质感
        val cr = if (intoGlass) (baseR * 0.55f + 0.08f) else baseR
        val cg = if (intoGlass) (baseG * 0.65f + 0.30f) else baseG
        val cb = if (intoGlass) (baseB * 0.65f + 0.35f) else baseB

        // 1. Z 轴朝向面 (顶面最亮 1.10x，底面背光 0.45x)
        if (curEyeZ >= cz) {
            pushObsQuadFlat(
                intoGlass,
                x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1,
                min(1f, cr * 1.10f), min(1f, cg * 1.10f), min(1f, cb * 1.08f), alpha
            )
        } else {
            pushObsQuadFlat(
                intoGlass,
                x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0,
                cr * 0.45f, cg * 0.45f, cb * 0.48f, alpha
            )
        }

        if (blend3D > 0.04f && z1 - z0 > 0.015f) {
            // 2. X 轴朝向面 (东面 +X 次亮 0.82x，西面 -X 背阴 0.58x)
            if (curEyeX >= cx) {
                pushObsQuadFlat(
                    intoGlass,
                    x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1,
                    cr * 0.82f, cg * 0.82f, cb * 0.84f, alpha
                )
            } else {
                pushObsQuadFlat(
                    intoGlass,
                    x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1,
                    cr * 0.58f, cg * 0.58f, cb * 0.62f, alpha
                )
            }

            // 3. Y 轴朝向面 (南面 -Y 向阳 0.96x，北面 +Y 深阴影 0.46x)
            if (curEyeY <= cy) {
                pushObsQuadFlat(
                    intoGlass,
                    x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1,
                    cr * 0.96f, cg * 0.96f, cb * 0.96f, alpha
                )
            } else {
                pushObsQuadFlat(
                    intoGlass,
                    x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1,
                    cr * 0.46f, cg * 0.46f, cb * 0.52f, alpha
                )
            }
        }

        // 透视玻璃态下勾勒体素顶面微光网格框，让飞手一眼看清膨胀后的立体边界厚度
        if (intoGlass && alpha < 0.55f) {
            val rimA = (0.48f - alpha * 0.4f).coerceIn(0.18f, 0.46f)
            pushObsEdge(true, x0, y0, z1 + 0.001f, x1, y0, z1 + 0.001f, 0.32f, 0.92f, 1.0f, rimA)
            pushObsEdge(true, x1, y0, z1 + 0.001f, x1, y1, z1 + 0.001f, 0.32f, 0.92f, 1.0f, rimA)
            pushObsEdge(true, x1, y1, z1 + 0.001f, x0, y1, z1 + 0.001f, 0.32f, 0.92f, 1.0f, rimA)
            pushObsEdge(true, x0, y1, z1 + 0.001f, x0, y0, z1 + 0.001f, 0.32f, 0.92f, 1.0f, rimA)
        }
    }

    private fun pushLit3DCylinder(
        cx: Float, cy: Float, rad: Float, height: Float, segs: Int,
        alpha: Float, intoGlass: Boolean, blend3D: Float
    ) {
        val baseR = if (intoGlass) 0.12f else 0.19f
        val baseG = if (intoGlass) 0.62f else 0.44f
        val baseB = if (intoGlass) 0.88f else 0.68f
        val roofR = (baseR * 1.32f).coerceAtMost(1f)
        val roofG = (baseG * 1.32f).coerceAtMost(1f)
        val roofB = (baseB * 1.28f).coerceAtMost(1f)

        var c0 = 1f
        var s0 = 0f
        for (s in 1..segs) {
            val lutIdx = (s * LUT_N) / segs
            val c1 = COS_LUT[lutIdx]
            val s1 = SIN_LUT[lutIdx]
            pushObsTri(intoGlass, cx, cy, height, cx + c0 * rad, cy + s0 * rad, height, cx + c1 * rad, cy + s1 * rad, height, roofR, roofG, roofB, alpha)
            if (blend3D > 0.04f && height > 0.03f) {
                val nx = (c0 + c1) * 0.5f
                val ny = (s0 + s1) * 0.5f
                val shade = (0.64f + 0.36f * (nx * 0.48f - ny * 0.62f)).coerceIn(0.32f, 1.05f)
                pushObsWallQuadAO(
                    intoGlass,
                    cx + c0 * rad, cy + s0 * rad, 0f,
                    cx + c1 * rad, cy + s1 * rad, 0f,
                    cx + c1 * rad, cy + s1 * rad, height,
                    cx + c0 * rad, cy + s0 * rad, height,
                    baseR * shade, baseG * shade, baseB * shade, alpha
                )
            }
            c0 = c1; s0 = s1
        }
    }

    private fun pushLit3DBox(
        cx: Float, cy: Float, rx: Float, ry: Float, z0: Float, z1: Float,
        alpha: Float, intoGlass: Boolean, blend3D: Float, drawHeightTicks: Boolean
    ) {
        val x0 = cx - rx; val x1 = cx + rx
        val y0 = cy - ry; val y1 = cy + ry
        val baseR = if (intoGlass) 0.12f else 0.18f
        val baseG = if (intoGlass) 0.62f else 0.42f
        val baseB = if (intoGlass) 0.88f else 0.66f

        pushObsQuadFlat(intoGlass, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, min(1f, baseR * 1.35f), min(1f, baseG * 1.35f), min(1f, baseB * 1.30f), alpha)
        if (blend3D > 0.04f && z1 - z0 > 0.03f) {
            pushObsWallQuadAO(intoGlass, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, baseR * 0.98f, baseG * 0.98f, baseB * 0.98f, alpha)
            pushObsWallQuadAO(intoGlass, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, baseR * 0.84f, baseG * 0.84f, baseB * 0.84f, alpha)
            pushObsWallQuadAO(intoGlass, x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, baseR * 0.56f, baseG * 0.56f, baseB * 0.58f, alpha)
            pushObsWallQuadAO(intoGlass, x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1, baseR * 0.44f, baseG * 0.44f, baseB * 0.48f, alpha)
            if (drawHeightTicks) {
                val edgeA = if (intoGlass) 0.72f else 0.45f
                pushObsEdge(intoGlass, x0, y0, z0, x0, y0, z1, 0.45f, 0.88f, 1.0f, edgeA)
                pushObsEdge(intoGlass, x1, y0, z0, x1, y0, z1, 0.45f, 0.88f, 1.0f, edgeA)
                pushObsEdge(intoGlass, x1, y1, z0, x1, y1, z1, 0.45f, 0.88f, 1.0f, edgeA)
                pushObsEdge(intoGlass, x0, y1, z0, x0, y1, z1, 0.45f, 0.88f, 1.0f, edgeA)
            }
        }
    }

    private fun pushAltitudeCurtain(pts: FloatArray, count: Int, zScale: Float, r: Float, g: Float, b: Float, topAlpha: Float) {
        for (i in 0 until count - 1) {
            val aIdx = i * 3
            val bIdx = (i + 1) * 3
            val x0 = pts[aIdx]; val y0 = pts[aIdx + 1]; val z0 = pts[aIdx + 2] * zScale
            val x1 = pts[bIdx]; val y1 = pts[bIdx + 1]; val z1 = pts[bIdx + 2] * zScale

            pushGroundLine(x0, y0, 0.010f, x1, y1, 0.010f, r, g, b, 0.25f)
            pushFxGradientQuad(
                x0, y0, 0.012f, r, g, b, 0.015f,
                x1, y1, 0.012f, r, g, b, 0.015f,
                x1, y1, z1, r, g, b, topAlpha,
                x0, y0, z0, r, g, b, topAlpha
            )
            if (i % 6 == 0) {
                pushGroundLine(x0, y0, 0.012f, x0, y0, z0, r, g, b, topAlpha * 1.45f)
            }
        }
    }

    private fun drawHomePad3D(hx: Float, hy: Float) {
        val z = 0.016f
        pushFxDiscXY(hx, hy, z, 0.34f, 20, 1.0f, 0.72f, 0.0f, 0.18f)
        pushFxRingXY(hx, hy, z + 0.002f, 0.34f, 0.036f, 20, 1.0f, 0.76f, 0.05f, 0.85f)
        pushActorQuadSeg3D(hx - 0.11f, hy - 0.13f, z + 0.004f, hx - 0.11f, hy + 0.13f, z + 0.004f, 0.022f, 1.0f, 0.82f, 0.12f, 0.92f, -1f, -1f)
        pushActorQuadSeg3D(hx + 0.11f, hy - 0.13f, z + 0.004f, hx + 0.11f, hy + 0.13f, z + 0.004f, 0.022f, 1.0f, 0.82f, 0.12f, 0.92f, -1f, -1f)
        pushActorQuadSeg3D(hx - 0.11f, hy, z + 0.004f, hx + 0.11f, hy, z + 0.004f, 0.022f, 1.0f, 0.82f, 0.12f, 0.92f, -1f, -1f)
    }

    private fun drawQuadrotor3D(snap: RenderSnapshot, zScale: Float, blend: Float) {
        val ux = snap.uavX
        val uy = snap.uavY
        val uz = snap.uavZ * zScale
        val yaw = snap.yaw
        // 3D 视图下完整呈现真实横滚与俯仰姿态，2D 正射俯视下平滑归零保持平面投影规整
        val roll = snap.smoothRoll * blend
        val pitch = snap.smoothPitch * blend
        val rig = DroneVectorModel.activeRig
        val worldScale = 0.46f

        if (blend > 0.05f) {
            pushFxDiscXY(ux, uy, 0.008f, 0.30f, 16, 0f, 0f, 0f, 0.50f * blend)
            pushActorLine(ux, uy, 0.015f, ux, uy, uz, 0.65f, 0.88f, 1.0f, 0.45f, 0f, uz)
        }

        if (droneOccludedBlend > 0.03f) {
            val sonarPhase = (SystemClock.uptimeMillis() % 1100L) / 1100f
            val sonarR = 0.42f + sonarPhase * 0.55f
            val sonarA = (1f - sonarPhase) * 0.85f * droneOccludedBlend
            pushActorRingXY(ux, uy, uz, sonarR, 0.035f, 24, 0.12f, 0.94f, 1.0f, sonarA, -1f)
        }

        // 1. 渲染 DroneVectorModel 机身甲板面片 (带三维姿态倾转)
        for (face in rig.faces) {
            val pts = face.pts
            val n = pts.size / 3
            if (n < 3) continue
            DroneVectorModel.transformBodyToWorld(pts[0], pts[1], pts[2], worldScale, roll, pitch, yaw, uavTmpA)
            val x0 = ux + uavTmpA[0]; val y0 = uy + uavTmpA[1]; val z0 = uz + uavTmpA[2]
            for (i in 1 until n - 1) {
                val b1 = i * 3; val b2 = (i + 1) * 3
                DroneVectorModel.transformBodyToWorld(pts[b1], pts[b1 + 1], pts[b1 + 2], worldScale, roll, pitch, yaw, uavTmpA)
                DroneVectorModel.transformBodyToWorld(pts[b2], pts[b2 + 1], pts[b2 + 2], worldScale, roll, pitch, yaw, uavTmpB)
                val sh = 0.22f * face.shadeBoost
                pushActorTri(
                    x0, y0, z0, -1f,
                    ux + uavTmpA[0], uy + uavTmpA[1], uz + uavTmpA[2], -1f,
                    ux + uavTmpB[0], uy + uavTmpB[1], uz + uavTmpB[2], -1f,
                    sh, sh * 1.18f, sh * 1.48f, 0.96f
                )
            }
        }

        // 2. 渲染 DroneVectorModel 全部三维矢量机身线段与涵道护圈
        for (seg in rig.segments) {
            DroneVectorModel.transformBodyToWorld(seg.x0, seg.y0, seg.z0, worldScale, roll, pitch, yaw, uavTmpA)
            DroneVectorModel.transformBodyToWorld(seg.x1, seg.y1, seg.z1, worldScale, roll, pitch, yaw, uavTmpB)
            val x0 = ux + uavTmpA[0]; val y0 = uy + uavTmpA[1]; val z0 = uz + uavTmpA[2]
            val x1 = ux + uavTmpB[0]; val y1 = uy + uavTmpB[1]; val z1 = uz + uavTmpB[2]

            when (seg.role) {
                DroneVectorModel.PartRole.ARM_BEAM ->
                    pushActorQuadSeg3D(x0, y0, z0, x1, y1, z1, 0.022f, 0.88f, 0.92f, 0.98f, 0.98f, -1f, -1f)
                DroneVectorModel.PartRole.GIMBAL_NOSE ->
                    pushActorQuadSeg3D(x0, y0, z0, x1, y1, z1, 0.024f, 0.12f, 0.68f, 1.0f, 0.98f, -1f, -1f)
                DroneVectorModel.PartRole.NAV_FRONT_RED ->
                    pushActorQuadSeg3D(x0, y0, z0, x1, y1, z1, 0.017f, 1.0f, 0.26f, 0.22f, 0.98f, -1f, -1f)
                DroneVectorModel.PartRole.NAV_REAR_GREEN ->
                    pushActorQuadSeg3D(x0, y0, z0, x1, y1, z1, 0.017f, 0.0f, 0.92f, 0.50f, 0.98f, -1f, -1f)
                DroneVectorModel.PartRole.LIDAR_DOME ->
                    pushActorLine(x0, y0, z0, x1, y1, z1, 0.35f, 0.96f, 0.88f, 0.95f, -1f, -1f)
                else ->
                    pushActorLine(x0, y0, z0, x1, y1, z1, 0.82f, 0.90f, 1.0f, 0.92f, -1f, -1f)
            }
        }

        // 3. 渲染高速旋转矢量桨叶
        val spinPhase = if (snap.armed) shaderClockSec * 22f else 0.4f
        for (rot in rig.rotors) {
            val ang = spinPhase * rot.spinSign
            val rBlade = rot.radius * 0.88f
            DroneVectorModel.transformBodyToWorld(rot.cx + cos(ang) * rBlade, rot.cy + sin(ang) * rBlade, rot.cz, worldScale, roll, pitch, yaw, uavTmpA)
            DroneVectorModel.transformBodyToWorld(rot.cx - cos(ang) * rBlade, rot.cy - sin(ang) * rBlade, rot.cz, worldScale, roll, pitch, yaw, uavTmpB)
            pushActorLine(
                ux + uavTmpA[0], uy + uavTmpA[1], uz + uavTmpA[2],
                ux + uavTmpB[0], uy + uavTmpB[1], uz + uavTmpB[2],
                0.92f, 0.96f, 1.0f, 0.72f, -1f, -1f
            )
        }
    }

    // ==================== 底层零分配顶点压入工具函数 ====================

    private fun pushVert(arr: FloatArray, vertIdx: Int, x: Float, y: Float, z: Float, r: Float, g: Float, b: Float, a: Float, arc: Float) {
        var o = vertIdx * FLOATS_PER_VERT
        arr[o++] = x; arr[o++] = y; arr[o++] = z
        arr[o++] = r; arr[o++] = g; arr[o++] = b; arr[o++] = a
        arr[o] = arc
    }

    private fun pushGroundLine(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, r: Float, g: Float, b: Float, a: Float) {
        if (groundLineVerts + 2 > MAX_ENV_LINE_VERTS) return
        pushVert(groundLineArray, groundLineVerts++, x0, y0, z0, r, g, b, a, 0f)
        pushVert(groundLineArray, groundLineVerts++, x1, y1, z1, r, g, b, a, 0f)
    }

    private fun pushGroundCircle(cx: Float, cy: Float, z: Float, rad: Float, segs: Int, r: Float, g: Float, b: Float, a: Float) {
        var px = cx + rad; var py = cy
        for (s in 1..segs) {
            val lutIdx = (s * LUT_N) / segs
            val nx = cx + COS_LUT[lutIdx] * rad; val ny = cy + SIN_LUT[lutIdx] * rad
            pushGroundLine(px, py, z, nx, ny, z, r, g, b, a)
            px = nx; py = ny
        }
    }

    private fun pushGroundDashedRect(x0: Float, y0: Float, x1: Float, y1: Float, z: Float, r: Float, g: Float, b: Float, a: Float) {
        pushGroundDashedSeg(x0, y0, z, x1, y0, z, r, g, b, a)
        pushGroundDashedSeg(x1, y0, z, x1, y1, z, r, g, b, a)
        pushGroundDashedSeg(x1, y1, z, x0, y1, z, r, g, b, a)
        pushGroundDashedSeg(x0, y1, z, x0, y0, z, r, g, b, a)
    }

    private fun pushGroundDashedSeg(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, r: Float, g: Float, b: Float, a: Float) {
        val steps = 16
        for (i in 0 until steps step 2) {
            val t0 = i.toFloat() / steps; val t1 = (i + 1).toFloat() / steps
            pushGroundLine(
                x0 + (x1 - x0) * t0, y0 + (y1 - y0) * t0, z0 + (z1 - z0) * t0,
                x0 + (x1 - x0) * t1, y0 + (y1 - y0) * t1, z0 + (z1 - z0) * t1,
                r, g, b, a
            )
        }
    }

    private fun pushObsEdge(intoGlass: Boolean, x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, r: Float, g: Float, b: Float, a: Float) {
        if (intoGlass) {
            if (glassObsEdgeVerts + 2 > MAX_GLASS_LINE_VERTS) return
            pushVert(glassObsEdgeArray, glassObsEdgeVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(glassObsEdgeArray, glassObsEdgeVerts++, x1, y1, z1, r, g, b, a, 0f)
        } else {
            if (solidObsEdgeVerts + 2 > MAX_ENV_LINE_VERTS) return
            pushVert(solidObsEdgeArray, solidObsEdgeVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(solidObsEdgeArray, solidObsEdgeVerts++, x1, y1, z1, r, g, b, a, 0f)
        }
    }

    private fun pushObsTri(
        intoGlass: Boolean,
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        if (intoGlass) {
            if (glassObsTriVerts + 3 > MAX_GLASS_TRI_VERTS) return
            pushVert(glassObsTriArray, glassObsTriVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, x1, y1, z1, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, x2, y2, z2, r, g, b, a, 0f)
        } else {
            if (solidObsTriVerts + 3 > MAX_ENV_TRI_VERTS) return
            pushVert(solidObsTriArray, solidObsTriVerts++, x0, y0, z0, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, x1, y1, z1, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, x2, y2, z2, r, g, b, a, 0f)
        }
    }

    private fun pushObsQuadFlat(
        intoGlass: Boolean,
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        pushObsTri(intoGlass, x0, y0, z0, x1, y1, z1, x2, y2, z2, r, g, b, a)
        pushObsTri(intoGlass, x0, y0, z0, x2, y2, z2, x3, y3, z3, r, g, b, a)
    }

    private fun pushObsWallQuadAO(
        intoGlass: Boolean,
        bx0: Float, by0: Float, bz0: Float,
        bx1: Float, by1: Float, bz1: Float,
        tx1: Float, ty1: Float, tz1: Float,
        tx0: Float, ty0: Float, tz0: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        val ao = 0.56f
        val br = r * ao; val bg = g * ao; val bb = b * ao
        if (intoGlass) {
            if (glassObsTriVerts + 6 > MAX_GLASS_TRI_VERTS) return
            pushVert(glassObsTriArray, glassObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, bx1, by1, bz1, br, bg, bb, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(glassObsTriArray, glassObsTriVerts++, tx0, ty0, tz0, r, g, b, a, 0f)
        } else {
            if (solidObsTriVerts + 6 > MAX_ENV_TRI_VERTS) return
            pushVert(solidObsTriArray, solidObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, bx1, by1, bz1, br, bg, bb, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, bx0, by0, bz0, br, bg, bb, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, tx1, ty1, tz1, r, g, b, a, 0f)
            pushVert(solidObsTriArray, solidObsTriVerts++, tx0, ty0, tz0, r, g, b, a, 0f)
        }
    }

    // ==================== 主角可遮挡批次 ====================

    private fun pushActorLine(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        r: Float, g: Float, b: Float, a: Float,
        arc0: Float, arc1: Float
    ) {
        if (actorLineVerts + 2 > MAX_ACTOR_LINE_VERTS) return
        pushVert(actorLineArray, actorLineVerts++, x0, y0, z0, r, g, b, a, arc0)
        pushVert(actorLineArray, actorLineVerts++, x1, y1, z1, r, g, b, a, arc1)
    }

    private fun pushActorPolyline3D(
        pts: FloatArray, count: Int, zScale: Float,
        r: Float, g: Float, b: Float, a: Float,
        fixedZ: Float = -1f
    ) {
        var cumArc = 0f
        for (i in 0 until count - 1) {
            val i0 = i * 3; val i1 = (i + 1) * 3
            val x0 = pts[i0]; val y0 = pts[i0 + 1]; val z0 = if (fixedZ >= 0f) fixedZ else pts[i0 + 2] * zScale + 0.012f
            val x1 = pts[i1]; val y1 = pts[i1 + 1]; val z1 = if (fixedZ >= 0f) fixedZ else pts[i1 + 2] * zScale + 0.012f
            val seg = hypot(hypot(x1 - x0, y1 - y0), z1 - z0)
            pushActorLine(x0, y0, z0, x1, y1, z1, r, g, b, a, cumArc, cumArc + seg)
            cumArc += seg
        }
    }

    private fun pushActorTri(
        x0: Float, y0: Float, z0: Float, arc0: Float,
        x1: Float, y1: Float, z1: Float, arc1: Float,
        x2: Float, y2: Float, z2: Float, arc2: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        if (actorTriVerts + 3 > MAX_ACTOR_TRI_VERTS) return
        pushVert(actorTriArray, actorTriVerts++, x0, y0, z0, r, g, b, a, arc0)
        pushVert(actorTriArray, actorTriVerts++, x1, y1, z1, r, g, b, a, arc1)
        pushVert(actorTriArray, actorTriVerts++, x2, y2, z2, r, g, b, a, arc2)
    }

    private fun pushActorQuadSeg3D(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        halfW: Float,
        r: Float, g: Float, b: Float, a: Float,
        arc0: Float, arc1: Float
    ) {
        val dx = x1 - x0; val dy = y1 - y0
        val len = hypot(dx, dy)
        val nx: Float; val ny: Float
        if (len > 1e-4f) {
            nx = (-dy / len) * halfW; ny = (dx / len) * halfW
        } else {
            nx = halfW; ny = 0f
        }
        pushActorTri(
            x0 - nx, y0 - ny, z0, arc0,
            x0 + nx, y0 + ny, z0, arc0,
            x1 + nx, y1 + ny, z1, arc1,
            r, g, b, a
        )
        pushActorTri(
            x0 - nx, y0 - ny, z0, arc0,
            x1 + nx, y1 + ny, z1, arc1,
            x1 - nx, y1 - ny, z1, arc1,
            r, g, b, a
        )
    }

    private fun pushActorRibbon3D(
        pts: FloatArray, count: Int, zScale: Float, halfW: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        var cumArc = 0f
        for (i in 0 until count - 1) {
            val aIdx = i * 3; val bIdx = (i + 1) * 3
            val x0 = pts[aIdx]; val y0 = pts[aIdx + 1]; val z0 = pts[aIdx + 2] * zScale + 0.012f
            val x1 = pts[bIdx]; val y1 = pts[bIdx + 1]; val z1 = pts[bIdx + 2] * zScale + 0.012f
            val seg = hypot(hypot(x1 - x0, y1 - y0), z1 - z0)
            pushActorQuadSeg3D(x0, y0, z0, x1, y1, z1, halfW, r, g, b, a, cumArc, cumArc + seg)
            cumArc += seg
        }
    }

    private fun pushActorDiscXY(cx: Float, cy: Float, z: Float, rad: Float, segs: Int, r: Float, g: Float, b: Float, a: Float, arc: Float) {
        var px = cx + rad; var py = cy
        for (s in 1..segs) {
            val lutIdx = (s * LUT_N) / segs
            val nx = cx + COS_LUT[lutIdx] * rad; val ny = cy + SIN_LUT[lutIdx] * rad
            pushActorTri(cx, cy, z, arc, px, py, z, arc, nx, ny, z, arc, r, g, b, a)
            px = nx; py = ny
        }
    }

    private fun pushActorRingXY(cx: Float, cy: Float, z: Float, rad: Float, thick: Float, segs: Int, r: Float, g: Float, b: Float, a: Float, arc: Float) {
        val rIn = max(0.005f, rad - thick * 0.5f)
        val rOut = rad + thick * 0.5f
        var c0 = 1f; var s0 = 0f
        for (s in 1..segs) {
            val lutIdx = (s * LUT_N) / segs
            val c1 = COS_LUT[lutIdx]; val s1 = SIN_LUT[lutIdx]
            pushActorTri(cx + c0 * rIn, cy + s0 * rIn, z, arc, cx + c0 * rOut, cy + s0 * rOut, z, arc, cx + c1 * rOut, cy + s1 * rOut, z, arc, r, g, b, a)
            pushActorTri(cx + c0 * rIn, cy + s0 * rIn, z, arc, cx + c1 * rOut, cy + s1 * rOut, z, arc, cx + c1 * rIn, cy + s1 * rIn, z, arc, r, g, b, a)
            c0 = c1; s0 = s1
        }
    }

    private fun pushActorBeaconBox(cx: Float, cy: Float, cz: Float, hw: Float, r: Float, g: Float, b: Float, a: Float) {
        val x0 = cx - hw; val x1 = cx + hw
        val y0 = cy - hw; val y1 = cy + hw
        val z0 = cz - hw; val z1 = cz + hw
        fun q(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, dx: Float, dy: Float, dz: Float, ex: Float, ey: Float, ez: Float, sh: Float) {
            pushActorTri(ax, ay, az, -1f, bx, by, bz, -1f, dx, dy, dz, -1f, r * sh, g * sh, b * sh, a)
            pushActorTri(ax, ay, az, -1f, dx, dy, dz, -1f, ex, ey, ez, -1f, r * sh, g * sh, b * sh, a)
        }
        q(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 1.0f)
        q(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0.88f)
        q(x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 0.76f)
        q(x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1, 0.62f)
        q(x0, y1, z0, x0, y0, z0, x0, y0, z1, x0, y1, z1, 0.68f)
    }

    // ==================== Pass 5 特效半透明批次 ====================

    private fun pushFxTri(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float, r: Float, g: Float, b: Float, a: Float) {
        if (fxAlphaTriVerts + 3 > fxAlphaTriArray.size / FLOATS_PER_VERT) return
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x0, y0, z0, r, g, b, a, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x1, y1, z1, r, g, b, a, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x2, y2, z2, r, g, b, a, 0f)
    }

    private fun pushFxQuad(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float, r: Float, g: Float, b: Float, a: Float) {
        pushFxTri(x0, y0, z0, x1, y1, z1, x2, y2, z2, r, g, b, a)
        pushFxTri(x0, y0, z0, x2, y2, z2, x3, y3, z3, r, g, b, a)
    }

    private fun pushFxGradientQuad(
        x0: Float, y0: Float, z0: Float, r0: Float, g0: Float, b0: Float, a0: Float,
        x1: Float, y1: Float, z1: Float, r1: Float, g1: Float, b1: Float, a1: Float,
        x2: Float, y2: Float, z2: Float, r2: Float, g2: Float, b2: Float, a2: Float,
        x3: Float, y3: Float, z3: Float, r3: Float, g3: Float, b3: Float, a3: Float
    ) {
        if (fxAlphaTriVerts + 6 > fxAlphaTriArray.size / FLOATS_PER_VERT) return
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x0, y0, z0, r0, g0, b0, a0, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x1, y1, z1, r1, g1, b1, a1, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x2, y2, z2, r2, g2, b2, a2, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x0, y0, z0, r0, g0, b0, a0, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x2, y2, z2, r2, g2, b2, a2, 0f)
        pushVert(fxAlphaTriArray, fxAlphaTriVerts++, x3, y3, z3, r3, g3, b3, a3, 0f)
    }

    private fun pushFxDiscXY(cx: Float, cy: Float, z: Float, rad: Float, segs: Int, r: Float, g: Float, b: Float, a: Float) {
        var px = cx + rad; var py = cy
        for (s in 1..segs) {
            val lutIdx = (s * LUT_N) / segs
            val nx = cx + COS_LUT[lutIdx] * rad; val ny = cy + SIN_LUT[lutIdx] * rad
            pushFxTri(cx, cy, z, px, py, z, nx, ny, z, r, g, b, a)
            px = nx; py = ny
        }
    }

    private fun pushFxRingXY(cx: Float, cy: Float, z: Float, rad: Float, thick: Float, segs: Int, r: Float, g: Float, b: Float, a: Float) {
        val rIn = max(0.005f, rad - thick * 0.5f)
        val rOut = rad + thick * 0.5f
        var c0 = 1f; var s0 = 0f
        for (s in 1..segs) {
            val lutIdx = (s * LUT_N) / segs
            val c1 = COS_LUT[lutIdx]; val s1 = SIN_LUT[lutIdx]
            pushFxQuad(
                cx + c0 * rIn, cy + s0 * rIn, z,
                cx + c0 * rOut, cy + s0 * rOut, z,
                cx + c1 * rOut, cy + s1 * rOut, z,
                cx + c1 * rIn, cy + s1 * rIn, z,
                r, g, b, a
            )
            c0 = c1; s0 = s1
        }
    }

    // ==================== VBO 提交与双遍绘制管线 ====================

    private fun bindPrimUniforms() {
        GLES20.glUseProgram(progPrim)
        GLES20.glUniformMatrix4fv(uPrimMvp, 1, false, vpMatrix, 0)
        GLES20.glUniform2f(uPrimFocusXY, camFocusX, camFocusY)
        GLES20.glUniform1f(uPrimFogSpan, worldHalfSpan * 2.2f)
        GLES20.glUniform3f(uPrimFogColor, curFogRgb[0], curFogRgb[1], curFogRgb[2])
    }

    private fun flushEnvLines(vboId: Int, src: FloatArray, vertCount: Int, lineWidthPx: Float) {
        if (vertCount <= 0) return
        envLineBuf.clear()
        envLineBuf.put(src, 0, vertCount * FLOATS_PER_VERT)
        envLineBuf.position(0)

        bindPrimUniforms()
        GLES20.glLineWidth(lineWidthPx)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboId)
        GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, vertCount * STRIDE_VERT, envLineBuf)

        GLES20.glEnableVertexAttribArray(aPrimPos)
        GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
        GLES20.glEnableVertexAttribArray(aPrimColor)
        GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
        if (aPrimArc >= 0) {
            GLES20.glEnableVertexAttribArray(aPrimArc)
            GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
        }

        GLES20.glDrawArrays(GLES20.GL_LINES, 0, vertCount)

        GLES20.glDisableVertexAttribArray(aPrimPos)
        GLES20.glDisableVertexAttribArray(aPrimColor)
        if (aPrimArc >= 0) GLES20.glDisableVertexAttribArray(aPrimArc)
    }

    private fun flushEnvTriangles(vboId: Int, src: FloatArray, vertCount: Int) {
        if (vertCount <= 0) return
        envTriBuf.clear()
        envTriBuf.put(src, 0, vertCount * FLOATS_PER_VERT)
        envTriBuf.position(0)

        bindPrimUniforms()

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboId)
        GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, vertCount * STRIDE_VERT, envTriBuf)

        GLES20.glEnableVertexAttribArray(aPrimPos)
        GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
        GLES20.glEnableVertexAttribArray(aPrimColor)
        GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
        if (aPrimArc >= 0) {
            GLES20.glEnableVertexAttribArray(aPrimArc)
            GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
        }

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertCount)

        GLES20.glDisableVertexAttribArray(aPrimPos)
        GLES20.glDisableVertexAttribArray(aPrimColor)
        if (aPrimArc >= 0) GLES20.glDisableVertexAttribArray(aPrimArc)
    }

    private fun uploadActorVbos() {
        if (actorLineVerts > 0) {
            actorLineBuf.clear()
            actorLineBuf.put(actorLineArray, 0, actorLineVerts * FLOATS_PER_VERT)
            actorLineBuf.position(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
            GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, actorLineVerts * STRIDE_VERT, actorLineBuf)
        }
        if (actorTriVerts > 0) {
            actorTriBuf.clear()
            actorTriBuf.put(actorTriArray, 0, actorTriVerts * FLOATS_PER_VERT)
            actorTriBuf.position(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
            GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, actorTriVerts * STRIDE_VERT, actorTriBuf)
        }
    }

    private fun drawActorBatchesOccluded(lineWidthPx: Float) {
        GLES20.glUseProgram(progOccluded)
        GLES20.glUniformMatrix4fv(uOccMvp, 1, false, vpMatrix, 0)
        GLES20.glUniform1f(uOccTime, shaderClockSec)

        if (actorLineVerts > 0) {
            GLES20.glLineWidth(lineWidthPx)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
            GLES20.glEnableVertexAttribArray(aOccPos)
            GLES20.glVertexAttribPointer(aOccPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aOccColor)
            GLES20.glVertexAttribPointer(aOccColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            GLES20.glEnableVertexAttribArray(aOccArc)
            GLES20.glVertexAttribPointer(aOccArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, actorLineVerts)
        }

        if (actorTriVerts > 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
            GLES20.glEnableVertexAttribArray(aOccPos)
            GLES20.glVertexAttribPointer(aOccPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aOccColor)
            GLES20.glVertexAttribPointer(aOccColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            GLES20.glEnableVertexAttribArray(aOccArc)
            GLES20.glVertexAttribPointer(aOccArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, actorTriVerts)
        }

        GLES20.glDisableVertexAttribArray(aOccPos)
        GLES20.glDisableVertexAttribArray(aOccColor)
        GLES20.glDisableVertexAttribArray(aOccArc)
    }

    private fun drawActorBatchesVisible(lineWidthPx: Float) {
        bindPrimUniforms()

        if (actorLineVerts > 0) {
            GLES20.glLineWidth(lineWidthPx)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorLineId)
            GLES20.glEnableVertexAttribArray(aPrimPos)
            GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aPrimColor)
            GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            if (aPrimArc >= 0) {
                GLES20.glEnableVertexAttribArray(aPrimArc)
                GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            }
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, actorLineVerts)
        }

        if (actorTriVerts > 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboActorTriId)
            GLES20.glEnableVertexAttribArray(aPrimPos)
            GLES20.glVertexAttribPointer(aPrimPos, 3, GLES20.GL_FLOAT, false, STRIDE_VERT, 0)
            GLES20.glEnableVertexAttribArray(aPrimColor)
            GLES20.glVertexAttribPointer(aPrimColor, 4, GLES20.GL_FLOAT, false, STRIDE_VERT, 12)
            if (aPrimArc >= 0) {
                GLES20.glEnableVertexAttribArray(aPrimArc)
                GLES20.glVertexAttribPointer(aPrimArc, 1, GLES20.GL_FLOAT, false, STRIDE_VERT, 28)
            }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, actorTriVerts)
        }

        GLES20.glDisableVertexAttribArray(aPrimPos)
        GLES20.glDisableVertexAttribArray(aPrimColor)
        if (aPrimArc >= 0) GLES20.glDisableVertexAttribArray(aPrimArc)
    }

    private fun buildProgram(vsSrc: String, fsSrc: String): Int {
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vsSrc)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fsSrc)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src)
        GLES20.glCompileShader(sh)
        return sh
    }
}
