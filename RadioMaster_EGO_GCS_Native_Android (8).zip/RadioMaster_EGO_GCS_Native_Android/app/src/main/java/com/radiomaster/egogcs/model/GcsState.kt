package com.radiomaster.egogcs.model

/**
 * 预分配四缓冲零 GC 渲染帧快照 (Zero-Allocation Quad-Buffered Frame Snapshot)：
 * 包含完整三维位置、速度、真实四元数与欧拉角姿态 (Roll / Pitch / Yaw) 及 EGO 三维膨胀体素地图。
 */
class RenderSnapshot {
    var uavX: Float = -5.5f
    var uavY: Float = -4.2f
    var uavZ: Float = 1.2f
    var vx: Float = 0f
    var vy: Float = 0f
    var vz: Float = 0f
    var ax: Float = 0f
    var ay: Float = 0f

    // 无人机实时三维姿态：yaw (世界系偏航 rad), smoothRoll (右倾为正 rad), smoothPitch (抬头为正 rad) + 单位四元数
    var yaw: Float = 0.65f
    var smoothRoll: Float = 0f
    var smoothPitch: Float = 0f
    var quatW: Float = 1f
    var quatX: Float = 0f
    var quatY: Float = 0f
    var quatZ: Float = 0f
    var hasLiveAttitudeQuat: Boolean = false

    var homeX: Float = -5.5f
    var homeY: Float = -4.2f
    var goalX: Float = 5.2f
    var goalY: Float = 3.8f
    var goalZ: Float = 1.2f
    var fsmState: String = "EXEC_TRAJ"
    var px4Mode: String = "OFFBOARD"
    var armed: Boolean = true

    // 无人机动力电池遥测 (来自 ROS1 /mavros/battery 或 AX12 ELRS Backpack MAVLink UDP:14550)
    var batVolt: Float = 16.24f
    var batCurrentAmps: Float = 12.6f
    var batPct: Int = 86

    // AX12 遥控器本机电源遥测 (来自 Android 原生 BatteryManager，双节 21700 10000mAh)
    var txBatPct: Int = 92
    var txBatVolt: Float = 8.08f
    var txCurrentAmps: Float = 1.05f

    var odomHz: Int = 50
    var cloudHz: Int = 15
    var cloudScanPts: Int = 0
    var mapPointCount: Int = 0
    var solveMs: Float = 0.4f
    var minClearance: Float = 1.45f
    var trajLength: Float = 6.2f

    // 选点预览光柱状态
    var hasPreviewPin: Boolean = false
    var previewX: Float = 0f
    var previewY: Float = 0f
    var previewZ: Float = 1.2f
    var previewClearance: Float = 9.5f
    var previewSafe: Boolean = true

    val obsPrimitives: FloatArray = FloatArray(24 * 6)
    var obsPrimitiveCount: Int = 0

    val voxels: FloatArray = FloatArray(4096 * 4)
    var voxelCount: Int = 0

    val astarPts: FloatArray = FloatArray(600 * 3)
    var astarCount: Int = 0

    val bsplinePts: FloatArray = FloatArray(420 * 3)
    var bsplineCount: Int = 0

    val ctrlPts: FloatArray = FloatArray(24 * 3)
    var ctrlCount: Int = 0

    val trailPts: FloatArray = FloatArray(240 * 3)
    var trailCount: Int = 0

    val lioPathPts: FloatArray = FloatArray(820 * 3)
    var lioPathCount: Int = 0

    val waypointQueuePts: FloatArray = FloatArray(16 * 3)
    var waypointQueueCount: Int = 0
    var isRouteStagedOnly: Boolean = false
    var stagedRouteArcLen: Float = 0f
    var routeClosedLoop: Boolean = false

    val radarSmooth60: FloatArray = FloatArray(60) { 9.5f }
}

data class TopicConfig(
    var protocol: String = "tcpros",
    var masterUri: String = "http://192.168.1.100:11311",
    var wsUrl: String = "ws://192.168.1.100:9090",
    var odomTopic: String = "/Odometry",
    var fastLioCloudTopic: String = "/cloud_registered",
    var fastLioPathTopic: String = "/path",
    var inflateTopic: String = "/grid_map/occupancy_inflate",
    var optimalTopic: String = "/ego_planner_node/optimal_list",
    var goalTopic: String = "/move_base_simple/goal"
)

class GcsSharedHub {
    @Volatile var isRosMode: Boolean = false
    @Volatile var rosConnected: Boolean = false
    @Volatile var connectionLabel: String = "仿真演练"
    @Volatile var connectionLevel: Int = 0
    @Volatile var renderFps: Int = 60
    @Volatile var frameRenderMs: Float = 2.0f
    // 硬件渲染性能模式: 0=均衡高帧(60FPS推荐), 1=极致画质(全量体素), 2=户外长续航省电(30FPS温控节流)
    @Volatile var perfMode: Int = 0

    @Volatile var themeId: Int = 0
    @Volatile var animStyle: Int = 0
    @Volatile var cameraDampingScale: Float = 1.0f

    @Volatile var autoConnectDiscovered: Boolean = true
    @Volatile var mavlinkBackpackEnabled: Boolean = true

    @Volatile var xrayOcclusionEnabled: Boolean = true
    @Volatile var droneCurrentlyOccluded: Boolean = false

    @Volatile var txBatPct: Int = 92
    @Volatile var txBatVolt: Float = 8.08f
    @Volatile var txCurrentAmps: Float = 1.05f

    @Volatile var obstaclesInflation: Float = 0.30f
    @Volatile var maxVel: Float = 2.0f
    @Volatile var maxAcc: Float = 3.0f
    @Volatile var goalZ: Float = 1.2f
    @Volatile var zSliceMax: Float = 3.0f
    @Volatile var mapVoxelSize: Float = 0.12f

    @Volatile var showFastLioMap: Boolean = true
    @Volatile var showInflate: Boolean = true
    @Volatile var showCore: Boolean = false
    @Volatile var showCtrlPts: Boolean = true
    @Volatile var showLocalBox: Boolean = true
    @Volatile var showGroundGrid: Boolean = true
    @Volatile var showTrajCurtain: Boolean = true
    @Volatile var showFlightTrail: Boolean = true
    @Volatile var autoPatrol: Boolean = true

    @Volatile var pointColorMode: Int = 0
    @Volatile var pointSizeScale: Float = 1.0f

    @Volatile var longPressQuickFlyEnabled: Boolean = true
    @Volatile var rthDoubleConfirm: Boolean = true
    @Volatile var hapticFeedbackEnabled: Boolean = true
    @Volatile var autoCloseDrawerOnConnect: Boolean = true
    @Volatile var altStepMeters: Float = 0.2f
    @Volatile var warnClearanceMeters: Float = 0.65f
    @Volatile var lowBatWarnPct: Int = 25

    // HUD 座舱组件显隐与顶栏快捷入口编排
    @Volatile var hudShowCompass: Boolean = true
    @Volatile var hudShowHsiRadar: Boolean = true
    @Volatile var hudShowTelemetryBox: Boolean = true
    @Volatile var hudShowAttitudeWidget: Boolean = true
    @Volatile var hudShowRightCamStack: Boolean = true
    @Volatile var hudShowDemoTools: Boolean = true

    @Volatile var quickSlotOrderCsv: String = "mission,topics,pcd,recenter"
    @Volatile var quickShowMission: Boolean = true
    @Volatile var quickShowTopics: Boolean = true
    @Volatile var quickShowPcd: Boolean = false
    @Volatile var quickShowRecenter: Boolean = false

    @Volatile var routeLoopMode: Int = 0
    @Volatile var routeFinishAction: Int = 0

    @Volatile var latestSnapshot: RenderSnapshot = RenderSnapshot()
}
