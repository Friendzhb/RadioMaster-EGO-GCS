import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val buildEpochMs = System.currentTimeMillis()
val autoVersionCode = ((buildEpochMs / 1000L) - 1_700_000_000L).toInt().coerceAtLeast(300)
val buildUtcStamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply {
    timeZone = TimeZone.getTimeZone("UTC")
}.format(Date(buildEpochMs)) + " UTC"

android {
    namespace = "com.radiomaster.egogcs"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.radiomaster.egogcs"
        minSdk = 26 // 原生兼容 RadioMaster AX12 (Android 9.0 / API 28)
        targetSdk = 34
        versionCode = autoVersionCode
        versionName = "2.2.0-ota"
        resValue("string", "ego_build_stamp", buildUtcStamp)
        resValue("string", "ego_build_epoch_ms", buildEpochMs.toString())
    }

    signingConfigs {
        create("otaShared") {
            storeFile = file("keystore/ego_pilot_ota.jks")
            storePassword = "egopilot2026"
            keyAlias = "egopilot"
            keyPassword = "egopilot2026"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("otaShared")
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            // 统一使用固定 OTA 证书签名，避免 GitHub Actions 每次构建生成随机 debug.keystore 导致覆盖安装签名不一致
            signingConfig = signingConfigs.getByName("otaShared")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // Google 官方物理弹簧动画库：提供抽屉阻尼滑出、标签切换与按键回弹 60FPS 物理动效
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
    // OkHttp 原生异步网络栈：支持 rosbridge WebSocket 与 GitHub Releases 302 重定向流式 OTA 下载
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
