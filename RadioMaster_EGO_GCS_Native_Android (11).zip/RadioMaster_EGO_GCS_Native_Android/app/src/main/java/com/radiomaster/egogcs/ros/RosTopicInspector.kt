package com.radiomaster.egogcs.ros

import com.radiomaster.egogcs.model.GcsSharedHub
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.EOFException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class TopicEchoState {
    CONNECTING,
    STREAMING,
    CAPTURED,
    PAUSED,
    WARNING
}

data class RosTopicEntry(
    val name: String,
    val type: String,
    val publisherCount: Int = 1
)

data class TopicEchoSnapshot(
    val topic: String,
    val msgType: String,
    val publisherNode: String,
    val state: TopicEchoState,
    val statusText: String,
    val isStreaming: Boolean,
    val receivedCount: Long,
    val hz: Float,
    val kbps: Float,
    val lastFrameBytes: Int,
    val timestampText: String,
    val bodyText: String
)

/**
 * 原生 ROS1 话题列表探测与单次截取 / 持续实时读取监控器 (RosTopicInspector)：
 * 采用纯结构化状态枚举 TopicEchoState 与专业终端输出格式，零表情字符。
 */
class RosTopicInspector(
    private val hub: GcsSharedHub,
    private val rosManager: RosConnectionManager,
    private val wsClient: RosBridgeClient
) {

    companion object {
        private const val INSPECTOR_CALLER = "/ego_topic_inspector"
    }

    private data class MsgFieldSpec(
        val baseType: String,
        val name: String,
        val isArray: Boolean,
        val fixedArrayLen: Int
    )

    private val sessionGen = AtomicInteger(0)
    @Volatile private var activeSocket: Socket? = null
    @Volatile private var demoStreamTask: ScheduledFuture<*>? = null

    private val workerPool = Executors.newCachedThreadPool { r ->
        Thread(r, "RosTopicInspectorIO").apply { isDaemon = true }
    }
    private val demoScheduler = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "RosDemoTopicEcho").apply { isDaemon = true }
    }

    fun fetchTopicsAsync(onResult: (topics: List<RosTopicEntry>, sourceHint: String) -> Unit) {
        if (!hub.isRosMode) {
            onResult(buildDemoTopicList(), "仿真演练环境 · 10 个活跃 ROS1 话题")
            return
        }

        val cfg = rosManager.topics.copy()
        if (cfg.protocol == "tcpros") {
            workerPool.execute {
                try {
                    val masterUri = cfg.masterUri.trim().removeSuffix("/")
                    val typesXml = xmlRpcCall(masterUri, "getTopicTypes", listOf(INSPECTOR_CALLER))
                    val stateXml = try {
                        xmlRpcCall(masterUri, "getSystemState", listOf(INSPECTOR_CALLER))
                    } catch (_: Throwable) {
                        ""
                    }

                    val pubCounts = parsePublisherCountsFromSystemState(stateXml)
                    val pairs = parseTopicTypePairs(typesXml)

                    val merged = LinkedHashMap<String, RosTopicEntry>()
                    for ((tName, tType) in pairs) {
                        val cnt = pubCounts[tName] ?: 0
                        merged[tName] = RosTopicEntry(tName, tType, cnt)
                    }
                    for ((tName, cnt) in pubCounts) {
                        if (!merged.containsKey(tName)) {
                            merged[tName] = RosTopicEntry(tName, "unknown", cnt)
                        }
                    }

                    val sorted = merged.values.sortedWith(
                        compareByDescending<RosTopicEntry> { it.publisherCount > 0 }
                            .thenBy { it.name.startsWith("/rosout") }
                            .thenBy { it.name }
                    )
                    onResult(sorted, "roscore (${URI(masterUri).host ?: masterUri}) · 共 ${sorted.size} 个话题")
                } catch (e: Exception) {
                    onResult(emptyList(), "读取 roscore 话题列表失败: ${e.localizedMessage ?: "网络不可达"}")
                }
            }
        } else {
            wsClient.onRosApiTopicsResult = { list ->
                val sorted = list.sortedWith(
                    compareBy<RosTopicEntry> { it.name.startsWith("/rosout") }.thenBy { it.name }
                )
                onResult(sorted, "rosbridge WebSocket · 共 ${sorted.size} 个话题")
            }
            val sent = wsClient.requestTopicsViaRosApi()
            if (!sent) {
                val fallback = listOf(
                    RosTopicEntry(cfg.odomTopic, "nav_msgs/Odometry", 1),
                    RosTopicEntry(cfg.fastLioCloudTopic, "sensor_msgs/PointCloud2", 1),
                    RosTopicEntry(cfg.inflateTopic, "sensor_msgs/PointCloud2", 1),
                    RosTopicEntry(cfg.optimalTopic, "visualization_msgs/Marker", 1),
                    RosTopicEntry(cfg.fastLioPathTopic, "nav_msgs/Path", 1),
                    RosTopicEntry("/mavros/state", "mavros_msgs/State", 1),
                    RosTopicEntry("/mavros/battery", "sensor_msgs/BatteryState", 1),
                    RosTopicEntry(cfg.goalTopic, "geometry_msgs/PoseStamped", 1)
                ).filter { it.name.isNotBlank() }.distinctBy { it.name }
                onResult(fallback, "rosbridge 未连接 · 当前展示预设话题 (${fallback.size})")
            }
        }
    }

    fun captureOnce(topic: String, knownType: String, onUpdate: (TopicEchoSnapshot) -> Unit) {
        startSessionInternal(topic, knownType, singleShot = true, onUpdate = onUpdate)
    }

    fun startContinuous(topic: String, knownType: String, onUpdate: (TopicEchoSnapshot) -> Unit) {
        startSessionInternal(topic, knownType, singleShot = false, onUpdate = onUpdate)
    }

    fun stopActiveSession() {
        sessionGen.incrementAndGet()
        demoStreamTask?.cancel(true)
        demoStreamTask = null
        wsClient.onWatchedTopicJson = null
        wsClient.stopWatchingTopic()
        try {
            activeSocket?.close()
        } catch (_: Throwable) {}
        activeSocket = null
    }

    fun shutdown() {
        stopActiveSession()
        demoScheduler.shutdownNow()
        workerPool.shutdownNow()
    }

    private fun startSessionInternal(
        topic: String,
        knownType: String,
        singleShot: Boolean,
        onUpdate: (TopicEchoSnapshot) -> Unit
    ) {
        stopActiveSession()
        val mySid = sessionGen.incrementAndGet()

        onUpdate(
            TopicEchoSnapshot(
                topic = topic,
                msgType = knownType.ifBlank { "探测中..." },
                publisherNode = "--",
                state = TopicEchoState.CONNECTING,
                statusText = if (singleShot) "正在等待截取首帧消息..." else "正在建立实时订阅数据流...",
                isStreaming = !singleShot,
                receivedCount = 0L,
                hz = 0f,
                kbps = 0f,
                lastFrameBytes = 0,
                timestampText = nowTimeStr(),
                bodyText = "# 正在连接话题 $topic ...\n# 若该话题当前无节点发布数据，将保持监听直到新消息到达。"
            )
        )

        if (!hub.isRosMode) {
            runDemoInspectSession(mySid, topic, knownType, singleShot, onUpdate)
            return
        }

        val cfg = rosManager.topics.copy()
        if (cfg.protocol == "tcpros") {
            workerPool.execute {
                runTcpRosInspectSession(mySid, cfg.masterUri.trim().removeSuffix("/"), topic, knownType, singleShot, onUpdate)
            }
        } else {
            runRosBridgeInspectSession(mySid, topic, knownType, singleShot, onUpdate)
        }
    }

    private fun runTcpRosInspectSession(
        sid: Int,
        masterUri: String,
        topic: String,
        knownType: String,
        singleShot: Boolean,
        onUpdate: (TopicEchoSnapshot) -> Unit
    ) {
        var registeredCallerApi: String? = null
        var sock: Socket? = null
        try {
            val masterHost = URI(masterUri).host ?: throw IllegalArgumentException("Master URI 无效")
            val localIp = detectLocalIp(masterHost)
            val callerApi = "http://$localIp:49151/"
            val regType = if (knownType.isNotBlank() && knownType != "unknown") knownType else "*"

            val regXml = xmlRpcCall(masterUri, "registerSubscriber", listOf(INSPECTOR_CALLER, topic, regType, callerApi))
            registeredCallerApi = callerApi
            val pubUris = Regex("http://[^<\\s\"']+").findAll(regXml).map { it.value }.toList()

            if (pubUris.isEmpty()) {
                if (sessionGen.get() == sid) {
                    onUpdate(
                        TopicEchoSnapshot(
                            topic = topic,
                            msgType = knownType,
                            publisherNode = "无活跃节点",
                            state = TopicEchoState.WARNING,
                            statusText = "当前无活跃节点发布该话题",
                            isStreaming = false,
                            receivedCount = 0L,
                            hz = 0f,
                            kbps = 0f,
                            lastFrameBytes = 0,
                            timestampText = nowTimeStr(),
                            bodyText = "# roscore 中该话题当前有 0 个活跃 Publisher。\n# 请确认机载对应节点 (如 fast_lio 或 ego_planner_node) 已启动。"
                        )
                    )
                }
                return
            }

            val pubUri = rewriteHostIfLocal(pubUris[0], masterHost)
            val reqBody = buildString {
                append("<?xml version=\"1.0\"?><methodCall><methodName>requestTopic</methodName><params>")
                append("<param><value><string>$INSPECTOR_CALLER</string></value></param>")
                append("<param><value><string>${escapeXml(topic)}</string></value></param>")
                append("<param><value><array><data><value><array><data><value><string>TCPROS</string></value></data></array></value></data></array></value></param>")
                append("</params></methodCall>")
            }
            val topicResp = postXml(pubUri, reqBody)
            val endpoint = parseRequestTopicEndpoint(topicResp, masterHost)
                ?: throw IllegalStateException("Publisher 未返回有效 TCPROS 端口")

            sock = Socket()
            activeSocket = sock
            sock.tcpNoDelay = true
            sock.receiveBufferSize = 1024 * 1024
            sock.soTimeout = if (singleShot) 5000 else 3500
            sock.connect(InetSocketAddress(endpoint.first, endpoint.second), 3500)

            val out = BufferedOutputStream(sock.getOutputStream())
            val inp = DataInputStream(BufferedInputStream(sock.getInputStream(), 65536))

            val hdrBytes = encodeTcpRosHeader(
                listOf(
                    "callerid=$INSPECTOR_CALLER",
                    "topic=$topic",
                    "md5sum=*",
                    "type=*",
                    "tcp_nodelay=1"
                )
            )
            out.write(hdrBytes)
            out.flush()

            var scratch = ByteArray(65536)
            fun readNextFrame(maxAllowed: Int): Int {
                val b0 = inp.read()
                if (b0 < 0) return -1
                val b1 = inp.read(); val b2 = inp.read(); val b3 = inp.read()
                if ((b1 or b2 or b3) < 0) throw EOFException()
                val len = (b0 and 0xFF) or ((b1 and 0xFF) shl 8) or ((b2 and 0xFF) shl 16) or ((b3 and 0xFF) shl 24)
                if (len < 0 || len > maxAllowed) throw IllegalStateException("消息帧长度超限: $len")
                if (len > scratch.size) {
                    var cap = scratch.size
                    while (cap < len) cap = cap shl 1
                    scratch = ByteArray(cap)
                }
                inp.readFully(scratch, 0, len)
                return len
            }

            val replyHdrLen = readNextFrame(262_144)
            if (replyHdrLen <= 0) throw EOFException("未收到 TCPROS 握手响应头")
            val hdrMap = decodeTcpRosHeader(scratch, replyHdrLen)
            hdrMap["error"]?.let { err -> throw IllegalStateException("TCPROS 握手拒绝: $err") }

            val actualType = hdrMap["type"]?.takeIf { it.isNotBlank() } ?: knownType
            val pubNode = hdrMap["callerid"] ?: endpoint.first
            val msgDef = hdrMap["message_definition"] ?: ""
            val schemaMap = parseMessageDefinitionBundle(actualType, msgDef)

            if (sessionGen.get() == sid && !singleShot) {
                onUpdate(
                    TopicEchoSnapshot(
                        topic = topic,
                        msgType = actualType,
                        publisherNode = pubNode,
                        state = TopicEchoState.CONNECTING,
                        statusText = "已握手 ($pubNode) · 等待首帧...",
                        isStreaming = true,
                        receivedCount = 0L,
                        hz = 0f,
                        kbps = 0f,
                        lastFrameBytes = 0,
                        timestampText = nowTimeStr(),
                        bodyText = "# 已直连发布节点 $pubNode (${endpoint.first}:${endpoint.second})\n# 消息类型: $actualType\n# 正在等待数据流..."
                    )
                )
            }

            var totalFrames = 0L
            var winFrames = 0
            var winBytes = 0L
            var winStartMs = System.currentTimeMillis()
            var smoothHz = 0f
            var smoothKbps = 0f
            var lastUiPushMs = 0L

            while (sessionGen.get() == sid && !sock.isClosed) {
                val frameLen = try {
                    readNextFrame(12 * 1024 * 1024)
                } catch (_: SocketTimeoutException) {
                    if (singleShot) {
                        onUpdate(
                            TopicEchoSnapshot(
                                topic = topic,
                                msgType = actualType,
                                publisherNode = pubNode,
                                state = TopicEchoState.WARNING,
                                statusText = "等待超时 (5s 内无新帧发布)",
                                isStreaming = false,
                                receivedCount = 0L,
                                hz = 0f,
                                kbps = 0f,
                                lastFrameBytes = 0,
                                timestampText = nowTimeStr(),
                                bodyText = "# 已连接节点 $pubNode，但 5 秒内未发布新帧。\n# 可点击「持续读取」保持挂起监听后续触发消息。"
                            )
                        )
                        break
                    } else {
                        smoothHz = 0f
                        smoothKbps = 0f
                        continue
                    }
                }
                if (frameLen < 0) break

                totalFrames++
                winFrames++
                winBytes += (frameLen + 4)
                val nowMs = System.currentTimeMillis()
                val dtSec = (nowMs - winStartMs) / 1000f
                if (dtSec >= 0.45f) {
                    val instHz = winFrames / dtSec
                    val instKbps = (winBytes / 1024f) / dtSec
                    smoothHz = if (smoothHz <= 0.01f) instHz else (smoothHz * 0.4f + instHz * 0.6f)
                    smoothKbps = if (smoothKbps <= 0.01f) instKbps else (smoothKbps * 0.4f + instKbps * 0.6f)
                    winFrames = 0
                    winBytes = 0L
                    winStartMs = nowMs
                }

                if (singleShot) {
                    val text = formatBinaryRosPayload(actualType, scratch, frameLen, schemaMap)
                    onUpdate(
                        TopicEchoSnapshot(
                            topic = topic,
                            msgType = actualType,
                            publisherNode = pubNode,
                            state = TopicEchoState.CAPTURED,
                            statusText = "单次截取完成 (1 帧 · $frameLen B)",
                            isStreaming = false,
                            receivedCount = 1L,
                            hz = smoothHz,
                            kbps = smoothKbps,
                            lastFrameBytes = frameLen,
                            timestampText = nowTimeStr(),
                            bodyText = text
                        )
                    )
                    break
                } else if (nowMs - lastUiPushMs >= 150L) {
                    lastUiPushMs = nowMs
                    val text = formatBinaryRosPayload(actualType, scratch, frameLen, schemaMap)
                    onUpdate(
                        TopicEchoSnapshot(
                            topic = topic,
                            msgType = actualType,
                            publisherNode = pubNode,
                            state = TopicEchoState.STREAMING,
                            statusText = "实时读取中 ($pubNode)",
                            isStreaming = true,
                            receivedCount = totalFrames,
                            hz = smoothHz,
                            kbps = smoothKbps,
                            lastFrameBytes = frameLen,
                            timestampText = nowTimeStr(),
                            bodyText = text
                        )
                    )
                }
            }
        } catch (e: Exception) {
            if (sessionGen.get() == sid) {
                onUpdate(
                    TopicEchoSnapshot(
                        topic = topic,
                        msgType = knownType,
                        publisherNode = "--",
                        state = TopicEchoState.WARNING,
                        statusText = "读取中断: ${e.localizedMessage ?: "连接关闭"}",
                        isStreaming = false,
                        receivedCount = 0L,
                        hz = 0f,
                        kbps = 0f,
                        lastFrameBytes = 0,
                        timestampText = nowTimeStr(),
                        bodyText = "# 读取话题 $topic 发生异常:\n# ${e.localizedMessage ?: e.javaClass.simpleName}"
                    )
                )
            }
        } finally {
            try { sock?.close() } catch (_: Throwable) {}
            if (activeSocket === sock) activeSocket = null
            if (registeredCallerApi != null) {
                try {
                    xmlRpcCall(masterUri, "unregisterSubscriber", listOf(INSPECTOR_CALLER, topic, registeredCallerApi))
                } catch (_: Throwable) {}
            }
        }
    }

    private fun runRosBridgeInspectSession(
        sid: Int,
        topic: String,
        knownType: String,
        singleShot: Boolean,
        onUpdate: (TopicEchoSnapshot) -> Unit
    ) {
        if (!hub.rosConnected) {
            onUpdate(
                TopicEchoSnapshot(
                    topic = topic,
                    msgType = knownType,
                    publisherNode = "rosbridge 未连接",
                    state = TopicEchoState.WARNING,
                    statusText = "请先连接机载 rosbridge",
                    isStreaming = false,
                    receivedCount = 0L,
                    hz = 0f,
                    kbps = 0f,
                    lastFrameBytes = 0,
                    timestampText = nowTimeStr(),
                    bodyText = "# 当前处于 rosbridge 模式但尚未建立 WebSocket 连接。"
                )
            )
            return
        }

        var count = 0L
        var winFrames = 0
        var winBytes = 0L
        var winStartMs = System.currentTimeMillis()
        var hz = 0f
        var kbps = 0f
        var lastUiMs = 0L

        wsClient.onWatchedTopicJson = { rxTopic, msgJson, rawLen ->
            if (sessionGen.get() == sid && rxTopic == topic) {
                count++
                winFrames++
                winBytes += rawLen
                val now = System.currentTimeMillis()
                val dt = (now - winStartMs) / 1000f
                if (dt >= 0.45f) {
                    hz = winFrames / dt
                    kbps = (winBytes / 1024f) / dt
                    winFrames = 0
                    winBytes = 0L
                    winStartMs = now
                }

                if (singleShot) {
                    wsClient.onWatchedTopicJson = null
                    wsClient.stopWatchingTopic(topic)
                    val formatted = formatJsonAsYaml(msgJson, 0)
                    onUpdate(
                        TopicEchoSnapshot(
                            topic = topic,
                            msgType = knownType,
                            publisherNode = "rosbridge_websocket",
                            state = TopicEchoState.CAPTURED,
                            statusText = "单次截取完成 ($rawLen B)",
                            isStreaming = false,
                            receivedCount = 1L,
                            hz = hz,
                            kbps = kbps,
                            lastFrameBytes = rawLen,
                            timestampText = nowTimeStr(),
                            bodyText = formatted
                        )
                    )
                } else if (now - lastUiMs >= 150L) {
                    lastUiMs = now
                    val formatted = formatJsonAsYaml(msgJson, 0)
                    onUpdate(
                        TopicEchoSnapshot(
                            topic = topic,
                            msgType = knownType,
                            publisherNode = "rosbridge_websocket",
                            state = TopicEchoState.STREAMING,
                            statusText = "实时读取中 (rosbridge)",
                            isStreaming = true,
                            receivedCount = count,
                            hz = hz,
                            kbps = kbps,
                            lastFrameBytes = rawLen,
                            timestampText = nowTimeStr(),
                            bodyText = formatted
                        )
                    )
                }
            }
        }
        wsClient.startWatchingTopic(topic)
    }

    private fun buildDemoTopicList(): List<RosTopicEntry> = listOf(
        RosTopicEntry("/Odometry", "nav_msgs/Odometry", 1),
        RosTopicEntry("/grid_map/occupancy_inflate", "sensor_msgs/PointCloud2", 1),
        RosTopicEntry("/cloud_registered", "sensor_msgs/PointCloud2", 1),
        RosTopicEntry("/ego_planner_node/optimal_list", "visualization_msgs/Marker", 1),
        RosTopicEntry("/planning/pos_cmd", "quadrotor_msgs/PositionCommand", 1),
        RosTopicEntry("/path", "nav_msgs/Path", 1),
        RosTopicEntry("/mavros/state", "mavros_msgs/State", 1),
        RosTopicEntry("/mavros/battery", "sensor_msgs/BatteryState", 1),
        RosTopicEntry("/mavros/imu/data", "sensor_msgs/Imu", 1),
        RosTopicEntry("/move_base_simple/goal", "geometry_msgs/PoseStamped", 1)
    )

    private fun runDemoInspectSession(
        sid: Int,
        topic: String,
        knownType: String,
        singleShot: Boolean,
        onUpdate: (TopicEchoSnapshot) -> Unit
    ) {
        val nominalHz = when (topic) {
            "/Odometry", "/planning/pos_cmd" -> 50f
            "/mavros/imu/data" -> 200f
            "/cloud_registered", "/path" -> 15f
            "/grid_map/occupancy_inflate", "/ego_planner_node/optimal_list" -> 12.5f
            else -> 5f
        }

        if (singleShot) {
            demoScheduler.schedule({
                if (sessionGen.get() != sid) return@schedule
                val (text, estBytes, pub) = synthesizeDemoMessage(topic, 1L)
                onUpdate(
                    TopicEchoSnapshot(
                        topic = topic,
                        msgType = knownType,
                        publisherNode = pub,
                        state = TopicEchoState.CAPTURED,
                        statusText = "单次截取完成 (仿真 · $estBytes B)",
                        isStreaming = false,
                        receivedCount = 1L,
                        hz = nominalHz,
                        kbps = (nominalHz * estBytes) / 1024f,
                        lastFrameBytes = estBytes,
                        timestampText = nowTimeStr(),
                        bodyText = text
                    )
                )
            }, 60L, TimeUnit.MILLISECONDS)
        } else {
            val startMs = System.currentTimeMillis()
            var seq = 0L
            demoStreamTask = demoScheduler.scheduleAtFixedRate({
                if (sessionGen.get() != sid) return@scheduleAtFixedRate
                seq++
                val elapsedSec = max(0.15f, (System.currentTimeMillis() - startMs) / 1000f)
                val simTotalFrames = max(seq, (elapsedSec * nominalHz).toLong())
                val (text, estBytes, pub) = synthesizeDemoMessage(topic, simTotalFrames)
                onUpdate(
                    TopicEchoSnapshot(
                        topic = topic,
                        msgType = knownType,
                        publisherNode = pub,
                        state = TopicEchoState.STREAMING,
                        statusText = "实时读取中 ($pub · 仿真)",
                        isStreaming = true,
                        receivedCount = simTotalFrames,
                        hz = nominalHz,
                        kbps = (nominalHz * estBytes) / 1024f,
                        lastFrameBytes = estBytes,
                        timestampText = nowTimeStr(),
                        bodyText = text
                    )
                )
            }, 50L, 160L, TimeUnit.MILLISECONDS)
        }
    }

    private fun synthesizeDemoMessage(topic: String, seq: Long): Triple<String, Int, String> {
        val s = hub.latestSnapshot
        val nowMs = System.currentTimeMillis()
        val secs = nowMs / 1000L
        val nsecs = (nowMs % 1000L) * 1_000_000L
        val halfYaw = s.yaw * 0.5
        val qz = sin(halfYaw)
        val qw = cos(halfYaw)

        return when (topic) {
            "/Odometry" -> Triple(
                String.format(
                    Locale.US,
                    """header:
  seq: %d
  stamp: %d.%09d
  frame_id: "world"
child_frame_id: "body"
pose:
  position: { x: %.4f, y: %.4f, z: %.4f }
  orientation: { x: %.4f, y: %.4f, z: %.4f, w: %.4f }
twist:
  linear: { x: %.4f, y: %.4f, z: %.4f }
  angular: { x: 0.0012, y: -0.0008, z: %.4f }""",
                    seq, secs, nsecs, s.uavX, s.uavY, s.uavZ,
                    s.smoothRoll * 0.5f, s.smoothPitch * 0.5f, qz, qw,
                    s.vx, s.vy, s.vz, s.ay * 0.12f
                ),
                736,
                "/laserMapping"
            )

            "/grid_map/occupancy_inflate" -> {
                val n = s.voxelCount
                val sb = StringBuilder()
                sb.append(String.format(Locale.US, "header:\n  seq: %d\n  stamp: %d.%09d\n  frame_id: \"world\"\n", seq, secs, nsecs))
                sb.append("height: 1\nwidth: $n\npoint_step: 12\nis_dense: true\n")
                sb.append("fields: [x(FLOAT32), y(FLOAT32), z(FLOAT32)]\n")
                sb.append("# EGO-Planner 膨胀占据体素块中心点摘要 (共 $n 个三维体素):\n")
                val sampleCnt = min(n, 5)
                for (i in 0 until sampleCnt) {
                    sb.append(String.format(Locale.US, "  voxel[%d]: (%.2f, %.2f, %.2f)\n", i, s.voxels[i * 4], s.voxels[i * 4 + 1], s.voxels[i * 4 + 2]))
                }
                if (n > sampleCnt) sb.append("  ... (其余 ${n - sampleCnt} 个膨胀体素已省略)")
                Triple(sb.toString(), 64 + n * 12, "/ego_planner_node")
            }

            "/cloud_registered" -> Triple(
                String.format(
                    Locale.US,
                    """header:
  seq: %d
  stamp: %d.%09d
  frame_id: "camera_init"
height: 1
width: %d
point_step: 16
fields: [x(FLOAT32), y(FLOAT32), z(FLOAT32), intensity(FLOAT32)]
is_dense: true
# FAST-LIO 配准点云统计:
  单帧激光点数: %d pts
  全局累积体素: %d / 300000""",
                    seq, secs, nsecs, s.cloudScanPts, s.cloudScanPts, s.mapPointCount
                ),
                80 + max(1, s.cloudScanPts) * 16,
                "/laserMapping"
            )

            "/ego_planner_node/optimal_list" -> {
                val cnt = s.bsplineCount
                val sb = StringBuilder()
                sb.append(String.format(Locale.US, "header:\n  seq: %d\n  stamp: %d.%09d\n  frame_id: \"world\"\n", seq, secs, nsecs))
                sb.append("ns: \"optimal_list\"\ntype: 4 (LINE_STRIP)\naction: 0 (ADD)\n")
                sb.append(String.format(Locale.US, "scale: { x: 0.10, y: 0.10, z: 0.10 }\npoints_count: %d (弧长 %.2f m)\n", cnt, s.trajLength))
                val showN = min(cnt, 4)
                for (i in 0 until showN) {
                    sb.append(String.format(Locale.US, "  pt[%d]: { x: %.3f, y: %.3f, z: %.3f }\n", i, s.bsplinePts[i * 3], s.bsplinePts[i * 3 + 1], s.bsplinePts[i * 3 + 2]))
                }
                Triple(sb.toString().trimEnd(), 148 + cnt * 24, "/ego_planner_node")
            }

            "/planning/pos_cmd" -> Triple(
                String.format(
                    Locale.US,
                    """header:
  seq: %d
  stamp: %d.%09d
  frame_id: "world"
position:     { x: %.4f, y: %.4f, z: %.4f }
velocity:     { x: %.4f, y: %.4f, z: %.4f }
acceleration: { x: %.4f, y: %.4f, z: 0.0000 }
yaw: %.4f
yaw_dot: 0.0000
trajectory_flag: 1 (TRAJECTORY_STATUS_READY)""",
                    seq, secs, nsecs, s.uavX, s.uavY, s.uavZ, s.vx, s.vy, s.vz, s.ax, s.ay, s.yaw
                ),
                136,
                "/traj_server"
            )

            "/mavros/state" -> Triple(
                String.format(
                    Locale.US,
                    """header:
  seq: %d
  stamp: %d.%09d
connected: true
armed: %s
guided: true
manual_input: false
mode: "%s"
system_status: 4 (MAV_STATE_ACTIVE)""",
                    seq, secs, nsecs, s.armed.toString(), s.px4Mode
                ),
                52,
                "/mavros"
            )

            "/mavros/battery" -> Triple(
                String.format(
                    Locale.US,
                    """header:
  seq: %d
  stamp: %d.%09d
voltage: %.3f
current: -%.2f
percentage: %.2f
power_supply_status: 2 (DISCHARGING)""",
                    seq, secs, nsecs, s.batVolt, s.batCurrentAmps, s.batPct / 100f
                ),
                68,
                "/mavros"
            )

            else -> Triple(
                String.format(
                    Locale.US,
                    """header:
  seq: %d
  stamp: %d.%09d
  frame_id: "world"
pose:
  position: { x: %.3f, y: %.3f, z: %.3f }
  orientation: { x: 0.000, y: 0.000, z: %.4f, w: %.4f }""",
                    seq, secs, nsecs, s.goalX, s.goalY, s.goalZ, qz, qw
                ),
                84,
                "/ego_pilot_android"
            )
        }
    }

    private fun parseMessageDefinitionBundle(rootType: String, rawDef: String): Map<String, List<MsgFieldSpec>> {
        if (rawDef.isBlank()) return emptyMap()
        val map = HashMap<String, List<MsgFieldSpec>>()
        val sections = rawDef.split(Regex("={10,}"))
        for ((idx, sec) in sections.withIndex()) {
            val lines = sec.lines()
            var secType = if (idx == 0) rootType else ""
            val fields = ArrayList<MsgFieldSpec>()

            for (rawLine in lines) {
                val clean = rawLine.substringBefore('#').trim()
                if (clean.isEmpty()) continue
                if (clean.startsWith("MSG:")) {
                    secType = clean.removePrefix("MSG:").trim()
                    continue
                }
                if (clean.contains('=')) continue

                val parts = clean.split(Regex("\\s+"), limit = 2)
                if (parts.size < 2) continue
                val rawFieldType = parts[0].trim()
                val fieldName = parts[1].trim()

                val bracketOpen = rawFieldType.indexOf('[')
                if (bracketOpen > 0 && rawFieldType.endsWith(']')) {
                    val baseT = rawFieldType.substring(0, bracketOpen)
                    val inside = rawFieldType.substring(bracketOpen + 1, rawFieldType.length - 1).trim()
                    val fixedLen = if (inside.isEmpty()) -1 else (inside.toIntOrNull() ?: -1)
                    fields.add(MsgFieldSpec(baseT, fieldName, isArray = true, fixedArrayLen = fixedLen))
                } else {
                    fields.add(MsgFieldSpec(rawFieldType, fieldName, isArray = false, fixedArrayLen = 0))
                }
            }
            if (secType.isNotEmpty()) {
                map[secType] = fields
                val shortName = secType.substringAfterLast('/')
                if (!map.containsKey(shortName)) {
                    map[shortName] = fields
                }
            }
        }
        return map
    }

    private fun formatBinaryRosPayload(
        rootType: String,
        bytes: ByteArray,
        length: Int,
        schemaMap: Map<String, List<MsgFieldSpec>>
    ): String {
        if (rootType == "sensor_msgs/PointCloud2") {
            formatPointCloud2Summary(bytes, length)?.let { return it }
        }
        if (schemaMap.containsKey(rootType)) {
            try {
                val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
                val sb = StringBuilder()
                val parentPkg = rootType.substringBefore('/', "")
                decodeStructRecursive(bb, rootType, parentPkg, schemaMap, sb, indent = 0, depth = 0)
                if (sb.isNotEmpty()) return sb.toString().trimEnd()
            } catch (_: Throwable) {}
        }
        return formatHexFallback(rootType, bytes, length)
    }

    private fun decodeStructRecursive(
        bb: ByteBuffer,
        typeName: String,
        parentPkg: String,
        schemaMap: Map<String, List<MsgFieldSpec>>,
        sb: StringBuilder,
        indent: Int,
        depth: Int
    ) {
        if (depth > 8) return
        val resolvedKey = resolveSubTypeKey(typeName, parentPkg, schemaMap)
            ?: throw IllegalStateException("Unknown nested type: $typeName")
        val fields = schemaMap[resolvedKey] ?: return
        val curPkg = resolvedKey.substringBefore('/', parentPkg)
        val pad = "  ".repeat(indent)

        for (f in fields) {
            if (!f.isArray) {
                if (isPrimitiveRosType(f.baseType)) {
                    val vStr = readPrimitiveAsString(bb, f.baseType)
                    sb.append(pad).append(f.name).append(": ").append(vStr).append('\n')
                } else {
                    sb.append(pad).append(f.name).append(":\n")
                    decodeStructRecursive(bb, f.baseType, curPkg, schemaMap, sb, indent + 1, depth + 1)
                }
            } else {
                val count = if (f.fixedArrayLen >= 0) f.fixedArrayLen else bb.int
                if (count < 0 || count > 20_000_000) throw IllegalStateException("Invalid array count: $count")

                if ((f.baseType == "uint8" || f.baseType == "byte" || f.baseType == "int8") && count > 16) {
                    if (bb.remaining() < count) throw EOFException()
                    bb.position(bb.position() + count)
                    sb.append(pad).append(f.name).append(": [二进制数据流 ").append(count).append(" bytes]\n")
                } else if (isPrimitiveRosType(f.baseType)) {
                    val previewMax = 8
                    val items = ArrayList<String>(min(count, previewMax))
                    for (i in 0 until count) {
                        val sVal = readPrimitiveAsString(bb, f.baseType)
                        if (i < previewMax) items.add(sVal)
                    }
                    val tail = if (count > previewMax) ", ... 共 $count 项" else ""
                    sb.append(pad).append(f.name).append(": [").append(items.joinToString(", ")).append(tail).append("]\n")
                } else {
                    sb.append(pad).append(f.name).append(": (共 ").append(count).append(" 项)\n")
                    val showStructMax = 4
                    val dummySb = StringBuilder()
                    for (i in 0 until count) {
                        if (i < showStructMax) {
                            sb.append(pad).append("  - [").append(i).append("]:\n")
                            decodeStructRecursive(bb, f.baseType, curPkg, schemaMap, sb, indent + 2, depth + 1)
                        } else {
                            dummySb.setLength(0)
                            decodeStructRecursive(bb, f.baseType, curPkg, schemaMap, dummySb, 0, depth + 1)
                        }
                    }
                    if (count > showStructMax) {
                        sb.append(pad).append("  ... (其余 ").append(count - showStructMax).append(" 项已折叠)\n")
                    }
                }
            }
        }
    }

    private fun resolveSubTypeKey(rawType: String, parentPkg: String, schemaMap: Map<String, List<MsgFieldSpec>>): String? {
        if (rawType == "Header" || rawType == "std_msgs/Header") {
            if (schemaMap.containsKey("std_msgs/Header")) return "std_msgs/Header"
            if (schemaMap.containsKey("Header")) return "Header"
        }
        if (schemaMap.containsKey(rawType)) return rawType
        if (!rawType.contains('/') && parentPkg.isNotEmpty()) {
            val qualified = "$parentPkg/$rawType"
            if (schemaMap.containsKey(qualified)) return qualified
        }
        val shortName = rawType.substringAfterLast('/')
        return if (schemaMap.containsKey(shortName)) shortName else null
    }

    private fun isPrimitiveRosType(t: String): Boolean = when (t) {
        "bool", "int8", "uint8", "byte", "char",
        "int16", "uint16", "int32", "uint32", "int64", "uint64",
        "float32", "float64", "string", "time", "duration" -> true
        else -> false
    }

    private fun readPrimitiveAsString(bb: ByteBuffer, t: String): String = when (t) {
        "bool" -> if (bb.get().toInt() != 0) "true" else "false"
        "int8", "byte" -> bb.get().toInt().toString()
        "uint8", "char" -> (bb.get().toInt() and 0xFF).toString()
        "int16" -> bb.short.toInt().toString()
        "uint16" -> (bb.short.toInt() and 0xFFFF).toString()
        "int32" -> bb.int.toString()
        "uint32" -> (bb.int.toLong() and 0xFFFFFFFFL).toString()
        "int64" -> bb.long.toString()
        "uint64" -> java.lang.Long.toUnsignedString(bb.long)
        "float32" -> String.format(Locale.US, "%.4f", bb.float)
        "float64" -> String.format(Locale.US, "%.4f", bb.double)
        "time", "duration" -> {
            val sec = bb.int.toLong() and 0xFFFFFFFFL
            val nsec = bb.int.toLong() and 0xFFFFFFFFL
            String.format(Locale.US, "%d.%09d", sec, nsec)
        }
        "string" -> {
            val sLen = bb.int
            if (sLen < 0 || sLen > bb.remaining()) throw EOFException()
            val pos = bb.position()
            val s = String(bb.array(), bb.arrayOffset() + pos, sLen, Charsets.UTF_8)
            bb.position(pos + sLen)
            "\"$s\""
        }
        else -> "?"
    }

    private fun formatPointCloud2Summary(bytes: ByteArray, length: Int): String? {
        try {
            val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
            if (bb.remaining() < 24) return null
            val seq = bb.int.toLong() and 0xFFFFFFFFL
            val secs = bb.int.toLong() and 0xFFFFFFFFL
            val nsecs = bb.int.toLong() and 0xFFFFFFFFL
            val fIdLen = bb.int
            if (fIdLen < 0 || bb.remaining() < fIdLen + 12) return null
            val fIdPos = bb.position()
            val frameId = String(bytes, fIdPos, fIdLen, Charsets.UTF_8)
            bb.position(fIdPos + fIdLen)

            val height = bb.int
            val width = bb.int
            val fieldCount = bb.int
            if (fieldCount < 0 || fieldCount > 64) return null

            val fieldDesc = ArrayList<String>(fieldCount)
            var offX = -1; var offY = -1; var offZ = -1
            for (i in 0 until fieldCount) {
                val nLen = bb.int
                if (nLen < 0 || bb.remaining() < nLen + 9) return null
                val np = bb.position()
                val fName = String(bytes, np, nLen, Charsets.UTF_8)
                bb.position(np + nLen)
                val offset = bb.int
                val dtype = bb.get().toInt() and 0xFF
                bb.int
                fieldDesc.add("$fName(off=$offset,t=$dtype)")
                when (fName) {
                    "x" -> offX = offset
                    "y" -> offY = offset
                    "z" -> offZ = offset
                }
            }
            if (bb.remaining() < 14) return null
            val bigEnd = bb.get().toInt() != 0
            val pointStep = bb.int
            val rowStep = bb.int
            val dataLen = bb.int
            if (pointStep <= 0 || dataLen < 0 || bb.remaining() < dataLen) return null
            val dataPos = bb.position()
            bb.position(dataPos + dataLen)
            val isDense = if (bb.remaining() >= 1) (bb.get().toInt() != 0) else true

            val totalPts = if (pointStep > 0) dataLen / pointStep else (width * height)
            val sb = StringBuilder()
            sb.append(String.format(Locale.US, "header:\n  seq: %d\n  stamp: %d.%09d\n  frame_id: \"%s\"\n", seq, secs, nsecs, frameId))
            sb.append("height: $height\nwidth: $width (总点数/体素数: $totalPts)\n")
            sb.append("point_step: $pointStep  row_step: $rowStep  is_dense: $isDense\n")
            sb.append("fields: ").append(fieldDesc.joinToString(", ")).append('\n')

            if (offX >= 0 && offY >= 0 && offZ >= 0 && totalPts > 0) {
                val view = ByteBuffer.wrap(bytes, dataPos, dataLen)
                    .order(if (bigEnd) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN)
                var minX = Float.POSITIVE_INFINITY; var maxX = Float.NEGATIVE_INFINITY
                var minY = Float.POSITIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY
                var minZ = Float.POSITIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
                val step = max(1, totalPts / 500)
                var p = 0
                val req = max(offX, max(offY, offZ)) + 4
                while (p < totalPts) {
                    val base = dataPos + p * pointStep
                    if (base + req > dataPos + dataLen) break
                    val x = view.getFloat(base + offX)
                    val y = view.getFloat(base + offY)
                    val z = view.getFloat(base + offZ)
                    if (x.isFinite() && y.isFinite() && z.isFinite()) {
                        if (x < minX) minX = x; if (x > maxX) maxX = x
                        if (y < minY) minY = y; if (y > maxY) maxY = y
                        if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
                    }
                    p += step
                }
                if (minX.isFinite()) {
                    sb.append(String.format(Locale.US, "xyz_bounds:\n  X: [%.2f, %.2f] m\n  Y: [%.2f, %.2f] m\n  Z: [%.2f, %.2f] m\n", minX, maxX, minY, maxY, minZ, maxZ))
                }
                sb.append("sample_points:\n")
                val showK = min(totalPts, 5)
                for (k in 0 until showK) {
                    val base = dataPos + k * pointStep
                    if (base + req > dataPos + dataLen) break
                    sb.append(String.format(Locale.US, "  [%d]: (%.3f, %.3f, %.3f)\n", k, view.getFloat(base + offX), view.getFloat(base + offY), view.getFloat(base + offZ)))
                }
            }
            return sb.toString().trimEnd()
        } catch (_: Throwable) {
            return null
        }
    }

    private fun formatHexFallback(msgType: String, bytes: ByteArray, length: Int): String {
        val sb = StringBuilder()
        sb.append("# 消息类型: $msgType (总长 $length bytes)\n")
        val showN = min(length, 96)
        for (i in 0 until showN step 16) {
            sb.append(String.format(Locale.US, "%04X: ", i))
            val end = min(i + 16, showN)
            for (j in i until end) {
                sb.append(String.format(Locale.US, "%02X ", bytes[j].toInt() and 0xFF))
            }
            sb.append('\n')
        }
        if (length > showN) sb.append("... (后续 ${length - showN} 字节已省略)")
        return sb.toString()
    }

    private fun formatJsonAsYaml(obj: JSONObject, indent: Int): String {
        val sb = StringBuilder()
        val pad = "  ".repeat(indent)
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = obj.opt(k)
            when (v) {
                is JSONObject -> {
                    sb.append(pad).append(k).append(":\n").append(formatJsonAsYaml(v, indent + 1))
                }
                is JSONArray -> {
                    val n = v.length()
                    if (n == 0) {
                        sb.append(pad).append(k).append(": []\n")
                    } else if (v.opt(0) is JSONObject) {
                        sb.append(pad).append(k).append(": (共 ").append(n).append(" 项)\n")
                        val lim = min(n, 4)
                        for (i in 0 until lim) {
                            sb.append(pad).append("  - [").append(i).append("]:\n")
                            sb.append(formatJsonAsYaml(v.optJSONObject(i), indent + 2))
                        }
                        if (n > lim) sb.append(pad).append("  ... (其余 ").append(n - lim).append(" 项已折叠)\n")
                    } else {
                        val lim = min(n, 8)
                        val list = (0 until lim).map { idx -> v.opt(idx).toString() }
                        val tail = if (n > lim) ", ... 共 $n 项" else ""
                        sb.append(pad).append(k).append(": [").append(list.joinToString(", ")).append(tail).append("]\n")
                    }
                }
                is String -> {
                    if (v.length > 120) {
                        sb.append(pad).append(k).append(": [Base64/长文本 ").append(v.length).append(" chars]\n")
                    } else {
                        sb.append(pad).append(k).append(": \"").append(v).append("\"\n")
                    }
                }
                is Number -> {
                    val d = v.toDouble()
                    if (v is Double || v is Float) {
                        sb.append(pad).append(k).append(": ").append(String.format(Locale.US, "%.4f", d)).append('\n')
                    } else {
                        sb.append(pad).append(k).append(": ").append(v).append('\n')
                    }
                }
                else -> sb.append(pad).append(k).append(": ").append(v).append('\n')
            }
        }
        return sb.toString()
    }

    private fun parseTopicTypePairs(xml: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val pairRegex = Regex("<array>\\s*<data>\\s*<value>(?:<string>)?([^<]+?)(?:</string>)?</value>\\s*<value>(?:<string>)?([^<]+?)(?:</string>)?</value>\\s*</data>\\s*</array>")
        for (m in pairRegex.findAll(xml)) {
            val name = m.groupValues[1].trim()
            val tp = m.groupValues[2].trim()
            if (name.startsWith('/')) {
                out.add(name to tp)
            }
        }
        return out
    }

    private fun parsePublisherCountsFromSystemState(xml: String): Map<String, Int> {
        if (xml.isBlank()) return emptyMap()
        val result = HashMap<String, Int>()
        val pubSection = xml.substringAfter("<data>", "").substringAfter("<data>", "")
        val itemRegex = Regex("<array>\\s*<data>\\s*<value>(?:<string>)?(/[^<\\s]+)(?:</string>)?</value>\\s*<value>\\s*<array>\\s*<data>(.*?)</data>\\s*</array>\\s*</value>\\s*</data>\\s*</array>", setOf(RegexOption.DOT_MATCHES_ALL))
        for (m in itemRegex.findAll(pubSection)) {
            val topic = m.groupValues[1].trim()
            val inner = m.groupValues[2]
            val nodeCount = Regex("<value>").findAll(inner).count()
            if (!result.containsKey(topic) && nodeCount > 0) {
                result[topic] = nodeCount
            }
        }
        return result
    }

    private fun encodeTcpRosHeader(fields: List<String>): ByteArray {
        val encoded = fields.map { it.toByteArray(Charsets.UTF_8) }
        val payloadLen = encoded.sumOf { 4 + it.size }
        val bb = ByteBuffer.allocate(4 + payloadLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(payloadLen)
        for (f in encoded) {
            bb.putInt(f.size)
            bb.put(f)
        }
        return bb.array()
    }

    private fun decodeTcpRosHeader(bytes: ByteArray, length: Int): Map<String, String> {
        val map = HashMap<String, String>()
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        while (bb.remaining() >= 4) {
            val fLen = bb.int
            if (fLen <= 0 || bb.remaining() < fLen) break
            val pos = bb.position()
            val str = String(bytes, pos, fLen, Charsets.UTF_8)
            bb.position(pos + fLen)
            val eq = str.indexOf('=')
            if (eq > 0) map[str.substring(0, eq)] = str.substring(eq + 1)
        }
        return map
    }

    private fun xmlRpcCall(uri: String, method: String, stringArgs: List<String>): String {
        val xml = buildString {
            append("<?xml version=\"1.0\"?><methodCall><methodName>$method</methodName><params>")
            for (arg in stringArgs) {
                append("<param><value><string>${escapeXml(arg)}</string></value></param>")
            }
            append("</params></methodCall>")
        }
        return postXml(uri, xml)
    }

    private fun postXml(uri: String, xmlBody: String): String {
        val conn = (URL(uri).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 3000
            readTimeout = 3500
            doOutput = true
            setRequestProperty("Content-Type", "text/xml")
        }
        return try {
            val bytes = xmlBody.toByteArray(Charsets.UTF_8)
            conn.outputStream.use { it.write(bytes) }
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun rewriteHostIfLocal(pubUri: String, masterHost: String): String {
        return try {
            val u = URI(pubUri)
            val h = u.host ?: ""
            if (h == "localhost" || h == "127.0.0.1" || !h.contains('.')) {
                "http://$masterHost:${u.port}${u.path ?: "/"}"
            } else pubUri
        } catch (_: Throwable) {
            pubUri
        }
    }

    private fun parseRequestTopicEndpoint(xml: String, fallbackHost: String): Pair<String, Int>? {
        val strs = Regex("<string>\\s*([^<]+?)\\s*</string>").findAll(xml).map { it.groupValues[1] }.toList()
        val ints = Regex("<(?:int|i4)>\\s*(\\d+)\\s*</(?:int|i4)>").findAll(xml).mapNotNull { it.groupValues[1].toIntOrNull() }.toList()
        val tcpIdx = strs.indexOf("TCPROS")
        if (tcpIdx < 0 || ints.size < 2) return null
        val rawHost = if (tcpIdx + 1 < strs.size) strs[tcpIdx + 1] else fallbackHost
        val host = if (rawHost == "localhost" || rawHost == "127.0.0.1" || !rawHost.contains('.')) fallbackHost else rawHost
        val port = ints.last()
        return if (port in 1..65535) host to port else null
    }

    private fun detectLocalIp(remoteHost: String): String {
        try {
            Socket().use { probe ->
                probe.connect(InetSocketAddress(remoteHost, 11311), 1200)
                val addr = probe.localAddress?.hostAddress
                if (!addr.isNullOrBlank() && addr != "127.0.0.1") return addr
            }
        } catch (_: Throwable) {}
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val nif = interfaces.nextElement()
                if (!nif.isUp || nif.isLoopback) continue
                val addrs = nif.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: continue
                }
            }
        } catch (_: Throwable) {}
        return "127.0.0.1"
    }

    private fun nowTimeStr(): String =
        SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())

    private fun escapeXml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}
