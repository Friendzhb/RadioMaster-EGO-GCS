package com.radiomaster.egogcs.ota

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import androidx.core.content.FileProvider
import com.radiomaster.egogcs.R
import com.radiomaster.egogcs.model.GcsSharedHub
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * 商业飞控级 GitHub Releases 直链应用内 OTA 更新管理器 (`OtaUpdateManager`)：
 *
 * 1. 默认直连仓库自动构建产物直链 (`https://github.com/Friendzhb/RadioMaster-EGO-GCS/releases/download/latest-apk/EGO-Pilot-AX12.apk`)，
 *    同时内置镜像加速通道与自定义直链回退机制，适应户外热点及不同网络环境；
 * 2. 支持通过 GitHub Releases API (`releases/tags/latest-apk`) 或直链 HTTP HEAD 比对云端产物更新时间与体积；
 * 3. 流式分块下载至应用缓存目录，校验 ZIP/APK 魔数 (`PK\x03\x04`) 与 `PackageManager.getPackageArchiveInfo` 包名完整性，
 *    杜绝校园网/热点认证网页或残损文件误触发安装；
 * 4. 集成飞行解锁安全互锁（实机连接且处于解锁飞行状态时禁止切出覆盖安装）与 Android 8.0+ 未知应用安装授权返回自动续装。
 */
class OtaUpdateManager(
    private val context: Context,
    private val hub: GcsSharedHub,
    private val onStateChanged: (Snapshot) -> Unit,
    private val onNotifyToast: (String) -> Unit
) {

    enum class Phase {
        IDLE,
        CHECKING,
        UPDATE_AVAILABLE,
        UP_TO_DATE,
        DOWNLOADING,
        READY_TO_INSTALL,
        ERROR
    }

    data class Snapshot(
        val phase: Phase,
        val progressPct: Int,
        val downloadedBytes: Long,
        val totalBytes: Long,
        val speedBytesPerSec: Long,
        val localVersionSummary: String,
        val remoteSummary: String,
        val statusMessage: String,
        val activeDirectUrl: String,
        val hasVerifiedApk: Boolean
    )

    companion object {
        const val OFFICIAL_GITHUB_APK_URL =
            "https://github.com/Friendzhb/RadioMaster-EGO-GCS/releases/download/latest-apk/EGO-Pilot-AX12.apk"
        const val GITHUB_RELEASE_API_URL =
            "https://api.github.com/repos/Friendzhb/RadioMaster-EGO-GCS/releases/tags/latest-apk"
        const val MIRROR_PREFIX = "https://ghfast.top/"
        private const val APK_FILE_NAME = "EGO-Pilot-AX12.apk"
        // 预留 4 分钟 CI 上传时间窗，避免刚编译出的同一轮构建把自己判定为新版本
        private const val CI_PUBLISH_GRACE_MS = 240_000L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "EgoOtaUpdater").apply { isDaemon = true }
    }

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private val stateLock = Any()
    @Volatile private var activeCall: Call? = null
    @Volatile private var userCancelled = false
    @Volatile private var pendingInstallAfterPermission = false

    private val localBuildEpochMs: Long = runCatching {
        context.getString(R.string.ego_build_epoch_ms).trim().toLong()
    }.getOrDefault(0L)

    private val localBuildStamp: String = runCatching {
        context.getString(R.string.ego_build_stamp)
    }.getOrDefault("本地构建")

    private var curPhase: Phase = Phase.IDLE
    private var curProgressPct: Int = 0
    private var curDownloaded: Long = 0L
    private var curTotal: Long = 0L
    private var curSpeedBps: Long = 0L
    private var curRemoteSummary: String = "云端分支 : latest-apk / EGO-Pilot-AX12.apk"
    private var curStatusMsg: String = "就绪 · 可检查云端构建或直接拉取直链覆盖安装"

    val currentSnapshot: Snapshot
        get() = synchronized(stateLock) { buildSnapshotLocked() }

    fun resolveDirectDownloadUrl(channelOverride: Int = hub.otaChannelMode): String {
        return when (channelOverride) {
            1 -> MIRROR_PREFIX + OFFICIAL_GITHUB_APK_URL
            2 -> {
                val custom = hub.otaCustomUrl.trim()
                if (custom.startsWith("http://") || custom.startsWith("https://")) custom else OFFICIAL_GITHUB_APK_URL
            }
            else -> OFFICIAL_GITHUB_APK_URL
        }
    }

    fun onChannelOrUrlChanged() {
        synchronized(stateLock) {
            if (curPhase != Phase.DOWNLOADING && curPhase != Phase.CHECKING) {
                curStatusMsg = "已切换下载源，点击「直链下载更新」即可拉取安装包"
            }
        }
        dispatchSnapshot()
    }

    /**
     * 当用户从系统「允许安装未知应用」授权页返回地面站时，自动续接弹出系统 APK 安装界面。
     */
    fun onHostResume() {
        if (!pendingInstallAfterPermission) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            return
        }
        pendingInstallAfterPermission = false
        val apk = getVerifiedCachedApk()
        if (apk != null) {
            triggerPackageInstallerUi(apk)
        }
    }

    fun checkForUpdate(silentOnUpToDate: Boolean = false) {
        synchronized(stateLock) {
            if (curPhase == Phase.DOWNLOADING || curPhase == Phase.CHECKING) return
            curPhase = Phase.CHECKING
            curProgressPct = 0
            curStatusMsg = "正在查询 GitHub latest-apk 发布状态..."
        }
        dispatchSnapshot()

        ioExecutor.execute {
            try {
                val meta = fetchReleaseMetadata()
                val remoteUtcStr = if (meta.updatedEpochMs > 0L) formatUtcMs(meta.updatedEpochMs) else "时间未知"
                val sizeStr = if (meta.sizeBytes > 0L) formatBytes(meta.sizeBytes) else "大小未知"
                val isNewer = meta.updatedEpochMs > 0L &&
                    localBuildEpochMs > 0L &&
                    (meta.updatedEpochMs > localBuildEpochMs + CI_PUBLISH_GRACE_MS)

                synchronized(stateLock) {
                    curRemoteSummary = "云端产物 : EGO-Pilot-AX12.apk ($sizeStr · $remoteUtcStr)"
                    if (isNewer) {
                        curPhase = Phase.UPDATE_AVAILABLE
                        curStatusMsg = "检测到云端新构建版本，可点击「直链下载更新」一键升级"
                    } else {
                        curPhase = Phase.UP_TO_DATE
                        curStatusMsg = "当前已是最新构建（仍可随时点击「直链下载更新」强制覆盖安装）"
                    }
                }
                dispatchSnapshot()

                if (isNewer) {
                    postToast("发现 GitHub 新版地面站安装包 ($sizeStr)，可在「设置 -> 显示与通用」一键更新")
                } else if (!silentOnUpToDate) {
                    postToast("当前地面站已是最新构建版本 ($sizeStr)")
                }
            } catch (e: Throwable) {
                synchronized(stateLock) {
                    curPhase = Phase.IDLE
                    curStatusMsg = "元数据查询受限，可直接点击「直链下载更新」拉取最新 APK"
                }
                dispatchSnapshot()
                if (!silentOnUpToDate) {
                    postToast("GitHub API 查询超时，可直接点击「直链下载更新」下载安装")
                }
            }
        }
    }

    fun startDownloadOrCancelOrInstall() {
        val phaseSnapshot: Phase
        synchronized(stateLock) {
            phaseSnapshot = curPhase
        }
        if (phaseSnapshot == Phase.DOWNLOADING) {
            cancelActiveDownload()
            return
        }
        val readyApk = if (phaseSnapshot == Phase.READY_TO_INSTALL) getVerifiedCachedApk() else null
        if (readyApk != null) {
            requestInstallVerifiedApk(readyApk)
            return
        }
        startDirectDownload()
    }

    fun startDirectDownload() {
        if (isRealDroneArmedInFlight()) {
            postToast("实机处于解锁飞行状态，为保障飞行安全请降落上锁后再更新软件")
            return
        }
        synchronized(stateLock) {
            if (curPhase == Phase.DOWNLOADING) return
            userCancelled = false
            curPhase = Phase.DOWNLOADING
            curProgressPct = 0
            curDownloaded = 0L
            curTotal = 0L
            curSpeedBps = 0L
            curStatusMsg = "正在连接 GitHub Releases 下载通道..."
        }
        dispatchSnapshot()

        val primaryUrl = resolveDirectDownloadUrl()
        val allowOfficialFallback = (hub.otaChannelMode == 1 && primaryUrl != OFFICIAL_GITHUB_APK_URL)

        ioExecutor.execute {
            try {
                val apkFile = try {
                    downloadAndVerifyApk(primaryUrl)
                } catch (firstErr: Throwable) {
                    if (!userCancelled && allowOfficialFallback) {
                        updateProgressState(0, 0L, 0L, 0L, "镜像通道响应异常，自动切换至 GitHub 官方直链重试...")
                        downloadAndVerifyApk(OFFICIAL_GITHUB_APK_URL)
                    } else {
                        throw firstErr
                    }
                }

                synchronized(stateLock) {
                    curPhase = Phase.READY_TO_INSTALL
                    curProgressPct = 100
                    curDownloaded = apkFile.length()
                    curTotal = apkFile.length()
                    curSpeedBps = 0L
                    curStatusMsg = "安装包校验通过 (${formatBytes(apkFile.length())})，正在调起系统覆盖安装..."
                }
                dispatchSnapshot()

                mainHandler.post {
                    requestInstallVerifiedApk(apkFile)
                }
            } catch (e: Throwable) {
                synchronized(stateLock) {
                    activeCall = null
                    if (userCancelled) {
                        curPhase = Phase.IDLE
                        curProgressPct = 0
                        curSpeedBps = 0L
                        curStatusMsg = "已取消下载"
                    } else {
                        curPhase = Phase.ERROR
                        curSpeedBps = 0L
                        val msg = (e.message ?: "网络连接中断").take(64)
                        curStatusMsg = "下载失败：$msg（可尝试切换「镜像加速通道」后重试）"
                    }
                }
                dispatchSnapshot()
                if (!userCancelled) {
                    postToast("更新包下载失败，可在设置内切换「镜像加速通道」重试")
                }
            }
        }
    }

    fun cancelActiveDownload() {
        userCancelled = true
        activeCall?.cancel()
        activeCall = null
        synchronized(stateLock) {
            curPhase = Phase.IDLE
            curProgressPct = 0
            curSpeedBps = 0L
            curStatusMsg = "已取消下载任务"
        }
        dispatchSnapshot()
    }

    fun shutdown() {
        userCancelled = true
        activeCall?.cancel()
        ioExecutor.shutdownNow()
    }

    private fun requestInstallVerifiedApk(apkFile: File) {
        if (!apkFile.exists() || apkFile.length() < 200_000L) {
            startDirectDownload()
            return
        }
        if (isRealDroneArmedInFlight()) {
            synchronized(stateLock) {
                curPhase = Phase.READY_TO_INSTALL
                curStatusMsg = "安装包已就绪，请先将实机降落上锁后再点击「立即覆盖安装」"
            }
            dispatchSnapshot()
            postToast("安装包已下载就绪，请降落上锁后再执行覆盖安装")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            pendingInstallAfterPermission = true
            synchronized(stateLock) {
                curPhase = Phase.READY_TO_INSTALL
                curStatusMsg = "请开启「允许安装未知应用」权限，返回后将自动弹出安装界面"
            }
            dispatchSnapshot()
            postToast("请开启「允许安装未知应用」权限后返回自动安装")
            runCatching {
                val permIntent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(permIntent)
            }
            return
        }

        triggerPackageInstallerUi(apkFile)
    }

    private fun triggerPackageInstallerUi(apkFile: File) {
        try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
            synchronized(stateLock) {
                curPhase = Phase.READY_TO_INSTALL
                curStatusMsg = "已调起系统安装器（若首次切换固定签名提示冲突，卸载旧版重装一次后即可永久直连覆盖）"
            }
            dispatchSnapshot()
        } catch (e: Throwable) {
            synchronized(stateLock) {
                curPhase = Phase.ERROR
                curStatusMsg = "调起系统安装器失败：${e.message ?: "未知异常"}"
            }
            dispatchSnapshot()
            postToast("无法调起系统安装器：${e.message ?: "请检查系统安装权限"}")
        }
    }

    private fun downloadAndVerifyApk(url: String): File {
        val otaDir = File(context.cacheDir, "ota")
        if (!otaDir.exists()) otaDir.mkdirs()
        val partFile = File(otaDir, "$APK_FILE_NAME.part")
        val finalFile = File(otaDir, APK_FILE_NAME)
        if (partFile.exists()) partFile.delete()

        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "RadioMaster-EGO-Pilot-Android-OTA/2.2")
            .header("Accept", "application/octet-stream,*/*")
            .get()
            .build()

        val call = httpClient.newCall(req)
        activeCall = call

        call.execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IOException("HTTP ${resp.code}")
            }
            val body = resp.body ?: throw IOException("空响应数据")
            val totalLen = body.contentLength()

            body.byteStream().use { input ->
                FileOutputStream(partFile).use { output ->
                    val buf = ByteArray(16 * 1024)
                    var downloaded = 0L
                    var windowBytes = 0L
                    var lastUiTickMs = SystemClock.elapsedRealtime()
                    var currentSpeed = 0L

                    while (true) {
                        if (userCancelled) throw IOException("Cancelled")
                        val n = input.read(buf)
                        if (n <= 0) break
                        output.write(buf, 0, n)
                        downloaded += n
                        windowBytes += n

                        val nowMs = SystemClock.elapsedRealtime()
                        val elapsedMs = nowMs - lastUiTickMs
                        if (elapsedMs >= 90L) {
                            val instantBps = (windowBytes * 1000L) / elapsedMs.coerceAtLeast(1L)
                            currentSpeed = if (currentSpeed == 0L) instantBps else ((currentSpeed * 3L + instantBps) / 4L)
                            windowBytes = 0L
                            lastUiTickMs = nowMs

                            val pct = if (totalLen > 0L) {
                                ((downloaded * 100L) / totalLen).toInt().coerceIn(0, 99)
                            } else {
                                ((downloaded / (32 * 1024L)).toInt()).coerceIn(1, 95)
                            }
                            val progText = if (totalLen > 0L) {
                                "正在下载更新包 $pct% (${formatBytes(downloaded)} / ${formatBytes(totalLen)} · ${formatBytes(currentSpeed)}/s)"
                            } else {
                                "正在下载更新包 (${formatBytes(downloaded)} · ${formatBytes(currentSpeed)}/s)"
                            }
                            updateProgressState(pct, downloaded, totalLen, currentSpeed, progText)
                        }
                    }
                    output.flush()
                }
            }
        }
        activeCall = null

        verifyDownloadedApkOrThrow(partFile)
        if (finalFile.exists()) finalFile.delete()
        if (!partFile.renameTo(finalFile)) {
            partFile.copyTo(finalFile, overwrite = true)
            partFile.delete()
        }
        return finalFile
    }

    private fun verifyDownloadedApkOrThrow(file: File) {
        if (!file.exists() || file.length() < 250_000L) {
            file.delete()
            throw IOException("安装包体积异常 (${file.length()} B)")
        }
        val magic = ByteArray(4)
        FileInputStream(file).use { fis ->
            if (fis.read(magic) != 4) {
                throw IOException("无法读取文件头")
            }
        }
        val isZipHeader = magic[0] == 0x50.toByte() &&
            magic[1] == 0x4B.toByte() &&
            magic[2] == 0x03.toByte() &&
            magic[3] == 0x04.toByte()
        if (!isZipHeader) {
            file.delete()
            throw IOException("非有效 APK 归档（请检查热点是否需要网页登录）")
        }

        val archiveInfo = getArchivePackageInfoCompat(file.absolutePath)
        if (archiveInfo == null) {
            file.delete()
            throw IOException("APK 包解析校验未通过")
        }
        if (archiveInfo.packageName != context.packageName) {
            file.delete()
            throw IOException("包名不匹配 (${archiveInfo.packageName})")
        }
    }

    private fun getVerifiedCachedApk(): File? {
        val f = File(File(context.cacheDir, "ota"), APK_FILE_NAME)
        if (!f.exists() || f.length() < 250_000L) return null
        val info = getArchivePackageInfoCompat(f.absolutePath) ?: return null
        return if (info.packageName == context.packageName) f else null
    }

    private data class ReleaseMeta(val sizeBytes: Long, val updatedEpochMs: Long)

    private fun fetchReleaseMetadata(): ReleaseMeta {
        // 优先通过 GitHub REST API 获取精确的 latest-apk 资产大小与发布时间戳
        runCatching {
            val apiReq = Request.Builder()
                .url(GITHUB_RELEASE_API_URL)
                .header("Accept", "application/vnd.github+json")
                .header("User-Agent", "RadioMaster-EGO-Pilot-Android-OTA/2.2")
                .get()
                .build()
            httpClient.newCall(apiReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    val raw = resp.body?.string().orEmpty()
                    val root = JSONObject(raw)
                    val assets = root.optJSONArray("assets")
                    if (assets != null && assets.length() > 0) {
                        for (i in 0 until assets.length()) {
                            val item = assets.optJSONObject(i) ?: continue
                            val name = item.optString("name", "")
                            if (name.equals(APK_FILE_NAME, ignoreCase = true) || name.endsWith(".apk", ignoreCase = true)) {
                                val sz = item.optLong("size", 0L)
                                val updatedIso = item.optString("updated_at", item.optString("created_at", ""))
                                val epoch = parseIso8601UtcMs(updatedIso)
                                return ReleaseMeta(sz, epoch)
                            }
                        }
                    }
                }
            }
        }

        // 回退方案：使用 1 字节 Range GET 探测（兼容 GitHub Releases 302 跳转至 objects.githubusercontent.com 仅签发 GET 的预签名 URL）
        val probeReq = Request.Builder()
            .url(resolveDirectDownloadUrl())
            .header("User-Agent", "RadioMaster-EGO-Pilot-Android-OTA/2.2")
            .header("Range", "bytes=0-0")
            .get()
            .build()
        httpClient.newCall(probeReq).execute().use { resp ->
            if (!resp.isSuccessful && resp.code != 206) throw IOException("HTTP ${resp.code}")
            val contentRange = resp.header("Content-Range").orEmpty()
            val totalFromRange = contentRange.substringAfter('/', "").trim().toLongOrNull()
            val len = totalFromRange ?: resp.header("Content-Length")?.toLongOrNull() ?: 0L
            val lastMod = resp.header("Last-Modified").orEmpty()
            val modEpoch = parseHttpDateMs(lastMod)
            return ReleaseMeta(len, modEpoch)
        }
    }

    private fun isRealDroneArmedInFlight(): Boolean {
        return hub.isRosMode && hub.rosConnected && hub.latestSnapshot.armed
    }

    private fun updateProgressState(pct: Int, down: Long, total: Long, speed: Long, msg: String) {
        synchronized(stateLock) {
            curPhase = Phase.DOWNLOADING
            curProgressPct = pct
            curDownloaded = down
            curTotal = total
            curSpeedBps = speed
            curStatusMsg = msg
        }
        dispatchSnapshot()
    }

    private fun buildSnapshotLocked(): Snapshot {
        val localInfo = getSelfPackageInfoCompat()
        val vName = localInfo?.versionName ?: "2.2.0-ota"
        val vCode = getVersionCodeCompat(localInfo)
        val localSummary = "当前版本 : v$vName (#$vCode · 编译于 $localBuildStamp)"
        return Snapshot(
            phase = curPhase,
            progressPct = curProgressPct,
            downloadedBytes = curDownloaded,
            totalBytes = curTotal,
            speedBytesPerSec = curSpeedBps,
            localVersionSummary = localSummary,
            remoteSummary = curRemoteSummary,
            statusMessage = curStatusMsg,
            activeDirectUrl = resolveDirectDownloadUrl(),
            hasVerifiedApk = (curPhase == Phase.READY_TO_INSTALL)
        )
    }

    private fun dispatchSnapshot() {
        val snap = currentSnapshot
        mainHandler.post { onStateChanged(snap) }
    }

    private fun postToast(msg: String) {
        mainHandler.post { onNotifyToast(msg) }
    }

    @Suppress("DEPRECATION")
    private fun getArchivePackageInfoCompat(archivePath: String): PackageInfo? {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageArchiveInfo(
                    archivePath,
                    PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                context.packageManager.getPackageArchiveInfo(archivePath, 0)
            }
        }.getOrNull()
    }

    @Suppress("DEPRECATION")
    private fun getSelfPackageInfoCompat(): PackageInfo? {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                context.packageManager.getPackageInfo(context.packageName, 0)
            }
        }.getOrNull()
    }

    @Suppress("DEPRECATION")
    private fun getVersionCodeCompat(info: PackageInfo?): Long {
        if (info == null) return 0L
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            info.versionCode.toLong()
        }
    }

    private fun parseIso8601UtcMs(iso: String): Long {
        if (iso.isBlank()) return 0L
        return runCatching {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            sdf.parse(iso.trim())?.time ?: 0L
        }.getOrDefault(0L)
    }

    private fun parseHttpDateMs(httpDate: String): Long {
        if (httpDate.isBlank()) return 0L
        return runCatching {
            val sdf = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
            }
            sdf.parse(httpDate.trim())?.time ?: 0L
        }.getOrDefault(0L)
    }

    private fun formatUtcMs(epochMs: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        return sdf.format(Date(epochMs)) + " UTC"
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024.0
        return String.format(Locale.US, "%.2f MB", mb)
    }
}
