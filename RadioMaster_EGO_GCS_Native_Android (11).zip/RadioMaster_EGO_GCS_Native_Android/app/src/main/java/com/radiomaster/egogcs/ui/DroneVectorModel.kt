package com.radiomaster.egogcs.ui

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * 可热插拔参数化矢量无人机模型定义层 (Plug-and-Play Vector Drone Rig)：
 *
 * 坐标系约定 (标准 ROS REP-103 机体 FLU 归一化坐标系，单位 1.0 = 机臂展开半径)：
 *   +X = 机头正前方 (Forward / Nose)
 *   +Y = 机身左侧   (Port / Left)
 *   +Z = 机身正上方 (Up / Top)
 *
 * 【后续替换自定义矢量无人机模型入口】：
 *   收到你的专属矢量模型（SVG 路径、CAD 顶点或 2D/3D 轮廓折线）后，只需替换下方
 *   `activeRig` 或调用 `installCustom2DOutlineRig(...)` / `installCustom3DRig(...)`，
 *   右下角「三维实时姿态视窗」与主界面「OpenGL 三维地图机体」将自动同步切换为你的专属机体！
 */
object DroneVectorModel {

    enum class PartRole {
        FUSELAGE_SHELL,
        FUSELAGE_EDGE,
        ARM_BEAM,
        LIDAR_DOME,
        GIMBAL_NOSE,
        NAV_FRONT_RED,
        NAV_REAR_GREEN,
        LANDING_SKID
    }

    /**
     * 三维机身矢量线段：(x0, y0, z0) -> (x1, y1, z1)
     */
    data class VecSeg3D(
        val x0: Float, val y0: Float, val z0: Float,
        val x1: Float, val y1: Float, val z1: Float,
        val role: PartRole,
        val widthFactor: Float = 1.0f
    )

    /**
     * 三维机身多边形面片：pts 为交替的 [x0, y0, z0, x1, y1, z1, ...] 顶点序列 (>= 3 点)
     */
    data class VecFace3D(
        val pts: FloatArray,
        val role: PartRole,
        val shadeBoost: Float = 1.0f
    )

    /**
     * 旋翼/涵道盘安装位：中心 (cx, cy, cz)、归一化半径与转向 (+1 逆时针 / -1 顺时针)
     */
    data class RotorMount(
        val cx: Float,
        val cy: Float,
        val cz: Float,
        val radius: Float,
        val isFront: Boolean,
        val spinSign: Int
    )

    class VectorRigSpec(
        val modelName: String,
        val faces: List<VecFace3D>,
        val segments: List<VecSeg3D>,
        val rotors: List<RotorMount>
    )

    @Volatile
    var activeRig: VectorRigSpec = buildPlaceholderTacticalQuad()

    /**
     * 将机体 FLU 坐标点 (bx, by, bz) 按实时三维姿态 (roll, pitch, yaw) 刚体变换至世界局部系 (outXyz[0..2])：
     * - roll  > 0 : 右机翼下压、左机翼抬升
     * - pitch > 0 : 机头抬升、机尾下压
     * - yaw       : 世界系航向角 (ENU)
     */
    fun transformBodyToWorld(
        bx: Float, by: Float, bz: Float,
        scale: Float,
        roll: Float, pitch: Float, yaw: Float,
        outXyz: FloatArray
    ) {
        val sx = bx * scale
        val sy = by * scale
        val sz = bz * scale

        val cr = cos(roll)
        val sr = sin(roll)
        val y1 = sy * cr - sz * sr
        val z1 = sy * sr + sz * cr

        val cp = cos(pitch)
        val sp = sin(pitch)
        val x2 = sx * cp - z1 * sp
        val z2 = sx * sp + z1 * cp

        val cy = cos(yaw)
        val sYaw = sin(yaw)
        outXyz[0] = x2 * cy - y1 * sYaw
        outXyz[1] = x2 * sYaw + y1 * cy
        outXyz[2] = z2
    }

    /**
     * 便捷接口：若后续提供 2D 俯视归一化轮廓折线列表 (每条折线为 [x0, y0, x1, y1, ...])，
     * 可一键拉伸生成上下双层立体机身线框模型。
     */
    fun installCustom2DOutlineRig(
        name: String,
        polylines2D: List<FloatArray>,
        rotors: List<RotorMount>,
        halfThicknessZ: Float = 0.07f
    ) {
        val segs = ArrayList<VecSeg3D>()
        for (poly in polylines2D) {
            val n = poly.size / 2
            for (i in 0 until n - 1) {
                val x0 = poly[i * 2]; val y0 = poly[i * 2 + 1]
                val x1 = poly[(i + 1) * 2]; val y1 = poly[(i + 1) * 2 + 1]
                segs.add(VecSeg3D(x0, y0, halfThicknessZ, x1, y1, halfThicknessZ, PartRole.FUSELAGE_EDGE, 1.15f))
                segs.add(VecSeg3D(x0, y0, -halfThicknessZ, x1, y1, -halfThicknessZ, PartRole.FUSELAGE_EDGE, 0.85f))
                if (i % 2 == 0) {
                    segs.add(VecSeg3D(x0, y0, -halfThicknessZ, x0, y0, halfThicknessZ, PartRole.ARM_BEAM, 0.75f))
                }
            }
        }
        activeRig = VectorRigSpec(name, emptyList(), segs, rotors)
    }

    /**
     * 当前内置替代模型：工业级碳纤 X 型自主避障四旋翼 (含八边形航电舱、顶部激光雷达塔、双目云台与四涵道旋翼护圈)
     */
    private fun buildPlaceholderTacticalQuad(): VectorRigSpec {
        val faces = ArrayList<VecFace3D>()
        val segs = ArrayList<VecSeg3D>()

        // 1. 中心流线型八边形碳纤航电舱 (上下甲板 + 棱线)
        val topZ = 0.085f
        val botZ = -0.065f
        val hullXY = arrayOf(
            floatArrayOf(0.42f, 0.11f),
            floatArrayOf(0.18f, 0.22f),
            floatArrayOf(-0.20f, 0.20f),
            floatArrayOf(-0.36f, 0.10f),
            floatArrayOf(-0.36f, -0.10f),
            floatArrayOf(-0.20f, -0.20f),
            floatArrayOf(0.18f, -0.22f),
            floatArrayOf(0.42f, -0.11f)
        )

        val topDeckPts = FloatArray(hullXY.size * 3)
        val botDeckPts = FloatArray(hullXY.size * 3)
        for (i in hullXY.indices) {
            topDeckPts[i * 3] = hullXY[i][0]
            topDeckPts[i * 3 + 1] = hullXY[i][1]
            topDeckPts[i * 3 + 2] = topZ

            val rev = hullXY.lastIndex - i
            botDeckPts[i * 3] = hullXY[rev][0] * 0.90f
            botDeckPts[i * 3 + 1] = hullXY[rev][1] * 0.90f
            botDeckPts[i * 3 + 2] = botZ
        }
        faces.add(VecFace3D(topDeckPts, PartRole.FUSELAGE_SHELL, 1.05f))
        faces.add(VecFace3D(botDeckPts, PartRole.FUSELAGE_SHELL, 0.65f))

        for (i in hullXY.indices) {
            val nxt = (i + 1) % hullXY.size
            val x0 = hullXY[i][0]; val y0 = hullXY[i][1]
            val x1 = hullXY[nxt][0]; val y1 = hullXY[nxt][1]
            segs.add(VecSeg3D(x0, y0, topZ, x1, y1, topZ, PartRole.FUSELAGE_EDGE, 1.25f))
            segs.add(VecSeg3D(x0 * 0.90f, y0 * 0.90f, botZ, x1 * 0.90f, y1 * 0.90f, botZ, PartRole.FUSELAGE_EDGE, 0.85f))
            segs.add(VecSeg3D(x0, y0, topZ, x0 * 0.90f, y0 * 0.90f, botZ, PartRole.FUSELAGE_EDGE, 0.9f))
        }

        // 2. 机头双目深度相机视窗与航向指向针
        segs.add(VecSeg3D(0.42f, -0.09f, 0.02f, 0.48f, -0.05f, 0.02f, PartRole.GIMBAL_NOSE, 1.3f))
        segs.add(VecSeg3D(0.42f, 0.09f, 0.02f, 0.48f, 0.05f, 0.02f, PartRole.GIMBAL_NOSE, 1.3f))
        segs.add(VecSeg3D(0.48f, -0.05f, 0.02f, 0.48f, 0.05f, 0.02f, PartRole.GIMBAL_NOSE, 1.4f))
        segs.add(VecSeg3D(0.45f, 0f, 0.02f, 0.88f, 0f, 0.02f, PartRole.GIMBAL_NOSE, 1.5f))
        segs.add(VecSeg3D(0.88f, 0f, 0.02f, 0.74f, 0.08f, 0.02f, PartRole.GIMBAL_NOSE, 1.35f))
        segs.add(VecSeg3D(0.88f, 0f, 0.02f, 0.74f, -0.08f, 0.02f, PartRole.GIMBAL_NOSE, 1.35f))

        // 3. 顶部 FAST-LIO 固态激光雷达塔 (8 段环形顶盖 + 4 根保护立柱)
        val lidarBaseZ = topZ
        val lidarTopZ = 0.21f
        val lidarR = 0.13f
        for (k in 0 until 8) {
            val a0 = (k / 8.0) * PI * 2.0
            val a1 = ((k + 1) / 8.0) * PI * 2.0
            val lx0 = -0.03f + cos(a0).toFloat() * lidarR
            val ly0 = sin(a0).toFloat() * lidarR
            val lx1 = -0.03f + cos(a1).toFloat() * lidarR
            val ly1 = sin(a1).toFloat() * lidarR
            segs.add(VecSeg3D(lx0, ly0, lidarTopZ, lx1, ly1, lidarTopZ, PartRole.LIDAR_DOME, 1.15f))
            if (k % 2 == 0) {
                segs.add(VecSeg3D(lx0, ly0, lidarBaseZ, lx0, ly0, lidarTopZ, PartRole.LIDAR_DOME, 0.95f))
            }
        }

        // 4. 四根高刚度碳纤 X 型机臂 + 电机座立柱 + 前红后绿全向护圈弧
        val armSpecs = arrayOf(
            // (rootX, rootY, tipX, tipY, isFront, spinSign)
            floatArrayOf(0.17f, 0.16f, 0.64f, 0.64f, 1f, -1f),   // 右前? 注意 +Y 为左: 前左 (Front-Left)
            floatArrayOf(0.17f, -0.16f, 0.64f, -0.64f, 1f, 1f),  // 前右 (Front-Right)
            floatArrayOf(-0.17f, 0.15f, -0.64f, 0.64f, 0f, 1f),  // 后左 (Rear-Left)
            floatArrayOf(-0.17f, -0.15f, -0.64f, -0.64f, 0f, -1f)// 后右 (Rear-Right)
        )

        val rotors = ArrayList<RotorMount>(4)
        val shroudRadius = 0.36f

        for (spec in armSpecs) {
            val rx = spec[0]; val ry = spec[1]
            val tx = spec[2]; val ty = spec[3]
            val isFront = spec[4] > 0.5f
            val spin = spec[5].toInt()
            val motorZ = 0.055f

            // 双梁桁架机臂
            segs.add(VecSeg3D(rx, ry, 0.045f, tx, ty, motorZ, PartRole.ARM_BEAM, 1.45f))
            segs.add(VecSeg3D(rx * 0.92f, ry * 0.92f, -0.02f, tx, ty, motorZ - 0.04f, PartRole.ARM_BEAM, 1.0f))
            // 电机座短柱
            segs.add(VecSeg3D(tx, ty, motorZ - 0.045f, tx, ty, motorZ + 0.045f, PartRole.FUSELAGE_EDGE, 1.3f))

            // 碳纤涵道防撞外护圈 (12 段圆环：前臂红色航行灯识别，后臂绿色航行灯识别)
            val ringRole = if (isFront) PartRole.NAV_FRONT_RED else PartRole.NAV_REAR_GREEN
            for (s in 0 until 12) {
                val a0 = (s / 12.0) * PI * 2.0
                val a1 = ((s + 1) / 12.0) * PI * 2.0
                segs.add(
                    VecSeg3D(
                        tx + cos(a0).toFloat() * shroudRadius,
                        ty + sin(a0).toFloat() * shroudRadius,
                        motorZ + 0.02f,
                        tx + cos(a1).toFloat() * shroudRadius,
                        ty + sin(a1).toFloat() * shroudRadius,
                        motorZ + 0.02f,
                        ringRole,
                        1.2f
                    )
                )
            }

            rotors.add(RotorMount(tx, ty, motorZ + 0.032f, shroudRadius * 0.86f, isFront, spin))
        }

        // 5. 左右双橇式起落架
        for (side in intArrayOf(-1, 1)) {
            val sy = side * 0.24f
            val skidZ = -0.22f
            segs.add(VecSeg3D(-0.26f, sy, skidZ, 0.28f, sy, skidZ, PartRole.LANDING_SKID, 1.15f))
            segs.add(VecSeg3D(0.28f, sy, skidZ, 0.34f, sy, skidZ + 0.05f, PartRole.LANDING_SKID, 1.1f))
            segs.add(VecSeg3D(0.14f, side * 0.16f, botZ, 0.16f, sy, skidZ, PartRole.LANDING_SKID, 0.95f))
            segs.add(VecSeg3D(-0.14f, side * 0.16f, botZ, -0.16f, sy, skidZ, PartRole.LANDING_SKID, 0.95f))
        }

        return VectorRigSpec(
            modelName = "TACTICAL-X4 矢量替代机",
            faces = faces,
            segments = segs,
            rotors = rotors
        )
    }
}
