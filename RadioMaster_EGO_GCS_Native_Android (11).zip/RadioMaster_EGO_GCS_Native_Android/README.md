# EGO Pilot · 纯原生 Kotlin + OpenGL ES 单层透镜透视与无碰撞座舱地面站

本工程为 **100% 纯原生 Kotlin + [OpenGL ES](https://developer.android.com/develop/ui/views/graphics/opengl/about-opengl) 硬件加速安卓应用（无任何 WebView、无 HTML 套壳文件、全界面零 Emoji 表情符号）**，专为 [RadioMaster AX12](https://radiomasterrc.com/products/ax12-android-radio-controller)（MediaTek MT8788 八核处理器、ARM Mali-G72 GPU、4GB RAM、5.5 英寸 `1280×720` 1000nits 高亮触控屏，见 [AX12 规格手册](https://manuals.plus/radiomaster/ax12-android-radio-controller-manual)）打造，界面与设置逻辑参照 [DJI Pilot 2](https://dl.djicdn.com/downloads/matrice-30-series/20230922UM/Matrice30_Series_User_Manual_v2.0_EN.pdf)、[DJI Fly 系统设置规范](https://support.dji.com/help/content?customId=en-us03400006562&spaceId=34&re=US&lang=en&documentType=artical&paperDocType=paper) 与 [QGroundControl Settings View](https://docs.qgroundcontrol.com/Stable_V5.1/en/qgc-user-guide/settings_view/settings_view.html)。

## 1. 成熟商业引擎级「单层外皮深度预通透镜 + 双色对比虚线 X-Ray」透视管线 (`GlPointCloudMapView.kt`)

- **外表面深度预通单层光学透镜（Depth-Only Prepass + `GL_EQUAL` Single-Skin Cutaway，参照 [Depth Prepass 半透明外表面消隐方案](https://medium.com/design-bootcamp/transparency-the-rasterization-nightmare-71ceb98a8e3c) 与 [Visibility Equalizer Cutaway](https://pmc.ncbi.nlm.nih.gov/articles/PMC5364803/)）**：先绘制 100% 不透明远景体素与前景实体飞机/航线，再对视线走廊内的遮挡膨胀体素执行 `glColorMask(false)` 硬件深度预通 + `GL_EQUAL` 单层外皮着色，100% 硬件剔除相邻体素内部所有共享内壁与多层混浊叠影；片元着色器逐像素计算胶囊视线距离与全息边缘光晕，消除整块体素跳变，配合点云 4×4 Bayer 有序抖动消隐 ([Ordered Dithering](https://blog.maximeheckel.com/posts/the-art-of-dithering-and-retro-shading-web/)) 实现丝滑通透的立体视野。
- **硬件 `GL_GREATER` 双色抗锯齿流动虚线与高程接触阴影**：严格遵循 [OpenGL Depth Testing](https://learnopengl.com/Advanced-OpenGL/Depth-testing) 逆深度测试，被实体墙或透视薄壳遮挡的规划轨迹自动切换为「连续微光底轨 + 高对比向前流动胶囊虚线」，被遮挡机体呈现稳态全息轮廓，并结合 51° 自然透视视场、柱顶微倒角与底部接触阴影强化三维空间纵深感。

## 2. 全界面响应式五区无碰撞对齐、三维实时姿态与主流四大飞控设置

- **五区零重叠对齐与四大飞控设置 (`MainActivity.kt` + `GcsSettingsModal.kt`)**：重构 36dp 顶栏、顶部居中统一流式堆栈、对称等高 94dp 双仪表底栏与空间互斥避让协调器，并将设置收敛为「飞行安全 · 感知与飞控 · 通信链路 · 显示与通用」四大实战分类。
- **右下角三维实时姿态视窗、可替换矢量机体与原生 ROS1 话题监控 (`UavAttitudeHudView.kt` + `DroneVectorModel.kt` + `RosTopicInspector.kt`)**：实时解算 `/Odometry` 四元数姿态，支持三视角平滑切换与后续矢量模型替换；通过 [ROS Master XML-RPC API](https://wiki.ros.org/ROS/Master_API) 与 [TCPROS Connection Header](https://wiki.ros.org/ROS/Connection%20Header) 支持话题浏览、单次截取、持续读取与一键绑定通道；零串口冲突（不触碰 `/dev/ttyS0`，见 [ax12-research](https://github.com/rmeadomavic/ax12-research)），兼容 [ELRS Backpack](https://github.com/rmeadomavic/ax12-research/blob/main/docs/hardware/elrs-backpack.md) [MAVLink](https://mavlink.io/en/messages/common.html) `UDP :14550`、原生 [TCPROS](https://wiki.ros.org/ROS/TCPROS)、[EGO-Planner](https://github.com/ZJU-FAST-Lab/ego-planner/issues/106) 与 [FAST-LIO2](https://github.com/hku-mars/fast_lio)，上传仓库即可由 [GitHub Actions](https://docs.github.com/actions) 自动构建发布 APK。

## 3. 应用内 GitHub Releases 直链 OTA 在线更新系统 (`OtaUpdateManager.kt`)

- **一键直链覆盖更新与多通道回退**：默认绑定仓库最新构建直链 ([EGO-Pilot-AX12.apk](https://github.com/Friendzhb/RadioMaster-EGO-GCS/releases/download/latest-apk/EGO-Pilot-AX12.apk))，结合 [GitHub Releases REST API](https://docs.github.com/en/rest/releases/releases) 与 HTTP `HEAD` 时间戳探测实时检测云端新构建，支持「GitHub 官方直链 / 镜像加速通道 / 自定义直链」三通道流式进度下载与失败自动回退。
- **固定签名证书、包体完整性校验与飞行安全互锁**：工程内置固定签名证书 (`app/keystore/ego_pilot_ota.jks`) 与编译时间自动递增 `versionCode`，避免云端构建更换随机调试证书导致覆盖冲突；下载完成后自动校验 APK 魔数与包名，通过 [Android FileProvider](https://developer.android.com/training/secure-file-sharing/setup-sharing) 与 [REQUEST_INSTALL_PACKAGES](https://support.google.com/googleplay/android-developer/answer/12085295?hl=en) 安全拉起系统覆盖安装，并在实机解锁飞行状态下自动锁定安装以确保安全。
